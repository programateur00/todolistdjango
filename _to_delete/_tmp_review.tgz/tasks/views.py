import json

from django.contrib import messages
from django.db.models import Count, Q
from django.http import FileResponse, Http404, HttpResponseNotAllowed, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_POST

import datetime as _dt
import uuid as _uuid

from django.utils import timezone

from . import ai, api
from . import time_stats
from .models import (
    CourseQuiz, Exercise, Occurrence, Plan, PlanItem, Routine, RoutineItem, SavedVideo, Task,
    TimerSession, UserSettings, WarmupStatus, WorkoutSession, last_set_reps, last_set_seconds,
)
from . import calories
from .utils import get_current_user, read_mobile_release, resolve_plan_target
from urllib.parse import quote


# Calentamiento/enfriamiento RECOMENDADO (no obligatorio) en toda sesión
# de Deporte (ver _require_warmup, task_warmup y task_cooldown): se
# pregunta primero si ya has calentado/quieres estirar, y si se pide, se
# ofrece el circuito (Routine) que tengas montado para esa subcategoría
# -- ver _warmup_routine_for. Antes esto era un vídeo fijo de YouTube
# igual para todo el mundo; se quitó a petición de Alex a favor de sus
# propios ejercicios catalogados (calentamiento con cámara + estiramientos
# cronometrados), específicos por subcategoría (tren superior/inferior).


def _finish_redirect_url(task, closed_plan):
    """
    URL a la que ir justo después de guardar una sesión (task.mark_done()
    ya se llamó, closed_plan es lo que devolvió). Si esa sesión acababa
    de terminar el plan que la generó (ver Plan.close_if_finished), va a
    la pantalla de cierre/celebración (plan_close) en vez de a la lista
    de tareas de siempre -- para Deporte, Estudio y General por igual,
    sea cual sea la vista que guardó la sesión.
    """
    if closed_plan:
        return reverse("tasks:plan_close", args=[closed_plan.pk])
    return reverse("tasks:task_list")


def _task_warmup_subcategory(task):
    """
    Subcategoría a efectos de elegir circuito de calentamiento (ver
    _warmup_routine_for). Una tarea freestyle ya trae `subcategory`
    puesto (tren superior/inferior/running/warmup). Pero una tarea
    generada por un Plan de Deporte que NO es running se guarda con
    `subcategory=""` -- ver Plan.sync_task/_running_target_fields: solo
    running copia subcategoría a la tarea diaria, el resto la deja en
    blanco desde siempre (de antes de que este campo existiera). Así
    que aquí se deriva del `body_area` del ejercicio headline del plan
    -- el mismo ejercicio que ya decide sport_mode/objetivo del día.
    """
    if task.subcategory:
        return task.subcategory
    if task.plan:
        head = task.plan.headline
        if head and head.exercise:
            return head.exercise.body_area
    return ""


def _warmup_routine_for(task):
    """
    Circuito de calentamiento/estiramiento para la subcategoría de esta
    tarea (ver Routine.subcategory) -- sustituye al vídeo fijo genérico
    que había antes. None si el usuario todavía no tiene ninguno montado
    para esa subcategoría (task_warmup/task_cooldown lo tratan como "sin
    alternativa", igual que antes cuando el vídeo no cargaba).
    """
    subcategory = _task_warmup_subcategory(task)
    if not subcategory:
        return None
    return Routine.objects.filter(
        user=get_current_user(), subcategory=subcategory, is_warmup_bookend=True,
        deleted_at__isnull=True,
    ).first()


def _routine_items_data(items):
    """Serializa RoutineItem -> items_data para circuit.js. Compartido por
    routine_play, task_warmup_routine y task_cooldown_routine."""
    data = []
    for it in items:
        t = it.resolved_target()
        data.append({
            "slug": it.exercise.slug,
            "name": it.exercise.name,
            "mode": it.exercise.mode,
            "counter_key": it.exercise.counter_key,
            "voice_step": it.exercise.voice_step,
            "work": t["seconds"],
            "rest": it.effective_rest_seconds,
            "target_sets": t["sets"],
            "target_reps": t["reps"],
            "target_source": t["source"],
            "plan_name": t["plan_name"],
        })
    return data


def _require_warmup(request, task):
    """
    Punto de entrada común a task_workout, routine_play y plan_session
    (las tres formas de empezar a entrenar): si la tarea es de Deporte y
    no se ha calentado hace poco (WarmupStatus.FRESH_WINDOW), manda a
    preguntar si ya has calentado (task_warmup, con ?next= para volver
    exactamente a donde se iba) — RECOMENDADO, no un bloqueo: desde ahí
    se puede decir que sí y seguir al momento, o ver el vídeo (opcional,
    saltable). Devuelve None si se puede seguir tal cual.
    """
    if task.category != Task.CATEGORY_SPORT:
        return None
    if task.subcategory in (Task.SUBCATEGORY_RUNNING, Task.SUBCATEGORY_WARMUP):
        # Running no se cuenta con la cámara ni con un circuito: la
        # sesión ya queda validada por datos reales (distancia/tiempo,
        # Health Connect...), así que no hace falta calentar antes.
        # Estiramientos y calentamientos tampoco -- ya ES el calentamiento,
        # pedir que se caliente antes de calentar no tiene sentido.
        return None
    if WarmupStatus.is_fresh(get_current_user()):
        return None
    warmup_url = reverse("tasks:task_warmup", args=[task.pk])
    return redirect(f"{warmup_url}?next={quote(request.get_full_path())}")


def _read_category(request, default=Task.CATEGORY_GENERAL):
    """Lee la categoría del POST/GET, validando contra choices."""
    raw = request.POST.get("category", default) or default
    valid = {key for key, _ in Task.CATEGORY_CHOICES}
    return raw if raw in valid else default


def _read_subcategory(request, default=""):
    """Lee la subcategoría (deporte o enfoque, según la categoría)."""
    raw = request.POST.get("subcategory", default) or default
    valid = {key for key, _ in Task.SUBCATEGORY_CHOICES}
    return raw if raw in valid else default


def _read_language_name(request):
    """Idioma de una tarea suelta con subcategory=Idiomas (Task.language_name)."""
    return request.POST.get("language_name", "").strip()[:40]


def _read_watch_keyword(request):
    """Palabra clave de una tarea con subcategory=Udemy (Task.watch_keyword)."""
    return request.POST.get("watch_keyword", "").strip()[:120]


def _read_level(request):
    """Nivel MCER de una tarea suelta con subcategory=Idiomas (Task.level)."""
    raw = request.POST.get("level", "")
    valid = {k for k, _ in Task.CEFR_LEVEL_CHOICES}
    return raw if raw in valid else ""


def _read_target_minutes(request):
    """
    Objetivo en minutos — un solo campo en el modelo (Task.target_minutes)
    sirve para dos cosas distintas según cuál aplique: minutos del
    temporizador de Enfoque, o minutos vistos de un vídeo/playlist. En
    el formulario son dos inputs separados (para no chocar cuando los
    dos son visibles a la vez, con category=work + vídeo puesto), pero
    aquí se funden en el campo que de verdad toca.
    """
    has_video = bool(request.POST.get("youtube_video_id", "").strip()) \
        or bool(request.POST.get("youtube_playlist_id", "").strip())
    field = "video_target_minutes" if has_video else "target_minutes"
    raw = request.POST.get(field, "").strip()
    if not raw:
        return None
    try:
        return max(1, int(raw))
    except ValueError:
        return None


def _read_youtube_video_id(request):
    """
    Enlace de YouTube pegado tal cual — la normalización a un ID limpio
    la hace Task.save(), no hace falta duplicarla aquí.
    """
    return request.POST.get("youtube_video_id", "").strip()[:255]


def _read_youtube_playlist_id(request):
    return request.POST.get("youtube_playlist_id", "").strip()[:255]


def _read_target_video_count(request):
    """Cuántos vídeos de la playlist hay que ver. Vacío = sin objetivo por cuenta."""
    raw = request.POST.get("target_video_count", "").strip()
    if not raw:
        return None
    try:
        return max(1, int(raw))
    except ValueError:
        return None


def _read_sport_mode(request):
    """Cómo se completa una tarea de Deporte: cámara, circuito o vídeo."""
    raw = request.POST.get("sport_mode", "").strip()
    valid = {k for k, _ in Task.SPORT_MODE_CHOICES}
    return raw if raw in valid else ""


def _read_target_steps(request):
    raw = request.POST.get("target_steps", "").strip()
    if not raw:
        return None
    try:
        return max(1, int(raw))
    except ValueError:
        return None


def _read_target_distance_km(request):
    raw = request.POST.get("target_distance_km", "").strip().replace(",", ".")
    if not raw:
        return None
    try:
        return max(0.1, float(raw))
    except ValueError:
        return None


def _read_max_pace(request):
    """
    Ritmo máximo. El formulario ya no pide "6:30" a mano — eso no dice
    nada a quien no corre — sino que ofrece un desplegable con opciones
    en lenguaje llano (paseo tranquilo, correr rápido…) que ya llevan el
    número por dentro. Aquí solo se valida que sea uno de los que existen.
    """
    raw = request.POST.get("max_pace_seconds_per_km", "").strip()
    if not raw:
        return None
    try:
        val = int(raw)
    except ValueError:
        return None
    return val if val in Task.PACE_PRESET_SECONDS else None


def _read_has_local_video(request):
    """El formulario eligió 'archivo de mi dispositivo' en vez de YouTube."""
    return bool(request.POST.get("has_local_video"))


def _read_client_uuid(request):
    """
    UUID generado en el propio navegador (crypto.randomUUID()) ANTES de
    guardar la tarea — solo así el selector de archivo local puede
    guardar el archivo con la clave correcta desde el primer momento,
    sin esperar a que el servidor invente un id que el JS no conocería
    todavía. Si no llega uno válido (formularios viejos, o simplemente
    porque no se eligió vídeo local), Task.save() genera el suyo como
    siempre — esto es un añadido, no un requisito.
    """
    raw = request.POST.get("client_uuid", "").strip()
    if not raw:
        return None
    try:
        return _uuid.UUID(raw)
    except ValueError:
        return None


def task_list(request):
    # Se comprueba en cada visita si alguna tarea con hora límite ya
    # venció sin completarse, y se marca sola como "no hecha".
    # (No usamos cron: en el hosting gratuito no está disponible, y al
    # ser una app de un solo usuario, comprobarlo al abrir la página
    # es suficiente.)
    Task.expire_overdue()
    Plan.auto_close_expired(user=get_current_user())
    Plan.sync_all_tasks(user=get_current_user())

    # Filtro opcional por categoría (?cat=sport, ?cat=study, …)
    cat = request.GET.get("cat") or ""
    valid_cats = {key for key, _ in Task.CATEGORY_CHOICES}
    active_category = cat if cat in valid_cats else ""

    # Selector Hoy / Esta semana / Este mes / Todas (?range=week, …)
    rng = request.GET.get("range") or ""
    valid_ranges = {key for key, _ in Task.RANGE_CHOICES}
    active_range = rng if rng in valid_ranges else Task.RANGE_TODAY

    base_qs = Task.objects.filter(user=get_current_user())
    if active_category:
        base_qs = base_qs.filter(category=active_category)

    # for_range evita que la tarea de mañana (generada al resolver la de
    # hoy) aparezca ya en la lista y se pueda marcar dos veces; con
    # rango "hoy" se comporta exactamente igual que antes.
    pending_tasks = Task.for_range(base_qs.filter(is_done=False), active_range)

    # La minibarra "hoy" de un plan de lectura (ver task_list.html) lee
    # reading_today_status directamente -- normalmente se refresca sola
    # al abrir el visor (ver task_reading -> ensure_reading_day_goal),
    # pero si se leyó "adelantado" (sesión extra, ver
    # reading_session_ready) desde Planes sin pasar por aquí, esta lista
    # seguiría enseñando el objetivo/página de partida viejos hasta la
    # próxima vez que se abriera el visor de ESA tarea en concreto. Se
    # refresca aquí también, igual que expire_overdue/sync_all_tasks más
    # arriba -- barato: no hace nada (ni un save) si ya está al día.
    for t in pending_tasks:
        if t.reading_mode == Task.READING_MODE_PLAN:
            t.ensure_reading_day_goal()

    # "Por generar": qué más se generaría de las tareas repetidas
    # durante el rango elegido (sin crear nada real todavía). No aplica
    # a "hoy" porque ahí no hay nada más que asomar más allá de hoy.
    projected_series = (
        Task.project_pending_series(pending_tasks, active_range)
        if active_range != Task.RANGE_TODAY else []
    )

    # "Todas" en Hechas puede acumular mucho con años de tareas
    # repetidas — se limita a las más recientes para que la página no
    # se dispare de peso, con un aviso en la plantilla si se recorta.
    COMPLETED_CAP = 200
    completed_qs = Task.completed_in_range(base_qs, active_range)
    completed_total = completed_qs.count()
    completed_tasks = completed_qs[:COMPLETED_CAP] if completed_total > COMPLETED_CAP else completed_qs

    # Conteos por categoría para los chips de filtro: las mismas tareas
    # que se verían si se aplicara ese filtro con el rango actual, no
    # el total histórico de tareas que ha tenido esa categoría alguna
    # vez (eso hacía que el chip dijera "15" cuando al pulsarlo solo
    # aparecía 1 tarea).
    all_pending_in_range = Task.for_range(
        Task.objects.filter(user=get_current_user(), is_done=False), active_range
    )
    counts = dict(
        all_pending_in_range
        .values_list("category").annotate(n=Count("id")).values_list("category", "n")
    )
    category_counts = [
        {"key": key, "label": label, "count": counts.get(key, 0)}
        for key, label in Task.CATEGORY_CHOICES
    ]

    return render(request, "tasks/task_list.html", {
        "pending_tasks": pending_tasks,
        "projected_series": projected_series,
        "completed_tasks": completed_tasks,
        "completed_total": completed_total,
        "completed_capped": completed_total > COMPLETED_CAP,
        "category_choices": Task.CATEGORY_CHOICES,
        "active_category": active_category,
        "category_counts": category_counts,
        "total_task_count": sum(counts.values()),
        "range_choices": Task.RANGE_CHOICES,
        "active_range": active_range,
        "weekly": Occurrence.weekly_completion(get_current_user()),
        "daily": Occurrence.daily_completion(get_current_user()),
    })


def task_create(request):
    if request.method == "POST":
        title = request.POST.get("title", "").strip()
        # Sin hora, 23:59: así siempre hay a qué hora sonar el aviso y
        # cuándo darla por no hecha al final del día (ver
        # Task.expire_overdue y notifications.js, en la app móvil).
        due_time = request.POST.get("due_time") or "23:59"
        if not title:
            messages.error(request, "Ponle un título a la tarea.")
        else:
            client_uuid = _read_client_uuid(request)
            repeat = request.POST.get("repeat", Task.REPEAT_NONE)
            due_date = request.POST.get("due_date") or None
            if due_date is None and repeat != Task.REPEAT_NONE:
                # Una tarea repetida necesita una fecha desde la que
                # calcular la siguiente (ver Task.next_due_date /
                # _spawn_next) — sin fecha se queda pillada la primera
                # vez que se resuelve, aunque diga "se repite". Si no se
                # pone ninguna, se usa hoy como punto de partida en vez
                # de dejarla coja.
                due_date = timezone.localtime(timezone.now()).date()
            task = Task(
                title=title,
                notes=request.POST.get("notes", "").strip(),
                category=_read_category(request),
                subcategory=_read_subcategory(request),
                language_name=_read_language_name(request),
                level=_read_level(request),
                watch_keyword=_read_watch_keyword(request),
                target_minutes=_read_target_minutes(request),
                youtube_video_id=_read_youtube_video_id(request),
                youtube_playlist_id=_read_youtube_playlist_id(request),
                target_video_count=_read_target_video_count(request),
                has_local_video=_read_has_local_video(request),
                sport_mode=_read_sport_mode(request),
                target_steps=_read_target_steps(request),
                target_distance_km=_read_target_distance_km(request),
                max_pace_seconds_per_km=_read_max_pace(request),
                due_date=due_date,
                due_time=due_time,
                repeat=repeat,
                interval=request.POST.get("interval") or 1,
                custom_days=",".join(request.POST.getlist("custom_days")),
                is_important=bool(request.POST.get("is_important")),
                wants_timer=bool(request.POST.get("wants_timer")),
                avoid_question=request.POST.get("avoid_question", "").strip()[:120],
                avoid_success_label=request.POST.get("avoid_success_label", "").strip()[:32],
                avoid_fail_label=request.POST.get("avoid_fail_label", "").strip()[:32],
                user=get_current_user(),
            )
            if task.subcategory == Task.SUBCATEGORY_UDEMY:
                # Freestyle Udemy NUNCA lleva palabra clave (ver
                # _study_link_error) -- si llego alguna en el POST se
                # ignora, es exclusiva de un Plan.
                task.watch_keyword = ""
            link_error = task.study_link_error()
            if link_error:
                messages.error(request, link_error)
            else:
                if client_uuid:
                    task.uuid = client_uuid
                task.save()
                if task.youtube_playlist_id:
                    task.sync_playlist_videos()
                messages.success(request, "Tarea creada.")
                return redirect(reverse("tasks:task_list"))

    initial_title = title if request.method == "POST" else request.GET.get("title", "")
    return render(request, "tasks/task_form.html", {
        "repeat_choices": Task.REPEAT_CHOICES,
        "weekdays": Task.WEEKDAYS,
        "category_choices": Task.CATEGORY_CHOICES,
        "sport_subcategory_choices": Task.SPORT_SUBCATEGORY_CHOICES,
        "focus_subcategory_choices": Task.FOCUS_SUBCATEGORY_CHOICES,
        "study_subcategory_choices": Task.STUDY_SUBCATEGORY_CHOICES,
        "study_subcategory_values": [v for v, _ in Task.STUDY_SUBCATEGORY_CHOICES],
        "cefr_level_choices": Task.CEFR_LEVEL_CHOICES,
        "pace_presets": Task.PACE_PRESETS,
        "initial_title": initial_title,
    })


def task_edit(request, pk):
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    if task.reading_mode == Task.READING_MODE_PLAN:
        # Un Plan de lectura se edita en su propio formulario (título,
        # última página, plazo, PDF) -- este mega-formulario no sabe nada
        # de esos campos, y dejar que alguien lo abra aquí por una URL
        # vieja lo dejaría atascado sin forma de tocar nada del plan.
        return redirect(reverse("tasks:reading_plan_edit", args=[task.pk]))
    if request.method == "POST":
        old_playlist_id = task.youtube_playlist_id
        task.title = request.POST.get("title", task.title).strip()
        task.notes = request.POST.get("notes", "").strip()
        task.category = _read_category(request, default=task.category)
        task.subcategory = _read_subcategory(request, default=task.subcategory)
        task.language_name = _read_language_name(request)
        task.level = _read_level(request)
        task.watch_keyword = _read_watch_keyword(request)
        task.target_minutes = _read_target_minutes(request)
        task.youtube_video_id = _read_youtube_video_id(request)
        task.youtube_playlist_id = _read_youtube_playlist_id(request)
        task.target_video_count = _read_target_video_count(request)
        task.has_local_video = _read_has_local_video(request)
        task.sport_mode = _read_sport_mode(request)
        task.target_steps = _read_target_steps(request)
        task.target_distance_km = _read_target_distance_km(request)
        task.max_pace_seconds_per_km = _read_max_pace(request)
        task.repeat = request.POST.get("repeat", Task.REPEAT_NONE)
        due_date = request.POST.get("due_date") or None
        if due_date is None and task.repeat != Task.REPEAT_NONE:
            # Mismo motivo que en task_create: una tarea repetida sin
            # fecha se queda pillada en cuanto se resuelve una vez, así
            # que si no se pone ninguna se usa hoy como punto de partida.
            due_date = timezone.localtime(timezone.now()).date()
        task.due_date = due_date
        task.due_time = request.POST.get("due_time") or "23:59"
        task.interval = request.POST.get("interval") or 1
        task.custom_days = ",".join(request.POST.getlist("custom_days"))
        task.is_important = bool(request.POST.get("is_important"))
        task.wants_timer = bool(request.POST.get("wants_timer"))
        task.avoid_question = request.POST.get("avoid_question", "").strip()[:120]
        task.avoid_success_label = request.POST.get("avoid_success_label", "").strip()[:32]
        task.avoid_fail_label = request.POST.get("avoid_fail_label", "").strip()[:32]
        if task.subcategory == Task.SUBCATEGORY_UDEMY:
            task.watch_keyword = ""
        link_error = task.study_link_error()
        if link_error:
            messages.error(request, link_error)
        else:
            task.save()
            if task.youtube_playlist_id and task.youtube_playlist_id != old_playlist_id:
                task.sync_playlist_videos()
            messages.success(request, "Tarea actualizada.")
            return redirect(reverse("tasks:task_list"))
    return render(request, "tasks/task_form.html", {
        "task": task,
        # task_form.html usa initial_title como argumento del filtro
        # `default` en el campo de título (ver task_create) -- un
        # argumento de filtro que falta lanza VariableDoesNotExist sin
        # capturar (a diferencia de una variable normal, que se resuelve
        # a "") y tira la página entera con un 500. Aquí task.title
        # siempre existe, así que este valor nunca se usa de verdad --
        # solo evita que falte la clave en el contexto.
        "initial_title": task.title,
        "repeat_choices": Task.REPEAT_CHOICES,
        "weekdays": Task.WEEKDAYS,
        "category_choices": Task.CATEGORY_CHOICES,
        "sport_subcategory_choices": Task.SPORT_SUBCATEGORY_CHOICES,
        "focus_subcategory_choices": Task.FOCUS_SUBCATEGORY_CHOICES,
        "study_subcategory_choices": Task.STUDY_SUBCATEGORY_CHOICES,
        "study_subcategory_values": [v for v, _ in Task.STUDY_SUBCATEGORY_CHOICES],
        "cefr_level_choices": Task.CEFR_LEVEL_CHOICES,
        "pace_presets": Task.PACE_PRESETS,
    })


@require_POST
def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    if (
        task.reading_mode == Task.READING_MODE_PLAN and task.due_date
        and task.repeat != Task.REPEAT_NONE and not task.reading_completed_at
    ):
        # Borrar el día de un plan de lectura en marcha NO debe acabar con
        # el plan (era lo que pasaba: al borrar la instancia pendiente
        # nadie generaba la siguiente y el libro dejaba de salir). Se
        # salta ese día y se genera ya el siguiente; para borrar el plan
        # entero está reading_plan_delete.
        task._spawn_next()
        task.delete()
        messages.success(request, "Sesión saltada. El plan de lectura sigue en su próximo día.")
        return redirect(reverse("tasks:task_list"))
    task.delete()
    messages.success(request, "Tarea eliminada. Su historial y estadísticas se conservan.")
    return redirect(reverse("tasks:task_list"))


@require_POST
def reading_plan_delete(request, pk):
    """Borra el plan de lectura ENTERO (todos sus días). Único sitio que lo hace."""
    task = get_object_or_404(
        Task, pk=pk, user=get_current_user(), reading_mode=Task.READING_MODE_PLAN,
    )
    Task.objects.filter(series_id=task.series_id, user=get_current_user()).delete()
    messages.success(request, "Plan de lectura eliminado. Su historial y estadísticas se conservan.")
    return redirect(reverse("tasks:task_list"))


@require_POST
def task_mark_done(request, pk):
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    closed_plan = task.mark_done()
    return redirect(_finish_redirect_url(task, closed_plan))


@require_POST
def task_mark_not_done(request, pk):
    get_object_or_404(Task, pk=pk, user=get_current_user()).mark_not_done()
    return redirect(reverse("tasks:task_list"))


@require_POST
def task_mark_failed(request, pk):
    """Antitareas: "he caído hoy" — ver Task.mark_failed()."""
    get_object_or_404(Task, pk=pk, user=get_current_user()).mark_failed()
    return redirect(reverse("tasks:task_list"))


@require_POST
def task_reopen(request, pk):
    """Deshacer: devuelve la tarea a pendiente y revierte lo que provocó
    marcarla (la ocurrencia del día y la instancia futura), para que las
    estadísticas vuelvan a estar como antes. Ver Task.reopen()."""
    get_object_or_404(Task, pk=pk, user=get_current_user()).reopen()
    messages.success(request, "Tarea devuelta a pendientes.")
    return redirect(reverse("tasks:task_list"))


def task_workout(request, pk):
    """
    Página de entreno para una tarea. En dos pasos:
    1. Sin ?exercise= ni ?video= en la URL: muestra el catálogo de
       ejercicios activos para elegir cuál tocar hoy — filtrado por la
       subcategoría de la tarea (tren superior / tren inferior /
       running) si la tiene. Para tren superior/inferior, además se
       ofrece "seguir un vídeo" como alternativa: se elige AQUÍ, cada
       vez, no queda fijado en la tarea — la misma tarea que se repite
       puede ir un día con vídeo y otro con circuito.
    2. Con ?exercise=<slug>: como antes (cámara / manual / sin contador).
       Con ?video=<id>: va directo al vídeo, sin pasar por lo demás.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    task.mark_started()
    gate = _require_warmup(request, task)
    if gate:
        return gate
    exercise_slug = request.GET.get("exercise")
    video_id = request.GET.get("video")

    # Un vídeo elegido en el selector manda por encima de todo: ni plan,
    # ni ejercicio, ni circuito — es una tarea que se resuelve viéndolo.
    if video_id:
        return render(request, "tasks/task_video.html", {
            "task": task, "video_id": video_id,
            "playlist_id": "", "target_minutes": None, "target_video_count": None, "has_local_video": False,
        })

    # Si la tarea la generó un plan, no hay nada que elegir: el plan ya
    # decidió qué ejercicios y con qué objetivo. Se va directo a la
    # sesión, que es lo que hace que esto sea simple de usar.
    plan = task.plan
    if plan and not exercise_slug and plan.items.filter(exercise__isnull=False).exists():
        return redirect(reverse("tasks:plan_session", args=[task.pk, plan.pk]))

    # "timed" normalmente solo vive dentro de un circuito (cuenta atrás a
    # secas) — pero plancha y plancha lateral, al llevar cámara propia
    # comprobando la postura, también se pueden entrenar sueltas para
    # una sola tarea, igual que dominadas o sentadillas. El resto de
    # "timed" (bicicleta…) se queda fuera del selector individual.
    exercises_qs = Exercise.objects.filter(is_active=True).exclude(
        Q(mode=Exercise.MODE_TIMED) & ~Q(counter_key__in=POSTURE_COUNTERS)
    )
    routines_qs = Routine.objects.filter(user=get_current_user())
    if task.subcategory:
        exercises_qs = exercises_qs.filter(body_area=task.subcategory)
        routines_qs = routines_qs.filter(subcategory=task.subcategory)

    videos_qs = SavedVideo.objects.none()
    if task.subcategory in (Task.SUBCATEGORY_LOWER_BODY, Task.SUBCATEGORY_UPPER_BODY):
        videos_qs = SavedVideo.objects.filter(
            user=get_current_user(), scope=task.subcategory, deleted_at__isnull=True,
        )

    if not exercise_slug:
        return render(request, "tasks/task_workout_select.html", {
            "task": task, "exercises": exercises_qs, "routines": routines_qs, "videos": videos_qs,
        })

    exercise = get_object_or_404(Exercise, slug=exercise_slug, is_active=True)

    if exercise.mode == Exercise.MODE_DISTANCE:
        return render(request, "tasks/task_workout_manual.html", {
            "task": task, "exercise": exercise,
        })

    # Contadores implementados en workout.js: dominadas (y variantes),
    # fondos, flexiones, sentadillas, abdominales, crunch, elevación de
    # piernas, doble crunch y tijeretas cuentan repeticiones (mode="pose");
    # plancha y plancha lateral se aguantan y llevan la cámara para
    # comprobar la postura (mode="timed", ver POSTURE_COUNTERS).
    # Cualquier otra combinación (o un ejercicio sin cámara) cae aquí
    # como "no soportado".
    is_pose_supported = exercise.mode == Exercise.MODE_POSE and exercise.counter_key in COUNTERS
    is_posture_supported = exercise.mode == Exercise.MODE_TIMED and exercise.counter_key in POSTURE_COUNTERS
    if not (is_pose_supported or is_posture_supported):
        return render(request, "tasks/task_workout_select.html", {
            "task": task, "exercises": exercises_qs, "routines": routines_qs, "videos": videos_qs,
            "unsupported": exercise,
        })

    # DECIMOTERCER BUG REAL (2026-09-04): resolve_plan_target busca por
    # SLUG de ejercicio, no por tarea — así que una tarea freestyle de
    # fondos enseñaba el objetivo (y el nombre) de un plan activo que
    # también entrena fondos, como si la tarea perteneciera a ese plan.
    # El usuario pidió que freestyle y plan queden del todo separados:
    # solo se resuelve el objetivo del plan si ESTA tarea la generó un
    # plan de verdad (task.plan) — si no, freestyle no ve nada de ningún
    # plan, aunque haya uno activo con el mismo ejercicio.
    target = (
        resolve_plan_target(exercise.slug) if task.plan
        else {"plan": None, "target_sets": None, "target_reps": None, "target_seconds": None}
    )
    # Reps de cada serie la última vez que hiciste este ejercicio (también
    # en entreno suelto, sin plan) -- "Serie 2: la última vez hiciste 10".
    last_sets = last_set_reps(get_current_user(), exercise.slug, plan=target["plan"])
    # Ejercicios cronometrados (plancha...): segundos aguantados por serie.
    last_seconds = last_set_seconds(get_current_user(), exercise.slug, plan=target["plan"])
    return render(request, "tasks/task_workout.html", {
        "task": task, "exercise": exercise,
        "target": target,
        "last_sets_json": json.dumps(last_sets) if last_sets else "",
        "last_seconds_json": json.dumps(last_seconds) if last_seconds else "",
    })


@require_POST
def task_workout_save(request, pk):
    """
    Recibe (por fetch/AJAX, en JSON) las estadísticas ya calculadas en
    el navegador al terminar la sesión, las guarda, y marca la tarea
    como hecha. No se recibe ni se guarda ningún vídeo — solo números.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    exercise_slug = request.GET.get("exercise", "pullup")
    exercise = Exercise.objects.filter(slug=exercise_slug).first()
    exercise_value = exercise.slug if exercise else WorkoutSession.EXERCISE_PULLUP
    exercise_label = exercise.name.lower() if exercise else "dominadas"

    try:
        data = json.loads(request.body)
    except (json.JSONDecodeError, TypeError):
        return JsonResponse({"ok": False, "error": "JSON inválido"}, status=400)

    total_reps = int(data.get("total_reps", 0))
    rep_durations = data.get("rep_durations", [])
    if not isinstance(rep_durations, list):
        rep_durations = []
    rep_durations = [float(d) for d in rep_durations if isinstance(d, (int, float))]

    raw_sets = data.get("sets", [])
    clean_sets = []
    if isinstance(raw_sets, list):
        for s in raw_sets:
            if not isinstance(s, dict):
                continue
            s_reps = int(s.get("reps", 0))
            s_durations = [float(d) for d in s.get("durations", []) if isinstance(d, (int, float))]
            clean_sets.append({"reps": s_reps, "durations": s_durations})
    total_sets = int(data.get("total_sets", len(clean_sets)))

    avg_rep_seconds = round(sum(rep_durations) / len(rep_durations), 2) if rep_durations else None

    # DECIMOTERCER BUG REAL (2026-09-04): esto usaba a propósito
    # resolve_plan_target(exercise_value) sin más — cualquier tarea de
    # este ejercicio "enganchaba" el objetivo (y la progresión) de un
    # plan activo, aunque la tarea en concreto fuera freestyle y no la
    # hubiera generado ese plan. El usuario reportó justo esto (una
    # tarea freestyle de fondos enseñando el objetivo de su plan de tren
    # superior) y, tras ver que separarlo del todo significaba perder el
    # conteo cruzado (ver SingleExerciseCompletionTests, actualizado en
    # el mismo commit), pidió explícitamente separarlo igualmente: ahora
    # solo se resuelve contra un plan si ESTA tarea la generó un plan de
    # verdad (task.plan) — freestyle ya no ve ni cuenta para el plan.
    ctx = (
        resolve_plan_target(exercise_value) if task.plan
        else {"plan": None, "target_sets": None, "target_reps": None, "target_seconds": None}
    )

    ws = WorkoutSession.objects.create(
        task=task,
        user=get_current_user(),
        series_id=task.series_id,
        exercise=exercise_value,
        plan=ctx["plan"],
        target_sets=ctx["target_sets"],
        target_reps=ctx["target_reps"],
        target_seconds=ctx["target_seconds"],
        total_reps=total_reps,
        total_sets=total_sets,
        sets=clean_sets,
        session_duration_seconds=int(data.get("session_duration_seconds", 0)),
        avg_rep_seconds=avg_rep_seconds,
        rest_alerts_triggered=int(data.get("rest_alerts_triggered", 0)),
        rep_durations=rep_durations,
    )

    # Un solo ejercicio con objetivo: la tarea solo se da por completada
    # si se llegó a él. Si se quedó corta, se queda pendiente con el
    # porcentaje ya guardado en la sesión, para poder retomarla el mismo
    # día. Sin objetivo (entreno libre), se completa como siempre.
    resumen = f"Sesión guardada: {total_reps} {exercise_label} en {total_sets} serie(s)"
    if avg_rep_seconds:
        resumen += f", ritmo medio {avg_rep_seconds}s/rep."
    else:
        resumen += "."

    if ws.calories_kcal:
        resumen += f" ≈{round(ws.calories_kcal)} kcal."

    if ws.target_met:
        # La tarea no se marca hecha aquí — falta el enfriamiento
        # obligatorio (ver task_cooldown), que es quien la cierra de verdad.
        redirect_url = reverse("tasks:task_cooldown", args=[task.pk])
    else:
        resumen += f" Te has quedado en el {ws.achievement_pct}% del objetivo — la tarea sigue pendiente."
        redirect_url = reverse("tasks:task_list")
    messages.success(request, resumen)
    return JsonResponse({"ok": True, "redirect_url": redirect_url})


@require_POST
def task_workout_save_manual(request, pk):
    """
    Guarda una sesión escrita a mano (running: cinta, reloj, Samsung
    Health…). A diferencia de task_workout_save, esto es un <form> normal
    (no fetch/JSON) — se valida, se guarda y se redirige, sin JS de por
    medio.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    exercise_slug = request.GET.get("exercise", "running")
    exercise = get_object_or_404(Exercise, slug=exercise_slug, mode=Exercise.MODE_DISTANCE)

    def _to_float(raw):
        try:
            return float(str(raw).replace(",", "."))
        except (TypeError, ValueError):
            return None

    def _to_int(raw):
        try:
            return int(raw)
        except (TypeError, ValueError):
            return None

    distance_km = _to_float(request.POST.get("distance_km"))
    duration_minutes = _to_float(request.POST.get("duration_minutes"))
    steps = _to_int(request.POST.get("steps"))

    if not distance_km and not duration_minutes:
        messages.error(request, "Pon al menos la distancia o la duración para guardar la sesión.")
        return redirect(f"{reverse('tasks:task_workout', args=[task.pk])}?exercise={exercise.slug}")

    session_duration_seconds = int(round(duration_minutes * 60)) if duration_minutes else 0
    avg_rep_seconds = None
    if distance_km and duration_minutes:
        # "ritmo" en min/km, reutilizando avg_rep_seconds (en segundos) para no
        # añadir otro campo solo para esto.
        avg_rep_seconds = round((duration_minutes * 60) / distance_km, 2)

    WorkoutSession.objects.create(
        task=task,
        user=get_current_user(),
        series_id=task.series_id,
        exercise=exercise.slug,
        session_duration_seconds=session_duration_seconds,
        avg_rep_seconds=avg_rep_seconds,
        distance_km=distance_km,
        steps=steps,
    )

    bits = []
    if distance_km:
        bits.append(f"{distance_km}km")
    if duration_minutes:
        bits.append(f"{duration_minutes:.0f} min")
    if steps:
        bits.append(f"{steps} pasos")
    # A diferencia del resto de Deporte, running no pasa por el
    # enfriamiento obligatorio: la sesión ya viene de un dato real
    # (distancia/tiempo, Health Connect...), no hace falta el vídeo.
    # Solo se cierra si lo de hoy cumple el objetivo (distancia/pasos/
    # ritmo). Si no, la sesión queda guardada y la tarea sigue abierta
    # para completarla.
    if task.running_goal_met():
        closed_plan = task.mark_done()
        messages.success(request, "Sesión de running guardada: " + ", ".join(bits) + ".")
        return redirect(_finish_redirect_url(task, closed_plan))
    progress = task.auto_progress
    falta = f" ({progress['label']})" if progress else ""
    messages.warning(
        request,
        "Sesión guardada: " + ", ".join(bits) + f". Aún no llegas al objetivo{falta}, la tarea sigue pendiente.",
    )
    return redirect(reverse("tasks:task_list"))


def task_warmup(request, pk):
    """
    Calentamiento recomendado antes de entrenar (ver _require_warmup):
    se pregunta primero si ya has calentado — si dices que sí, o pasas
    por el circuito de calentamiento de esa subcategoría (opcional, ver
    tasks/task_warmup.html y task_warmup_routine), el POST apunta la
    hora (WarmupStatus) y se vuelve a donde se iba (?next=), que ya no
    lo volverá a pedir mientras siga "fresco".
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    task.mark_started()
    next_url = request.GET.get("next") or reverse("tasks:task_workout", args=[task.pk])
    if request.method == "POST":
        WarmupStatus.mark_done(get_current_user())
        return redirect(next_url)
    routine = _warmup_routine_for(task)
    routine_url = None
    create_routine_url = None
    if routine:
        routine_url = (
            f"{reverse('tasks:task_warmup_routine', args=[task.pk, routine.pk])}"
            f"?next={quote(next_url)}"
        )
    subcategory_label = ""
    sub = _task_warmup_subcategory(task)
    if not routine and sub:
        create_routine_url = (
            f"{reverse('tasks:routine_create')}?subcategory={sub}"
            f"&next={quote(request.get_full_path())}"
        )
        subcategory_label = dict(Task.SPORT_SUBCATEGORY_CHOICES).get(sub, sub)
    return render(request, "tasks/task_warmup.html", {
        "task": task, "next": next_url, "routine": routine,
        "routine_url": routine_url, "create_routine_url": create_routine_url,
        "subcategory_label": subcategory_label,
    })


def task_cooldown(request, pk):
    """
    Enfriamiento/estiramiento recomendado al terminar de entrenar: mismo
    mecanismo que task_warmup pero al revés (se pregunta si quieres
    estirar; el circuito, si se pide, es opcional y se puede saltar). Se
    llega aquí DESPUÉS de guardar ya los números de la sesión
    (task_workout_save, .._save_manual, routine_save, plan_session_save,
    task_video_save) — la tarea se marca hecha de verdad al pasar por
    aquí (con o sin estiramiento), sea cual sea la elección.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    if request.method == "POST":
        closed_plan = task.mark_done()
        messages.success(request, "Sesión completada.")
        return redirect(_finish_redirect_url(task, closed_plan))
    routine = _warmup_routine_for(task)
    routine_url = None
    create_routine_url = None
    if routine:
        routine_url = reverse("tasks:task_cooldown_routine", args=[task.pk, routine.pk])
    subcategory_label = ""
    sub = _task_warmup_subcategory(task)
    if not routine and sub:
        create_routine_url = (
            f"{reverse('tasks:routine_create')}?subcategory={sub}"
            f"&next={quote(request.get_full_path())}"
        )
        subcategory_label = dict(Task.SPORT_SUBCATEGORY_CHOICES).get(sub, sub)
    return render(request, "tasks/task_cooldown.html", {
        "task": task, "routine": routine,
        "routine_url": routine_url, "create_routine_url": create_routine_url,
        "subcategory_label": subcategory_label,
    })


def task_warmup_routine(request, pk, routine_pk):
    """
    Reproductor del circuito de calentamiento (sustituye al vídeo fijo
    de antes) — mismo motor que un circuito normal (routine_play +
    circuit.js), pero terminar AQUÍ no cuenta como la sesión de la
    tarea: no se crea ningún WorkoutSession, solo se marca WarmupStatus
    (ver task_warmup_routine_save) y se vuelve a lo que tocaba hacer.
    Sin _require_warmup aquí a propósito -- esto YA ES el calentamiento,
    pedirlo de nuevo sería un bucle.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    task.mark_started()
    routine = get_object_or_404(Routine, pk=routine_pk, user=get_current_user())
    next_url = request.GET.get("next") or reverse("tasks:task_workout", args=[task.pk])
    items = list(routine.items.select_related("exercise"))
    if not items:
        messages.error(request, "Este circuito todavía no tiene ejercicios.")
        return redirect(next_url)
    save_url = (
        f"{reverse('tasks:task_warmup_routine_save', args=[task.pk, routine.pk])}"
        f"?next={quote(next_url)}"
    )
    return render(request, "tasks/routine_play.html", {
        "task": task, "routine": routine, "items": items,
        "items_json": json.dumps(_routine_items_data(items)),
        "save_url": save_url, "cancel_url": next_url, "back_url": next_url,
    })


@require_POST
def task_warmup_routine_save(request, pk, routine_pk):
    get_object_or_404(Task, pk=pk, user=get_current_user())
    WarmupStatus.mark_done(get_current_user())
    next_url = request.GET.get("next") or reverse("tasks:task_workout", args=[pk])
    return JsonResponse({"ok": True, "redirect_url": next_url})


def task_cooldown_routine(request, pk, routine_pk):
    """
    Igual que task_warmup_routine pero para el enfriamiento: terminar el
    circuito aquí SÍ marca la tarea como hecha (ver
    task_cooldown_routine_save) -- es la continuación natural de
    task_cooldown, que ya se llama después de guardar los números de la
    sesión de verdad.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    task.mark_started()
    routine = get_object_or_404(Routine, pk=routine_pk, user=get_current_user())
    items = list(routine.items.select_related("exercise"))
    if not items:
        messages.error(request, "Este circuito todavía no tiene ejercicios.")
        closed_plan = task.mark_done()
        messages.success(request, "Sesión completada.")
        return redirect(_finish_redirect_url(task, closed_plan))
    save_url = reverse("tasks:task_cooldown_routine_save", args=[task.pk, routine.pk])
    return render(request, "tasks/routine_play.html", {
        "task": task, "routine": routine, "items": items,
        "items_json": json.dumps(_routine_items_data(items)),
        "save_url": save_url,
        "cancel_url": reverse("tasks:task_list"),
        "back_url": reverse("tasks:task_list"),
    })


@require_POST
def task_cooldown_routine_save(request, pk, routine_pk):
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    closed_plan = task.mark_done()
    messages.success(request, "Sesión completada.")
    return JsonResponse({"ok": True, "redirect_url": _finish_redirect_url(task, closed_plan)})


# ------------------------------------------------------------- lectura / cronometro suelto

def task_focus(request, pk):
    """
    Pantalla del temporizador de una tarea de Lectura (category="work")
    o de una tarea de General con cronómetro (Task.wants_timer). El
    cronómetro es JS puro en la plantilla — aquí solo se enseña el
    objetivo, si lo hay.

    El antiguo subtipo "Estudio" de esta categoría (antes de reducirla a
    solo Lectura) ofrecía además un selector de vídeos guardados — se
    quitó junto con el subtipo al no haber ninguna tarea real usándolo;
    tasks/templates/tasks/task_focus_mode.html se queda sin usar por si
    hiciera falta recuperar la idea más adelante.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    task.mark_started()
    video_id = request.GET.get("video")
    if video_id:
        # Mismo contexto completo que task_video: la plantilla necesita
        # SIEMPRE estas claves, aunque sea None/"" — si falta alguna, el
        # JS que arma con {{ target_minutes|default_if_none:"null" }}
        # se queda con una asignación vacía y ni siquiera arranca.
        return render(request, "tasks/task_video.html", {
            "task": task, "video_id": video_id,
            "playlist_id": "", "target_minutes": None, "target_video_count": None, "has_local_video": False,
        })

    return render(request, "tasks/task_focus.html", {"task": task})


@require_POST
def task_focus_save(request, pk):
    """
    Recibe los minutos ya contados en el navegador (fetch/JSON) y
    guarda la sesión. Mismo criterio que task_workout_save: si había
    objetivo y no se llegó, la tarea se queda pendiente con el
    porcentaje guardado, para poder retomarla el mismo día.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    try:
        data = json.loads(request.body)
    except (json.JSONDecodeError, TypeError):
        return JsonResponse({"ok": False, "error": "JSON inválido"}, status=400)

    minutes = max(0, int(data.get("minutes", 0)))

    ts = TimerSession.objects.create(
        task=task,
        user=get_current_user(),
        series_id=task.series_id,
        subcategory=task.subcategory,
        source=TimerSession.SOURCE_MANUAL,
        minutes=minutes,
        target_minutes=task.target_minutes,
    )

    closed_plan = None
    if ts.target_met:
        closed_plan = task.mark_done()

    resumen = f"Sesión guardada: {minutes} min"
    resumen += "." if ts.target_met else f" — {ts.achievement_pct}% del objetivo. La tarea sigue pendiente."
    messages.success(request, resumen)
    return JsonResponse({"ok": True, "redirect_url": _finish_redirect_url(task, closed_plan)})


# ------------------------------------------------------- plan de lectura

def reading_plan_form(request, pk=None):
    """
    Crea o edita un Plan de lectura: una tarea de Lectura (category='work',
    subcategory='reading') con reading_mode='plan'. El PDF se elige AQUÍ
    mismo (a diferencia del vídeo local, que se elige ya en el visor) para
    poder autorrellenar el título con el nombre del archivo -- ver el JS
    de la plantilla. Como el archivo vive solo en este navegador (File
    System Access API + IndexedDB, nunca sube al servidor), lo único que
    llega en el POST es reading_pdf_key, la clave con la que el visor
    (task_reading) lo va a encontrar.

    Se guarda como una tarea normal que se repite en los días que se
    elijan (repeat=custom, custom_days -- mismo mecanismo que un Plan de
    Deporte/Estudio/General, ver plan_form view): el plan no tiene su
    propio ciclo de "sesiones por semana" como un Plan de Estudio -- es
    una tarea de Lectura de toda la vida, solo que con visor propio y
    objetivo de página en vez de minutos. Por eso vive aparte de
    tasks/task_form.html en vez de meterse ahí: ese formulario no tiene
    forma de pedir el PDF con autorrelleno del título sin liar todo lo
    demás que ya hace.
    """
    task = None
    if pk is not None:
        task = get_object_or_404(
            Task, pk=pk, user=get_current_user(),
            category=Task.CATEGORY_WORK, subcategory=Task.SUBCATEGORY_READING,
            reading_mode=Task.READING_MODE_PLAN,
        )

    if request.method == "POST":
        title = request.POST.get("title", "").strip()[:255] or "Plan de lectura"
        pdf_key = request.POST.get("reading_pdf_key", "").strip()[:64]
        try:
            last_page = int(request.POST.get("reading_last_page") or 0)
        except ValueError:
            last_page = 0
        try:
            target_weeks = int(request.POST.get("reading_target_weeks") or 0)
        except ValueError:
            target_weeks = 0
        # Opcional -- en blanco (o cualquier cosa rara) es "empieza en la
        # 1", el de toda la vida antes de que existiera este campo.
        try:
            first_page = int(request.POST.get("reading_first_page") or 1)
        except ValueError:
            first_page = 1
        first_page = max(1, first_page)
        # Sin ningún día marcado (o si el navegador no manda nada), se cae
        # en lunes/miércoles/viernes -- mismo valor por defecto que un Plan
        # de Deporte/Estudio/General (ver plan_form), nunca "ningún día"
        # (una tarea que no vuelve a salir nunca no sirve de nada).
        custom_days = ",".join(request.POST.getlist("custom_days")) or "0,2,4"

        if last_page < 1 or target_weeks < 1:
            messages.error(request, "Pon la última página real del libro y en cuántas semanas quieres terminarlo.")
            return render(request, "tasks/reading_plan_form.html", {
                "task": task, "weekdays": Task.WEEKDAYS,
                "selected_days": custom_days.split(","),
            })
        if first_page > last_page:
            messages.error(request, "La página donde empieza el libro no puede ser mayor que la última página real.")
            return render(request, "tasks/reading_plan_form.html", {
                "task": task, "weekdays": Task.WEEKDAYS,
                "selected_days": custom_days.split(","),
            })

        today = timezone.localtime(timezone.now()).date()
        if task is None:
            task = Task.objects.create(
                user=get_current_user(), title=title,
                category=Task.CATEGORY_WORK, subcategory=Task.SUBCATEGORY_READING,
                reading_mode=Task.READING_MODE_PLAN,
                reading_pdf_key=pdf_key, reading_first_page=first_page,
                reading_last_page=last_page, reading_target_weeks=target_weeks,
                reading_started_on=today,
                repeat=Task.REPEAT_CUSTOM, custom_days=custom_days, due_date=today, series_start_date=today,
            )
            # Objetivo de HOY para esta primera instancia -- reading_current_page
            # todavía está a 0 (default del modelo), así que el "inicio del
            # día" es 0 y el objetivo sale del ritmo completo del plan.
            task.ensure_reading_day_goal()
        else:
            task.title = title
            # El plazo puede tocarse desde aquí sin más -- lo único que NO
            # se toca al editar es reading_started_on ni reading_current_page:
            # cambiar de idea sobre el plazo no debe reiniciar el avance ya
            # hecho ni fingir que el plan empezó hoy.
            task.reading_first_page = first_page
            task.reading_last_page = last_page
            task.reading_target_weeks = target_weeks
            task.repeat = Task.REPEAT_CUSTOM
            task.custom_days = custom_days
            if pdf_key:
                task.reading_pdf_key = pdf_key
            task.recompute_reading_day_goal()
            task.save(update_fields=[
                "title", "reading_first_page", "reading_last_page", "reading_target_weeks",
                "reading_pdf_key", "repeat", "custom_days", "reading_day_goal",
            ])
        messages.success(request, "Plan de lectura guardado.")
        return redirect(reverse("tasks:task_reading", args=[task.pk]))

    return render(request, "tasks/reading_plan_form.html", {
        "task": task, "weekdays": Task.WEEKDAYS,
        "selected_days": task.custom_days_list() if task else ["0", "2", "4"],
    })


def task_reading(request, pk):
    """
    Visor de PDF a pantalla completa de un Plan de lectura -- pdf.js
    propio, mismo espíritu que task_video.html con el IFrame de YouTube.
    El PDF en sí se abre desde el archivo guardado en IndexedDB (ver
    reading_plan_form.html, que es donde se elige) usando task.reading_pdf_key
    como clave; si no hay ninguno guardado en ESTE navegador (aparato
    nuevo, o se limpió el sitio), el propio visor ofrece elegirlo de
    nuevo, igual que "olvidar vídeo local" en task_video.html.
    """
    task = get_object_or_404(
        Task, pk=pk, user=get_current_user(),
        category=Task.CATEGORY_WORK, subcategory=Task.SUBCATEGORY_READING,
        reading_mode=Task.READING_MODE_PLAN,
    )
    # Dos casos: planes abiertos antes de que existiera el objetivo
    # diario (reading_day_goal todavía None) y, sobre todo, que haya
    # cambiado el día de calendario desde la última vez que se fijó --
    # ver ensure_reading_day_goal, que además no hace nada si due_date
    # todavía no ha llegado (sesión extra, ver reading_session_ready).
    task.mark_started()
    task.ensure_reading_day_goal()
    return render(request, "tasks/task_reading.html", {
        "task": task,
        "status": task.reading_plan_status,
        "today_status": task.reading_today_status,
    })


@require_POST
def task_reading_progress(request, pk):
    """
    Reporta la página por la que va el visor -- se llama en cada cambio
    de página (con un pequeño debounce en el JS), mismo patrón que
    playlist_start_index con los vídeos. Ligero a propósito: solo guarda
    la página y, si con eso se llega a la última página real, cierra el
    plan entero -- ver Task.record_reading_page. No marca "hecho el día
    de hoy" (eso es task_reading_save, aparte) salvo que esto sea
    justamente lo que termina el libro.
    """
    task = get_object_or_404(
        Task, pk=pk, user=get_current_user(),
        category=Task.CATEGORY_WORK, subcategory=Task.SUBCATEGORY_READING,
        reading_mode=Task.READING_MODE_PLAN,
    )
    if request.content_type == "application/x-www-form-urlencoded":
        # navigator.sendBeacon() del visor (task_reading.html), usado al
        # cerrar/ocultar la pestaña para no perder un cambio de página
        # que seguía esperando su debounce -- sendBeacon no permite poner
        # cabeceras, así que ese aviso concreto llega como formulario
        # (csrfmiddlewaretoken en el body, no en X-CSRFToken) en vez de
        # JSON. CsrfViewMiddleware ya sabe leer el token de ahí.
        raw_page = request.POST.get("page")
    else:
        try:
            data = json.loads(request.body or b"{}")
        except (json.JSONDecodeError, TypeError):
            return JsonResponse({"ok": False, "error": "JSON inválido"}, status=400)
        raw_page = data.get("page")
    try:
        page = int(raw_page)
    except (TypeError, ValueError):
        return JsonResponse({"ok": False, "error": "Falta 'page'"}, status=400)

    finished = task.record_reading_page(page)
    response = {
        "ok": True, "finished": finished,
        "status": task.reading_plan_status,
        "today": task.reading_today_status,
    }
    if finished:
        response["redirect_url"] = reverse("tasks:task_list")
        messages.success(
            request,
            f"«{task.title}» terminado — {task.reading_final_pct}% del plazo original."
            if task.reading_target_weeks else f"«{task.title}» terminado.",
        )
    return JsonResponse(response)


@require_POST
def task_reading_save(request, pk):
    """
    "Terminar sesión de hoy" del visor: mismo criterio que task_focus_save,
    marca hecha la instancia de HOY y genera la de mañana (mark_done ->
    _spawn_next), sin cerrar el plan -- para eso hace falta llegar de
    verdad a la última página (ver task_reading_progress). Independiente
    del progreso de página en sí, que ya se reporta aparte según se va
    leyendo: aquí solo se resuelve el día, como cualquier otra tarea de
    Enfoque.

    También vuelca aquí el tiempo real de lectura acumulado en esta
    sesión (ver Task._flush_reading_time) -- ANTES de mirar
    reading_session_ready: el tiempo ya leído cuenta igual aunque vayas
    adelantado y esta instancia concreta no se pueda cerrar todavía.
    """
    task = get_object_or_404(
        Task, pk=pk, user=get_current_user(),
        category=Task.CATEGORY_WORK, subcategory=Task.SUBCATEGORY_READING,
        reading_mode=Task.READING_MODE_PLAN,
    )
    if task.reading_completed_at:
        # El libro ya se terminó (task_reading_progress ya cerró el plan
        # y marcó hecho, volcando el tiempo pendiente de paso) -- nada
        # que guardar aquí, evita un mark_done() de más sobre una serie
        # que ya está en REPEAT_NONE.
        return JsonResponse({"ok": True, "redirect_url": reverse("tasks:task_list")})
    task._flush_reading_time()
    if not task.reading_session_ready:
        # Se puede entrar al visor y seguir leyendo cualquier día (eso ya
        # se guarda aparte, en task_reading_progress) -- lo que no se deja
        # es CERRAR una instancia futura antes de que toque, porque eso
        # hacía avanzar la serie entera y el día real que tocaba llegaba
        # ya "hecho" de antemano (ver Task.reading_session_ready). Se
        # responde ok=True (no ha fallado nada, el progreso de página ya
        # está guardado) con early=True para que el visor avise en vez de
        # redirigir como si hubiera cerrado el día.
        return JsonResponse({
            "ok": True, "early": True,
            "message": (
                f"Vas adelantado — esta sesión es del "
                f"{task.due_date.strftime('%d/%m')}. Tu progreso de página ya "
                "está guardado; se completará sola ese día."
            ),
        })
    task.mark_done()
    messages.success(request, "Sesión de lectura guardada.")
    return JsonResponse({"ok": True, "redirect_url": reverse("tasks:task_list")})


# --------------------------------------------------------------- vídeo

# -------------------------------------------------------- vídeos guardados

@require_POST
def saved_video_create(request):
    """
    Guarda un vídeo nuevo desde el selector de tren superior/inferior o
    de estudio, y va derecho a reproducirlo — un paso menos que guardar
    y luego tener que ir a buscarlo en la lista.
    """
    scope = request.POST.get("scope", "")
    valid_scopes = {key for key, _ in SavedVideo.SCOPE_CHOICES}
    if scope not in valid_scopes:
        messages.error(request, "Tipo de vídeo no válido.")
        return redirect(reverse("tasks:task_list"))

    raw = request.POST.get("youtube_video_id", "").strip()
    if not raw:
        messages.error(request, "Pega un enlace de YouTube.")
        return redirect(request.POST.get("next") or reverse("tasks:task_list"))

    sv = SavedVideo.objects.create(
        user=get_current_user(), scope=scope,
        title=request.POST.get("title", "").strip()[:120],
        youtube_video_id=raw,
    )

    task_pk = request.POST.get("task_pk")
    entry_url = request.POST.get("entry_url") or reverse("tasks:task_workout", args=[task_pk])
    sep = "&" if "?" in entry_url else "?"
    return redirect(f"{entry_url}{sep}video={sv.youtube_video_id}")


@require_POST
def saved_video_delete(request, uuid):
    """Borrado suave, para poder limpiar la lista sin romper el historial."""
    sv = get_object_or_404(SavedVideo, uuid=uuid, user=get_current_user())
    sv.deleted_at = timezone.now()
    sv.save(update_fields=["deleted_at"])
    messages.success(request, "Vídeo quitado de la lista.")
    return redirect(request.POST.get("next") or reverse("tasks:task_list"))


def task_video(request, pk):
    """
    Pantalla del vídeo de una tarea. El vídeo puede venir fijado en la
    propia tarea (task.youtube_video_id) o elegido al vuelo desde el
    selector de tren superior/inferior/estudio (?video=) — task_workout
    y task_focus redirigen aquí pasándolo. El embed y la detección de
    "terminó" son JS puro (IFrame Player API de YouTube).

    task.youtube_playlist_id / target_minutes / target_video_count solo
    aplican al vídeo fijado en la tarea, no al elegido al vuelo (ese
    siempre es un vídeo suelto, sin objetivo por cuenta ni por minutos).

    Un curso de idioma (Plan.STUDY_SUBTYPE_LANGUAGE) asigna UN vídeo por
    día, que suele durar mucho menos que el objetivo diario en minutos
    — sin más, la tarea se marcaría hecha en cuanto acabara ese primer
    vídeo corto, sin llegar ni de lejos al objetivo. `course_queue` lleva
    los siguientes vídeos del temario para que task_video.html los
    encadene solo, en la misma sesión, hasta llenar el objetivo (ver
    Plan.upcoming_course_queue).
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    task.mark_started()
    override_video_id = request.GET.get("video")
    video_id = override_video_id or task.youtube_video_id
    plan = None if override_video_id else task.plan
    is_language_session = bool(
        plan and plan.plan_type == Plan.PLAN_TYPE_STUDY and plan.study_subtype == Plan.STUDY_SUBTYPE_LANGUAGE
    )
    course_queue = plan.upcoming_course_queue() if is_language_session else []
    return render(request, "tasks/task_video.html", {
        "task": task,
        "video_id": video_id,
        "playlist_id": "" if override_video_id else task.youtube_playlist_id,
        "target_minutes": None if override_video_id else task.target_minutes,
        "target_video_count": None if override_video_id else task.target_video_count,
        "playlist_start_index": None if override_video_id else task.playlist_start_index,
        # Un vídeo elegido al vuelo siempre es de YouTube, suelto — el
        # "solo local, sin YouTube" solo puede venir de la propia tarea.
        "has_local_video": False if override_video_id else task.has_local_video,
        "course_queue_json": json.dumps(course_queue),
    })


@require_POST
def task_video_save(request, pk):
    """
    El vídeo llegó al objetivo en minutos, o al final (evento ENDED en
    el navegador) -> la tarea se marca hecha directamente. No hay
    objetivo que comparar contra un mínimo para dejarla pendiente (a
    diferencia de Enfoque): aquí target_minutes solo decide CUÁNDO
    cortar, no si la tarea vale o no — ver task_video.html.

    `minutes` son los minutos reales vistos, contados en el navegador
    con la IFrame API de YouTube (no un dato de confianza del cliente
    sin más: solo cuenta mientras el vídeo está de verdad reproduciéndose).
    Se guardan en la Occurrence del día para que salgan en resultados.

    Si esto era un vídeo de un curso de idioma con Plan.quiz_every_n_videos
    puesto, y justo tocaba test de repaso, se redirige al test en vez de
    a la lista de tareas — ver api.maybe_trigger_quiz. La tarea ya está
    hecha de todas formas: el test es aparte y nunca bloquea nada.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    try:
        data = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, TypeError):
        data = {}
    raw_minutes = data.get("minutes")
    minutes_watched = max(0, int(raw_minutes)) if isinstance(raw_minutes, (int, float)) else None
    # Cuántos vídeos del temario se completaron ENTEROS en esta sesión —
    # una sesión de idioma puede encadenar varios vídeos cortos seguidos
    # hasta llenar el objetivo diario en minutos (ver task_video.html);
    # sin dato (cliente viejo, o tarea que no es de idioma) se asume 1,
    # ver Plan.mark_current_module_watched.
    raw_videos = data.get("videos_watched")
    videos_watched = max(0, int(raw_videos)) if isinstance(raw_videos, (int, float)) else None
    plan = task.plan

    # Un vídeo de Deporte (seguir una rutina en YouTube) no se marca
    # hecho aquí: falta el enfriamiento obligatorio (task_cooldown), que
    # es quien la cierra de verdad. El resto (Estudio, idiomas…) sigue
    # exactamente como antes.
    if task.category == Task.CATEGORY_SPORT:
        return JsonResponse({"ok": True, "redirect_url": reverse("tasks:task_cooldown", args=[task.pk])})

    # Tarea suelta (sin Plan detrás) de Estudio con un vídeo/playlist de
    # YouTube fijado: a diferencia de un curso de idioma con Plan (que
    # avanza su propio temario vía Plan.mark_current_module_watched más
    # abajo), aquí el contenido puesto ES todo lo que hay que ver -- un
    # vídeo suelto se acaba al verlo entero, una playlist se acaba al
    # ver su último vídeo. En cualquiera de los dos casos ya no tiene
    # sentido seguir pidiendo esta tarea cada día: se cierra la serie
    # entera, igual que hace Udemy cuando la extensión detecta el curso
    # al 100% (ver Task.finish_recurring_series).
    if not plan and task.category == Task.CATEGORY_STUDY:
        if task.youtube_playlist_id:
            watched_count = videos_watched if videos_watched is not None else 1
            next_index = (task.playlist_start_index or 0) + watched_count
            task.playlist_start_index = next_index
            if task.is_last_playlist_video(next_index - 1):
                task.finish_recurring_series()
                messages.success(request, "Playlist terminada — tarea completada.")
                return JsonResponse({"ok": True, "redirect_url": reverse("tasks:task_list")})
        elif task.youtube_video_id:
            task.finish_recurring_series()
            messages.success(request, "Vídeo visto — tarea completada.")
            return JsonResponse({"ok": True, "redirect_url": reverse("tasks:task_list")})

    closed_plan = task.mark_done(minutes_watched=minutes_watched)
    messages.success(request, "Vídeo visto — tarea completada.")

    quiz = None
    if plan and plan.plan_type == Plan.PLAN_TYPE_STUDY and plan.study_subtype == Plan.STUDY_SUBTYPE_LANGUAGE:
        plan.mark_current_module_watched(count=videos_watched)
        # El progreso del temario se acaba de actualizar -- si ESTE
        # vídeo era el que completaba el curso, mark_done() de arriba
        # todavía no lo sabía (se llamó antes de mark_current_module_watched);
        # se vuelve a comprobar aquí ya con el dato al día.
        if not closed_plan and plan.close_if_finished():
            closed_plan = plan
        quiz = api.maybe_trigger_quiz(plan)

    redirect_url = (
        reverse("tasks:quiz_take", args=[quiz.uuid]) if quiz
        else _finish_redirect_url(task, closed_plan)
    )
    return JsonResponse({"ok": True, "redirect_url": redirect_url})


def _save_routine(request, routine=None):
    """Crea o actualiza una Routine a partir del formulario del
    constructor de circuitos. Compartido por routine_create/routine_edit."""
    name = request.POST.get("name", "").strip() or "Circuito sin nombre"

    subcategory = request.POST.get("subcategory", "")
    valid_sub = {key for key, _ in Task.SUBCATEGORY_CHOICES}
    if subcategory not in valid_sub:
        subcategory = ""

    try:
        work = max(5, int(request.POST.get("default_work_seconds", 40)))
    except (TypeError, ValueError):
        work = 40
    try:
        rest = max(0, int(request.POST.get("default_rest_seconds", 20)))
    except (TypeError, ValueError):
        rest = 20

    raw_items = request.POST.get("items", "")
    exercise_ids = [int(x) for x in raw_items.split(",") if x.strip().isdigit()]
    next_url = request.POST.get("next") or reverse("tasks:task_list")

    if not exercise_ids:
        messages.error(request, "Elige al menos un ejercicio para el circuito.")
        back = reverse("tasks:routine_edit", args=[routine.pk]) if routine else reverse("tasks:routine_create")
        return redirect(f"{back}?next={next_url}")

    is_warmup_bookend = bool(request.POST.get("is_warmup_bookend"))

    if routine is None:
        routine = Routine.objects.create(
            user=get_current_user(), name=name, subcategory=subcategory,
            default_work_seconds=work, default_rest_seconds=rest,
            is_warmup_bookend=is_warmup_bookend,
        )
    else:
        routine.name = name
        routine.subcategory = subcategory
        routine.default_work_seconds = work
        routine.default_rest_seconds = rest
        routine.is_warmup_bookend = is_warmup_bookend
        routine.save()
        routine.items.all().delete()

    # Solo uno marcado por usuario+subcategoría a la vez (ver
    # _warmup_routine_for) -- si este se marca, se desmarcan los demás
    # de la misma subcategoría para que no quede ambigüedad de cuál se
    # ofrece como calentamiento/enfriamiento.
    if is_warmup_bookend and subcategory:
        Routine.objects.filter(
            user=get_current_user(), subcategory=subcategory, is_warmup_bookend=True,
        ).exclude(pk=routine.pk).update(is_warmup_bookend=False)

    # Se admite cualquier ejercicio activo, no solo los cronometrados: un
    # circuito de tren superior (dominadas, fondos) es tan válido como
    # uno de abdominales — cada uno se reproduce luego con lo que le
    # toque (cámara, cronómetro, o cronómetro con cámara comprobando la
    # postura). Esto solo evita que alguien cuele por POST un id de
    # ejercicio que no existe o está desactivado.
    valid_exercise_ids = set(
        Exercise.objects.filter(id__in=exercise_ids, is_active=True).values_list("id", flat=True)
    )
    order = 0
    for eid in exercise_ids:
        if eid not in valid_exercise_ids:
            continue
        RoutineItem.objects.create(routine=routine, exercise_id=eid, order=order)
        order += 1

    messages.success(request, f"Circuito «{routine.name}» guardado con {order} ejercicio(s).")
    return redirect(next_url)


def routine_create(request):
    if request.method == "POST":
        return _save_routine(request)
    # Cualquier ejercicio activo vale para un circuito, no solo los
    # cronometrados (ver _save_routine) — cada uno se reproduce luego
    # con lo suyo.
    exercises = Exercise.objects.filter(is_active=True)
    return render(request, "tasks/routine_form.html", {
        "exercises": exercises,
        "subcategory_choices": Task.SPORT_SUBCATEGORY_CHOICES,
        "initial_subcategory": request.GET.get("subcategory", ""),
        "next_url": request.GET.get("next", ""),
    })


def routine_edit(request, pk):
    routine = get_object_or_404(Routine, pk=pk, user=get_current_user())
    if request.method == "POST":
        return _save_routine(request, routine=routine)
    exercises = Exercise.objects.filter(is_active=True)
    return render(request, "tasks/routine_form.html", {
        "routine": routine,
        "exercises": exercises,
        "subcategory_choices": Task.SPORT_SUBCATEGORY_CHOICES,
        "initial_subcategory": routine.subcategory,
        "next_url": request.GET.get("next", ""),
        "selected_items": list(routine.items.select_related("exercise")),
    })


@require_POST
def routine_delete(request, pk):
    routine = get_object_or_404(Routine, pk=pk, user=get_current_user())
    routine.delete()
    messages.success(request, "Circuito eliminado.")
    return redirect(request.POST.get("next") or reverse("tasks:task_list"))


def routine_play(request, pk, routine_pk):
    """
    Reproductor del circuito: encadena todos los RoutineItem de la
    rutina, cada uno con lo que le toca — cronómetro, cámara contando
    reps, o cronómetro con cámara comprobando la postura (plancha) —,
    ver static/js/circuit.js. `mode`/`counter_key`/`target_*` van en
    items_data igual que en la API (ver api._routine_item_json), así
    que el objetivo de un ejercicio de cámara sube solo si hay un plan
    activo siguiéndolo.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    task.mark_started()
    gate = _require_warmup(request, task)
    if gate:
        return gate
    routine = get_object_or_404(Routine, pk=routine_pk, user=get_current_user())
    items = list(routine.items.select_related("exercise"))

    if not items:
        messages.error(request, "Este circuito todavía no tiene ejercicios.")
        return redirect(reverse("tasks:task_workout", args=[task.pk]))

    return render(request, "tasks/routine_play.html", {
        "task": task, "routine": routine, "items": items,
        "items_json": json.dumps(_routine_items_data(items)),
        "save_url": reverse("tasks:routine_save", args=[task.pk, routine.pk]),
        "cancel_url": reverse("tasks:task_list"),
        "back_url": reverse("tasks:task_workout", args=[task.pk]),
    })


@require_POST
def routine_save(request, pk, routine_pk):
    """
    Guarda el resultado del circuito al terminar (o al cortarlo antes de
    tiempo): UNA WorkoutSession POR EJERCICIO, no una combinada.

    Antes se guardaba una única sesión con exercise="ab-circuit" y el
    desglose metido en `sets`. Eso perdía la trazabilidad por ejercicio:
    si algún día sigues un plan sobre "plancha" (subir el tiempo cada
    semana), esa sesión combinada nunca contaría, porque
    PlanItem busca WorkoutSession.exercise="plank", no "ab-circuit".
    Guardando una por ejercicio, cualquier plan que siga alguno de ellos
    avanza solo — igual que ya hacía la app móvil.

    La tarea del día se completa siempre que termines el circuito,
    lleguen o no todos los ejercicios a su objetivo: aquí lo que importa
    es que has entrenado, no que cada ejercicio individual esté a tope.
    El % de cada uno se guarda igualmente, para las estadísticas.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    routine = get_object_or_404(Routine, pk=routine_pk, user=get_current_user())

    try:
        data = json.loads(request.body)
    except (json.JSONDecodeError, TypeError):
        return JsonResponse({"ok": False, "error": "JSON inválido"}, status=400)

    raw_breakdown = data.get("breakdown", [])
    entries = []
    total_seconds = 0
    if isinstance(raw_breakdown, list):
        for b in raw_breakdown:
            if not isinstance(b, dict):
                continue
            slug = str(b.get("exercise", ""))[:32]
            seconds = int(b.get("seconds", 0)) if isinstance(b.get("seconds"), (int, float)) else 0
            reps = int(b.get("reps", 0)) if isinstance(b.get("reps"), (int, float)) else 0
            sets = int(b.get("sets", 0)) if isinstance(b.get("sets"), (int, float)) else 0
            if not slug:
                continue
            entries.append({
                "exercise": slug, "seconds": seconds, "reps": reps, "sets": sets,
                "timing": api._breakdown_timing(b),
            })
            total_seconds += seconds

    if not entries:
        return JsonResponse({"ok": False, "error": "Sin datos que guardar"}, status=400)

    created = []
    for e in entries:
        ctx = resolve_plan_target(e["exercise"])
        created.append(WorkoutSession.objects.create(
            task=task, user=get_current_user(), routine=routine, series_id=task.series_id,
            plan=ctx["plan"], target_sets=ctx["target_sets"],
            target_reps=ctx["target_reps"], target_seconds=ctx["target_seconds"],
            exercise=e["exercise"],
            total_reps=e["reps"], total_sets=e["sets"],
            session_duration_seconds=e["seconds"],
            **e["timing"],
        ))

    api._save_training_session(task, data, created, routine=routine)

    cortas = [w for w in created if not w.target_met]
    resumen = f"Circuito «{routine.name}» completado: {len(created)} ejercicio(s), {total_seconds}s."
    if cortas:
        resumen += " " + ", ".join(f"{w.exercise_name} al {w.achievement_pct}%" for w in cortas) + "."
    messages.success(request, resumen)
    # La tarea se marca hecha en task_cooldown — falta el enfriamiento
    # obligatorio.
    return JsonResponse({"ok": True, "redirect_url": reverse("tasks:task_cooldown", args=[task.pk])})


def stats_list(request):
    summary = {}
    for occ in Occurrence.objects.filter(user=get_current_user()).order_by("recorded_at"):
        s = summary.setdefault(occ.series_id, {
            "title": occ.title, "done": 0, "not_done": 0, "series_id": occ.series_id,
            "pcts": [],
        })
        s["title"] = occ.title
        s["pcts"].append(occ.pct)
        if occ.result == Occurrence.RESULT_DONE:
            s["done"] += 1
        else:
            s["not_done"] += 1

    series_list = list(summary.values())
    for s in series_list:
        total = s["done"] + s["not_done"]
        s["total"] = total
        # % cumplido = media del % de cada día (no solo hecho/no hecho).
        s["success_rate"] = round(sum(s["pcts"]) / len(s["pcts"])) if s["pcts"] else 0
        s["bar_pct"] = min(100, s["success_rate"])
        streaks = Occurrence.streak_stats(s["series_id"])
        s["current_streak"] = streaks["current_streak"]
        s["max_streak"] = streaks["max_streak"]
    series_list.sort(key=lambda s: s["total"], reverse=True)

    return render(request, "tasks/stats_list.html", {
        "series_list": series_list,
        "weekly": Occurrence.weekly_completion(get_current_user()),
        "daily": Occurrence.daily_completion(get_current_user()),
        "time_buckets": time_stats.time_totals(get_current_user()),
        "kcal": _kcal_totals(get_current_user()),
    })


def _kcal_totals(user):
    """Calorías aproximadas de hoy y de esta semana (lunes-domingo), sumando
    WorkoutSession.calories_kcal, más el peso con el que se estiman."""
    today = timezone.localtime(timezone.now()).date()
    week_start = today - _dt.timedelta(days=today.weekday())
    qs = WorkoutSession.objects.filter(
        user=user, deleted_at__isnull=True, calories_kcal__isnull=False,
        recorded_at__date__gte=week_start, recorded_at__date__lte=week_start + _dt.timedelta(days=6),
    )
    week = today_kcal = 0.0
    for recorded_at, kcal in qs.values_list("recorded_at", "calories_kcal"):
        week += kcal
        if timezone.localtime(recorded_at).date() == today:
            today_kcal += kcal
    weight, is_default = calories.body_weight_for(user)
    return {
        "today": round(today_kcal), "week": round(week),
        "weight": f"{weight:g}", "default_weight": is_default,
    }


def settings_page(request):
    """Ajustes personales: de momento el peso corporal (para las calorías)."""
    user = get_current_user()
    if request.method == "POST":
        raw = (request.POST.get("body_weight_kg") or "").strip().replace(",", ".")
        if raw == "":
            UserSettings.objects.update_or_create(user=user, defaults={"body_weight_kg": None})
            messages.success(request, "Peso borrado — se usarán 70 kg por defecto.")
            return redirect(reverse("tasks:settings"))
        try:
            kg = float(raw)
        except ValueError:
            kg = None
        if kg is None or not (30 <= kg <= 300):
            messages.error(request, "Pon un peso válido en kg (entre 30 y 300).")
            return redirect(reverse("tasks:settings"))
        from . import profile as _profile
        if kg != _profile.get_settings(user).body_weight_kg:
            _profile.log_weight(user, kg)
        UserSettings.objects.update_or_create(user=user, defaults={"body_weight_kg": kg})
        messages.success(request, f"Peso guardado: {kg:g} kg. Se usará en las sesiones nuevas "
                                  "(las antiguas se recalculan con «manage.py backfill_calories --all»).")
        return redirect(reverse("tasks:settings"))
    weight, is_default = calories.body_weight_for(user)
    return render(request, "tasks/settings.html", {
        "body_weight_kg": "" if is_default else f"{weight:g}",
        "default_weight_kg": f"{calories.DEFAULT_BODY_WEIGHT_KG:g}",
    })


def profile_page(request):
    """Perfil: nombre, avatar y datos corporales (nacimiento, altura, peso, peso objetivo)."""
    from . import profile
    user = get_current_user()
    if request.method == "POST":
        posted = {k: request.POST.get(k, "") for k in profile.FORM_FIELDS}
        ok, errors = profile.apply_profile(user, posted)
        if ok:
            messages.success(request, "Perfil guardado.")
            return redirect(reverse("tasks:profile"))
        for msg in errors.values():
            messages.error(request, msg)
        data = profile.profile_data(user)
        # Que no se pierda lo escrito al fallar la validación.
        data.update({k: v for k, v in posted.items() if v != "" or k not in ("avatar_emoji", "avatar_color")})
    else:
        data = profile.profile_data(user)
    return render(request, "tasks/profile.html", {
        "p": data,
        "emojis": profile.AVATAR_EMOJIS,
        "colors": profile.AVATAR_COLORS,
        "name_max": profile.DISPLAY_NAME_MAX,
        "default_weight_kg": f"{calories.DEFAULT_BODY_WEIGHT_KG:g}",
        "today": timezone.localdate().isoformat(),
    })


def _stats_chart_points(occurrences, limit=60):
    """
    Un punto por día de la tarea, en orden cronológico, para la gráfica de
    stats_detail. Lleva lo que enseña el tooltip al pasar el ratón: fecha,
    % guardado ese día (Occurrence.completion_pct: media de todos los
    ejercicios; un día sin hacer = 0), si se hizo o caducó, y el desglose
    por ejercicio (mejor sesión de cada uno, igual que Task.day_completion_pct).
    """
    occs = list(occurrences)[::-1][-limit:]  # occurrences viene de más nuevo a más viejo
    task_ids = {o.task_id for o in occs if o.task_id}
    by_task = {}
    names = {}
    kcal_by_task = {}   # kcal del día: se SUMAN todas las sesiones (a diferencia del %, que usa la mejor)
    kcal_by_exercise = {}
    if task_ids:
        for ws in WorkoutSession.objects.filter(task_id__in=task_ids, deleted_at__isnull=True).order_by("recorded_at"):
            if ws.calories_kcal:
                kcal_by_task[ws.task_id] = kcal_by_task.get(ws.task_id, 0) + ws.calories_kcal
                key = (ws.task_id, ws.exercise)
                kcal_by_exercise[key] = kcal_by_exercise.get(key, 0) + ws.calories_kcal
            pct = ws.achievement_pct
            if pct is None:
                continue
            if ws.exercise not in names:
                names[ws.exercise] = ws.exercise_name
            if ws.distance_km is not None:
                hecho = f"{ws.distance_km:g} km"
            elif ws.target_seconds and not ws.target_reps:
                hecho = f"{ws.session_duration_seconds} s"
            else:
                hecho = f"{ws.total_reps} reps"
            row = by_task.setdefault(ws.task_id, {})
            if ws.exercise not in row or pct >= row[ws.exercise]["pct"]:
                row[ws.exercise] = {
                    "name": names[ws.exercise], "pct": pct, "done": hecho,
                    "target": ws.target_label or "",
                    "slug": ws.exercise,
                }
        timers = {}
        for ts in TimerSession.objects.filter(task_id__in=task_ids, deleted_at__isnull=True).select_related("task"):
            timers.setdefault(ts.task_id, []).append(ts)
        for task_id, group in timers.items():
            target = group[0].task.target_minutes or max((g.target_minutes or 0 for g in group), default=0)
            if not target:
                continue
            total = sum(g.minutes for g in group)
            by_task.setdefault(task_id, {})["__timer__"] = {
                "name": group[0].subcategory_label, "pct": round(100 * total / target),
                "done": f"{total} min", "target": f"{target} min",
            }
    for task_id, row in by_task.items():
        for ex in row.values():
            kcal = kcal_by_exercise.get((task_id, ex.get("slug")))
            ex["kcal"] = round(kcal) if kcal else None
    points = []
    for o in occs:
        day = o.due_date or timezone.localtime(o.recorded_at).date()
        points.append({
            "kcal": round(kcal_by_task[o.task_id]) if o.task_id in kcal_by_task else None,
            "label": day.strftime("%d/%m"),
            "date": day.isoformat(),
            "pct": o.pct,
            "done": o.result == Occurrence.RESULT_DONE,
            "auto": o.auto_expired,
            "minutes_watched": o.minutes_watched,
            "exercises": list(by_task.get(o.task_id, {}).values()) if o.task_id else [],
        })
    return points


def stats_detail(request, series_id):
    occurrences = Occurrence.objects.filter(
        series_id=series_id, user=get_current_user()
    ).order_by("-recorded_at")
    if not occurrences.exists():
        messages.error(request, "No hay estadísticas para esa tarea.")
        return redirect(reverse("tasks:stats_list"))

    title = occurrences.first().title
    done_count = occurrences.filter(result=Occurrence.RESULT_DONE).count()
    not_done_count = occurrences.filter(result=Occurrence.RESULT_NOT_DONE).count()
    success_rate = Occurrence.average_pct(occurrences)
    streaks = Occurrence.streak_stats(series_id)
    chart_points = _stats_chart_points(occurrences)
    occurrences = list(occurrences)
    kcal_by_task = {}
    for task_id, kcal in WorkoutSession.objects.filter(
        task_id__in=[o.task_id for o in occurrences if o.task_id],
        deleted_at__isnull=True, calories_kcal__isnull=False,
    ).values_list("task_id", "calories_kcal"):
        kcal_by_task[task_id] = kcal_by_task.get(task_id, 0) + kcal
    for o in occurrences:
        o.kcal = round(kcal_by_task[o.task_id]) if o.task_id in kcal_by_task else None
    total_kcal = sum(o.kcal for o in occurrences if o.kcal)

    return render(request, "tasks/stats_detail.html", {
        "chart_points": chart_points,
        "title": title,
        "series_id": series_id,
        "occurrences": occurrences,
        "total_kcal": total_kcal,
        "done_count": done_count,
        "not_done_count": not_done_count,
        "success_rate": success_rate,
        "current_streak": streaks["current_streak"],
        "max_streak": streaks["max_streak"],
    })


@require_POST
def stats_delete_all(request):
    """Borra TODAS las estadísticas (todas las Occurrence) del usuario —
    botón "Borrar todas las estadísticas" en stats_list.html."""
    Occurrence.objects.filter(user=get_current_user()).delete()
    messages.success(request, "Estadísticas eliminadas.")
    return redirect(reverse("tasks:stats_list"))


@require_POST
def stats_delete_series(request, series_id):
    """Borra las estadísticas de una sola tarea/serie — botón "Borrar
    estas estadísticas" en stats_detail.html."""
    Occurrence.objects.filter(series_id=series_id, user=get_current_user()).delete()
    messages.success(request, "Estadísticas de la tarea eliminadas.")
    return redirect(reverse("tasks:stats_list"))


# ─────────────────────────────────────────────────────────────────────
# Planes de progresión
# ─────────────────────────────────────────────────────────────────────

# Contadores que existen de verdad en workout.js.
COUNTERS = {"superman", "lsit", "elephantsteps", "burpee", "pullup", "dip", "pushup", "squat", "splitsquat", "crunch", "legraise", "highlegraise", "situp", "doublecrunch", "scissor", "archerpullup", "inclinepushup", "pikepushup", "dumbbellcurl", "jumpingjack", "benchdip", "armcircles", "necklateral", "armscissors", "legrotation", "kneeraises", "heelkicks", "hiplateral", "neckcircles", "neckhalfturn", "neckturn", "forearmrotation", "hipforwardback", "scapularpull", "handstandpushup", "pistolsquat"}

# Ejercicios "timed" (se aguantan, no se cuentan en repeticiones) que
# workout.js sabe seguir con cámara comprobando la postura — plancha,
# plancha lateral, silla en pared, kneehold en barra y pino. Ver
# task_workout: a estos, a diferencia del resto de "timed" (bicicleta…),
# sí se les deja entrar en el entreno individual de una tarea con cámara
# encendida, no solo dentro de un circuito.
POSTURE_COUNTERS = {"supermanhold", "lsithold", "plank", "sideplank", "wallsit", "kneeholdbar", "tucklever", "deadhang", "handstand", "armcrossstretch", "tricepsoverheadstretch", "seatedhamstringstretch", "standingquadstretch", "elephantstepshold"}


def _plans_qs():
    return Plan.objects.filter(user=get_current_user(), deleted_at__isnull=True)


def plan_list(request):
    """
    Los planes, con su medida principal y cuánto llevas -- agrupados por
    categoría (Deporte/Estudio/General, más Lectura aparte), cada grupo
    en su propio desplegable (ver plan_list.html, mismo patrón <details>
    sin JS que ya usaba "Planes cerrados"). Antes Deporte/Estudio/General
    iban todos mezclados en una lista plana bajo "Progresión" sin
    distinguirse por tipo -- pensado para cuando esto tenga muchos
    usuarios con muchos planes a la vez (ver strive-producto), que no se
    pierdan entre una lista larga sin ninguna separación.
    """
    by_type = {key: [] for key, _ in Plan.PLAN_TYPE_CHOICES}
    for p in _plans_qs().filter(closed_at__isnull=True):
        head = p.headline
        by_type[p.plan_type].append({
            "plan": p,
            "headline": head,
            "target": head.current_target() if head else None,
            "remaining": head.sessions_to_goal() if head else None,
            "progress": p.progress_pct(),
        })
    # Un grupo por categoría, en el mismo orden que PLAN_TYPE_CHOICES --
    # y solo si tiene algo dentro, para no enseñar un desplegable vacío
    # de "Estudio" a quien nunca ha creado uno.
    plan_groups = [
        {"key": key, "label": label, "items": by_type[key]}
        for key, label in Plan.PLAN_TYPE_CHOICES if by_type[key]
    ]

    closed_by_type = {key: [] for key, _ in Plan.PLAN_TYPE_CHOICES}
    for p in _plans_qs().filter(closed_at__isnull=False).order_by("-closed_at"):
        closed_by_type[p.plan_type].append({"plan": p, "progress": p.final_progress_pct})
    closed_plan_groups = [
        {"key": key, "label": label, "items": closed_by_type[key]}
        for key, label in Plan.PLAN_TYPE_CHOICES if closed_by_type[key]
    ]
    # Planes borrados (borrado suave, deleted_at): solo para que se vea
    # cuántos se han borrado y con qué progreso. Sin enlace a la ficha
    # (plan_detail solo abre planes no borrados).
    deleted_by_type = {key: [] for key, _ in Plan.PLAN_TYPE_CHOICES}
    for p in Plan.objects.filter(user=get_current_user(), deleted_at__isnull=False).order_by("-deleted_at"):
        progress = p.final_progress_pct if p.closed_at else p.progress_pct()
        deleted_by_type[p.plan_type].append({"plan": p, "progress": progress})
    deleted_plan_groups = [
        {"key": key, "label": label, "items": deleted_by_type[key]}
        for key, label in Plan.PLAN_TYPE_CHOICES if deleted_by_type[key]
    ]
    # Lectura no es un Plan de verdad (vive aparte en Task.reading_mode=
    # 'plan', ver el comentario junto a ese campo en models.py) -- pero
    # para quien lo crea, es un plan igual que los demás, y no aparecía
    # aquí para nada. Se enseña en su propia sección, con lo suyo (ritmo,
    # % leído), en vez de forzarlo en las tarjetas de Plan de verdad, que
    # esperan campos que un plan de lectura no tiene (semanas, objetivo
    # con series/repeticiones...).
    reading_qs = Task.objects.filter(
        user=get_current_user(), category=Task.CATEGORY_WORK, subcategory=Task.SUBCATEGORY_READING,
        reading_mode=Task.READING_MODE_PLAN, deleted_at__isnull=True,
    )
    # UNA tarjeta por plan, no una por cada día: un plan de lectura es una
    # serie de tareas diarias (una fila por día, ver Task._spawn_next), y
    # listarlas todas enseñaba el plan repetido -- la del día ya hecho y la
    # de hoy, con el mismo título. Eso invitaba a borrar "la repetida", y
    # borrar la instancia pendiente acaba con el plan entero (nadie
    # genera ya la siguiente). Se queda la más reciente de cada serie, y
    # es esa la que decide si el plan está abierto o terminado.
    latest_by_series = {}
    for t in reading_qs.order_by("-due_date", "-pk"):
        latest_by_series.setdefault(t.series_id, t)
    latest = list(latest_by_series.values())
    reading_plans = [
        {"task": t, "status": t.reading_plan_status}
        for t in sorted((t for t in latest if not t.reading_completed_at), key=lambda t: t.title)
    ]
    closed_reading_plans = [
        {"task": t, "status": t.reading_plan_status}
        for t in sorted((t for t in latest if t.reading_completed_at), key=lambda t: t.reading_completed_at, reverse=True)
    ]
    return render(request, "tasks/plan_list.html", {
        "plan_groups": plan_groups, "closed_plan_groups": closed_plan_groups,
        "deleted_plan_groups": deleted_plan_groups,
        "deleted_plans_count": sum(len(g["items"]) for g in deleted_plan_groups),
        "reading_plans": reading_plans, "closed_reading_plans": closed_reading_plans,
        "closed_plans_count": (
            sum(len(g["items"]) for g in closed_plan_groups) + len(closed_reading_plans)
        ),
    })


def challenges_list(request):
    """
    Retos de un solo intento (Bring Sally Up, 100 dominadas...) — sin
    progresión semanal detrás, a diferencia de un Plan (ver plan_list).
    Viven colgados de Planes (un enlace más en plan_list.html) para no
    meter una entrada nueva en el menú principal.

    v1: todo se juega en el navegador — nada se guarda en el backend
    todavía (solo la mejor marca en localStorage de este navegador, ver
    static/js/challenges.js). Si esto cuaja, el siguiente paso natural
    es un endpoint de guardado como routine_save/plan_session_save, para
    que aparezca también en el histórico real de la cuenta.
    """
    return render(request, "tasks/challenges_list.html")


def challenge_sally_pushups(request):
    """
    Réplica del reto viral "Bring Sally Up" con flexiones, SIN la
    canción real de Moby (derechos de autor) — una voz propia marca
    "Sube y aguanta" / "Baja y aguanta" con un guion de cadencia propio
    (ver SALLY_* en challenges.js). Toda la lógica de cámara/postura
    vive en ese archivo; esta vista solo pone la página.
    """
    return render(request, "tasks/challenge_sally_pushups.html")


def challenge_pullups_100(request):
    """100 dominadas acumuladas, en las series que quieras, con
    descanso obligatorio entre serie y serie — ver challenges.js."""
    return render(request, "tasks/challenge_pullups_100.html")


def challenge_cindy(request):
    """Cindy workout (Tom Holland): 5 dominadas -> 10 flexiones -> 15
    sentadillas en bucle durante 20 min, mínimo por ronda, más si quieres.
    Flexiones y sentadillas se cuentan de frente (pushupfront/squatfront
    en workout.js). Todo en el navegador — ver challenges.js."""
    return render(request, "tasks/challenge_cindy.html")


def weekly_review(request):
    """
    La revisión semanal del 12 Week Year: cómo ha ido la semana en
    conjunto y en cada objetivo activo, en una sola pantalla — en vez
    de tener que entrar plan a plan para hacerse una idea de conjunto.
    """
    plans = []
    for p in _plans_qs().filter(is_active=True):
        plans.append({
            "plan": p,
            "weekly": p.weekly_completion(),
            "progress": p.progress_pct(),
        })
    return render(request, "tasks/weekly_review.html", {
        "weekly": Occurrence.weekly_completion(get_current_user()),
        "daily": Occurrence.daily_completion(get_current_user()),
        "plans": plans,
    })


# Colores de las líneas de la gráfica de "al fallo" (ver _failure_chart).
# Vars del tema donde hay (se adaptan a oscuro/claro) + tonos fijos
# distinguibles entre sí para cuando hay más ejercicios que vars.
_CHART_COLORS = [
    "var(--ember)", "var(--gold)", "#4FA3C7", "#8DB654",
    "#B47CCB", "var(--amber)", "#D9627A", "#5FBFA6",
]


def _epley(load_kg, reps):
    """
    Fuerza estimada (1RM de Epley): carga × (1 + reps / 30). Pondera peso
    y repeticiones a la vez, así que 8 reps con +5 kg puntúan más que 8
    reps sin lastre, y 6 reps con +10 kg más que 8 con +5 kg si la carga
    extra compensa las reps perdidas. Se aplica a las reps medias por
    serie de la sesión, para que mejorar en cualquier serie se note.
    """
    return load_kg * (1 + reps / 30.0)


def _fmt_kg(x):
    return f"{x:g}"


# Alto de cada fila de la franja: título, barras (kg) y la línea de números (reps).
_STRIP_LABEL_Z, _STRIP_BAR_Z, _STRIP_NUM_Z, _STRIP_ROW_GAP = 11, 26, 13, 9
_STRIP_ROW_H = _STRIP_LABEL_Z + _STRIP_BAR_Z + _STRIP_NUM_Z


def _weight_strip(lines, X, xi, pw, n, top):
    """
    Franja de "peso" dentro de la misma gráfica de progreso: bajo las
    líneas, una fila por ejercicio con peso, con el mismo eje x (fechas)
    que las líneas. En cada sesión, una barra con los kg que tocaban (los
    del plan en ese momento) y encima el número de reps que hiciste con
    ellos. Así se ve a la vez la subida de kg y cómo mejoran las reps con
    cada peso (caen al subir el peso y vuelven a subir).

    Cada fila usa su propia escala: la barra llena es su peso objetivo (o,
    sin meta, el máximo que has usado), porque dominadas con +10 kg y
    sentadillas con +60 kg no caben en la misma escala. Una línea
    punteada marca el peso objetivo y el título de la fila lo dice.

    "line" es la posición del ejercicio en chart["lines"] (el Total es la
    0), para que tocar su nombre en la leyenda resalte también su fila.
    """
    weighted = [(pos, l) for pos, l in enumerate(lines, start=1) if l["weighted"]]
    bw = round(max(6.0, min(22.0, pw / max(n, 1) * 0.55)), 1)
    hit_w = max(bw, 10.0)
    show_all = (pw / max(n - 1, 1)) >= 20  # caben todos los números sin pisarse
    groups = []
    for k, (pos, l) in enumerate(weighted):
        row_top = top + k * (_STRIP_ROW_H + _STRIP_ROW_GAP)
        base = round(row_top + _STRIP_LABEL_Z + _STRIP_BAR_Z, 1)
        dates = sorted(l["pts"])
        kgs = [l["pts"][d]["kg"] for d in dates]
        goal = l["goal_kg"]
        ymax = max(max(kgs), goal or 0, 1.0)
        bars, prev = [], None
        for d in dates:
            p = l["pts"][d]
            kg = p["kg"]
            bh = max(2.5, _STRIP_BAR_Z * kg / ymax) if kg > 0 else 1.5
            tip = f"{l['name']} · {d.strftime('%d/%m')} — "
            tip += f"{'-'.join(str(r) for r in p['sets'])} ({p['reps']} reps)" if p["sets"] else f"{p['reps']} reps"
            tip += f" con +{_fmt_kg(kg)} kg" if kg > 0 else " sin lastre"
            if goal:
                tip += f" · meta +{_fmt_kg(goal)} kg"
            if p["up"]:
                tip += f" · subiste el peso (+{_fmt_kg(round(kg - prev, 2))} kg)"
            x = X(xi[d])
            bars.append({
                "x": round(x - bw / 2, 1), "cx": x, "y": round(base - bh, 1), "h": round(bh, 1), "w": bw,
                "hit_x": round(x - hit_w / 2, 1), "hit_w": hit_w,
                "zero": kg <= 0, "up": p["up"], "tip": tip,
                "label": str(p["reps"]) if (show_all or p["up"] or d in (dates[0], dates[-1])) else None,
                "label_y": round(base + 11, 1),
            })
            prev = kg
        name = l["name"] if len(l["name"]) <= 24 else l["name"][:23] + "…"
        groups.append({
            "line": pos, "color": l["color"], "bars": bars,
            "top": round(row_top, 1), "base": base, "bar_zone": _STRIP_BAR_Z,
            "zone_top": round(base - _STRIP_BAR_Z, 1),
            "title": f"{name} · meta +{_fmt_kg(goal)} kg" if goal else name,
            "title_y": round(row_top + 8, 1), "nums_y": round(base + 11, 1),
            "ymax_label": _fmt_kg(ymax), "has_goal": bool(goal),
        })
    return {
        "top": round(top, 1), "h": len(weighted) * _STRIP_ROW_H + (len(weighted) - 1) * _STRIP_ROW_GAP,
        "base": groups[-1]["base"], "groups": groups, "row_h": _STRIP_ROW_H,
        "has_goal": any(l["goal_kg"] for _, l in weighted),
    }


def _failure_chart(plan):
    """
    Gráfica de progreso de un plan con ejercicios "al fallo": en estos
    la barra de logro (series hechas / pedidas) siempre da 100% y no
    enseña lo único que de verdad mejora, las repeticiones.

    Cada ejercicio es una línea en % de SU propia base (100% = media de
    sus 2 primeras sesiones, para que un mal primer día no falsee todo),
    así dominadas (8 reps) y sentadillas (40) caben en el mismo eje.

    Qué se mide en cada línea:
      - Ejercicio sin lastre: las repeticiones totales del día.
      - Ejercicio CON peso (alguna sesión con kg añadidos): la fuerza
        estimada de la sesión (_epley, con peso corporal +
        kg añadidos) con las reps medias por serie de la sesión. Contar
        solo reps o reps × kg haría caer la línea
        cada vez que el plan sube el peso (al subir kg las reps vuelven
        a la parte baja del rango aunque estés más fuerte).

    La línea gruesa es el total: media de los % de los ejercicios que se
    hicieron ESE día, ponderada por las reps base de cada uno (si un día
    faltó uno, no se compara contra lo que nunca se pidió).

    Cada punto sabe si ese día subiste el peso (up) para marcarlo.

    Devuelve None si no hay objetivos al fallo. Si hay menos de 2 días
    con sesión devuelve {"ready": False, ...} (con una sola sesión todo
    sería 100% y no hay nada que dibujar).

    La geometría (coordenadas SVG) se calcula aquí, no en la plantilla.
    """
    items = [i for i in plan.ordered_items() if i.progression == PlanItem.PROG_FAILURE and i.exercise_id]
    if not items:
        return None

    body_kg, _ = calories.body_weight_for(plan.user)

    # {item.pk: {date: {"reps": int, "kg": float, "score": float, "sets": [reps por serie]}}}
    # "kg" = mayor peso añadido ese día; "score" = mejor fuerza estimada.
    per_item = {}
    for it in items:
        days = {}
        for s in it._sessions():
            d = s.recorded_at.astimezone(timezone.get_current_timezone()).date() if timezone.is_aware(s.recorded_at) else s.recorded_at.date()
            slot = days.setdefault(d, {"reps": 0, "kg": 0.0, "score": 0.0, "sets": []})
            added = max(0.0, float(s.added_weight_kg or 0))
            # Solo series de repeticiones: las de aguante ({"reps": 0,
            # "durations": [...]}) no pintan "0-0" en el tooltip.
            reps_sets = [x.get("reps", 0) for x in (s.sets or []) if isinstance(x, dict) and (x.get("reps") or 0) > 0]
            slot["reps"] += s.total_reps or 0
            slot["kg"] = max(slot["kg"], added)
            slot["sets"] += reps_sets
            avg_reps = sum(reps_sets) / len(reps_sets) if reps_sets else ((s.total_reps or 0) / max(1, s.total_sets or 1))
            slot["score"] = max(slot["score"], _epley(body_kg + added, avg_reps))
        if days:
            per_item[it.pk] = days

    all_dates = sorted({d for days in per_item.values() for d in days})
    if len(all_dates) < 2:
        return {"ready": False, "n_dates": len(all_dates)}

    lines = []  # una entrada por ejercicio: puntos en %
    for idx, it in enumerate(i for i in items if i.pk in per_item):
        days = per_item[it.pk]
        ds = sorted(days)
        weighted = any(days[d]["kg"] > 0 for d in ds)
        key = "score" if weighted else "reps"
        base = sum(days[d][key] for d in ds[:2]) / len(ds[:2])
        if base <= 0:
            continue
        base_reps = sum(days[d]["reps"] for d in ds[:2]) / len(ds[:2])
        pts, prev_kg = {}, None
        for d in ds:
            p = days[d]
            pts[d] = {
                "pct": 100.0 * p[key] / base, "reps": p["reps"], "kg": p["kg"], "sets": p["sets"],
                "up": bool(weighted and prev_kg is not None and p["kg"] > prev_kg + 1e-9),
            }
            prev_kg = p["kg"]
        kg_label = None
        if weighted:
            first, last = days[ds[0]]["kg"], days[ds[-1]]["kg"]
            end = f"+{_fmt_kg(last)}" if last > 0 else "0"
            if first != last:
                kg_label = f"{'+' + _fmt_kg(first) if first > 0 else '0'} → {end} kg"
            elif last > 0:
                kg_label = f"{end} kg"
        lines.append({
            "name": it.display_name,
            "color": _CHART_COLORS[idx % len(_CHART_COLORS)],
            "base_reps": max(base_reps, 1.0),
            "weighted": weighted, "kg_label": kg_label, "pts": pts,
            "goal_kg": it.goal_weight_kg if (weighted and it.goal_weight_kg) else None,
            "start_kg": it.start_weight_kg or 0.0,
            "last_kg": days[ds[-1]]["kg"],
        })
    if not lines:
        return {"ready": False, "n_dates": len(all_dates)}

    total = {}
    for d in all_dates:
        done = [l for l in lines if d in l["pts"]]
        if not done:
            continue
        den = sum(l["base_reps"] for l in done)
        total[d] = {
            "pct": sum(l["pts"][d]["pct"] * l["base_reps"] for l in done) / den,
            "reps": sum(l["pts"][d]["reps"] for l in done), "kg": 0.0, "sets": [], "up": False,
        }

    vals = [p["pct"] for l in lines for p in l["pts"].values()] + [p["pct"] for p in total.values()]
    lo = min(90, int(min(vals) // 10) * 10)
    hi = max(120, int(-(-max(vals) // 10)) * 10)

    # Si hay ejercicios con peso, bajo las líneas va una franja con los kg
    # añadidos en cada sesión (mismas fechas, mismo eje x).
    has_weight = any(l["weighted"] for l in lines)
    n_rows = sum(1 for l in lines if l["weighted"])
    strip_h = n_rows * _STRIP_ROW_H + max(0, n_rows - 1) * _STRIP_ROW_GAP
    strip_gap = 12 if has_weight else 0
    W = 520
    L, R, T, B = 42, 12, 12, 28
    ph = 250 - T - B  # alto del área de líneas
    H = T + ph + strip_gap + strip_h + B
    pw = W - L - R
    n = len(all_dates)

    def X(i):
        return round(L + (pw * i / (n - 1)), 1)

    def Y(v):
        return round(T + ph * (1 - (v - lo) / (hi - lo)), 1)

    xi = {d: i for i, d in enumerate(all_dates)}

    def build(name, color, pts, thick, weighted=False, kg_label=None, goal_kg=None, start_kg=0.0, last_kg=0.0):
        dots = []
        last_d = max(pts)
        for d in sorted(pts):
            p = pts[d]
            tip = f"{name} · {d.strftime('%d/%m')}"
            if p["sets"]:
                tip += f" — {'-'.join(str(r) for r in p['sets'])} ({p['reps']} reps)"
            if p["kg"] > 0:
                tip += f" · +{_fmt_kg(p['kg'])} kg"
            tip += f" · {round(p['pct'])}%"
            if p["up"]:
                tip += " · subiste el peso"
            y = Y(p["pct"])
            dots.append({"x": X(xi[d]), "y": y, "y_up": round(y - 6, 1), "tip": tip, "up": p["up"], "last": d == last_d})
        delta = round(pts[last_d]["pct"]) - 100
        # Progreso hacia el peso objetivo: del peso de partida de ese
        # objetivo (start_weight_kg) a la meta (goal_weight_kg), con el
        # último peso usado. None si no hay meta.
        progress = goal_text = None
        if goal_kg:
            span = goal_kg - start_kg
            progress = 100 if last_kg >= goal_kg else max(0, min(99, int(100 * (last_kg - start_kg) / span))) if span > 0 else 0
            goal_text = (f"✓ meta +{_fmt_kg(goal_kg)} kg conseguida" if progress >= 100
                         else f"{progress}% · faltan {_fmt_kg(round(goal_kg - last_kg, 2))} kg para +{_fmt_kg(goal_kg)}")
        return {
            "name": name, "color": color, "thick": thick, "dots": dots,
            "points": " ".join(f"{q['x']},{q['y']}" for q in dots),
            "last": round(pts[last_d]["pct"]),
            "delta": f"{'+' if delta > 0 else '−' if delta < 0 else ''}{abs(delta)}%",
            "trend": "up" if delta > 0 else "down" if delta < 0 else "flat",
            "kg_label": kg_label,
            "goal_kg": _fmt_kg(goal_kg) if goal_kg else None,
            "progress": progress, "goal_text": goal_text,
        }

    out_lines = [build("Total", "var(--bone)", total, True)]
    out_lines += [build(l["name"], l["color"], l["pts"], False, l["weighted"], l["kg_label"], l["goal_kg"], l["start_kg"], l["last_kg"]) for l in lines]

    step = 20 if hi - lo > 60 else 10
    yticks = [{"y": Y(v), "label": f"{v}%", "base": v == 100} for v in range(lo, hi + 1, step)]
    # Como mucho ~6 etiquetas de fecha para que no se pisen.
    every = max(1, -(-n // 6))
    xticks = [{"x": X(i), "label": all_dates[i].strftime("%d/%m")} for i in range(0, n, every)]

    strip = _weight_strip(lines, X, xi, pw, n, T + ph + strip_gap) if has_weight else None

    return {
        "ready": True, "w": W, "h": H, "left": L, "right": W - R, "top": T, "bottom": H - B,
        "ref_y": Y(100), "zone_w": pw, "zone_h": max(0, round(Y(100) - T, 1)), "yticks": yticks, "xticks": xticks, "lines": out_lines,
        "has_weight": has_weight, "strip": strip,
        "has_up": any(p["up"] for l in lines for p in l["pts"].values()),
    }


def plan_detail(request, pk):
    """
    La pantalla del plan: dónde estás, qué te toca hoy, el camino que
    queda y lo que ya hiciste.
    """
    plan = get_object_or_404(_plans_qs(), pk=pk)

    def _pack(item):
        # La tabla tiene que llegar hasta el destino. Con un número fijo
        # se cortaba antes de tiempo — un objetivo de 4x12 con 20 kg son
        # 35 escalones — y no se veía el final, que es lo que da sentido
        # a todo. El tope es solo una red de seguridad.
        remaining = item.sessions_to_goal()
        _sessions_to_next_step = item.sessions_to_next_step()
        if remaining is not None:
            rows = min(120, item.current_step() + remaining // max(1, item.sessions_per_step) + 2)
        elif item.is_flat:
            # Sin destino Y el objetivo no cambia (running "sin
            # progresión", o cualquier otra progresión sin meta puesta):
            # con una fila basta, el tope de 60 de más abajo es para
            # progresiones que SÍ siguen cambiando sin límite.
            rows = 1
        else:
            rows = 60
        return {
            "item": item,
            "target": item.current_target(),
            "step": item.current_step(),
            "remaining": remaining,
            # Lo que aporta ESTE objetivo al % del plan (Plan.progress_pct()
            # ahora promedia esto de todos, no solo de la medida principal)
            # — se enseña aquí para que se vea de dónde sale el número de
            # arriba, en vez de que parezca sacado de la nada.
            "own_progress": item.own_progress_pct(),
            "schedule": item.schedule(rows),
            "history": item.history(12),
            # Cuántas sesiones cumplidas más hacen falta para el
            # siguiente escalón (None en cumplimiento, donde no aplica) —
            # sin esto, entre escalón y escalón no había ninguna señal de
            # que las sesiones de sobra estuvieran contando para algo.
            # `sessions_into_step` es la cuenta ya hecha del par, lista
            # para pintar "X de Y sesiones" sin hacer aritmética en la
            # plantilla.
            "sessions_to_next_step": _sessions_to_next_step,
            "sessions_into_step": (
                item.sessions_per_step - _sessions_to_next_step
                if _sessions_to_next_step is not None else None
            ),
            # Si el entrenador ha bajado un escalón conviene decirlo: si
            # no, parece que la app se ha equivocado.
            "deloaded": item.successes_and_streak()[1] >= item.deload_after_failures > 0,
        }

    # Estudio · Idiomas no tiene PlanItem — el temario es la lista de
    # CourseModule, así que la pantalla se arma distinto: en vez de la
    # medida principal + objetivos, se enseña el progreso del curso y
    # qué vídeo toca ahora.
    is_language = plan.plan_type == Plan.PLAN_TYPE_STUDY and plan.study_subtype == Plan.STUDY_SUBTYPE_LANGUAGE
    # Estudio · Hábito simple: el vídeo/playlist/temporizador se edita
    # desde "Editar plan" (ver views.plan_form), no con un botón aparte
    # de "+ Añadir objetivo" — ese solo tiene sentido en Deporte, donde
    # puede haber varios ejercicios.
    is_study_general = plan.plan_type == Plan.PLAN_TYPE_STUDY and not is_language
    course_progress = plan.course_progress() if is_language else None

    if plan.plan_type == Plan.PLAN_TYPE_SPORT:
        # Deporte: sin ejercicio "estrella" -- todos en la misma lista,
        # cada uno con sus flechas para subir/bajar.
        head = None
        supports = [_pack(i) for i in plan.ordered_items()]
    else:
        head = plan.headline
        supports = [_pack(i) for i in plan.support_items]
    return render(request, "tasks/plan_detail.html", {
        "plan": plan,
        "headline": _pack(head) if head else None,
        "supports": supports,
        "progress": plan.progress_pct(),
        "failure_chart": _failure_chart(plan),
        "is_language": is_language,
        "is_study_general": is_study_general,
        "course_progress": course_progress,
        "quiz_streaks": plan.quiz_streak_stats() if is_language and plan.quiz_every_n_videos else None,
    })


# ------------------------------------------------- tests de repaso (idiomas)

def _quizzes_qs():
    return CourseQuiz.objects.filter(plan__user=get_current_user())


def quiz_take(request, quiz_uuid):
    """
    Pantalla del test de repaso: preguntas de opción múltiple sobre los
    últimos vídeos vistos de un curso de idioma (ver
    api.maybe_trigger_quiz). NO bloquea nada — el vídeo que lo disparó
    ya se dio por visto antes de llegar aquí; esto es aparte, con su
    propia racha (ver plan_detail.html).
    """
    quiz = get_object_or_404(_quizzes_qs(), uuid=quiz_uuid)
    if quiz.answered_at:
        return redirect(reverse("tasks:quiz_result", args=[quiz.uuid]))

    if request.method == "POST":
        selected = []
        for i in range(len(quiz.questions)):
            raw = request.POST.get(f"q{i}")
            try:
                selected.append(int(raw))
            except (TypeError, ValueError):
                selected.append(-1)
        quiz.answer(selected)
        return redirect(reverse("tasks:quiz_result", args=[quiz.uuid]))

    return render(request, "tasks/quiz_take.html", {"quiz": quiz, "plan": quiz.plan})


def quiz_result(request, quiz_uuid):
    """
    Corrección del test: se arma `review` aquí (no en la plantilla) para
    no necesitar un filtro a medida solo para mirar `quiz.answers[i]` —
    cada opción ya lleva consigo si era la correcta y si fue la elegida.
    """
    quiz = get_object_or_404(_quizzes_qs(), uuid=quiz_uuid)
    if not quiz.answered_at:
        return redirect(reverse("tasks:quiz_take", args=[quiz.uuid]))

    answers = quiz.answers or []
    review = []
    for i, q in enumerate(quiz.questions):
        chosen = answers[i] if i < len(answers) else None
        review.append({
            "question": q.get("question", ""),
            "options": [
                {
                    "text": opt,
                    "is_correct": idx == q.get("correct_index"),
                    "is_chosen": idx == chosen,
                }
                for idx, opt in enumerate(q.get("options") or [])
            ],
        })

    return render(request, "tasks/quiz_result.html", {
        "quiz": quiz, "plan": quiz.plan, "streaks": quiz.plan.quiz_streak_stats(), "review": review,
    })


def plan_ai_form(request):
    """
    Crear un plan de Deporte generándolo automáticamente en vez de
    rellenar el formulario objetivo a objetivo — 100% determinista, sin
    IA de por medio (ver docstring de `api.build_plan_draft`): tú eliges
    nivel físico, foco corporal, equipamiento, semanas y días, y la app
    elige los ejercicios del catálogo que tocan para ese nivel/foco y
    calcula la progresión con matemáticas fijas, no con un modelo de
    lenguaje. Dos pasos, sin guardar nada hasta el final:

      1. El usuario rellena el cuestionario. Al enviarlo se genera el
         borrador (`api.build_plan_draft`, compartida con el endpoint de
         la app móvil) y se enseña para revisar.
      2. El usuario revisa el borrador — puede tocar los números — y lo
         confirma, o pide "generar otra vez" con los mismos filtros.

    Solo Deporte: Estudio y General no pasan por aquí — "Estudio ·
    Idiomas" asigna cursos del catálogo sin IA por su propio camino (ver
    `views.plan_form` → `plan_language_confirm`), y General no tiene
    ningún catálogo del que elegir, así que no hay nada que autogenerar
    — ambos se crean a mano («+ Nuevo plan a mano»).

    El borrador vive en la sesión entre los dos pasos, para que tocar un
    número y confirmar no obligue a recalcular nada.
    """
    step = request.POST.get("step")

    if request.method == "POST" and step in ("generar", "regenerar"):
        weeks = request.POST.get("weeks")
        custom_days = request.POST.getlist("custom_days")

        # Cuestionario — nivel físico, foco corporal, equipamiento, tope
        # de lastre. Con esto la app elige el catálogo (ver
        # `ai._select_sport_exercises`) y los números de partida/meta
        # (ver `ai.default_item_fields`); no hace falta nada más.
        fitness_level = request.POST.get("fitness_level", "")
        focus_area = request.POST.get("focus_area", "")
        no_bar_equipment = request.POST.get("no_bar_equipment") == "on"
        max_load_kg = request.POST.get("max_load_kg", "").strip()
        # Selector manual de ejercicios (ver plan_ai_form.html) — siempre
        # visible, da igual nivel/foco: si el usuario marca algo aquí,
        # sustituye del todo a la elección automática por nivel/zona.
        selected_exercises = request.POST.getlist("exercises")
        # El orden de los checkboxes en el HTML es fijo (agrupados por
        # zona corporal), así que NO refleja el orden real en que se han
        # ido marcando — exercises_order sí lo lleva (lo mantiene el JS del
        # propio formulario, actualizado con cada clic). Se reordena
        # selected_exercises con eso: se filtra por si acaso a lo que sigue
        # marcado de verdad (por si un ejercicio se desactivó al cambiar de
        # foco corporal) y se añade al final cualquier marcado que faltara
        # ahí (JS desactivado, etc.), para no perder ninguna selección
        # aunque en ese caso el orden no sea exacto.
        exercises_order_raw = request.POST.get("exercises_order", "")
        if exercises_order_raw:
            checked = set(selected_exercises)
            ordered = list(dict.fromkeys(
                s for s in exercises_order_raw.split(",") if s in checked
            ))
            missing = [s for s in selected_exercises if s not in ordered]
            selected_exercises = ordered + missing

        draft, error = api.build_plan_draft(
            user=get_current_user(), weeks=weeks, custom_days=custom_days,
            fitness_level=fitness_level, focus_area=focus_area,
            no_bar_equipment=no_bar_equipment, max_load_kg=max_load_kg,
            selected_exercises=selected_exercises,
        )
        if error:
            messages.error(request, error)
            return render(request, "tasks/plan_ai_form.html", {
                "fitness_level_choices": ai.FITNESS_LEVEL_CHOICES,
                "focus_area_choices": ai.FOCUS_AREA_CHOICES,
                "exercise_choices": ai.all_exercise_choices(),
                "weekdays": Task.WEEKDAYS,
                "selected_days": custom_days or ["0", "2", "4"],
                "weeks": weeks or 12,
                "fitness_level": fitness_level,
                "focus_area": focus_area,
                "no_bar_equipment": no_bar_equipment,
                "max_load_kg": max_load_kg,
                "selected_exercises": selected_exercises,
            })
        request.session["plan_ai_draft"] = draft
        return render(request, "tasks/plan_ai_preview.html", {
            "draft": draft,
            "fitness_level": fitness_level, "focus_area": focus_area,
            "no_bar_equipment": no_bar_equipment, "max_load_kg": max_load_kg,
        })

    if request.method == "POST" and step == "recalcular":
        # Recalcula la tabla de progresion de la vista previa sin guardar
        # nada: si el usuario cambia una meta (p.ej. reps de destino de 7
        # a 12) los inputs se actualizan solos pero la tabla "semana a
        # semana" seguia mostrando la que salio de la generacion inicial,
        # porque esa tabla se calculo una sola vez en build_plan_draft y
        # no se volvia a tocar hasta guardar. Aqui se reconstruye cada
        # PlanItem del borrador con los numeros que hay ahora mismo en el
        # formulario, se le pide a ai.apply_pacing (la MISMA funcion que
        # usa la generacion automatica, no una copia en JS que se pudiera
        # desincronizar) que recalcule el incremento por escalon para la
        # nueva meta, y se vuelve a pintar la vista previa con la tabla
        # puesta al dia. El borrador en sesion se sustituye por esta
        # version para que "Guardar plan" y "Generar otra vez" sigan
        # partiendo de los numeros que se acaban de ver.
        draft = request.session.get("plan_ai_draft")
        if not draft:
            messages.error(request, "El borrador ha caducado — genera el plan otra vez.")
            return redirect(reverse("tasks:plan_ai_create"))

        fitness_level = request.POST.get("fitness_level", "")
        focus_area = request.POST.get("focus_area", "")
        no_bar_equipment = request.POST.get("no_bar_equipment") == "on"
        max_load_kg_raw = request.POST.get("max_load_kg", "").strip()
        try:
            max_load_kg = float(max_load_kg_raw) if max_load_kg_raw != "" else None
        except (TypeError, ValueError):
            max_load_kg = None

        weeks = draft["plan_fields"].get("weeks") or 12
        sessions_per_week = max(1, len(draft["plan_fields"].get("custom_days") or []))

        # Nombre/notas se conservan tal cual esten en el formulario — que
        # recalcular la tabla no borre lo que ya se habia escrito ahi.
        draft["plan_fields"]["name"] = request.POST.get("name", draft["plan_fields"].get("name", ""))
        draft["plan_fields"]["notes"] = request.POST.get("notes", draft["plan_fields"].get("notes", ""))
        # Hora y recompensa no forman parte de plan_fields (solo se piden
        # aqui, no las decide la generacion automatica) — se guardan
        # aparte en el borrador solo para que la vista previa no los
        # vacie al recalcular.
        draft["ui_due_time"] = request.POST.get("due_time", draft.get("ui_due_time", ""))
        draft["ui_reward"] = request.POST.get("reward", draft.get("ui_reward", ""))

        draft_plan = Plan(user=get_current_user(), plan_type=draft["plan_type"])

        for idx, item in enumerate(draft.get("items") or []):
            prefix = f"items-{idx}-"
            # Parte de los campos ya calculados (exercise, sessions_per_step,
            # rep_range_low...) y solo pisa los que la vista previa deja
            # tocar — igual que hace "confirmar" al guardar de verdad.
            item_fields = dict(item["fields"])
            for key in (
                "label", "start_sets", "start_reps", "start_seconds", "start_weight_kg",
                "goal_reps", "goal_seconds", "goal_weight_kg", "start_distance_km",
                "start_pace_seconds_per_km", "goal_distance_km", "goal_pace_seconds_per_km",
            ):
                field_name = prefix + key
                if field_name not in request.POST:
                    continue
                raw = request.POST.get(field_name, "").strip()
                item_fields[key] = raw if (raw != "" or key == "label") else None

            exercise = Exercise.objects.filter(slug=item_fields.get("exercise")).first()
            if not exercise:
                continue

            ai.apply_pacing(
                item_fields, exercise=exercise, sessions_per_week=sessions_per_week,
                max_load_kg=max_load_kg,
            )

            draft_item = PlanItem(plan=draft_plan)
            item_error = api._apply_plan_item_fields(draft_item, draft_plan, item_fields)
            if item_error:
                continue  # se deja el objetivo tal como estaba antes de tocarlo

            item["fields"] = item_fields
            item["preview"]["progression"] = draft_item.progression
            item["preview"]["weekly"] = draft_item.weekly_schedule(weeks, sessions_per_week)

        request.session["plan_ai_draft"] = draft
        request.session.modified = True
        return render(request, "tasks/plan_ai_preview.html", {
            "draft": draft,
            "fitness_level": fitness_level, "focus_area": focus_area,
            "no_bar_equipment": no_bar_equipment, "max_load_kg": max_load_kg,
        })

    if request.method == "POST" and step == "confirmar":
        draft = request.session.get("plan_ai_draft")
        if not draft:
            messages.error(request, "El borrador ha caducado — genera el plan otra vez.")
            return redirect(reverse("tasks:plan_ai_create"))

        # Igual que en la tarea suelta (ver task_form/task_create): sin
        # hora puesta no se bloquea, se asume 23:59.
        due_time = request.POST.get("due_time") or "23:59"

        plan_data = {
            "name": request.POST.get("name", "").strip(),
            "notes": request.POST.get("notes", "").strip(),
            "weeks": draft["plan_fields"].get("weeks"),
            "custom_days": draft["plan_fields"].get("custom_days"),
            "started_on": draft["plan_fields"].get("started_on"),
            "reward": request.POST.get("reward", "").strip(),
            "due_time": due_time,
            "is_active": True,
        }

        plan = Plan(user=get_current_user(), plan_type=draft["plan_type"])
        error = api._apply_plan_fields(plan, plan_data)
        if error:
            messages.error(request, error)
            return redirect(reverse("tasks:plan_ai_create"))
        plan.save()

        for idx, item in enumerate(draft.get("items") or []):
            prefix = f"items-{idx}-"
            item_data = dict(item["fields"])
            # Solo estos números son editables en la vista previa — el
            # resto (ejercicio, modo, incrementos ya calculados a partir
            # de las tablas por nivel...) se queda tal como lo propuso la
            # generación automática.
            for key in (
                "label", "start_sets", "start_reps", "start_seconds", "start_weight_kg",
                "goal_reps", "goal_seconds", "goal_weight_kg", "start_distance_km",
                "start_pace_seconds_per_km", "goal_distance_km", "goal_pace_seconds_per_km",
                "target_minutes",
            ):
                field_name = prefix + key
                if field_name not in request.POST:
                    continue
                raw = request.POST.get(field_name, "").strip()
                item_data[key] = raw if (raw != "" or key == "label") else None

            plan_item = PlanItem(plan=plan)
            item_error = api._apply_plan_item_fields(plan_item, plan, item_data)
            if item_error:
                continue  # se descarta en vez de tirar el plan entero
            plan_item.save()

        plan.sync_task()
        request.session.pop("plan_ai_draft", None)
        messages.success(request, f"Plan «{plan.name}» creado automáticamente.")
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    # GET, o "volver" desde la vista previa sin confirmar.
    return render(request, "tasks/plan_ai_form.html", {
        "fitness_level_choices": ai.FITNESS_LEVEL_CHOICES,
        "focus_area_choices": ai.FOCUS_AREA_CHOICES,
        "exercise_choices": ai.all_exercise_choices(),
        "weekdays": Task.WEEKDAYS,
        "selected_days": ["0", "2", "4"],
        "weeks": 12,
        "fitness_level": "",
        "focus_area": "",
        "no_bar_equipment": False,
        # Precargado con un valor por defecto razonable (chaleco lastrado
        # doméstico típico — mismo número que `ai._DEFAULT_MAX_LOAD_KG`)
        # ya que el campo es obligatorio: así el usuario ve un número con
        # sentido en vez de una casilla vacía, y solo tiene que cambiarlo
        # a 0 si de verdad no tiene nada de peso extra.
        "max_load_kg": 20,
        "selected_exercises": [],
    })


def plan_form(request, pk=None):
    """Crear o editar un plan. Los objetivos se editan uno a uno."""
    plan = get_object_or_404(_plans_qs(), pk=pk) if pk else None

    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        # Igual que en la tarea suelta (ver task_form/task_create): sin
        # hora puesta no se bloquea el guardado, se asume 23:59 — la
        # tarea del plan hereda esta hora en Plan.sync_task().
        due_time = request.POST.get("due_time") or "23:59"
        if not name:
            messages.error(request, "Ponle un nombre al plan.")
        else:
            if plan is None:
                plan = Plan(user=get_current_user())
                # El tipo solo se decide al crear — cambiarlo después
                # dejaría objetivos huérfanos que ya no encajan (un
                # objetivo de ejercicio en un plan que ahora es Estudio
                # no significa nada). El subtipo de Estudio (Idiomas) es
                # la misma decisión un escalón más abajo: cambiarlo
                # después dejaría un temario de vídeos (CourseModule)
                # huérfano igual que pasaría con los objetivos.
                raw_type = request.POST.get("plan_type", "")
                valid_types = {k for k, _ in Plan.PLAN_TYPE_CHOICES}
                plan.plan_type = raw_type if raw_type in valid_types else Plan.PLAN_TYPE_SPORT
                if plan.plan_type == Plan.PLAN_TYPE_STUDY:
                    raw_subtype = request.POST.get("study_subtype", "")
                    valid_subtypes = {k for k, _ in Plan.STUDY_SUBTYPE_CHOICES}
                    plan.study_subtype = raw_subtype if raw_subtype in valid_subtypes else Plan.STUDY_SUBTYPE_GENERAL

            # Idioma + nivel son metadata editable en cualquier momento
            # (a diferencia del subtipo) — no cambian ningún CourseModule
            # ya creado, solo el contexto que se enseña y lo que usará la
            # próxima asignación de cursos del catálogo.
            is_language = plan.plan_type == Plan.PLAN_TYPE_STUDY and plan.study_subtype == Plan.STUDY_SUBTYPE_LANGUAGE
            # Estudio · Hábito simple: el resto de Estudio que no es un
            # curso de idioma — lleva su vídeo/playlist/temporizador
            # propio en vez de un temario (ver más abajo).
            is_study_general = plan.plan_type == Plan.PLAN_TYPE_STUDY and not is_language
            if is_language:
                api._apply_language_plan_fields(plan, {
                    "language_name": request.POST.get("language_name", ""),
                    "level_from": request.POST.get("level_from", ""),
                    "level_to": request.POST.get("level_to", ""),
                    # Checkboxes: puede venir mas de un idioma ya sabido.
                    "known_languages": ", ".join(request.POST.getlist("known_languages")),
                    "language_daily_minutes": request.POST.get("language_daily_minutes", ""),
                    "quiz_every_n_videos": request.POST.get("quiz_every_n_videos", ""),
                })

            # known_languages y language_daily_minutes son obligatorios en
            # un plan de idiomas: sin idioma ya sabido no hay con qué
            # comparar al elegir cursos del catálogo, y sin minutos/día no
            # hay objetivo que corte el vídeo (ver task_video.html —
            # target_minutes sale de aquí). El HTML ya los pide con
            # `required`, pero el de minutos es en verdad un campo oculto
            # que rellena JS — el navegador no lo valida solo — así que el
            # mínimo se repite aquí en el servidor.
            if is_language and not (plan.known_languages and plan.language_daily_minutes):
                messages.error(
                    request,
                    "Un plan de idiomas necesita el idioma que ya sabes y los minutos de vídeo al día.",
                )
            else:
                plan.name = name[:80]
                plan.notes = request.POST.get("notes", "").strip()
                raw_started_on = request.POST.get("started_on", "").strip()
                if raw_started_on:
                    try:
                        plan.started_on = _dt.date.fromisoformat(raw_started_on)
                    except ValueError:
                        plan.started_on = plan.started_on or _dt.date.today()
                else:
                    plan.started_on = plan.started_on or _dt.date.today()
                # Semanas: campo oculto para planes de Idiomas (ver
                # language-fields en plan_form.html -- ahí el ritmo real
                # lo decide lo que se cumple de verdad, no el calendario,
                # ver Plan.auto_close_expired). Si no viene en el POST
                # (input deshabilitado por el toggle) se deja tal cual
                # estaba -- 12 si es un plan nuevo (default del modelo),
                # o lo que ya tuviera si se está editando -- en vez de
                # resetearlo a 12 cada vez que se guarda el plan.
                raw_weeks = request.POST.get("weeks")
                if raw_weeks:
                    try:
                        plan.weeks = max(1, int(raw_weeks))
                    except (TypeError, ValueError):
                        pass
                plan.is_active = bool(request.POST.get("is_active"))
                plan.reward = request.POST.get("reward", "").strip()[:200]
                plan.repeat = request.POST.get("repeat", "custom")
                plan.custom_days = ",".join(request.POST.getlist("custom_days")) or "0,2,4"
                plan.due_time = due_time
                try:
                    plan.interval = max(1, int(request.POST.get("interval", 1)))
                except (TypeError, ValueError):
                    plan.interval = 1

                # Idioma, al CREAR: en vez de guardar ya, se asignan los
                # cursos del catálogo (sin IA, ver api.build_language_plan_draft)
                # y se enseña un paso de revisión antes de guardar nada de
                # verdad — igual que el resto de la app deja revisar un
                # borrador antes de confirmar. Al EDITAR un plan de
                # idiomas ya creado no se toca el temario (mismo criterio
                # de siempre: idioma/nivel son editables, el CourseModule
                # ya generado no se regenera solo).
                if is_language and plan.pk is None:
                    draft, error = api.build_language_plan_draft(
                        user=get_current_user(), weeks=plan.weeks, custom_days=plan.custom_days_list(),
                        language=plan.language_name, level_from=plan.level_from, level_to=plan.level_to,
                        known_languages=plan.known_languages, quiz_every_n_videos=plan.quiz_every_n_videos,
                        language_daily_minutes=plan.language_daily_minutes,
                    )
                    if error:
                        messages.error(request, error)
                    else:
                        draft["plan_fields"]["name"] = plan.name
                        draft["plan_fields"]["notes"] = plan.notes
                        draft["due_time"] = due_time
                        draft["reward"] = plan.reward
                        request.session["plan_language_draft"] = draft
                        return redirect(reverse("tasks:plan_language_confirm"))
                else:
                    plan.save()
                    # El plan crea y mantiene su propia tarea: el usuario
                    # no tiene que crear nada a mano ni saber qué es un
                    # circuito.
                    plan.sync_task()

                    # Estudio · Hábito simple: el vídeo/playlist/temporizador
                    # de la tarea diaria se rellena aquí mismo, en el mismo
                    # paso — así el plan sale ya con su tarea lista para
                    # comprobar, en vez de dejar al usuario un plan "vacío"
                    # que solo se completa si además recuerda ir a "+ Añadir
                    # objetivo" (ver plan_item_form, que sigue existiendo
                    # para poder cambiarlo más tarde).
                    if is_study_general:
                        item = plan.items.filter(is_headline=True).first()
                        if item is None:
                            item = PlanItem(plan=plan, is_headline=True, progression=PlanItem.PROG_COMPLETION)
                        item.exercise = None
                        item.series_id = plan.task_series_id
                        item.progression = PlanItem.PROG_COMPLETION
                        item.is_headline = True
                        item.youtube_video_id = request.POST.get("youtube_video_id", "").strip()[:255]
                        item.youtube_playlist_id = request.POST.get("youtube_playlist_id", "").strip()[:255]
                        # Clases de Ilerna (Zoom): no es un curso de Udemy aunque
                        # lleve palabra clave (asignatura, opcional) -- watch_site
                        # lo distingue. La palabra clave de cada fuente viaja en su
                        # propio input (los de las fuentes no elegidas llegan
                        # deshabilitados, ver refreshStudySource en plan_form.html).
                        is_ilerna = request.POST.get("study_source") == "ilerna"
                        if is_ilerna:
                            item.watch_site = PlanItem.SITE_ILERNA
                            item.watch_keyword = request.POST.get("ilerna_keyword", "").strip()[:120]
                        else:
                            item.watch_site = ""
                            item.watch_keyword = request.POST.get("watch_keyword", "").strip()[:120]
                        # Solo tiene sentido con watch_keyword puesto (Curso de
                        # Udemy) -- toggle "por vídeos vistos" (exige audio, de
                        # siempre) vs "por tiempo en la página" (vídeo + ejercicios,
                        # sin exigir audio, ver Task.watch_requires_audio).
                        item.watch_requires_audio = request.POST.get("watch_track_mode") != "time"
                        # Igual que una tarea suelta de Estudio (ver
                        # _study_link_error): sin nada de esto puesto, el
                        # plan sale con una tarea diaria "Estudio simple"
                        # sin nada que comprobar ni forma de cerrarse solo
                        # -- ya no se deja crear/guardar así.
                        if not (item.youtube_video_id or item.youtube_playlist_id or item.watch_keyword or is_ilerna):
                            messages.error(
                                request,
                                "Pon algo enlazado: un curso de Udemy (palabra clave), un vídeo "
                                "o una playlist de YouTube — un plan de Estudio necesita saber "
                                "qué vas a estudiar.",
                            )
                            return redirect(
                                reverse("tasks:plan_edit", args=[plan.pk]) if plan.pk
                                else reverse("tasks:plan_create")
                            )
                        raw_minutes = request.POST.get("target_minutes", "").strip()
                        try:
                            item.target_minutes = max(1, int(raw_minutes)) if raw_minutes else None
                        except (TypeError, ValueError):
                            item.target_minutes = None
                        if is_ilerna and not item.target_minutes:
                            messages.error(request, "Clases de Ilerna: pon los minutos de clase al día.")
                            return redirect(reverse("tasks:plan_edit", args=[plan.pk]))
                        raw_count = request.POST.get("target_video_count", "").strip()
                        try:
                            item.target_video_count = max(1, int(raw_count)) if raw_count else None
                        except (TypeError, ValueError):
                            item.target_video_count = None
                        # Con playlist, uno de los dos es obligatorio: sin
                        # ninguno, el seguimiento de progreso
                        # (Plan._study_playlist_progress) se quedaría
                        # siempre en el primer vídeo y no avanzaría nunca.
                        # Un hábito sin vídeo ni playlist (temporizador
                        # manual, tipo Enfoque) no necesita esto.
                        if item.youtube_playlist_id and not (item.target_minutes or item.target_video_count):
                            messages.error(
                                request,
                                "Con una playlist, pon minutos al día o número de vídeos al día — "
                                "hace falta uno de los dos.",
                            )
                            return redirect(reverse("tasks:plan_edit", args=[plan.pk]))
                        item.save()
                        # Playlist con seguimiento de progreso: se refresca
                        # la caché de vídeos justo al guardar (nunca desde
                        # sync_task, que se llama en cada carga de la lista
                        # de tareas y sería demasiado caro/lento llamar ahí
                        # a la API de YouTube).
                        item.sync_playlist_videos()
                        # La tarea ya se creó/actualizó arriba sin el vídeo
                        # (no existía el objetivo todavía) — se sincroniza
                        # otra vez para que recoja lo que se acaba de poner.
                        plan.sync_task()

                    messages.success(request, f"Plan «{plan.name}» guardado.")
                    return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    # Si esto era una creación (sin pk) y se quedó a medias por el error
    # de idiomas de arriba, `plan` es ya una instancia sin guardar — no
    # se le pasa tal cual a la plantilla, o se vería como "editar" un
    # plan que en realidad no existe (radios bloqueados, tipo fijado...).
    # Mismo criterio que ya tenía el error de "falta el nombre".
    display_plan = plan if pk else None
    # Para poder rellenar el vídeo/playlist/temporizador de un plan de
    # Estudio · Hábito simple ya creado (editar reutiliza este mismo
    # formulario, ver arriba).
    study_headline = (
        display_plan.headline
        if display_plan and display_plan.plan_type == Plan.PLAN_TYPE_STUDY
        and display_plan.study_subtype != Plan.STUDY_SUBTYPE_LANGUAGE
        else None
    )
    # Desplegables de idioma: solo los que ya tienen curso verificado en
    # el catalogo (ver api.catalog_language_options) -- si el plan que
    # se edita quedo con un idioma que luego se desactivo/desaparecio
    # del catalogo, se anade igual para no perder el valor guardado.
    language_choices = api.catalog_language_options()
    if display_plan and display_plan.language_name and display_plan.language_name not in language_choices:
        language_choices = language_choices + [display_plan.language_name]
    native_language_choices = api.catalog_native_language_options()
    known_languages_selected = [
        s.strip() for s in (display_plan.known_languages.split(",") if display_plan and display_plan.known_languages else [])
        if s.strip()
    ]
    for lang in known_languages_selected:
        if lang not in native_language_choices:
            native_language_choices.append(lang)

    return render(request, "tasks/plan_form.html", {
        "plan": display_plan,
        "weekdays": Task.WEEKDAYS,
        "selected_days": display_plan.custom_days_list() if display_plan else ["0", "2", "4"],
        "plan_type_choices": Plan.PLAN_TYPE_CHOICES,
        "study_subtype_choices": Plan.STUDY_SUBTYPE_CHOICES,
        "cefr_level_choices": Plan.CEFR_LEVEL_CHOICES,
        "study_headline": study_headline,
        "language_choices": language_choices,
        "native_language_choices": native_language_choices,
        "known_languages_selected": known_languages_selected,
    })


def plan_language_confirm(request):
    """
    Paso 2 de crear un plan de Estudio · Idiomas a mano (paso 1:
    `plan_form`, que ya validó el idioma/nivel/minutos y armó el
    borrador vía `api.build_language_plan_draft`).

    Revisa qué cursos del catálogo se han asignado — sin IA, ver
    docstring de `api.build_language_plan_draft` — y confirma. Nada se
    guarda hasta el POST: si algún nivel pedido todavía no tiene curso
    verificado se avisa (`missing_levels`) pero no bloquea, el resto del
    temario se guarda igual.
    """
    draft = request.session.get("plan_language_draft")
    if not draft:
        messages.error(request, "Los datos del plan han caducado — vuelve a rellenarlo.")
        return redirect(reverse("tasks:plan_create"))

    if request.method == "POST":
        # Igual que en la tarea suelta (ver task_form/task_create): sin
        # hora puesta no se bloquea, se asume 23:59.
        due_time = request.POST.get("due_time") or draft.get("due_time") or "23:59"

        # Se expande el catálogo elegido (vídeo a vídeo, vía YouTube)
        # solo ahora que el usuario confirma de verdad — así no se gasta
        # cuota de la API de YouTube en un borrador que a lo mejor se
        # descarta (mismo criterio de siempre, ver expand_language_selection).
        course_modules, error = api.expand_language_selection(draft.get("selected") or [])
        if error:
            messages.error(request, error)
            return redirect(reverse("tasks:plan_create"))

        plan_data = dict(draft["plan_fields"])
        plan_data["name"] = request.POST.get("name", "").strip()[:80] or plan_data.get("name")
        plan_data["notes"] = request.POST.get("notes", "").strip()
        plan_data["reward"] = request.POST.get("reward", "").strip()[:200]
        plan_data["due_time"] = due_time
        plan_data["is_active"] = True

        plan = Plan(user=get_current_user(), plan_type=Plan.PLAN_TYPE_STUDY)
        error = api._apply_plan_fields(plan, plan_data)
        if not error:
            api._apply_language_plan_fields(plan, plan_data)
        if error:
            messages.error(request, error)
            return redirect(reverse("tasks:plan_create"))
        plan.save()

        for module in course_modules:
            module.plan = plan
            module.save()

        plan.sync_task()
        request.session.pop("plan_language_draft", None)
        messages.success(request, f"Plan «{plan.name}» creado.")
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    return render(request, "tasks/plan_language_confirm.html", {"draft": draft})


@require_POST
def plan_language_retry(request, pk):
    """
    Red de seguridad para un plan de idioma que se quedó sin temario —
    ej. porque al confirmar falló la llamada a YouTube, o porque el
    catálogo no tenía nada para ese nivel en su momento y desde entonces
    se han añadido cursos nuevos con `add_course_playlist`. Sin esto, un
    plan así se queda atascado para siempre («este curso todavía no
    tiene vídeos» en plan_detail.html, sin ninguna forma de arreglarlo
    salvo borrar el plan y volver a crearlo desde cero).

    Reutiliza el idioma/nivel/idiomas ya guardados en el propio plan —
    no hace falta volver a pedirlos — y AÑADE los módulos nuevos que
    encuentre sin tocar los que ya hubiera.
    """
    plan = get_object_or_404(_plans_qs(), pk=pk)
    is_language = plan.plan_type == Plan.PLAN_TYPE_STUDY and plan.study_subtype == Plan.STUDY_SUBTYPE_LANGUAGE
    if not is_language:
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    if plan.course_modules.exists():
        messages.info(request, "Este curso ya tiene vídeos asignados.")
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    draft, error = api.build_language_plan_draft(
        user=get_current_user(), weeks=plan.weeks, custom_days=plan.custom_days_list(),
        language=plan.language_name, level_from=plan.level_from, level_to=plan.level_to,
        known_languages=plan.known_languages, quiz_every_n_videos=plan.quiz_every_n_videos,
        language_daily_minutes=plan.language_daily_minutes,
    )
    if error:
        messages.error(request, error)
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    course_modules, error = api.expand_language_selection(draft.get("selected") or [])
    if error:
        messages.error(request, error)
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    for module in course_modules:
        module.plan = plan
        module.save()
    plan.sync_task()
    messages.success(request, "Vídeos asignados — ya puedes empezar el curso.")
    return redirect(reverse("tasks:plan_detail", args=[plan.pk]))


@require_POST
def plan_delete(request, pk):
    plan = get_object_or_404(_plans_qs(), pk=pk)
    plan.deleted_at = timezone.now()
    plan.save(update_fields=["deleted_at", "updated_at"])
    plan.sync_task()          # retira la tarea pendiente
    messages.success(request, "Plan eliminado.")
    return redirect(reverse("tasks:task_list"))


def _plan_summary_items(plan):
    """Un resumen ligero por objetivo: cuántas veces se cumplió, en qué
    escalón se quedó. Sin la tabla de progresión entera — esto es un
    vistazo hacia atrás, no una pantalla de trabajo."""
    items = []
    for item in plan.items.select_related("exercise").all():
        successes, _ = item.successes_and_streak()
        items.append({
            "item": item,
            "successes": successes,
            "step": item.current_step(),
            "target": item.current_target(),
        })
    return items


def plan_close(request, pk):
    """
    Cierre de ciclo: distinto de borrar. GET enseña el resumen (llevas
    cumplidos tantos escalones, tal racha…) con un botón para
    confirmar; POST cierra de verdad — dos pasos porque cerrar no se
    deshace con un "deshacer" fácil como sí lo tiene marcar una tarea.

    Una vez cerrado, el plan deja de generar tareas y sale de la lista
    de activos, pero se queda en "Planes cerrados" para poder mirar
    atrás — no es lo mismo que eliminar.
    """
    plan = get_object_or_404(_plans_qs(), pk=pk)

    if request.method == "POST" and not plan.closed_at:
        plan.final_progress_pct = plan.progress_pct()
        plan.closed_at = timezone.now()
        plan.is_active = False
        plan.save(update_fields=["final_progress_pct", "closed_at", "is_active", "updated_at"])
        plan.sync_task()  # retira la tarea pendiente, como al pausar

    return render(request, "tasks/plan_close.html", {
        "plan": plan,
        "progress": plan.final_progress_pct if plan.closed_at else plan.progress_pct(),
        "items": _plan_summary_items(plan),
    })


def plan_item_form(request, plan_pk, pk=None):
    """
    Un objetivo dentro del plan.

    El formulario enseña solo lo que aplica a cada tipo de progresión:
    no tiene sentido pedir "rango de repeticiones" en algo de
    cumplimiento, ni "peso" en una plancha.
    """
    plan = get_object_or_404(_plans_qs(), pk=plan_pk)
    item = get_object_or_404(PlanItem, pk=pk, plan=plan) if pk else None

    if plan.plan_type == Plan.PLAN_TYPE_GENERAL:
        # General no tiene nada que configurar — se creó solo al crear
        # el plan. Si alguien llega aquí de todos modos (enlace viejo,
        # yendo hacia atrás en el navegador), se le devuelve sin líos.
        messages.info(request, "Un plan General no necesita objetivos — la propia tarea diaria ya lo es.")
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    if request.method == "POST":
        if item is None:
            item = PlanItem(plan=plan)

        def _int(name, default):
            try:
                return max(0, int(request.POST.get(name) or default))
            except (TypeError, ValueError):
                return default

        def _float(name, default):
            try:
                return max(0.0, float((request.POST.get(name) or default)))
            except (TypeError, ValueError):
                return default

        if plan.plan_type == Plan.PLAN_TYPE_STUDY:
            # El objetivo ES el vídeo/playlist/temporizador — apunta a
            # la propia tarea diaria del plan, no a un ejercicio.
            item.exercise = None
            item.series_id = plan.task_series_id
            item.label = request.POST.get("label", "").strip()[:80]
            item.progression = PlanItem.PROG_COMPLETION
            item.is_headline = True
            item.youtube_video_id = request.POST.get("youtube_video_id", "").strip()[:255]
            item.youtube_playlist_id = request.POST.get("youtube_playlist_id", "").strip()[:255]
            raw_minutes = request.POST.get("target_minutes", "").strip()
            item.target_minutes = max(1, _int("target_minutes", 0)) if raw_minutes else None
            raw_count = request.POST.get("target_video_count", "").strip()
            item.target_video_count = max(1, _int("target_video_count", 0)) if raw_count else None
            # Con playlist, uno de los dos es obligatorio: sin ninguno, el
            # seguimiento de progreso (Plan._study_playlist_progress) se
            # quedaría siempre en el primer vídeo y no avanzaría nunca. Un
            # hábito sin vídeo ni playlist (temporizador manual, tipo
            # Enfoque) no necesita esto.
            if item.youtube_playlist_id and not (item.target_minutes or item.target_video_count):
                messages.error(
                    request,
                    "Con una playlist, pon minutos al día o número de vídeos al día — "
                    "hace falta uno de los dos.",
                )
                return redirect(request.path)
            item.save()
            # Se refresca la caché de vídeos justo al guardar (nunca desde
            # sync_task, que se llama en cada carga de la lista de tareas
            # y sería demasiado caro/lento llamar ahí a la API de YouTube).
            item.sync_playlist_videos()
            plan.sync_task()
            messages.success(request, "Objetivo guardado.")
            return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

        # plan_type == Deporte, a partir de aquí.
        slug = request.POST.get("exercise") or ""
        item.exercise = Exercise.objects.filter(slug=slug).first() if slug else None
        item.label = request.POST.get("label", "").strip()[:80]

        # Cómo se hace el ejercicio — no aplica a running.
        es_running = item.exercise and item.exercise.mode == Exercise.MODE_DISTANCE
        if es_running:
            item.sport_mode = ""
        else:
            valid_modes = {k for k, _ in PlanItem.SPORT_MODE_CHOICES}
            raw_mode = request.POST.get("sport_mode", "")
            item.sport_mode = raw_mode if raw_mode in valid_modes else ""
        if item.sport_mode == PlanItem.SPORT_MODE_VIDEO:
            item.youtube_video_id = request.POST.get("youtube_video_id", "").strip()[:255]
            item.youtube_playlist_id = request.POST.get("youtube_playlist_id", "").strip()[:255]
            raw_minutes = request.POST.get("target_minutes", "").strip()
            item.target_minutes = max(1, int(raw_minutes or 0)) if raw_minutes else None
            raw_count = request.POST.get("target_video_count", "").strip()
            item.target_video_count = max(1, int(raw_count or 0)) if raw_count else None

        valid = {k for k, _ in PlanItem.PROGRESSION_CHOICES}
        default_prog = (
            PlanItem.PROG_DISTANCE if item.exercise and item.exercise.mode == Exercise.MODE_DISTANCE
            else PlanItem.PROG_REPS
        )
        prog = request.POST.get("progression", default_prog)
        item.progression = prog if prog in valid else default_prog

        item.start_sets = _int("start_sets", 3) or 1
        item.start_reps = _int("start_reps", 8)
        item.start_seconds = _int("start_seconds", 40)
        item.start_weight_kg = _float("start_weight_kg", 0)

        item.goal_sets = _int("goal_sets", 0) or None
        item.goal_reps = _int("goal_reps", 0) or None
        item.goal_seconds = _int("goal_seconds", 0) or None
        gw = request.POST.get("goal_weight_kg")
        item.goal_weight_kg = _float("goal_weight_kg", 0) if gw else None

        # Running: distancia en km (decimales, por eso _float) y ritmo
        # en segundos por km (entero, viene del mismo desplegable de
        # presets que ya usa una tarea suelta de running).
        item.start_distance_km = _float("start_distance_km", 1.0) or 1.0
        item.start_pace_seconds_per_km = _int("start_pace_seconds_per_km", 420) or 420
        # Sin progresión: correr siempre la misma distancia/ritmo, sin
        # destino ni escalones — el mismo criterio que ya usa cualquier
        # otra progresión sin "goal_*" puesto (se queda fija para
        # siempre, ver PlanItem.target_for_step). Sin este atajo, un 0
        # en incremento/desaceleración se perdía igualmente porque
        # "_float(...) or 0.5" trata el 0 como "no puesto".
        distance_flat = bool(request.POST.get("distance_flat"))
        if distance_flat:
            item.goal_distance_km = None
            item.goal_pace_seconds_per_km = None
            item.distance_increment_km = 0.0
            item.pace_decrement_seconds = 0
        else:
            gd = request.POST.get("goal_distance_km")
            item.goal_distance_km = _float("goal_distance_km", 0) if gd else None
            gp = request.POST.get("goal_pace_seconds_per_km")
            item.goal_pace_seconds_per_km = _int("goal_pace_seconds_per_km", 0) if gp else None
            item.distance_increment_km = _float("distance_increment_km", 0.5) or 0.5
            item.pace_decrement_seconds = _int("pace_decrement_seconds", 10) or 10

        # Cómo avanza: ya no se pide a mano (ni "sesiones por escalón" ni
        # "sube de X"/"añade X kg") -- se reparte solo, en línea recta,
        # entre las semanas del plan (weekly_linear, ver PlanItem).
        # sessions_per_step se pone igual a las sesiones/semana del plan
        # para que un escalón sea exactamente una semana.
        item.weekly_linear = True
        item.sessions_per_step = max(1, len(plan.custom_days_list()))
        item.deload_after_failures = _int("deload_after_failures", 3)

        # Obligatorio de verdad: sin esto, un objetivo se puede guardar
        # "vacío" y al pulsar play la app no sabe qué pantalla enseñar
        # (cae en un comportamiento antiguo que confunde más que ayuda).
        error = None
        if not item.exercise:
            error = "Elige un ejercicio."
        elif es_running and not item.goal_distance_km and not distance_flat:
            error = "Pon una distancia de destino — sin eso el plan no sabría cuándo has llegado."
        elif not es_running and not item.sport_mode:
            error = "Elige cómo la vas a completar: cámara, circuito o vídeo."
        elif item.sport_mode == PlanItem.SPORT_MODE_VIDEO and not (item.youtube_video_id or item.youtube_playlist_id):
            error = "Pon un vídeo o una playlist de YouTube."

        if error:
            return render(request, "tasks/plan_item_form.html", {
                "plan": plan, "item": item, "error": error,
                "exercises": Exercise.objects.filter(is_active=True),
                "progressions": PlanItem.PROGRESSION_CHOICES,
                "pace_presets": Task.PACE_PRESETS,
                "sessions_per_week": max(1, len(plan.custom_days_list())),
                "weighted_slugs": Exercise.WEIGHTED_SLUGS,
            })

        item.save()

        plan.sync_task()
        messages.success(request, "Objetivo guardado.")
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    return render(request, "tasks/plan_item_form.html", {
        "plan": plan,
        "item": item,
        "exercises": Exercise.objects.filter(is_active=True),
        "progressions": PlanItem.PROGRESSION_CHOICES,
        "pace_presets": Task.PACE_PRESETS,
        # Para poder calcular el ritmo de progresión a partir de "en
        # cuántas semanas quiero llegar" en vez de que el usuario tenga
        # que hacer la cuenta él mismo de cuánto subir cada escalón.
        "sessions_per_week": max(1, len(plan.custom_days_list())),
        "weighted_slugs": Exercise.WEIGHTED_SLUGS,
    })


def plan_item_bulk_form(request, plan_pk):
    """
    Alta rápida de varios objetivos de Deporte a la vez.

    En vez de repetir "+ Añadir objetivo" ejercicio por ejercicio, se
    marcan los que se quieran y se les aplica LA MISMA configuración —
    pensado para un plan con muchos ejercicios seguidos (ej. tren
    superior con 8 ejercicios al fallo, todos "3 series, sube cada 2
    sesiones"). Se puede marcar running a la vez que ejercicios
    normales: cada ejercicio de running se crea con progresión por
    distancia/ritmo (los campos de esa sección), el resto con la
    progresión de series/reps elegida arriba — son dos bloques de
    ajustes compartidos, independientes entre sí, no uno según qué
    ejercicio esté seleccionado.

    Los objetivos que salen de aquí son PlanItem normales y corrientes:
    se pueden editar uno a uno después con plan_item_form si alguno
    necesita otros números.
    """
    plan = get_object_or_404(_plans_qs(), pk=plan_pk)
    if plan.plan_type != Plan.PLAN_TYPE_SPORT:
        messages.info(request, "El alta rápida solo aplica a planes de Deporte.")
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    exercises = Exercise.objects.filter(is_active=True)
    # Agrupados por tren superior/inferior/running (Exercise.body_area),
    # igual que ya se pesaría un plan de verdad — un "Marcar todos" por
    # grupo es lo que de verdad ahorra los clics que se quejaba Alex,
    # más que la lista plana.
    group_labels = dict(Task.SPORT_SUBCATEGORY_CHOICES)
    groups = []
    for value, label in Task.SPORT_SUBCATEGORY_CHOICES:
        qs = list(exercises.filter(body_area=value))
        if qs:
            groups.append((value, label, qs))
    otros = list(exercises.filter(body_area=""))
    if otros:
        groups.append(("", "Otros", otros))

    # 'distance' no es una opción a elegir aquí: se aplica sola a
    # cualquier ejercicio de running marcado, vía el bloque de
    # distancia/ritmo de más abajo — no tiene sentido como radio junto a
    # "reps"/"al fallo"/etc.
    progressions = [c for c in PlanItem.PROGRESSION_CHOICES if c[0] != PlanItem.PROG_DISTANCE]
    # Vídeo tampoco tiene sentido en alta rápida: todos los marcados
    # compartirían el mismo vídeo de YouTube, que no es lo que se pide.
    sport_modes = [c for c in PlanItem.SPORT_MODE_CHOICES if c[0] != PlanItem.SPORT_MODE_VIDEO]

    base_ctx = {
        "plan": plan,
        "groups": groups,
        "progressions": progressions,
        "sport_modes": sport_modes,
        "pace_presets": Task.PACE_PRESETS,
        "sessions_per_week": max(1, len(plan.custom_days_list())),
        "weighted_slugs": Exercise.WEIGHTED_SLUGS,
    }

    if request.method == "POST":
        def _int(name, default):
            try:
                return max(0, int(request.POST.get(name) or default))
            except (TypeError, ValueError):
                return default

        def _float(name, default):
            try:
                return max(0.0, float(request.POST.get(name) or default))
            except (TypeError, ValueError):
                return default

        slugs = request.POST.getlist("exercises")
        selected = list(exercises.filter(slug__in=slugs))
        if not selected:
            return render(request, "tasks/plan_item_bulk_form.html", {
                **base_ctx, "error": "Marca al menos un ejercicio.",
            })

        valid_prog = {k for k, _ in progressions}
        prog = request.POST.get("progression", PlanItem.PROG_REPS)
        prog = prog if prog in valid_prog else PlanItem.PROG_REPS

        valid_modes = {k for k, _ in sport_modes}
        raw_mode = request.POST.get("sport_mode", PlanItem.SPORT_MODE_CAMERA)
        sport_mode = raw_mode if raw_mode in valid_modes else PlanItem.SPORT_MODE_CAMERA

        # Compartido para los ejercicios normales (no running). Los dos
        # campos de "objetivo" (reps Y segundos) se guardan siempre — el
        # que no aplique lo ignora is_timed/PROG_FAILURE al leerlo,
        # mismo criterio que ya usa el formulario de uno en uno.
        # Cómo avanza: igual que en plan_item_form, ya no se pide "cada
        # cuántas sesiones sube" ni "cuánto sube" a mano -- weekly_linear
        # reparte en línea recta entre las semanas del plan, con
        # sessions_per_step = sesiones/semana (un escalón = una semana).
        shared = dict(
            sport_mode=sport_mode,
            progression=prog,
            start_sets=_int("start_sets", 3) or 1,
            start_reps=_int("start_reps", 8),
            start_seconds=_int("start_seconds", 40),
            start_weight_kg=_float("start_weight_kg", 0),
            goal_sets=_int("goal_sets", 0) or None,
            goal_reps=_int("goal_reps", 0) or None,
            goal_seconds=_int("goal_seconds", 0) or None,
            weekly_linear=True,
            sessions_per_step=max(1, len(plan.custom_days_list())),
            deload_after_failures=_int("deload_after_failures", 3),
        )
        gw = request.POST.get("goal_weight_kg")
        shared["goal_weight_kg"] = _float("goal_weight_kg", 0) if gw else None

        # Los tres campos de peso (start_weight_kg/goal_weight_kg/
        # weight_increment_kg) de `shared` vienen de un ÚNICO input
        # compartido por todo el lote (el formulario lo enseña en
        # cuanto HAY algún ejercicio con peso marcado, ver esPeso() en
        # plan_item_bulk_form.html) -- pero no todos los ejercicios
        # seleccionados tienen dónde poner ese peso: solo los de
        # Exercise.WEIGHTED_SLUGS (dominadas/fondos/sentadillas CON
        # peso) admiten lastre de verdad. Sin este segundo dict, ese
        # mismo peso se colaba también en flexiones/handstand/dominadas
        # normales solo por haber ido en el mismo lote (bug reportado:
        # "todos los ejercicios salen con 5 kg, no solo los que
        # llevan"). shared_no_weight es la misma configuración con los
        # tres a su "sin peso" de siempre (mismos defaults que
        # PlanItem.start_weight_kg/goal_weight_kg/weight_increment_kg).
        shared_no_weight = {
            **shared,
            "start_weight_kg": 0.0,
            "goal_weight_kg": None,
            "weight_increment_kg": 2.5,
        }

        # Compartido para los de running (distancia/ritmo) — progresión
        # forzada a PROG_DISTANCE, igual que hace plan_item_form con
        # es_running.
        distance_flat = bool(request.POST.get("distance_flat"))
        run_shared = dict(
            progression=PlanItem.PROG_DISTANCE,
            start_distance_km=_float("start_distance_km", 1.0) or 1.0,
            start_pace_seconds_per_km=_int("start_pace_seconds_per_km", 420) or 420,
            # Campo con name distinto en la plantilla a propósito: hay
            # dos "sesiones por escalón" en el formulario (uno para
            # series/reps, otro para running) y cada uno solo debe
            # afectar a SU bloque — con el mismo name, el segundo pisaría
            # al primero en request.POST.
            sessions_per_step=_int("sessions_per_step_distance", 2) or 1,
            # Sin progresión: mismos km/ritmo todos los días, sin
            # destino ni escalones — ver la nota equivalente en
            # plan_item_form.
            distance_increment_km=0.0 if distance_flat else (_float("distance_increment_km", 0.5) or 0.5),
            pace_decrement_seconds=0 if distance_flat else (_int("pace_decrement_seconds", 10) or 10),
        )
        if distance_flat:
            run_shared["goal_distance_km"] = None
            run_shared["goal_pace_seconds_per_km"] = None
        else:
            gd = request.POST.get("goal_distance_km")
            run_shared["goal_distance_km"] = _float("goal_distance_km", 0) if gd else None
            gp = request.POST.get("goal_pace_seconds_per_km")
            run_shared["goal_pace_seconds_per_km"] = _int("goal_pace_seconds_per_km", 0) if gp else None

        creados = 0
        sin_destino = []
        for ex in selected:
            item = PlanItem(plan=plan, exercise=ex)
            if ex.mode == Exercise.MODE_DISTANCE:
                fields = run_shared
            elif ex.slug in Exercise.WEIGHTED_SLUGS:
                fields = shared
            else:
                fields = shared_no_weight
            for k, v in fields.items():
                setattr(item, k, v)
            if ex.mode == Exercise.MODE_DISTANCE and not item.goal_distance_km and not distance_flat:
                # Igual que en plan_item_form: sin destino (y sin marcar
                # "sin progresión"), running no sabría cuándo ha llegado
                # — se salta en vez de crearlo roto, y se avisa al final
                # con cuáles se han quedado fuera (mejor que bloquear
                # TODO el envío por uno malo).
                sin_destino.append(ex.name)
                continue
            item.save()
            creados += 1

        plan.sync_task()
        if creados:
            messages.success(request, f"{creados} objetivo(s) creado(s).")
        if sin_destino:
            messages.error(
                request,
                "No se han creado (falta distancia de destino, hace falta para running): "
                + ", ".join(sin_destino),
            )
        if not creados and not sin_destino:
            messages.error(request, "No se ha creado ningún objetivo.")
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    return render(request, "tasks/plan_item_bulk_form.html", base_ctx)


@require_POST
def plan_item_delete(request, plan_pk, pk):
    plan = get_object_or_404(_plans_qs(), pk=plan_pk)
    get_object_or_404(PlanItem, pk=pk, plan=plan).delete()
    messages.success(request, "Objetivo eliminado.")
    return redirect(reverse("tasks:plan_detail", args=[plan.pk]))


@require_POST
def plan_item_move(request, plan_pk, pk):
    """
    Sube o baja un puesto un ejercicio de apoyo en el orden de la
    sesión — `Plan.session_items()` recorre `plan.items` (ordenados por
    PlanItem.order) para decidir en qué orden salen hoy los ejercicios
    en el circuito de cámara. Todos los ejercicios se pueden mover, sin
    excepción (ya no hay uno "estrella" fijo arriba).

    Casi todos los PlanItem nacen con order=0 (hasta ahora no había
    ningún sitio para cambiarlo), así que el primer movimiento en un
    plan renumera TODOS los ejercicios en su orden actual (0, 1, 2...) antes
    de intercambiar — si no, "subir" algo con order=0 no tendría con
    qué intercambiar.
    """
    plan = get_object_or_404(_plans_qs(), pk=plan_pk)
    item = get_object_or_404(PlanItem, pk=pk, plan=plan)
    direction = request.POST.get("direction")
    if direction not in ("up", "down"):
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    supports = list(plan.ordered_items())
    for i, it in enumerate(supports):
        if it.order != i:
            it.order = i
            it.save(update_fields=["order"])

    idx = next((i for i, it in enumerate(supports) if it.pk == item.pk), None)
    if idx is None:
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))

    swap_idx = idx - 1 if direction == "up" else idx + 1
    if 0 <= swap_idx < len(supports):
        a, b = supports[idx], supports[swap_idx]
        a.order, b.order = b.order, a.order
        a.save(update_fields=["order"])
        b.save(update_fields=["order"])

    return redirect(reverse("tasks:plan_detail", args=[plan.pk]))


def plan_session(request, pk, plan_pk):
    """
    La sesión de hoy según el plan: sus ejercicios, en orden, cada uno
    con el objetivo que toca. Sin elegir nada — el plan ya lo decidió.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    task.mark_started()
    gate = _require_warmup(request, task)
    if gate:
        return gate
    plan = get_object_or_404(_plans_qs(), pk=plan_pk)
    items = plan.session_items()
    if not items:
        messages.error(request, "Este plan todavía no tiene ejercicios que entrenar.")
        return redirect(reverse("tasks:plan_detail", args=[plan.pk]))
    return render(request, "tasks/plan_session.html", {
        "task": task, "plan": plan, "items": items,
        "items_json": json.dumps(items),
    })


@require_POST
def plan_session_save(request, pk, plan_pk):
    """
    Guarda la sesión del plan: una entrada por ejercicio, con el objetivo
    que estaba vigente. Al terminar, la tarea queda hecha y el plan
    avanza solo.
    """
    task = get_object_or_404(Task, pk=pk, user=get_current_user())
    plan = get_object_or_404(_plans_qs(), pk=plan_pk)

    try:
        data = json.loads(request.body)
    except (json.JSONDecodeError, TypeError):
        return JsonResponse({"ok": False, "error": "JSON inválido"}, status=400)

    targets = {}
    for it in plan.items.select_related("exercise"):
        if it.exercise:
            targets[it.exercise.slug] = it.current_target()

    created = []
    for b in data.get("breakdown", []) or []:
        if not isinstance(b, dict):
            continue
        slug = str(b.get("exercise", ""))[:32]
        if not slug:
            continue
        t = targets.get(slug, {})
        num = lambda k: int(b[k]) if isinstance(b.get(k), (int, float)) else 0
        created.append(WorkoutSession.objects.create(
            task=task, user=get_current_user(), plan=plan, series_id=task.series_id,
            exercise=slug,
            # Series con el tiempo de cada rep, o (aguantes) segundos por
            # serie -- ver api._breakdown_timing.
            **api._breakdown_timing(b),
            total_reps=num("reps"), total_sets=num("sets"),
            session_duration_seconds=num("seconds"),
            target_sets=t.get("sets"), target_reps=t.get("reps"),
            target_seconds=t.get("seconds"),
        ))

    if not created:
        return JsonResponse({"ok": False, "error": "Sin datos que guardar"}, status=400)

    # Cronómetro total de la sesión (si la página lo manda).
    api._save_training_session(task, data, created, plan=plan)

    messages.success(request, f"Sesión de «{plan.name}» guardada.")
    # La tarea se marca hecha en task_cooldown — falta el enfriamiento
    # obligatorio.
    return JsonResponse({"ok": True, "redirect_url": reverse("tasks:task_cooldown", args=[task.pk])})


# ---------------------------------------------------- app móvil: updates

def mobile_apk_download(request):
    """
    Sirve el último APK publicado a mano en mobile_releases/ (ver
    utils.read_mobile_release y el README, sección "Actualizaciones de
    la app móvil"). La app móvil llega aquí abriendo esta URL en el
    navegador del sistema (no vía fetch), después de ver en /api/meta/
    que hay una versión más reciente que la suya.

    Sigue detrás del candado Basic Auth de siempre — BasicAuthMiddleware
    envuelve toda la app, y aquí no se hace ninguna excepción a
    propósito (se decidió así conscientemente en vez de dejarla pública).
    """
    if request.method != "GET":
        return HttpResponseNotAllowed(["GET"])
    release = read_mobile_release()
    if not release:
        raise Http404("Todavía no hay ninguna build de la app publicada.")
    apk_path = release["apk_path"]
    response = FileResponse(
        open(apk_path, "rb"),
        content_type="application/vnd.android.package-archive",
    )
    response["Content-Disposition"] = f'attachment; filename="{apk_path.name}"'
    return response

"""
Rutas de la API JSON (para la app móvil). Se montan bajo /api/ — ver
todoapp/urls.py. Ese prefijo es también el que usa CORS_URLS_REGEX en
settings, así que si mueves esto de sitio, acuérdate de cambiarlo allí.
"""
from django.urls import path

from . import api

app_name = "api"

urlpatterns = [
    path("meta/", api.meta, name="meta"),
    path("profile/", api.profile, name="profile"),
    path("warmup/", api.warmup, name="warmup"),
    path("tasks/<uuid:uuid>/warmup-routine/", api.task_warmup_routine, name="task_warmup_routine"),

    path("tasks/", api.task_list, name="task_list"),
    path("tasks/create/", api.task_create, name="task_create"),
    path("tasks/<uuid:uuid>/", api.task_detail, name="task_detail"),
    path("tasks/<uuid:uuid>/started/", api.task_started, name="task_started"),
    path("tasks/<uuid:uuid>/mark/<str:action>/", api.task_mark, name="task_mark"),
    path("series/<uuid:series_id>/mark/<str:action>/", api.task_mark_by_series, name="task_mark_by_series"),
    # Consulta ligera para el aviso nativo, justo antes de enseñarlo (ver
    # AvoidPreCheckReceiver en el movil y notify_pending en api.py).
    path("notify-pending/", api.notify_pending, name="notify_pending"),

    path("exercises/", api.exercise_list, name="exercise_list"),
    path("exercises/<slug:slug>/target/", api.exercise_target, name="exercise_target"),

    path("routines/", api.routine_list, name="routine_list"),
    path("routines/<uuid:uuid>/", api.routine_detail, name="routine_detail"),

    path("tasks/<uuid:uuid>/workout/", api.workout_save, name="workout_save"),
    path("tasks/<uuid:uuid>/workout-manual/", api.workout_save_manual, name="workout_save_manual"),
    path("tasks/<uuid:uuid>/running-import/", api.running_import, name="running_import"),
    path("tasks/<uuid:uuid>/circuit/<uuid:routine_uuid>/", api.routine_result, name="routine_result"),
    path("tasks/<uuid:uuid>/focus/", api.focus_save, name="focus_save"),
    path("tasks/<uuid:uuid>/course-progress/", api.course_progress_save, name="course_progress_save"),
    path("tasks/<uuid:uuid>/video/", api.video_save, name="video_save"),
    path("videos/", api.saved_video_list, name="saved_video_list"),
    path("videos/<uuid:uuid>/", api.saved_video_delete, name="saved_video_delete"),

    path("plans/udemy-courses/", api.plan_udemy_courses, name="plan_udemy_courses"),
    path("plan-items/<int:pk>/course-progress/", api.plan_item_course_progress_save, name="plan_item_course_progress_save"),
    path("plans/", api.plan_list, name="plan_list"),
    path("plans/create/", api.plan_create, name="plan_create"),
    path("plans/generate/", api.plan_generate, name="plan_generate"),
    path("plans/language-options/", api.plan_language_options, name="plan_language_options"),
    path("plans/language-draft/", api.plan_language_draft, name="plan_language_draft"),
    path("plans/language-save/", api.plan_language_save, name="plan_language_save"),
    path("plans/<uuid:uuid>/", api.plan_detail, name="plan_detail"),
    path("plans/<uuid:uuid>/close/", api.plan_close, name="plan_close"),
    path("plans/<uuid:uuid>/items/", api.plan_item_create, name="plan_item_create"),
    path("plans/<uuid:uuid>/items/<int:item_id>/", api.plan_item_detail, name="plan_item_detail"),
    path("review/weekly/", api.weekly_review, name="weekly_review"),
    path("tasks/<uuid:uuid>/plan/<uuid:plan_uuid>/", api.plan_session, name="plan_session"),
    path("tasks/<uuid:uuid>/plan/<uuid:plan_uuid>/save/", api.plan_session_save, name="plan_session_save"),

    path("stats/", api.stats_list, name="stats_list"),
    path("stats/delete/", api.stats_delete_all, name="stats_delete_all"),
    path("stats/<uuid:series_id>/", api.stats_detail, name="stats_detail"),
    path("stats/<uuid:series_id>/delete/", api.stats_delete_series, name="stats_delete_series"),

    # Registro de depuración del botón 📋 (ver DebugLog en models.py) --
    # protegido por su propio token (settings.DEBUG_LOG_TOKEN), no por
    # BasicAuthMiddleware -- ver la excepción de ruta en todoapp/basic_auth.py.
    path("debug-log/", api.debug_log_create, name="debug_log_create"),
    path("debug-log/latest/", api.debug_log_latest, name="debug_log_latest"),
]

/**
 * Reproductor de circuitos MIXTOS.
 *
 * El problema que resuelve: un circuito no tiene por qué ser todo
 * cronómetro. Contar segundos de dominadas no dice nada — lo que importa
 * son las repeticiones. Así que cada ejercicio se reproduce con lo suyo:
 *
 *   - mode "timed"  (plancha, crunch)   -> cuenta atrás
 *   - mode "pose"   (dominadas, fondos) -> cámara contando reps
 *
 * Este módulo es el que orquesta la secuencia; el conteo real de reps lo
 * sigue haciendo workout.js sin tocarlo (se le engancha por
 * window.__workoutSubmit, igual que en el modo de ejercicio suelto).
 *
 * Al terminar, envía un desglose con lo que se hizo en cada ejercicio,
 * sean segundos o repeticiones.
 */

import { api } from "./api.js";
import { exerciseIcon } from "./exercise-icons.js";
import {
  loadModel, MEDIAPIPE_LIB, MEDIAPIPE_WASM,
  checkPlankPosture, checkSidePlankPosture, checkWallSitPosture, checkKneeHoldBarPosture, checkDeadHangPosture, checkTuckLeverPosture, checkHandstandPosture, createLSitHoldChecker, createSupermanHoldChecker,
  checkArmCrossStretch, checkTricepsOverheadStretch, checkSeatedHamstringStretch, createStandingQuadStretchChecker, checkElephantStepsHold,
  speakOut, numeroEnPalabras, isVoiceEnabled, REP_VOICE_RATE, exportDebugLogText, clearVoiceTransitionMute,
} from "./workout.js";
import { PersonGate } from "./workout.js";

// checkPlankPosture / checkSidePlankPosture / checkKneeHoldBarPosture /
// checkHandstandPosture viven ahora en workout.js (importadas arriba,
// igual que en circuit.js del lado web) — antes había aquí una copia
// local de esas funciones más sus constantes (PLANK_LINE_MIN_DEG y
// compañía), duplicando byte a byte lo que ya tenía workout.js. Se
// comparten así con el entreno suelto de una tarea (plancha ya no
// depende solo de estar dentro de un circuito), en vez de mantener la
// misma comprobación en dos sitios que se pueden desincronizar.
const POSTURE_COUNTERS = new Set(["supermanhold", "lsithold", "plank", "sideplank", "wallsit", "kneeholdbar", "tucklever", "deadhang", "handstand", "armcrossstretch", "tricepsoverheadstretch", "seatedhamstringstretch", "standingquadstretch", "elephantstepshold"]);

// Estiramientos bilaterales cronometrados (armcrossstretch/
// tricepsoverheadstretch: un brazo y luego el otro; seatedhamstringstretch/
// standingquadstretch: una pierna y luego la otra) -- en ROUTINES
// (seed_warmup_routines.py) aparecen dos veces seguidas, una por lado,
// porque un RoutineItem cronometrado no tiene "series" que alternar por sí
// solo (a diferencia de armcircles/legrotation, que sí llevan el sentido
// bloqueado dentro del propio contador -- ver processArmCircles en
// workout.js). Aquí se avisa (no se bloquea, el lado detectado por cámara
// puede fallar) si el lado de esta 2ª vez parece el mismo que la 1ª -- ver
// this.stretchSideDone/occurrenceInfo en runTimerWithPosture.
const STRETCH_SIDE_COUNTERS = new Set(["armcrossstretch", "tricepsoverheadstretch", "seatedhamstringstretch", "standingquadstretch"]);
const STRETCH_FIXED_SECONDS = 30; // duración fija de los estiramientos con cronómetro
const STRETCH_SIDE_LABEL = {
  armcrossstretch: "brazo",
  tricepsoverheadstretch: "brazo",
  seatedhamstringstretch: "pierna",
  standingquadstretch: "pierna",
};
// Rotación de codo (forearmrotation): mismo patrón "lado 1 de 2 / lado 2
// de 2" que los estiramientos de arriba, pero es un contador de repes por
// cámara (runCamera), no un aguante cronometrado (runTimerWithPosture) --
// aparte de STRETCH_SIDE_COUNTERS para no tocar isStretchFixed/
// POSTURE_COUNTERS, que no le corresponden. Badge/aviso añadidos dentro de
// runCamera() más abajo, reutilizando occurrenceInfo(). A petición de Alex
// (2026-09-25): antes un brazo y el otro compartían una sola pantalla con
// cambio de brazo a mitad (ver FOREARMROTATION_* en workout.js) -- ahora
// son dos pantallas seguidas, como los estiramientos.
const REP_SIDE_COUNTERS = new Set(["forearmrotation"]);
const REP_SIDE_LABEL = { forearmrotation: "brazo" };
// Círculos de brazos (2026-09-29, a petición de Alex): DOS pantallas seguidas
// (arm-circles listado 2 veces en seed_warmup_routines.py), la 1ª hacia
// delante y la 2ª hacia atrás; el sentido se fija por aparición (impar =
// hacia delante, par = hacia atrás) y viaja a workout.js en
// data-circle-direction. Sin segunda aparición no hay sentido fijo.
const DIRECTION_COUNTERS = new Set(["armcircles"]);

// Series de los ejercicios CRONOMETRADOS de un plan (2026-09-30, a petición
// de Alex): antes un aguante de plan (plancha, pino, silla en pared...)
// era UNA sola cuenta sin importar target_sets -- "3 series al fallo"
// hacía una y pasaba al siguiente. Ahora se repite target_sets veces con
// descanso entre series, igual que los de repeticiones (workout.js).
// SET_REST_SECONDS = REST_ALERT_SECONDS de workout.js (60 s de descanso
// entre series). Solo items con target_source === "plan": los circuitos
// sueltos también pueden traer target_sets (3 por defecto) sin que
// signifique "series" para un aguante.
const SET_REST_SECONDS = 60;
// "Al fallo" con cámara: la serie se da por terminada sola cuando la
// postura lleva FAILURE_POSTURE_LOST_SECONDS seguidos rota, siempre que
// antes se hubieran aguantado FAILURE_MIN_HOLD_SECONDS (mismo espíritu que
// PLANK_MIN_HOLD_TO_COUNT_SECONDS/*_INVALID_STABLE_MS de workout.js, pero
// más holgado: aquí el cierre también pasa de ejercicio y un falso
// positivo sale más caro).
const FAILURE_POSTURE_LOST_SECONDS = 3;
const FAILURE_MIN_HOLD_SECONDS = 2;

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

function beep(freq = 880, dur = 0.15) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = freq;
    osc.connect(gain);
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    osc.start();
    osc.stop(ctx.currentTime + dur);
  } catch {
    /* si el navegador bloquea el audio, seguimos igual */
  }
}

const fmt = (s) => {
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m > 0 ? `${m}:${String(r).padStart(2, "0")}` : String(r);
};

// Cronómetro de la sesión completa: h:mm:ss / m:ss.
const fmtClock = (s) => {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`
    : `${m}:${String(r).padStart(2, "0")}`;
};

const DRAFT_PREFIX = "libreta.sessionDraft.";

/**
 * Progreso guardado de una sesión sin terminar (llamada, distracción, lo
 * que sea que te saque a medias). Se guarda a nivel de EJERCICIO
 * completo -- cada vez que se cierra uno y se pasa al siguiente -- no
 * dentro de una serie en marcha: si la interrupción cae a mitad de un
 * ejercicio de cámara, ese ejercicio se pierde entero y hay que
 * rehacerlo, pero todo lo anterior queda a salvo y se puede continuar
 * justo por donde lo dejaste. Capturar el progreso SERIE A SERIE dentro
 * de un ejercicio exigiría enganchar el cierre de serie de workout.js en
 * cada contador (más de media docena de sitios distintos en un fichero
 * ya muy afinado a mano) -- se deja fuera por ahora.
 */
export function loadSessionDraft(key) {
  try {
    const raw = localStorage.getItem(DRAFT_PREFIX + key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveSessionDraft(key, data) {
  try {
    localStorage.setItem(DRAFT_PREFIX + key, JSON.stringify(data));
  } catch {
    /* localStorage lleno o bloqueado -- se sigue sin draft, no es fatal */
  }
}

export function clearSessionDraft(key) {
  try {
    localStorage.removeItem(DRAFT_PREFIX + key);
  } catch {
    /* nada que limpiar si ni esto funciona */
  }
}

// Voz encolada (flush:false) -- "Toca X", "la última vez aguantaste Y" -- que la cuenta
// del cronómetro (flush:true, cada segundo) cortaba en el segundo 1: el aviso de lo que
// aguantaste la última vez casi nunca se oía entero. Se estima cuánto dura lo encolado
// y la cuenta en voz alta espera a que acabe (la pantalla sigue contando).
let speechBusyUntil = 0;
function noteQueuedSpeech(text, { reset = false } = {}) {
  const now = performance.now();
  speechBusyUntil = (reset ? now : Math.max(now, speechBusyUntil)) + 400 + String(text).length * 90;
}
function countAloudOk() {
  return isVoiceEnabled() && performance.now() >= speechBusyUntil;
}

// "45 segundos" / "1 minuto y 5 segundos" -- para "la última vez aguantaste X"
// en los ejercicios cronometrados (item.last_seconds, ver Plan.session_items()).
function secondsLabel(n) {
  const t = Math.max(0, Math.round(n));
  if (t < 60) return `${t} ${t === 1 ? "segundo" : "segundos"}`;
  const m = Math.floor(t / 60), s = t % 60;
  const mm = `${m} ${m === 1 ? "minuto" : "minutos"}`;
  return s ? `${mm} y ${s} ${s === 1 ? "segundo" : "segundos"}` : mm;
}

export class SessionRunner {
  /**
   * @param {HTMLElement} host   dónde pintar
   * @param {Array} items        ejercicios del circuito, en el orden a hacer
   * @param {Function} onFinish  recibe el desglose al terminar
   * @param {string|null} draftKey  clave para guardar/retomar progreso si
   *   se sale a medias (ver loadSessionDraft) -- sin ella (circuitos
   *   sueltos, calentamiento) no se guarda ningún draft, como hasta ahora.
   * @param {boolean} autoFinish  a petición de Alex (2026-09-25), SOLO para
   *   el calentamiento: al terminar el último ejercicio, finish() pasa
   *   directo a onFinish() sin pintar la pantalla-resumen "Circuito
   *   completado" ni esperar el botón "Guardar y volver" -- el
   *   calentamiento no guarda ningún desglose de verdad (solo
   *   api.markWarmupDone() en warmup-view.js), así que no hay nada que
   *   confirmar. Circuitos normales y enfriamiento siguen con la pantalla
   *   de resumen de siempre (false por defecto).
   */
  constructor(host, items, onFinish, draftKey = null, autoFinish = false) {
    this.host = host;
    this.items = items;
    this.onFinish = onFinish;
    this.draftKey = draftKey;
    this.autoFinish = autoFinish;
    this.index = 0;
    this.breakdown = [];
    this.timerId = null;
    this.paused = false;
    // Lado (izquierdo/derecho) detectado por cámara la última vez que se
    // completó cada counter_key de STRETCH_SIDE_COUNTERS en ESTE circuito --
    // ver runTimerWithPosture/occurrenceInfo.
    this.stretchSideDone = {};
    // Series del ejercicio CRONOMETRADO en curso (ver SET_REST_SECONDS):
    // cuál toca, cuántas hay, cuántas se han hecho y los segundos sumados.
    this.setsTotal = 1;
    this.setNo = 1;
    this.setsDone = 0;
    this.heldTotal = 0;
    this.setSeconds = []; // segundos aguantados en cada serie del ejercicio en curso
    // Cronómetro de la SESIÓN COMPLETA (primer ejercicio -> último, con
    // descansos): tiempo activo en la app. Si se sale a medias y se
    // retoma, el rato fuera no cuenta (clockBeforeMs viene del draft).
    this.clockBeforeMs = 0;
    this.clockStartedAt = null;
    this.clockIntervalId = null;
    this.clockEl = null;
  }

  /** Segundos de sesión transcurridos (activos), con el rato de antes de
   *  retomar incluido. */
  elapsedSessionSeconds() {
    const running = this.clockStartedAt === null ? 0 : Date.now() - this.clockStartedAt;
    return Math.round((this.clockBeforeMs + running) / 1000);
  }

  startClock() {
    if (this.clockStartedAt !== null) return;
    this.clockStartedAt = Date.now();
    // Calentamiento (autoFinish): no es una sesión que se guarde -- sin reloj.
    if (this.autoFinish) return;
    this.clockEl = document.createElement("div");
    this.clockEl.className = "run-clock";
    this.clockEl.setAttribute("aria-label", "Tiempo total de la sesión");
    document.body.appendChild(this.clockEl);
    const paint = () => { this.clockEl.textContent = `⏱ ${fmtClock(this.elapsedSessionSeconds())}`; };
    paint();
    this.clockIntervalId = setInterval(paint, 1000);
  }

  /** Congela el cronómetro (al terminar o salir) y quita el reloj de pantalla. */
  stopClock() {
    if (this.clockStartedAt !== null) {
      this.clockBeforeMs += Date.now() - this.clockStartedAt;
      this.clockStartedAt = null;
    }
    clearInterval(this.clockIntervalId);
    this.clockIntervalId = null;
    this.clockEl?.remove();
    this.clockEl = null;
  }

  /** @param {{index:number, breakdown:Array}|null} resume  progreso
   *  guardado de una sesión anterior sin terminar -- si se pasa, continúa
   *  desde ahí en vez de empezar desde cero. */
  start(resume = null) {
    if (resume) {
      this.index = resume.index;
      this.breakdown = resume.breakdown;
      this.clockBeforeMs = Number(resume.elapsedMs) > 0 ? Number(resume.elapsedMs) : 0;
    } else {
      this.index = 0;
      this.breakdown = [];
      this.clockBeforeMs = 0;
    }
    this.startClock();
    // Confirmación antes de salir a medias -- ver __currentViewGuard en
    // app.js/router(). Se quita en finish() (ya queda a salvo, sea en el
    // draft o, tras guardar, en el servidor) y en destroy().
    window.__currentViewGuard = () => this.confirmExit();
    if (this.index >= this.items.length) this.finish();
    else this.runCurrent();
  }

  /** Texto de confirmación al intentar salir con la sesión a medias
   *  (botón atrás, "← Volver", cambiar de pestaña...). */
  confirmExit() {
    return confirm(
      this.draftKey
        ? "¿Seguro que quieres salir? Se guarda lo que ya has completado -- solo perderás el ejercicio en curso."
        : "¿Seguro que quieres salir? Perderás el progreso de este circuito."
    );
  }

  get current() {
    return this.items[this.index];
  }

  get hasNext() {
    return this.index < this.items.length - 1;
  }

  // "Al fallo" (item.work vacío): la última serie se anuncia como tal en
  // vez de "Serie N de N".
  setText(n, item) {
    const last = n === this.setsTotal && this.setsTotal > 1 && item && !item.work;
    return last ? "Última serie de este ejercicio" : `Serie ${n} de ${this.setsTotal}`;
  }

  progressLabel() {
    const base = `Ejercicio ${this.index + 1} de ${this.items.length}`;
    return this.setsTotal > 1 ? `${base} · ${this.setText(this.setNo, this.current)}` : base;
  }

  /** Series que tiene que hacer un ejercicio CRONOMETRADO (aguante o
   *  cuenta atrás). 1 = como siempre (una sola cuenta). Los de cámara
   *  (mode "pose") llevan sus series dentro de workout.js, y los
   *  estiramientos por lado ya son dos apariciones seguidas. */
  plannedSets(item) {
    if (item.target_source !== "plan" || item.mode === "pose") return 1;
    if (STRETCH_SIDE_COUNTERS.has(item.counter_key)) return 1;
    return Math.max(1, parseInt(item.target_sets, 10) || 1);
  }

  /** Decide con qué reproducir el ejercicio actual. */
  runCurrent() {
    const item = this.current;
    if (!item) return this.finish();
    this.setsTotal = this.plannedSets(item);
    this.setNo = 1;
    this.setsDone = 0;
    this.heldTotal = 0;
    this.setSeconds = [];
    // Dice el nombre del ejercicio al empezar (cámara, aguante o cronómetro,
    // tren superior o inferior) para saber cuál toca sin mirar la pantalla.
    // flush:false: no corta lo que aun estuviera sonando del ejercicio anterior
    // (p.ej. el ultimo numero); los avisos de después se encolan detrás.
    clearVoiceTransitionMute();
    if (isVoiceEnabled()) {
      const occ = this.occurrenceInfo(item);
      // El primero del plan dice "Toca ..."; los siguientes, "Ahora toca ...".
      const toca = this.index === 0 ? "Toca" : "Ahora toca";
      const nombre = occ ? `${toca} ${item.name}, lado ${occ.occurrence} de ${occ.total}` : `${toca} ${item.name}`;
      const frase = this.setsTotal > 1 ? `${nombre}. Serie 1 de ${this.setsTotal}` : nombre;
      noteQueuedSpeech(frase);
      speakOut(frase, { flush: false });
    }
    this.runSet(item);
  }

  /** Arranca UNA serie (o el ejercicio entero, si solo tiene una). */
  runSet(item) {
    if (item.mode !== "pose") this.announceLastSeconds(item);
    if (item.mode === "pose") this.runCamera(item);
    else if (POSTURE_COUNTERS.has(item.counter_key)) this.runTimerWithPosture(item);
    else this.runTimer(item);
  }

  // ------------------------------------------- "la última vez aguantaste"

  /** Lo que aguantaste en ESTA serie la última vez (item.last_seconds,
   *  [45, 40, 38]) o null si no hay historial. Sin parte "Serie N" si el
   *  ejercicio solo tiene una serie. */
  lastSecondsText(item, { spoken = false } = {}) {
    const last = item && item.last_seconds;
    if (!Array.isArray(last) || !last.length) return null;
    const i = this.setNo - 1; // serie en curso, base 0
    const multi = this.setsTotal > 1;
    const sep = spoken ? ". " : ": ";
    const cap = spoken ? "La" : "la";
    // Última serie al fallo: ya se rotula/anuncia como "Última serie de este
    // ejercicio" (setText), así que no se repite como "Serie N".
    const isLast = this.setNo === this.setsTotal && multi && item && !item.work;
    const pre = isLast ? "" : `Serie ${i + 1}${sep}`;
    if (i >= last.length) {
      return `${pre}${cap} última vez hiciste ${last.length} ${last.length === 1 ? "serie" : "series"}${spoken ? "." : ", esta es extra"}`;
    }
    const held = `${cap} última vez aguantaste ${secondsLabel(last[i])}`;
    return multi ? `${pre}${held}${spoken ? " en esta serie." : ""}` : `${held}${spoken ? "." : ""}`;
  }

  lastSecondsHintHtml(item) {
    const t = this.lastSecondsText(item);
    return t ? `<p class="circuit__side-hint run-last-hint">${esc(t)}</p>` : "";
  }

  /** Lo dice por voz al empezar cada serie cronometrada (sin cortar lo
   *  que ya estuviera sonando). */
  announceLastSeconds(item) {
    if (!isVoiceEnabled()) return;
    const t = this.lastSecondsText(item, { spoken: true });
    if (t) {
      noteQueuedSpeech(t);
      speakOut(t, { flush: false });
    }
  }

  // ------------------------------------------------------- cronómetro

  runTimer(item) {
    // ¿Quedan series después de esta? (ver plannedSets)
    const moreSets = this.setNo < this.setsTotal;
    this.host.innerHTML = `
      <div class="circuit">
        <p class="circuit__progress">${esc(this.progressLabel())}</p>
        <div class="circuit__icon">${exerciseIcon(item.slug)}</div>
        <h2 class="circuit__exercise-name">${esc(item.name)}</h2>
        <p class="circuit__phase circuit__phase--work">${item.work ? "Trabajo" : "Al fallo"}</p>
        ${this.lastSecondsHintHtml(item)}
        <div class="circuit__timer" id="run-timer">${fmt(item.work || 0)}</div>
        <p class="circuit__next">${
          this.hasNext ? `Siguiente: ${esc(this.items[this.index + 1].name)}` : "¡Último!"
        }</p>
        <div class="circuit__controls">
          <button type="button" class="workout__btn workout__btn--ghost" id="run-pause">Pausar</button>
          <button type="button" class="workout__btn workout__btn--primary" id="run-skip">${
            moreSets && !item.work ? "Serie hecha ▸" : this.hasNext ? "Siguiente ▸" : "Terminar"
          }</button>
        </div>
        ${moreSets && !item.work ? `<button type="button" class="workout__btn workout__btn--ghost" id="run-skip-exercise">Saltar ejercicio ▸</button>` : ""}
        <button type="button" class="workout__btn workout__btn--subtle" id="run-quit">Terminar sesión antes</button>
        <button type="button" class="workout__btn workout__btn--ghost" id="run-debug-export">📋 Enviar registro de depuración</button>
        <p id="run-debug-export-status" class="workout__debug"></p>
      </div>`;

    // "Al fallo" (item.work vacío/null -- ver Plan.session_items() en el
    // backend, PROG_FAILURE): no hay segundos objetivo que contar hacia
    // atrás -- el ejercicio consiste precisamente en aguantar hasta que
    // ya no puedas, así que aquí se cuenta libremente hacia ADELANTE
    // desde 0 (como cualquier cronómetro de cronómetro, sin cierre
    // automático) hasta que el usuario mismo decida que ha llegado al
    // fallo y pulse el botón de avanzar. Mismo concepto que el modo
    // freestyle sin objetivo de notePostureOk() en workout.js.
    const isFailure = !item.work;
    let remaining = item.work;
    let elapsed = 0;
    let lastSpokenNumber = null; // último entero ya dicho, para no repetirlo en el mismo segundo
    const timerEl = document.getElementById("run-timer");
    this.paused = false;

    // Registro de depuración -- misma idea que this.scissorLog en
    // workout.js (ver exportDebugLogText), pero sin controller de
    // cámara: aquí no hay reps que contar, así que basta una línea por
    // segundo con lo que estaba pasando (cuánto llevaba, paused...).
    const debugLines = [];
    const DEBUG_LINES_MAX = 3600;
    const logDebugLine = (line) => {
      debugLines.push(`${elapsed}s ${line}`);
      if (debugLines.length > DEBUG_LINES_MAX) debugLines.shift();
    };

    clearInterval(this.timerId);
    this.timerId = setInterval(() => {
      if (this.paused) return;
      elapsed += 1;
      if (isFailure) {
        timerEl.textContent = fmt(elapsed);
        logDebugLine("al fallo (cuenta libre)");
        if (countAloudOk() && elapsed !== lastSpokenNumber) {
          lastSpokenNumber = elapsed;
          speakOut(numeroEnPalabras(elapsed), { rate: REP_VOICE_RATE });
        }
        return;
      }
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(this.timerId);
        logDebugLine(`objetivo cumplido (${item.work}s)`);
        beep(880, 0.2);
        this.finishTimedSet(item, item.work);
        return;
      }
      logDebugLine(`restantes=${remaining}s de ${item.work}s`);
      if (remaining <= 3) beep(660, 0.1);
      // Cuenta atrás dicha en voz alta cada segundo — igual que ya hacía
      // runTimerWithPosture() más abajo (mismo motivo: se pidió poder
      // seguir un ejercicio cronometrado de oído, sin mirar la pantalla,
      // igual que ya se puede con las repeticiones).
      if (countAloudOk() && remaining !== lastSpokenNumber) {
        lastSpokenNumber = remaining;
        speakOut(numeroEnPalabras(remaining), { rate: REP_VOICE_RATE });
      }
      timerEl.textContent = fmt(remaining);
    }, 1000);

    const pauseBtn = document.getElementById("run-pause");
    pauseBtn.addEventListener("click", () => {
      this.paused = !this.paused;
      pauseBtn.textContent = this.paused ? "Reanudar" : "Pausar";
      logDebugLine(this.paused ? "pausado" : "reanudado");
    });
    // Al fallo: el botón principal cierra ESTA serie (y con ella el
    // ejercicio si era la última). Con objetivo de segundos: sigue siendo
    // "saltar el ejercicio" entero, como siempre.
    document.getElementById("run-skip").addEventListener("click", () => {
      clearInterval(this.timerId);
      this.finishTimedSet(item, elapsed, { skipExercise: !isFailure });
    });
    document.getElementById("run-skip-exercise")?.addEventListener("click", () => {
      clearInterval(this.timerId);
      this.finishTimedSet(item, elapsed, { skipExercise: true });
    });
    document.getElementById("run-quit").addEventListener("click", () => {
      clearInterval(this.timerId);
      this.quitTimed(item, elapsed);
    });
    document.getElementById("run-debug-export").addEventListener("click", () => {
      exportDebugLogText({
        lines: debugLines,
        counterKey: item.counter_key || item.slug,
        statusEl: document.getElementById("run-debug-export-status"),
        platform: "mobile",
      });
    });
  }

  // -------------------------------------------- series de un cronometrado

  /** Cierra UNA serie cronometrada con `seconds` aguantados. Si quedan
   *  series por hacer, descanso (SET_REST_SECONDS) y la siguiente; si era
   *  la última (o `skipExercise`), guarda el ejercicio entero -- segundos
   *  totales y series hechas, que es lo que espera el backend para
   *  medir el % (series × segundos, o series si es al fallo, ver
   *  WorkoutSession.achievement_pct) -- y pasa solo al siguiente. */
  finishTimedSet(item, seconds, { skipExercise = false, recordEmpty = false } = {}) {
    clearInterval(this.timerId);
    if (seconds > 0) {
      this.heldTotal += seconds;
      this.setsDone += 1;
      this.setSeconds.push(Math.round(seconds * 10) / 10);
    }
    if (!skipExercise && this.setNo < this.setsTotal) {
      const done = this.setNo;
      this.setNo += 1;
      this.runSetRest(item, done);
      return;
    }
    this.recordTimed(item, recordEmpty);
    this.advance();
  }

  /** "Terminar sesión antes" a mitad de un cronometrado: guarda lo que
   *  llevara y cierra todo. */
  quitTimed(item, seconds, recordEmpty = false) {
    if (seconds > 0) {
      this.heldTotal += seconds;
      this.setsDone += 1;
      this.setSeconds.push(Math.round(seconds * 10) / 10);
    }
    this.recordTimed(item, recordEmpty);
    this.finish();
  }

  recordTimed(item, recordEmpty = false) {
    if (this.heldTotal <= 0 && !recordEmpty) return;
    const entry = { exercise: item.slug, seconds: this.heldTotal };
    // "sets" solo en ejercicios de plan (el % de los "al fallo" se mide en
    // series hechas); en circuitos/calentamiento se queda como antes.
    if (item.target_source === "plan") entry.sets = this.setsDone;
    // Segundos de CADA serie: sirven para "la última vez aguantaste X".
    if (this.setSeconds.length) entry.set_seconds = [...this.setSeconds];
    this.record(entry);
  }

  /** Descanso ENTRE series del mismo ejercicio (el de entre ejercicios
   *  sigue siendo item.rest, ver advance()). */
  runSetRest(item, doneNo) {
    if (isVoiceEnabled()) {
      speakOut(`Serie ${doneNo} de ${this.setsTotal} terminada. Descanso.`, { flush: false }); // sin cortar el ultimo numero de la cuenta
    }
    this.runRest(SET_REST_SECONDS, {
      nextItem: item,
      progress: `${this.progressBase()} · Serie ${doneNo} de ${this.setsTotal} hecha`,
      nextLabel: `Siguiente: ${this.setText(this.setNo, item).toLowerCase()} — ${item.name}`,
      onDone: () => {
        if (isVoiceEnabled()) {
          const frase = this.setText(this.setNo, item);
          noteQueuedSpeech(frase, { reset: true }); // flush:true corta lo anterior
          speakOut(frase, { flush: true });
        }
        this.runSet(item);
      },
      onSkipExercise: () => {
        this.recordTimed(item);
        this.advance();
      },
    });
  }

  progressBase() {
    return `Ejercicio ${this.index + 1} de ${this.items.length}`;
  }

  // ------------------------------------------------- cronómetro + postura

  /** Para STRETCH_SIDE_COUNTERS con más de una aparición en this.items: en
   *  qué posición (1 de 2, 2 de 2...) está `item` entre las suyas -- para
   *  poder avisar "ahora el otro lado" en vez de repetir el mismo nombre
   *  sin más contexto. null si el ejercicio no es de este grupo o solo
   *  aparece una vez (nada que numerar). */
  occurrenceInfo(item) {
    if (!STRETCH_SIDE_COUNTERS.has(item.counter_key) && !REP_SIDE_COUNTERS.has(item.counter_key) && !DIRECTION_COUNTERS.has(item.counter_key)) return null;
    const siblings = this.items.filter((i) => i.counter_key === item.counter_key);
    if (siblings.length < 2) return null;
    return { occurrence: siblings.indexOf(item) + 1, total: siblings.length };
  }

  async runTimerWithPosture(item) {
    const checker =
      item.counter_key === "sideplank"
        ? checkSidePlankPosture
        : item.counter_key === "wallsit"
        ? checkWallSitPosture
        : item.counter_key === "kneeholdbar"
        ? checkKneeHoldBarPosture
        : item.counter_key === "deadhang"
        ? checkDeadHangPosture
        : item.counter_key === "tucklever"
        ? checkTuckLeverPosture
        : item.counter_key === "handstand"
        ? checkHandstandPosture
        : item.counter_key === "supermanhold"
        ? createSupermanHoldChecker()
        : item.counter_key === "lsithold"
        ? createLSitHoldChecker()
        : item.counter_key === "armcrossstretch"
        ? checkArmCrossStretch
        : item.counter_key === "tricepsoverheadstretch"
        ? checkTricepsOverheadStretch
        : item.counter_key === "seatedhamstringstretch"
        ? checkSeatedHamstringStretch
        : item.counter_key === "standingquadstretch"
        ? createStandingQuadStretchChecker()
        : item.counter_key === "elephantstepshold"
        ? checkElephantStepsHold
        : checkPlankPosture;

    // "Al fallo" (item.work vacío/null -- Plan.session_items(), PROG_FAILURE):
    // no hay segundos objetivo que cumplir, así que no tiene sentido ni
    // una cuenta atrás ni el aviso de "objetivo cumplido" -- se cuenta
    // libremente desde el principio y el botón principal para pasar al
    // siguiente ejercicio está disponible desde ya (como en el modo
    // cámara/reps, ver runCamera), no escondido detrás de un objetivo que
    // aquí no existe.
    // Estiramientos con cronómetro: 30 s fijos (da igual lo que diga el plan) y,
    // en cuanto se cumplen, pasa solo al siguiente ejercicio (sin pulsar nada).
    const isStretchFixed = STRETCH_SIDE_COUNTERS.has(item.counter_key);
    const work = isStretchFixed ? STRETCH_FIXED_SECONDS : item.work;
    const isFailure = !work;
    // Series (ver plannedSets/SET_REST_SECONDS): ¿esta no es la última?
    const moreSets = this.setNo < this.setsTotal;
    const multiSets = this.setsTotal > 1;
    const occ = this.occurrenceInfo(item);
    const sideLabel = STRETCH_SIDE_LABEL[item.counter_key] || "lado";

    this.host.innerHTML = `
      <div class="circuit">
        <p class="circuit__progress">${esc(this.progressLabel())}</p>
        <h2 class="circuit__exercise-name">${esc(item.name)}${occ ? ` <span class="circuit__side-badge">(lado ${occ.occurrence} de ${occ.total})</span>` : ""}</h2>
        <p class="circuit__phase circuit__phase--work">${isFailure ? "Al fallo" : "Trabajo"}</p>
        ${this.lastSecondsHintHtml(item)}
        ${
          occ
            ? occ.occurrence > 1
              ? `<p class="circuit__side-hint">🔁 Lado ${occ.occurrence} de ${occ.total} -- usa el ${sideLabel} contrario al de la vez anterior.</p>`
              : `<p class="circuit__side-hint">Lado ${occ.occurrence} de ${occ.total} -- elige un ${sideLabel} para empezar; el siguiente será con el contrario.</p>`
            : ""
        }
        <div class="workout__camera">
          <video id="posture-video" playsinline muted class="workout__video"></video>
          <canvas id="posture-canvas" class="workout__canvas"></canvas>
        </div>
        <p id="posture-status" class="workout__status">Preparando la cámara…</p>
        <p id="run-goal-banner" class="workout__goal-banner" hidden></p>
        <div class="circuit__timer" id="run-timer">${fmt(0)}</div>
        <p class="circuit__next">${
          this.hasNext ? `Siguiente: ${esc(this.items[this.index + 1].name)}` : "¡Último!"
        }</p>
        <div class="circuit__controls">
          <button type="button" class="workout__btn ${isFailure ? "workout__btn--primary" : "workout__btn--ghost"}" id="run-skip">${
            isFailure ? (moreSets ? "Serie hecha ▸" : this.hasNext ? "Siguiente ▸" : "Terminar") : "Saltar ▸"
          }</button>
        </div>
        ${isFailure && moreSets ? `<button type="button" class="workout__btn workout__btn--ghost" id="run-skip-exercise">Saltar ejercicio ▸</button>` : ""}
        <button type="button" class="workout__btn workout__btn--subtle" id="run-quit">Terminar sesión antes</button>
        <button type="button" class="workout__btn workout__btn--ghost" id="run-debug-export">📋 Enviar registro de depuración</button>
        <p id="run-debug-export-status" class="workout__debug"></p>
        <p class="workout__note">${
          isFailure
            ? `Aguanta hasta que ya no puedas: la serie se cierra sola si pierdes la postura unos segundos (o pulsa ${moreSets ? "«Serie hecha»" : "Siguiente/Terminar"}).${moreSets ? ` Después, descanso de ${SET_REST_SECONDS} s.` : this.hasNext ? " Al terminar pasa solo al siguiente ejercicio." : ""}`
            : multiSets
            ? `Serie ${this.setNo} de ${this.setsTotal}: al llegar a 0 ${moreSets ? `descansas ${SET_REST_SECONDS} s y sigue la siguiente serie` : "pasa solo al siguiente ejercicio"}. La cuenta atrás se pausa sola mientras la postura no sea correcta.`
            : this.autoFinish && !isStretchFixed ? "Al llegar a 0 pasa solo al siguiente ejercicio. La cuenta atrás se pausa sola mientras la postura no sea correcta."
            : isStretchFixed ? "30 segundos fijos: la cuenta atrás se pausa sola mientras la postura no sea correcta y, al llegar a 0, pasa sola al siguiente ejercicio." : "La cuenta atrás se pausa sola mientras la postura no sea correcta. Si sigues después del objetivo, sigue sumando por encima del 100%."
        }</p>
      </div>`;

    // OJO: a diferencia de antes, llegar a item.work YA NO cierra el
    // ejercicio solo — antes remaining llegaba a 0 y se cerraba la serie
    // de golpe, así que nunca se podía aguantar más del objetivo (ni
    // aunque quisieras). Ahora, igual que en dominadas/fondos (sigue
    // contando por encima del 100% si quieres, se guarda tal cual), el
    // cronómetro pasa a contar hacia ADELANTE los segundos de propina y
    // eres tú quien decide cuándo parar con "Saltar"/"Terminar antes".
    let elapsed = 0;
    let postureOk = false;
    let goalReached = false;
    let lastSpokenNumber = null; // último entero (cuenta atrás o adelante) ya dicho, para no repetirlo en el mismo segundo
    let lastPostureDebug = ""; // valores medidos (angulos, etc.) del ultimo check, para el registro
    let lastPostureReason = ""; // último check.reason (o motivo de "no visible"), para el registro de depuración
    let plankLowSince = null; // plancha: desde cuándo llevas pasando solo por el margen laxo de incline
    let detectedSide = null; // último lado ("left"/"right") que devolvió checker(), solo para STRETCH_SIDE_COUNTERS
    const previousSide = STRETCH_SIDE_COUNTERS.has(item.counter_key) ? this.stretchSideDone[item.counter_key] : null;
    this.postureRunning = true;
    this.postureStream = null;
    this.posturePoseLandmarker = null;
    // Esta función es async: mientras espera la cámara y el modelo el
    // usuario puede pulsar "Serie hecha"/"Saltar" (o pasar la serie sola).
    // stopPostureCamera() sube this.postureRun, así que `stale()` dice que
    // esta ejecución ya no es la vigente -- si siguiera, pisaría this.timerId
    // (el descanso de la pantalla nueva se quedaba congelado) y dejaría la
    // cámara encendida.
    const myRun = (this.postureRun = (this.postureRun || 0) + 1);
    const stale = () => this.postureRun !== myRun;
    const timerEl = document.getElementById("run-timer");
    const statusEl = document.getElementById("posture-status");
    const goalBannerEl = document.getElementById("run-goal-banner");
    const skipBtn = document.getElementById("run-skip");
    const video = document.getElementById("posture-video");
    const canvas = document.getElementById("posture-canvas");

    // Registro de depuración -- ver exportDebugLogText en workout.js.
    // Aquí sí hay datos reales de postura por segundo (postureOk,
    // check.reason), a diferencia del cronómetro puro de runTimer().
    const debugLines = [];
    const DEBUG_LINES_MAX = 3600;
    const logDebugLine = (line) => {
      debugLines.push(`${elapsed}s ${line}`);
      if (debugLines.length > DEBUG_LINES_MAX) debugLines.shift();
    };

    // Para la cámara y apunta el lado; el guardado y el paso a
    // descanso/siguiente los hace finishTimedSet (ver "series de un
    // cronometrado").
    const stopThis = () => {
      clearInterval(this.timerId);
      this.stopPostureCamera();
      if (STRETCH_SIDE_COUNTERS.has(item.counter_key) && detectedSide) {
        this.stretchSideDone[item.counter_key] = detectedSide;
      }
    };

    // Al fallo: el botón principal cierra ESTA serie. Con objetivo de
    // segundos: "Saltar"/"Siguiente" salta el ejercicio entero, como antes.
    skipBtn.addEventListener("click", () => {
      stopThis();
      this.finishTimedSet(item, elapsed, { skipExercise: !isFailure, recordEmpty: true });
    });
    document.getElementById("run-skip-exercise")?.addEventListener("click", () => {
      stopThis();
      this.finishTimedSet(item, elapsed, { skipExercise: true, recordEmpty: true });
    });
    document.getElementById("run-quit").addEventListener("click", () => {
      stopThis();
      this.quitTimed(item, elapsed, true);
    });
    document.getElementById("run-debug-export").addEventListener("click", () => {
      exportDebugLogText({
        lines: debugLines,
        counterKey: item.counter_key || item.slug,
        statusEl: document.getElementById("run-debug-export-status"),
        platform: "mobile",
      });
    });

    let stream = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        // Misma resolución que workout.js (ver ahí el porqué): 1280x720
        // en vez de 640x480, para que el seguimiento no se degrade a
        // cierta distancia de la cámara.
        video: { facingMode: "user", width: 1280, height: 720 }, audio: false,
      });
    } catch (err) {
      statusEl.textContent = "No se pudo acceder a la cámara — revisa el permiso en Ajustes. La cuenta atrás sigue sin comprobar la postura.";
      postureOk = true; // sin cámara, no bloquea el ejercicio — degrada a cronómetro normal
    }
    if (stale()) {
      if (stream) stream.getTracks().forEach((t) => t.stop());
      return;
    }
    this.postureStream = stream;

    if (this.postureStream) {
      video.srcObject = this.postureStream;
      await video.play();
      if (stale()) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;

      let landmarker = null;
      try {
        const { FilesetResolver, PoseLandmarker } = await import(MEDIAPIPE_LIB);
        const vision = await FilesetResolver.forVisionTasks(MEDIAPIPE_WASM);
        const modelBuffer = await loadModel((msg) => { statusEl.textContent = msg; });
        landmarker = await PoseLandmarker.createFromOptions(vision, {
          baseOptions: { modelAssetBuffer: new Uint8Array(modelBuffer), delegate: "GPU" },
          runningMode: "VIDEO", numPoses: 1, outputSegmentationMasks: true,
        });
      } catch (err) {
        statusEl.textContent = "No se pudo cargar el seguimiento de postura. La cuenta atrás sigue sin comprobarla.";
        postureOk = true;
        console.error(err);
      }
      if (stale()) {
        if (landmarker) landmarker.close();
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      this.posturePoseLandmarker = landmarker;

      if (this.posturePoseLandmarker) {
        const personGate = new PersonGate(); // 2026-10-08: solo se miden posturas de la persona confirmada (ver PersonGate en workout.js)
        const loop = () => {
          if (!this.postureRunning || stale()) return;
          const frameNow = performance.now();
          const result = this.posturePoseLandmarker.detectForVideo(video, frameNow);
          const hasPoseNow = !!(result.landmarks && result.landmarks.length);
          if (hasPoseNow) personGate.sampleMask(result, frameNow);
          const person = hasPoseNow ? personGate.check(result.landmarks[0], frameNow) : null;
          if (typeof result.close === "function") result.close(); // libera las máscaras de persona
          if (person && person.ok) {
            // 2026-10-01: plancha: igual que en el entreno suelto, umbrales laxos una vez aguantando (holding=postureOk del frame anterior)
            let check = item.counter_key === "plank" ? checker(result.landmarks[0], postureOk) : checker(result.landmarks[0]);
            if (item.counter_key === "plank") {
              if (check.ok && check.lowIncline) {
                if (plankLowSince === null) plankLowSince = performance.now();
                if (performance.now() - plankLowSince > 4000) {
                  check = { ok: false, reason: "Sube las caderas: el cuerpo entero tiene que quedar alzado del suelo, apoyado en los antebrazos y los pies, no tumbado.", debug: check.debug };
                }
              } else {
                plankLowSince = null;
              }
            }
            postureOk = check.ok;
            lastPostureReason = check.ok ? "" : check.reason;
            lastPostureDebug = check.debug ? Object.entries(check.debug).map(([k, v]) => `${k}=${v ?? "-"}`).join(" ") : "";
            if (check.ok && check.side) detectedSide = check.side;
            const sameSideWarning =
              check.ok && previousSide && detectedSide && detectedSide === previousSide
                ? ` ⚠️ Parece el mismo ${sideLabel} que la vez anterior -- prueba con el contrario para trabajar los dos lados.`
                : "";
            statusEl.textContent = check.ok ? `Postura correcta — aguanta.${sameSideWarning}` : `⚠️ ${check.reason}`;
          } else {
            postureOk = false;
            lastPostureReason = "no visible";
            statusEl.textContent = "No se te ve — sal en el encuadre.";
          }
          requestAnimationFrame(loop);
        };
        loop();
      }
    }

    clearInterval(this.timerId);
    let lostSeconds = 0; // segundos seguidos con la postura rota (solo para cerrar una serie al fallo)
    this.timerId = setInterval(() => {
      if (!postureOk) {
        lostSeconds += 1;
        logDebugLine(`pausado (postura no válida: ${lastPostureReason || "?"}) ${lastPostureDebug}`);
        // Al fallo no hay objetivo que dé la serie por cumplida: como en
        // los ejercicios de repeticiones, se cierra sola cuando ya no
        // aguantas la postura (tras haber aguantado algo).
        if (isFailure && elapsed >= FAILURE_MIN_HOLD_SECONDS && lostSeconds >= FAILURE_POSTURE_LOST_SECONDS) {
          logDebugLine(`serie al fallo cerrada: postura rota ${lostSeconds}s tras ${elapsed}s`);
          stopThis();
          beep(880, 0.2);
          this.finishTimedSet(item, elapsed, { recordEmpty: true });
        }
        return; // pausado mientras la postura no sea válida
      }
      lostSeconds = 0;
      elapsed += 1;

      if (isFailure) {
        // Sin objetivo: cuenta libre hacia adelante, cada 5s por voz
        // (mismo ritmo que el "over" de abajo, para no atropellar la
        // voz leyendo un número cada segundo).
        timerEl.textContent = fmt(elapsed);
        logDebugLine(`al fallo (cuenta libre), postura ok ${lastPostureDebug}`);
        if (countAloudOk() && elapsed !== lastSpokenNumber) {
          lastSpokenNumber = elapsed;
          speakOut(numeroEnPalabras(elapsed), { rate: REP_VOICE_RATE });
        }
        return;
      }

      if (!goalReached && elapsed < work) {
        // Cuenta atrás normal hacia el objetivo — igual que antes, pero
        // ahora además dicha en voz alta cada segundo (como cada
        // repetición en dominadas/fondos), para que se pueda seguir sin
        // mirar la pantalla.
        const remaining = work - elapsed;
        timerEl.textContent = fmt(remaining);
        logDebugLine(`restantes=${remaining}s de ${work}s, postura ok ${lastPostureDebug}`);
        if (remaining <= 3) beep(660, 0.1);
        if (countAloudOk() && remaining !== lastSpokenNumber) {
          lastSpokenNumber = remaining;
          speakOut(numeroEnPalabras(remaining), { rate: REP_VOICE_RATE });
        }
        return;
      }

      if (!goalReached) {
        // Calentamiento (this.autoFinish, ver constructor): TODO aguante
        // pasa solo al siguiente al cumplir el objetivo, no solo los
        // estiramientos de STRETCH_SIDE_COUNTERS (a petición de Alex,
        // 2026-09-30: dead hang se quedaba esperando "Siguiente ▸").
        if (isStretchFixed || this.autoFinish || multiSets) {
          // Objetivo cumplido: aviso y siguiente ejercicio automático (o,
          // con varias series, descanso y la siguiente -- ver
          // finishTimedSet).
          beep(880, 0.2);
          stopThis();
          this.finishTimedSet(item, work);
          return;
        }
        // Objetivo alcanzado justo este segundo — un aviso, una sola vez,
        // y sin cortar nada (el ejercicio sigue: ya no se cierra solo).
        goalReached = true;
        lastSpokenNumber = 0;
        logDebugLine(`objetivo cumplido (${work}s)`);
        beep(880, 0.2);
        if (isVoiceEnabled()) speakOut(numeroEnPalabras(0), { flush: true, rate: REP_VOICE_RATE });
        if (goalBannerEl) {
          goalBannerEl.hidden = false;
          goalBannerEl.textContent = `🎯 ¡Objetivo cumplido! (${fmt(work)}) Sigue si quieres, o termina cuando acabes.`;
        }
        // "Saltar" ya no describe bien lo que hace este botón una vez
        // cumplido el objetivo (no se está saltando nada) — mismo texto
        // que usa workout.js para el botón equivalente en reps. También
        // pasa a ser el botón PRINCIPAL (antes se quedaba de igual peso
        // visual que "Terminar sesión antes", que en realidad termina
        // TODA la sesión, no solo este ejercicio — se prestaba a
        // confusión, ver runTimer()).
        skipBtn.textContent = this.hasNext ? "Siguiente ▸" : "Terminar";
        skipBtn.classList.remove("workout__btn--ghost");
        skipBtn.classList.add("workout__btn--primary");
        timerEl.textContent = "+0";
        return;
      }

      // Por encima del objetivo: cuenta hacia ADELANTE los segundos de
      // propina, igual que seguir oyendo "9", "10" al pasarte de un
      // objetivo de 8 dominadas — así se nota de oído que vas por encima
      // del 100% (y se guarda tal cual: ver finish(), el % de logro ya
      // sabe compararlo contra item.work).
      const over = elapsed - work;
      timerEl.textContent = `+${fmt(over)}`;
      logDebugLine(`propina +${over}s por encima del objetivo`);
      if (countAloudOk() && over !== lastSpokenNumber) {
        lastSpokenNumber = over;
        speakOut(numeroEnPalabras(over), { rate: REP_VOICE_RATE });
      }
    }, 1000);
  }

  // ------------------------------------------------------------ cámara

  async runCamera(item) {
    const circleOcc = item.counter_key === "armcircles" ? this.occurrenceInfo(item) : null;
    // 2026-10-01 (Alex): igual que la rotación de codo -- el mismo ejercicio
    // DOS veces, cada una cuenta target_reps giros en el sentido que sea
    // (data-circle-direction="any", ver armCircleAnyDirection en workout.js).
    // Con una sola aparición en el circuito se conserva el modo antiguo.
    const circleDir = circleOcc ? "any" : "";
    const objetivo = item.counter_key === "armcircles"
      ? (circleDir ? `${item.target_reps}` : `${item.target_reps} de cada sentido`)
      : item.counter_key === "legrotation"
      ? `${item.target_reps} de cada pierna`
      // "Al fallo" (PROG_FAILURE): sin target_reps, no hay número que
      // pedir -- ver el mismo caso en runTimer/runTimerWithPosture y en
      // plan-view.js/targetText().
      : item.target_reps
      ? `${item.target_sets} × ${item.target_reps}`
      : `${item.target_sets} series al fallo`;
    // De dónde sale el número importa: no es lo mismo "porque lo pusiste
    // en el circuito" que "porque tu plan va por ahí".
    const fuente = item.target_source === "plan"
      ? `<span class="run-plan">plan «${esc(item.plan_name || "")}» · sesión ${item.session_index}</span>`
      : "";
    const occ = this.occurrenceInfo(item);
    const sideLabel = STRETCH_SIDE_LABEL[item.counter_key] || REP_SIDE_LABEL[item.counter_key] || "lado";
    this.host.innerHTML = `
      <div id="workout-root" class="workout"
           data-save-url="local" data-cancel-url="#/" data-exercise-slug="${esc(item.slug)}"
           data-counter-key="${esc(item.counter_key || "pullup")}"
           data-circle-direction="${circleDir}"
           data-voice-step="${item.voice_step || ""}"
           data-auto-advance="${this.autoFinish ? "1" : ""}"
           data-target-sets="${item.target_sets || ""}" data-target-reps="${item.target_reps || ""}"
           data-last-sets="${item.last_sets ? esc(JSON.stringify(item.last_sets)) : ""}">
        <p class="circuit__progress">${esc(this.progressLabel())}</p>
        <h2 class="circuit__exercise-name">${esc(item.name)}${circleDir ? ` <span class="circuit__side-badge">(vez ${circleOcc.occurrence} de ${circleOcc.total})</span>` : occ ? ` <span class="circuit__side-badge">(lado ${occ.occurrence} de ${occ.total})</span>` : ""}</h2>
        <p class="run-target">Objetivo: <strong>${objetivo}</strong> ${fuente}</p>
        <p id="workout-last-hint" class="circuit__side-hint run-last-hint" hidden></p>
        ${
          circleDir
            ? circleOcc.occurrence > 1
              ? `<p class="circuit__side-hint">🔁 Vez ${circleOcc.occurrence} de ${circleOcc.total} -- gira los dos brazos en el sentido contrario al de la vez anterior. Al llegar al objetivo pasa solo al siguiente.</p>`
              : `<p class="circuit__side-hint">Vez ${circleOcc.occurrence} de ${circleOcc.total} -- gira los dos brazos en el sentido que quieras; la siguiente vez será en el contrario. Al llegar al objetivo pasa solo a la siguiente.</p>`
            : occ
            ? occ.occurrence > 1
              ? `<p class="circuit__side-hint">🔁 Lado ${occ.occurrence} de ${occ.total} -- usa el ${sideLabel} contrario al de la vez anterior.</p>`
              : `<p class="circuit__side-hint">Lado ${occ.occurrence} de ${occ.total} -- elige un ${sideLabel} para empezar; el siguiente será con el contrario.</p>`
            : ""
        }
        <div class="workout__camera">
          <video id="workout-video" playsinline muted class="workout__video"></video>
          <canvas id="workout-canvas" class="workout__canvas"></canvas>
        </div>
        <p id="workout-goal-banner" class="workout__goal-banner" hidden></p>
        <button type="button" id="workout-debug-export" class="workout__btn workout__btn--ghost">📋 Copiar registro de depuración</button>
        <p id="workout-debug-export-status" class="workout__debug"></p>
        <details class="workout__stats-toggle">
          <summary class="workout__stats-summary">Datos</summary>
          <div class="workout__stats">
          <div class="workout__stat"><span class="workout__stat-value" id="workout-reps">0</span><span class="workout__stat-label">reps</span></div>
          <div class="workout__stat"><span class="workout__stat-value" id="workout-sets">1</span><span class="workout__stat-label">serie</span></div>
          <div class="workout__stat"><span class="workout__stat-value" id="workout-timer">0:00</span><span class="workout__stat-label">sesión</span></div>
          <div class="workout__stat"><span class="workout__stat-value" id="workout-rest">0:00</span><span class="workout__stat-label">descanso</span></div>
          <div class="workout__stat"><span class="workout__stat-value" id="workout-last-rep">–</span><span class="workout__stat-label">última rep</span></div>
          </div>
        </details>
        <div class="workout__actions">
          <button type="button" id="workout-cancel" class="workout__btn workout__btn--ghost">Saltar</button>
          <button type="button" id="workout-recalibrate" class="workout__btn workout__btn--ghost">↻ Recalibrar</button>
          <button type="button" id="workout-finish" class="workout__btn workout__btn--primary">
            ${this.hasNext ? "Siguiente ▸" : "Terminar"}
          </button>
        </div>
        <p class="workout__note">El vídeo no sale de tu móvil. Solo se guardan los números.</p>
      </div>`;

    // workout.js llama a esto al pulsar "Siguiente/Terminar". Aquí, en vez
    // de cerrar la sesión, se apunta lo hecho y se pasa al siguiente
    // ejercicio del circuito.
    window.__workoutSubmit = async (payload) => {
      this.record({
        exercise: item.slug,
        reps: payload.total_reps || 0,
        sets: payload.total_sets || 0,
        set_reps: (payload.sets || []).map((s) => s.reps || 0).filter((r) => r > 0),
        // Tiempo de cada rep, serie a serie (paralelo a set_reps: mismo
        // filtro reps > 0) -- el backend lo guarda en WorkoutSession.sets
        // y rep_durations.
        set_durations: (payload.sets || []).filter((s) => (s.reps || 0) > 0).map((s) => s.durations || []),
        avg_rep_seconds: payload.rep_durations?.length
          ? Math.round((100 * payload.rep_durations.reduce((a, d) => a + d, 0)) / payload.rep_durations.length) / 100
          : null,
        seconds: payload.session_duration_seconds || 0,
      });
      beep(880, 0.2);
      this.advance();
    };

    let __mod;
    try {
      __mod = await import("./workout.js");
    } catch (impErr) {
      throw new Error(`No se pudo cargar ./workout.js: ${impErr.message}`);
    }
    const { startWorkout } = __mod;
    this.workoutSession = startWorkout();

    // "Saltar" no debe guardar nada de este ejercicio, solo pasar.
    document.getElementById("workout-cancel").addEventListener(
      "click",
      (e) => {
        e.stopImmediatePropagation();
        this.workoutSession?.stopCamera?.();
        window.__workoutSubmit = null;
        this.advance();
      },
      true
    );
  }

  // ------------------------------------------------------------ flujo

  record(entry) {
    this.breakdown.push(entry);
  }

  advance() {
    const item = this.current;
    this.index += 1;
    this.saveDraft();
    if (this.index >= this.items.length) return this.finish();

    // Las series del ejercicio que acaba de cerrarse no pintan en la
    // pantalla de descanso del siguiente (ver progressLabel).
    this.setsTotal = 1;
    this.setNo = 1;

    // Plan: el descanso entre ejercicios = el de entre series (60 s, a
    // petición de Alex 2026-10-08). Calentamiento/circuitos sueltos: item.rest.
    const rest = item?.target_source === "plan" ? SET_REST_SECONDS : (item?.rest ?? 0);
    if (rest > 0) this.runRest(rest);
    else this.runCurrent();
  }

  /** Deja constancia de por dónde vas, para poder continuar si hace
   *  falta salir antes de terminar del todo (ver begin() en
   *  plan-view.js). Sin draftKey no hace nada. */
  saveDraft() {
    if (!this.draftKey) return;
    saveSessionDraft(this.draftKey, {
      items: this.items,
      index: this.index,
      breakdown: this.breakdown,
      // Tiempo de sesión ya cronometrado, para retomar sin perderlo.
      elapsedMs: this.elapsedSessionSeconds() * 1000,
      savedAt: Date.now(),
    });
  }

  /** @param {number} seconds
   *  @param {{nextItem?:object, progress?:string, nextLabel?:string,
   *           onDone?:Function, onSkipExercise?:Function}} opts  por
   *   defecto, el descanso de entre ejercicios (siguiente = this.current
   *   y luego runCurrent); runSetRest lo usa para el de entre series. */
  runRest(seconds, opts = {}) {
    const next = opts.nextItem || this.current;
    const onDone = opts.onDone || (() => this.runCurrent());
    this.host.innerHTML = `
      <div class="circuit">
        <p class="circuit__progress">${esc(opts.progress || this.progressLabel())}</p>
        <div class="circuit__icon circuit__icon--next">${exerciseIcon(next.slug)}</div>
        <h2 class="circuit__exercise-name">Descanso</h2>
        <p class="circuit__phase circuit__phase--rest">Descanso</p>
        <div class="circuit__timer" id="run-timer">${fmt(seconds)}</div>
        <p class="circuit__next">${esc(opts.nextLabel || `Siguiente: ${next.name}`)}</p>
        <div class="circuit__controls">
          <button type="button" class="workout__btn workout__btn--ghost" id="run-skip-rest">Saltar descanso ▸</button>
        </div>
        ${opts.onSkipExercise ? `<button type="button" class="workout__btn workout__btn--ghost" id="run-skip-exercise-rest">Saltar ejercicio ▸</button>` : ""}
      </div>`;

    let remaining = seconds;
    const timerEl = document.getElementById("run-timer");
    clearInterval(this.timerId);
    this.timerId = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(this.timerId);
        beep(880, 0.2);
        onDone();
        return;
      }
      if (remaining <= 3) beep(660, 0.1);
      timerEl.textContent = fmt(remaining);
    }, 1000);

    document.getElementById("run-skip-rest").addEventListener("click", () => {
      clearInterval(this.timerId);
      onDone();
    });
    document.getElementById("run-skip-exercise-rest")?.addEventListener("click", () => {
      clearInterval(this.timerId);
      opts.onSkipExercise();
    });
  }

  /** Corta la cámara de comprobación de postura (plancha/plancha
   * lateral), si había una encendida — pareja de stopCamera() en
   * workoutSession, pero para este caso que no pasa por workout.js. */
  stopPostureCamera() {
    this.postureRunning = false;
    // Invalida cualquier runTimerWithPosture() que siga esperando a la
    // cámara/modelo (ver `stale` allí).
    this.postureRun = (this.postureRun || 0) + 1;
    if (this.postureStream) this.postureStream.getTracks().forEach((t) => t.stop());
    if (this.posturePoseLandmarker) this.posturePoseLandmarker.close();
  }

  finish() {
    clearInterval(this.timerId);
    window.__workoutSubmit = null;
    this.workoutSession?.stopCamera?.();
    this.stopPostureCamera();
    // Por si se llega aquí por "Terminar antes" (run-quit) sin haber
    // pasado por advance(): deja el draft al día por si se sale de esta
    // misma pantalla de resumen sin pulsar "Guardar y volver".
    this.saveDraft();
    this.stopClock();
    const meta = { session_seconds: this.elapsedSessionSeconds() };

    // Calentamiento (autoFinish): nada que confirmar ni que guardar de
    // verdad (ver el JSDoc del constructor) -- se pasa directo a
    // onFinish() sin pintar la pantalla-resumen ni esperar ningún click,
    // igual que ya hace cada ejercicio suelto del calentamiento al
    // llegar a su objetivo (ver NO_REST_COUNTERS/"pushup" en workout.js).
    if (this.autoFinish) {
      window.__currentViewGuard = null;
      if (this.draftKey) clearSessionDraft(this.draftKey);
      this.onFinish(this.breakdown, meta);
      return;
    }

    const totalReps = this.breakdown.reduce((a, b) => a + (b.reps || 0), 0);
    const totalSecs = this.breakdown.reduce((a, b) => a + (b.seconds || 0), 0);

    this.host.innerHTML = `
      <div class="circuit__done">
        <p class="circuit__done-title">¡Circuito completado! 💪</p>
        <p>${this.breakdown.length} ejercicio(s)${
      totalReps ? ` · ${totalReps} repeticiones` : ""
    } · ${fmt(totalSecs)}</p>
        <p class="run-total-time">⏱ Tiempo total de la sesión: <strong>${fmtClock(meta.session_seconds)}</strong></p>
        <ul class="run-summary">
          ${this.breakdown
            .map((b) => {
              const item = this.items.find((i) => i.slug === b.exercise);
              const detail = b.reps
                ? `${b.reps} reps en ${b.sets} serie(s)`
                : b.sets > 1
                ? `${b.seconds}s en ${b.sets} series`
                : `${b.seconds}s`;
              // Porcentaje conseguido sobre el objetivo, si lo había.
              // Para reps es sobre el volumen total (sets × reps); para
              // cronometrados (plancha, plancha lateral…) es sobre el
              // objetivo de ESE tramo (item.work) — aquí no hay "series"
              // que sumar, cada aparición en el circuito es un aguante
              // suelto, y ahora puede superar el objetivo (ver
              // runTimerWithPosture, ya no se corta solo al llegar).
              let pct = "";
              if (item?.target_sets && item?.target_reps && b.reps) {
                const meta = item.target_sets * item.target_reps;
                const logro = Math.round((100 * b.reps) / meta);
                const clase = logro >= 100 ? "run-pct--full" : "run-pct--partial";
                pct = `<span class="run-pct ${clase}">${logro}%</span>`;
              } else if (item?.work && b.seconds) {
                // Con series (plan): total aguantado contra series × segundos.
                const series = item.target_source === "plan" ? Math.max(1, item.target_sets || 1) : 1;
                const logro = Math.round((100 * b.seconds) / (item.work * series));
                const clase = logro >= 100 ? "run-pct--full" : "run-pct--partial";
                pct = `<span class="run-pct ${clase}">${logro}%</span>`;
              } else if (item?.target_source === "plan" && !item.work && !item.target_reps && item.target_sets && b.sets) {
                // Al fallo: el % son series hechas sobre las pedidas (igual que el backend).
                const logro = Math.round((100 * b.sets) / item.target_sets);
                const clase = logro >= 100 ? "run-pct--full" : "run-pct--partial";
                pct = `<span class="run-pct ${clase}">${logro}%</span>`;
              }
              const avgRep = b.avg_rep_seconds ? ` · ${b.avg_rep_seconds.toFixed(1)}s/rep` : "";
              return `<li><span>${esc(item?.name || b.exercise)}</span><span>${detail}${avgRep} ${pct}</span></li>`;
            })
            .join("")}
        </ul>
        <button type="button" class="primary-btn" id="run-save">Guardar y volver</button>
      </div>`;

    document.getElementById("run-save").addEventListener("click", async (e) => {
      e.target.disabled = true;
      e.target.textContent = "Guardando…";
      // Ya se está guardando de verdad -- no hace falta seguir
      // preguntando si se sale, ni conservar el draft local.
      window.__currentViewGuard = null;
      if (this.draftKey) clearSessionDraft(this.draftKey);
      await this.onFinish(this.breakdown, meta);
    });
  }

  destroy() {
    clearInterval(this.timerId);
    this.stopClock();
    window.__workoutSubmit = null;
    window.__currentViewGuard = null;
    this.workoutSession?.stopCamera?.();
    this.stopPostureCamera();
  }
}

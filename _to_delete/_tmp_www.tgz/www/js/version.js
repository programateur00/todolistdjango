/**
 * Versión de esta build de la app — se sube a mano en cada release.
 *
 * app.js la compara contra el campo mobile_app.version que devuelve
 * /api/meta/ (ver tasks/utils.read_mobile_release en el backend) para
 * avisar de que hay una versión más nueva colgada en el servidor. Al
 * publicar una build nueva, este número y el "version" de
 * mobile_releases/latest.json en el servidor tienen que decir lo
 * mismo — si no coinciden, o la app avisa de una actualización que en
 * realidad ya tienes, o no avisa de una que sí hay.
 */
export const APP_VERSION = "93";

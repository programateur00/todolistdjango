/**
 * Comprobación automática de Health Connect para tareas de running.
 *
 * Running (subcategory="running") no tiene botón de "empezar sesión" —
 * ver Task.workout_kind en el backend: no hay nada que anotar a mano.
 * Esta función es la que de verdad cierra esas tareas: se llama sola
 * cada vez que se carga la lista de tareas (viewTasks en app.js), sin
 * que el usuario tenga que tocar nada.
 *
 * Necesita el plugin nativo HealthConnect (Kotlin + Capacitor, en
 * mobile-app/android — ver el README del proyecto para compilarlo). Si
 * esta build no lo tiene, o Health Connect no está instalado en el
 * móvil, aquí no pasa nada: la app sigue funcionando exactamente igual
 * que antes, solo que running no se completa sola y sigue haciendo
 * falta el check normal de "hecha" de cualquier tarea.
 */
import { api } from "./api.js";

function plugin() {
  return window.Capacitor?.Plugins?.HealthConnect || null;
}

/**
 * Desde cuándo buscar sesión para ESTA tarea concreta: medianoche de su
 * due_date si la tiene, o el momento en que se creó si es una tarea
 * suelta sin fecha. Con esto una tarea de hoy no se completa con la
 * salida a correr de anteayer, y — como cada repetición es una fila de
 * Task nueva (ver Task._spawn_next en el backend) — la de mañana no
 * hereda por error la sesión que ya cerró la de hoy.
 */
function sinceEpochMs(task) {
  if (task.due_date) {
    const [y, m, d] = task.due_date.split("-").map(Number);
    return new Date(y, m - 1, d, 0, 0, 0, 0).getTime();
  }
  return new Date(task.created_at).getTime();
}

/**
 * Comprueba las tareas de running PENDIENTES contra Health Connect y
 * cierra (vía api.saveWorkoutHealth) las que ya cumplan su objetivo.
 * Devuelve cuántas se cerraron, para que quien llame decida si hace
 * falta refrescar la pantalla — 0 es la respuesta normal la mayoría de
 * las veces (todavía no ha corrido, o el plugin no está compilado).
 */
export async function checkPendingRunningTasks(pendingTasks) {
  const runningTasks = (pendingTasks || []).filter(
    (t) => t.category === "sport" && t.subcategory === "running"
  );
  if (!runningTasks.length) return 0;

  const hc = plugin();
  if (!hc) return 0;

  try {
    const perm = await hc.hasPermissions();
    if (!perm?.granted) {
      // No se insiste en cada carga de la lista si el usuario ya dijo
      // que no: Health Connect enseña su propio diálogo del sistema,
      // así que pedirlo una y otra vez sería spam. Se intenta una vez;
      // si el usuario lo rechaza, tendrá que concederlo a mano desde
      // Ajustes de Android (Health Connect > libreta.tareas > permisos)
      // para que esto vuelva a intentarlo.
      const granted = await hc.requestPermissions().catch(() => null);
      if (!granted?.granted) return 0;
    }
  } catch {
    return 0; // Health Connect no instalado, o el plugin falló al arrancar
  }

  let closed = 0;
  for (const task of runningTasks) {
    try {
      const since = sinceEpochMs(task);
      const { sessions } = await hc.getSessions({ sinceEpochMs: since });
      if (!sessions?.length) continue;

      // La de más distancia primero: es la que más papeletas tiene de
      // cumplir el objetivo, así que si hay varias sesiones ese día se
      // manda esa antes que una más corta.
      const candidates = [...sessions].sort(
        (a, b) => (b.distanceMeters || 0) - (a.distanceMeters || 0)
      );
      for (const s of candidates) {
        const distanceKm = (s.distanceMeters || 0) / 1000;
        const durationMinutes = (s.endEpochMs - s.startEpochMs) / 60000;
        if (!distanceKm || !durationMinutes) continue;

        let result;
        try {
          result = await api.saveWorkoutHealth(task.uuid, {
            exercise: s.exerciseType === "walking" ? "walking" : "running",
            distance_km: Math.round(distanceKm * 100) / 100,
            duration_minutes: Math.round(durationMinutes * 10) / 10,
            steps: s.steps || undefined,
          });
        } catch {
          continue; // sin conexión u otro fallo — se reintenta la próxima vez que se abra la lista
        }
        if (result?.matched) {
          closed += 1;
          break; // esta tarea ya está — pasar a la siguiente tarea de running
        }
        // Si no cumplió, se prueba con la siguiente sesión candidata
        // (por si la más larga en distancia no llegaba a la velocidad
        // mínima, pero otra más corta y más rápida sí).
      }
    } catch {
      // Un fallo comprobando UNA tarea no debe impedir comprobar las demás.
    }
  }
  return closed;
}

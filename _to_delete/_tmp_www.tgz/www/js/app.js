/**
 * Router y vistas de la app.
 *
 * SPA con rutas por hash (#/ruta). Sin framework a propósito: son cinco
 * pantallas y meter React/Vue aquí traería más peso y más cosas que
 * aprender que las que ahorra.
 *
 * Reutiliza styles.css tal cual de la web, así la app se ve igual.
 */

import { api, AuthError } from "./api.js";
import { notifications } from "./notifications.js";
import * as healthSync from "./health-sync.js";
import { APP_VERSION } from "./version.js";

import "./camera-fullscreen.js";
// Mismo listado que Task.PACE_PRESETS en el servidor — en lenguaje llano
// porque "6:30/km" no dice nada a quien no corre. El número entre
// paréntesis es solo para quien ya lo sabe leer.
const PACE_PRESETS = [
  [900, "Paseo tranquilo (15:00/km)"],
  [720, "Paseo normal (12:00/km)"],
  [600, "Andar a paso ligero (10:00/km)"],
  [480, "Trote suave (8:00/km)"],
  [390, "Correr (6:30/km)"],
  [330, "Correr a buen ritmo (5:30/km)"],
  [270, "Correr rápido (4:30/km)"],
  [210, "Correr muy rápido (3:30/km)"],
];

// workout.js y circuit.js son copias de la web y allí arrancan solos al
// cargarse. Aquí los arranca el router en cada visita, así que esta
// bandera les dice que no se auto-arranquen.
window.__LIBRETA_APP__ = true;

const view = document.getElementById("view");
const tabbar = document.getElementById("tabbar");
const offlineBanner = document.getElementById("offline-banner");
const queueBanner = document.getElementById("queue-banner");
const updateBanner = document.getElementById("update-banner");

let META = null;

// ------------------------------------------------------------ helpers

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

function showOffline(on) {
  offlineBanner.hidden = !on;
}

function refreshQueueBanner() {
  const n = api.queueLength();
  queueBanner.hidden = n === 0;
  if (n) queueBanner.textContent = `${n} cambio(s) pendiente(s) de enviar.`;
}

/**
 * Compara la versión que devuelve /api/meta/ (mobile_app.version, leída
 * del lado del servidor de mobile_releases/latest.json — ver
 * tasks/utils.read_mobile_release) contra APP_VERSION de esta build.
 * Si no coinciden, enseña un aviso fijo con un enlace que abre la
 * descarga en el navegador DEL SISTEMA (no dentro del WebView: "_system"
 * es lo que Capacitor intercepta para eso sin añadir ningún plugin
 * nuevo) — así Android puede ofrecer instalar el APK al terminar de
 * bajarlo, cosa que dentro del propio WebView no pasa de forma fiable.
 *
 * Sin bloquear el arranque: si falla (sin red, servidor caído, versión
 * vieja del backend sin este campo todavía...) simplemente no avisa de
 * nada, igual que si no hubiera actualización.
 */
async function checkForAppUpdate() {
  if (!api.isConfigured()) return;
  const meta = await ensureMeta();
  const info = meta?.mobile_app;
  if (!info || !info.version || !info.download_url) return;
  if (String(info.version) === String(APP_VERSION)) return;
  const base = (api.getConfig().baseUrl || "").replace(/\/+$/, "");
  const downloadUrl = `${base}${info.download_url}`;
  updateBanner.innerHTML = `Hay una versión nueva de la app (${esc(info.version)}) — <a href="#" id="update-link">actualizar</a>`;
  updateBanner.hidden = false;
  document.getElementById("update-link")?.addEventListener("click", (e) => {
    e.preventDefault();
    window.open(downloadUrl, "_system");
  });
}

function loading(msg = "Cargando…") {
  view.innerHTML = `<p class="app-loading">${esc(msg)}</p>`;
}

/**
 * Aviso en pantalla. Sustituye a alert(): dentro de un WebView los
 * diálogos nativos del navegador pueden no aparecer según la
 * configuración, y entonces el usuario no se entera de nada — que es
 * justo lo que pasaba al intentar borrar una tarea.
 */
export function toast(msg, kind = "info") {
  const box = document.createElement("div");
  box.className = "toast toast--" + kind;
  box.textContent = msg;
  document.body.prepend(box);
  setTimeout(() => box.remove(), kind === "error" ? 7000 : 3500);
}
window.__toast = toast;

function errorView(err) {
  const isAuth = err instanceof AuthError;
  // 2026-09-18: para un SyntaxError al parsear un import() dinámico,
  // err.stack suele traer la URL exacta del módulo que no ha podido
  // parsear -- err.message solo (lo único que se enseñaba antes) no
  // decía CUÁL de los varios archivos que se cargan con import() había
  // fallado. Se enseña también aquí para poder leerlo directamente en
  // la pantalla del móvil, sin depurador conectado.
  const stackLine = (err.stack || "").split("\n").find((l) => /\.m?js/.test(l)) || "";
  view.innerHTML = `
    <div class="app-error">
      <p>${esc(err.message || "Algo ha fallado.")}</p>
      ${stackLine ? `<p class="workout__debug" style="user-select:text; word-break:break-all;">${esc(stackLine.trim())}</p>` : ""}
      ${isAuth ? '<a class="primary-btn" href="#/ajustes">Revisar ajustes</a>' : ""}
      <button class="ghost-btn" id="retry">Reintentar</button>
    </div>`;
  document.getElementById("retry")?.addEventListener("click", () => router());
}

function topbar(eyebrow, title, backHref) {
  return `
    <header class="topbar">
      <div class="topbar__title">
        <span class="topbar__eyebrow">${esc(eyebrow)}</span>
        <h1>${esc(title)}</h1>
      </div>
      ${backHref ? `<a href="${backHref}" class="stats-link">← Volver</a>` : ""}
    </header>`;
}

/**
 * Resumen de la semana (12 Week Year): done/total sobre las ocurrencias
 * de la semana actual. Lo manda ya calculado el backend — ver
 * Occurrence.weekly_completion en models.py — así que aquí solo se
 * pinta. Mismo componente en la lista de tareas y en Rachas.
 */
function countLabel(done, total, suffix = "") {
  // "1 tarea de 3 hechas", "2 tareas de 2 hechas", "0 tareas de 1 hecha"
  const noun = done === 1 ? "tarea" : "tareas";
  const part = total === 1 ? "hecha" : "hechas";
  return `${done} ${noun} de ${total} ${part}${suffix}`;
}

function progressBlock(label, stat, emptyText, suffix = "") {
  const pct = stat.pct;
  const bar =
    pct !== null && pct !== undefined
      ? `<div class="stats-bar"><div class="stats-bar__done" style="width:${pct}%"></div></div>`
      : "";
  const meta = stat.total ? countLabel(stat.done, stat.total, suffix) : emptyText;
  return `
      <div class="week-summary__top">
        <span class="week-summary__label">${esc(label)}</span>
        <span class="week-summary__pct">${pct !== null && pct !== undefined ? pct + "%" : "—"}</span>
      </div>
      ${bar}
      <p class="week-summary__meta">${esc(meta)}</p>`;
}

function weekSummary(weekly, daily) {
  if (!weekly) return "";
  return `
    <section class="week-summary" aria-label="Progreso de hoy y de la semana">
      ${daily ? progressBlock("Hoy", daily, "No hay tareas para hoy", " hoy") : ""}
      ${progressBlock("Esta semana", weekly, "Todavía no hay tareas esta semana")}
    </section>`;
}

async function ensureMeta() {
  if (META) return META;
  const { data } = await api.meta();
  META = data;
  return META;
}

// -------------------------------------------------------------- vistas

/**
 * Sincroniza con Health Connect sin bloquear el pintado de la lista: si
 * tarda o falla, la lista ya está en pantalla. Si algo se importa y
 * marca una tarea, se repinta para que se vea sin recargar a mano.
 */
async function syncHealthInBackground(pendingTasks) {
  if (!healthSync.isSupported()) return;
  const runTasks = pendingTasks.filter(
    (t) => t.subcategory === "running",
  );
  if (!runTasks.length) return;

  let cambioAlgo = false;
  for (const t of runTasks) {
    try {
      const res = await healthSync.syncRuns(t.uuid);
      if (res?.task?.is_done) cambioAlgo = true;
      // Antes los fallos eran invisibles: ahora se avisa del motivo.
      if (res?.reason === "sin-permiso") {
        window.__toast?.("Health Connect: falta permiso de lectura (Ajustes → Salud y actividad).", "error");
      } else if (res?.reason === "error-lectura") {
        window.__toast?.("Health Connect: error al leer — " + (res.errores?.[0] || "desconocido"), "error");
      } else if (res?.reason === "no-plugin") {
        window.__toast?.("Esta versión de la app no incluye Health Connect.", "error");
      } else if (res?.imported) {
        window.__toast?.(`Health Connect: importadas ${res.imported} sesiones.`);
      }
    } catch (err) {
      console.error("healthSync", t.uuid, err);
    }
  }
  if (cambioAlgo) {
    api.clearCache();
    window.__toast?.("Actividad importada — tarea completada.");
    if (location.hash === "#/" || location.hash === "") viewTasks();
  }
}

async function viewTasks() {
  loading();
  const { data, fromCache } = await api.tasks();
  showOffline(fromCache);
  await ensureMeta();

  // Reprograma los avisos nocturnos cada vez que se ve la lista: así se
  // mantienen al día sin necesidad de un sitio especial donde hacerlo.
  const all = [...data.pending, ...data.completed];
  const tasksByUuid = new Map(all.map((t) => [t.uuid, t]));
  notifications.schedule(all).catch(() => {});

  // Health Connect: se sincroniza al abrir la lista, no en segundo
  // plano. Android restringe mucho el trabajo en segundo plano para
  // ahorrar batería, y en la práctica da igual — nadie mira la app
  // mientras corre, así que al abrirla ya se encuentra la tarea marcada.
  syncHealthInBackground(data.pending);

  const card = (t) => {
    // Un play para todas: comunica "empezar sesión" mejor que un icono
    // técnico. Lo que cambia es el TEXTO, porque sí importa saber si va a
    // abrir la cámara antes de pulsar.
    const kind = t.workout_kind;
    const PLAY = '<path d="M7 4.5l12 7.5-12 7.5v-15z"/>';
    const TITLES = {
      camera: "Contar repeticiones con la cámara",
      timer: "Empezar circuito cronometrado",
      distance: "Anotar la sesión",
      focus: "Empezar temporizador",
      video: "Ver el vídeo",
    };
    const failAction = t.is_avoid ? "failed" : "not-done";
    return `
      <li class="task-card ${t.is_important ? "task-card--important" : ""} ${t.is_done ? "task-card--done" : ""}">
        <div class="task-card__actions">
          ${
            t.is_done
              ? `<button class="check-btn check-btn--undo" data-mark="reopen" data-uuid="${t.uuid}"
                    title="Deshacer: volver a dejarla pendiente">
                   <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10h11a5 5 0 0 1 0 10h-3M3 10l4-4M3 10l4 4"/></svg>
                 </button>`
              : kind === "distance" || kind === "auto"
              ? // Running/andar se completa solo al importar de Health
                // Connect en segundo plano (ver syncHealthInBackground), y
                // Curso de Udemy al recibir minutos suficientes de la
                // extensión de Chrome del PC — en ambos casos no hay nada
                // que pulsar ni que mostrar aquí: se resuelven solas o,
                // si no se cumple el objetivo, quedan como no hechas al
                // llegar la hora límite (ver Task.mark_expired). La
                // pantalla de importar a mano (#/entreno/) se queda
                // construida por si hace falta en el futuro, solo que ya
                // no se enlaza desde aquí. Se reserva el mismo ancho que
                // una tarjeta normal para que el título quede alineado
                // con el resto de la lista.
                `<span class="task-card__actions-spacer" aria-hidden="true"></span>`
              : kind
              ? `<a class="workout-btn" href="${
                    // Si la tarea la generó un plan, no hay nada que elegir:
                    // el plan ya decidió qué ejercicios y con qué objetivo.
                    // Vídeo manda por encima de todo lo demás — es una
                    // tarea que se resuelve entera viéndolo.
                    kind === "video"
                      ? `#/video/${t.uuid}`
                      : kind === "focus"
                      ? `#/enfoque/${t.uuid}`
                      : t.plan_uuid ? `#/plan-sesion/${t.uuid}/${t.plan_uuid}` : `#/entreno/${t.uuid}`
                  }" title="${t.plan_uuid && kind !== "video" ? "Empezar la sesión de tu plan" : TITLES[kind]}">
                   <svg viewBox="0 0 24 24" width="19" height="19" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${PLAY}</svg>
                 </a>`
              : `<button class="check-btn check-btn--done" data-mark="done" data-uuid="${t.uuid}"
                    title="${t.is_avoid ? "Confirmar que lo he evitado" : "Marcar como hecha"}">
                   <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5l5 5L20 6"/></svg>
                 </button>`
          }
          ${
            t.is_done || kind === "distance" || kind === "auto"
              ? ""
              : `<button class="check-btn check-btn--undone" data-mark="${failAction}" data-uuid="${t.uuid}"
                    title="${t.is_avoid ? "He caído hoy" : "Marcar como no hecha"}">
                   <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
                 </button>`
          }
        </div>
        <a class="task-card__body" href="#/editar/${t.uuid}">
          <div class="task-card__title-row">
            <p class="task-card__title ${t.is_done ? "task-card__title--struck" : ""}">
              ${t.is_done ? `<span class="strike-wrap">${esc(t.title)}</span>` : esc(t.title)}
            </p>
            ${t.current_streak > 0 ? `<span class="task-card__streak" title="Racha actual">🔥 ${t.current_streak}</span>` : ""}
          </div>
          <div class="task-card__meta">
            <span class="meta-pill meta-pill--category meta-pill--${esc(t.category)}">${esc(t.category_display)}</span>
            ${t.due_date ? `<span class="meta-pill meta-pill--date">${esc(t.due_date)}</span>` : ""}
            ${
              t.due_time
                ? t.is_avoid
                  ? `<span class="meta-pill meta-pill--time">🌙 ${esc(t.due_time)}</span>`
                  : t.is_overdue
                  ? `<span class="meta-pill meta-pill--time meta-pill--late">⏰ pasada</span>`
                  : t.minutes_left !== null && t.minutes_left <= 60
                  ? `<span class="meta-pill meta-pill--time meta-pill--urgent">⚡ ${t.minutes_left} min</span>`
                  : `<span class="meta-pill meta-pill--time">🕐 ${esc(t.due_time)}</span>`
                : ""
            }
          </div>
        </a>
        <button class="task-card__delete" data-del="${t.uuid}" title="Eliminar" aria-label="Eliminar">
          <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>
        </button>
      </li>`;
  };

  // La lista de hechas va plegada por defecto (como en Microsoft To Do):
  // lo que importa es lo que queda por hacer, no lo que ya cerraste.
  const doneOpen = localStorage.getItem("libreta.doneOpen") === "1";

  view.innerHTML = `
    ${topbar("mi libreta", "Tareas")}
    ${weekSummary(data.weekly, data.daily)}
    ${
      data.pending.length
        ? `<ul class="task-list">${data.pending.map(card).join("")}</ul>`
        : `<p class="empty">Nada pendiente. 🎉</p>`
    }
    ${
      data.completed.length
        ? `<button class="done-toggle" id="done-toggle" aria-expanded="${doneOpen}">
             <span class="done-toggle__arrow">${doneOpen ? "▾" : "▸"}</span>
             Hechas <span class="done-toggle__count">${data.completed.length}</span>
           </button>
           <ul class="task-list task-list--done" id="done-list" ${doneOpen ? "" : "hidden"}>
             ${data.completed.map(card).join("")}
           </ul>`
        : ""
    }`;

  const toggle = document.getElementById("done-toggle");
  if (toggle) {
    toggle.addEventListener("click", () => {
      const list = document.getElementById("done-list");
      const open = list.hasAttribute("hidden");
      list.toggleAttribute("hidden", !open);
      toggle.querySelector(".done-toggle__arrow").textContent = open ? "▾" : "▸";
      toggle.setAttribute("aria-expanded", String(open));
      localStorage.setItem("libreta.doneOpen", open ? "1" : "0");
    });
  }

  // Borrar desde la propia tarjeta, como en la web. Confirmación en dos
  // pasos por lo mismo de antes: confirm() puede no aparecer en el WebView.
  view.querySelectorAll("[data-del]").forEach((btn) => {
    let armed = false;
    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!armed) {
        armed = true;
        btn.classList.add("task-card__delete--armed");
        btn.title = "Pulsa otra vez para eliminar (el historial se conserva)";
        toast("Pulsa otra vez para eliminar. Su historial y estadísticas se conservan.");
        setTimeout(() => {
          armed = false;
          btn.classList.remove("task-card__delete--armed");
          btn.title = "Eliminar";
        }, 4000);
        return;
      }
      btn.disabled = true;
      try {
        await api.deleteTask(btn.dataset.del);
        toast("Tarea eliminada. Su historial y estadísticas se conservan.");
      } catch (err) {
        if (err.queued) toast("Sin conexión: se eliminará al volver la red.");
        else {
          toast(err.message, "error");
          btn.disabled = false;
          return;
        }
      }
      api.clearCache();
      router();
    });
  });

  view.querySelectorAll("[data-mark]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      // Cancela el aviso de esta tarea YA, sin esperar a que el
      // router() de más abajo recargue la lista y reconcilie todo —
      // así, si estás sin conexión (la marca queda en cola) o pasa un
      // rato antes de volver a abrir la app, no salta igual un aviso de
      // algo que ya se acaba de resolver aquí mismo. "reopen" queda
      // fuera a propósito: ahí la tarea vuelve a estar pendiente y sí
      // necesita su aviso de vuelta.
      if (btn.dataset.mark !== "reopen") {
        notifications.cancelNow(tasksByUuid.get(btn.dataset.uuid)).catch(() => {});
      }
      try {
        await api.markTask(btn.dataset.uuid, btn.dataset.mark);
      } catch (e) {
        if (!e.queued) {
          toast(e.message, "error");
        } else {
          // Sin red: ya ha quedado en la cola (y api._enqueue() se
          // encarga de que solo haya UNA copia por tarea, así que
          // tocar el tick otra vez desde aquí no hace nada nuevo). No
          // se llama a router(): la caché no se ha enterado de nada
          // todavía, así que redibujar la lista solo volvería a
          // enseñar esta misma tarea como pendiente e invitaría a
          // pulsar otra vez pensando que no ha servido de nada. Se
          // deja el botón deshabilitado y con un aviso claro en su
          // lugar.
          toast("Sin conexión: se enviará al recuperar la red.");
          refreshQueueBanner();
          return;
        }
      }
      refreshQueueBanner();
      router();
    });
  });
}

async function viewTaskForm(uuid) {
  loading();
  await ensureMeta();
  let task = null;
  if (uuid) {
    const { data } = await api.get(`/tasks/${uuid}/`);
    task = data.task;
  }

  const catOptions = META.categories
    .map(
      (c) => `<label class="category-option category-option--${c.value}">
        <input type="radio" name="category" value="${c.value}" ${
        (task ? task.category : "general") === c.value ? "checked" : ""
      }>
        <span>${esc(c.label)}</span></label>`
    )
    .join("");

  const subOptions = META.sport_subcategories
    .map(
      (s) => `<label class="repeat-option">
        <input type="radio" name="subcategory" value="${s.value}" ${
        task && task.subcategory === s.value ? "checked" : ""
      }>
        <span>${esc(s.label)}</span></label>`
    )
    .join("");

  const focusSubOptions = META.focus_subcategories
    .map(
      (s) => `<label class="repeat-option">
        <input type="radio" name="subcategory" value="${s.value}" ${
        task && task.subcategory === s.value ? "checked" : ""
      }>
        <span>${esc(s.label)}</span></label>`
    )
    .join("");

  const repeatOptions = META.repeats
    .map(
      (r) => `<label class="repeat-option">
        <input type="radio" name="repeat" value="${r.value}" ${
        (task ? task.repeat : "none") === r.value ? "checked" : ""
      }>
        <span>${esc(r.label)}</span></label>`
    )
    .join("");

  const dayOptions = META.weekdays
    .map(
      (d) => `<label class="repeat-option">
        <input type="checkbox" name="custom_days" value="${d.value}" ${
        task && (task.custom_days || []).includes(d.value) ? "checked" : ""
      }>
        <span>${esc(d.label)}</span></label>`
    )
    .join("");

  view.innerHTML = `
    ${topbar(uuid ? "editar" : "nueva", uuid ? "Editar tarea" : "Nueva tarea", "#/")}
    <form class="task-form" id="task-form">
      <label class="field">
        <span class="field__label">Título</span>
        <input type="text" name="title" required maxlength="255" value="${esc(task?.title || "")}">
      </label>
      <label class="field">
        <span class="field__label">Notas</span>
        <textarea name="notes" rows="2">${esc(task?.notes || "")}</textarea>
      </label>
      <div class="field-row">
        <label class="field">
          <span class="field__label" id="label-date">Fecha</span>
          <input type="date" name="due_date" value="${esc(task?.due_date || "")}">
          <span class="field__hint" id="hint-date" hidden></span>
        </label>
        <label class="field">
          <span class="field__label" id="label-time">Hora límite</span>
          <input type="time" name="due_time" value="${esc(task?.due_time || "23:59")}">
          <span class="field__hint" id="hint-time">Si pasa sin marcarla → auto no hecha. También es la hora del aviso.</span>
        </label>
      </div>
      <label class="field field--inline">
        <input type="checkbox" name="is_important" ${task?.is_important ? "checked" : ""}>
        <span class="field__label">Importante</span>
      </label>
      <fieldset class="field">
        <legend class="field__label">Tipo de tarea</legend>
        <div class="category-options">${catOptions}</div>
      </fieldset>
      <fieldset class="field" id="sub-field" hidden>
        <legend class="field__label">¿Qué toca?</legend>
        <div class="repeat-options">${subOptions}</div>
      </fieldset>
      <fieldset class="field" id="focus-sub-field" hidden>
        <legend class="field__label">¿Qué vas a cronometrar?</legend>
        <div class="repeat-options">${focusSubOptions}</div>
        <span class="field__hint">"Lectura" además podrá usar el tiempo en tu app de lectura, si lo configuras en Ajustes.</span>
      </fieldset>
      <label class="field" id="focus-target-field" hidden>
        <span class="field__label">Objetivo (minutos)</span>
        <input type="number" name="target_minutes" min="1" max="600" inputmode="numeric"
               placeholder="60" value="${task?.target_minutes ?? ""}">
        <span class="field__hint">En blanco = sesión libre, sin objetivo.</span>
      </label>
      <fieldset class="field" id="sport-mode-field" hidden>
        <legend class="field__label">¿Cómo la completas?</legend>
        <div class="repeat-options">
          <label class="repeat-option" data-mode-option="camera">
            <input type="radio" name="sport_mode" value="camera" ${task?.sport_mode === "camera" ? "checked" : ""}>
            <span>Contar con la cámara</span>
          </label>
          <label class="repeat-option" data-mode-option="circuit">
            <input type="radio" name="sport_mode" value="circuit" ${task?.sport_mode === "circuit" ? "checked" : ""}>
            <span>Circuito</span>
          </label>
          <label class="repeat-option" data-mode-option="video">
            <input type="radio" name="sport_mode" value="video" ${task?.sport_mode === "video" ? "checked" : ""}>
            <span>Vídeo</span>
          </label>
        </div>
      </fieldset>
      <fieldset class="field" id="running-goal-field" hidden>
        <legend class="field__label">Objetivo</legend>
        <label class="field">
          <span class="field__label">Distancia (km)</span>
          <input type="number" name="target_distance_km" step="0.1" min="0.1" inputmode="decimal"
                 placeholder="5" value="${task?.target_distance_km ?? ""}">
        </label>
        <label class="field">
          <span class="field__label">A qué ritmo (o más rápido)</span>
          <select name="max_pace_seconds_per_km">
            <option value="">Cualquier ritmo vale</option>
            ${PACE_PRESETS.map(
              ([s, label]) =>
                `<option value="${s}" ${task?.max_pace_seconds_per_km === s ? "selected" : ""}>${label}</option>`,
            ).join("")}
          </select>
        </label>
        <span class="field__hint">
          Se completa sola al importar una actividad que llegue a esa distancia a ese
          ritmo o mejor. Es lo que separa correr de andar: elige un paseo si lo que
          quieres es caminar.
        </span>
        <label class="field">
          <span class="field__label">…o pasos (para caminar)</span>
          <input type="number" name="target_steps" min="1" inputmode="numeric"
                 placeholder="10000" value="${task?.target_steps ?? ""}">
        </label>
      </fieldset>
      <fieldset class="field" id="video-source-field" hidden>
        <legend class="field__label">Vídeo</legend>
        <div class="repeat-options">
          <label class="repeat-option">
            <input type="radio" name="video_source" value="youtube" ${!task?.has_local_video ? "checked" : ""}>
            <span>YouTube</span>
          </label>
          <label class="repeat-option">
            <input type="radio" name="video_source" value="local" ${task?.has_local_video ? "checked" : ""}>
            <span>Archivo de mi galería</span>
          </label>
        </div>
        <span class="field__hint">Una de las dos — no hace falta rellenar ambas.</span>
      </fieldset>
      <label class="field" id="video-field" hidden>
        <span class="field__label">Vídeo de YouTube (opcional)</span>
        <input type="text" name="youtube_video_id" placeholder="https://youtube.com/watch?v=…"
               value="${esc(task?.youtube_video_id || "")}">
        <span class="field__hint">
          Si pones un vídeo, esta tarea se salta el selector de ejercicios (o el temporizador):
          al darle a play va directa al vídeo, y al terminarlo se marca hecha ella sola.
        </span>
      </label>
      <div class="field" id="local-video-field" hidden>
        <span class="field__label">Vídeo de tu galería</span>
        <div class="local-video-picker">
          <button type="button" class="ghost-btn" id="pick-local-file-btn">Elegir de la galería…</button>
        </div>
        <p class="field__hint" id="local-file-status">${task?.has_local_video ? "✓ Ya tienes uno elegido." : ""}</p>
        <p class="field__hint" id="local-file-unsupported" hidden>
          Esto necesita el plugin nativo, que todavía no está compilado en esta build de la app.
        </p>
        <input type="hidden" name="has_local_video" id="has-local-video-input" value="${task?.has_local_video ? "1" : ""}">
        <input type="hidden" name="client_uuid" id="client-uuid-input" value="${task?.uuid || ""}">
      </div>
      <label class="field" id="playlist-field" hidden>
        <span class="field__label">…o playlist de YouTube (alternativa al vídeo suelto)</span>
        <input type="text" name="youtube_playlist_id" placeholder="https://youtube.com/playlist?list=…"
               value="${esc(task?.youtube_playlist_id || "")}">
        <span class="field__hint">Si pones esto, se ignora el campo de vídeo de arriba.</span>
      </label>
      <label class="field" id="video-target-minutes-field" hidden>
        <span class="field__label">Objetivo del vídeo/playlist, en minutos (opcional)</span>
        <input type="number" name="video_target_minutes" min="1" max="6000" inputmode="numeric"
               placeholder="Ej: 20 (para un vídeo de 40h, o para una playlist)"
               value="${task?.target_minutes ?? ""}">
        <span class="field__hint">
          Se da por hecha al acumular ese tiempo viendo de verdad, aunque el vídeo o la
          lista sigan. En blanco = hay que verlo/verla entera.
        </span>
      </label>
      <label class="field" id="video-target-count-field" hidden>
        <span class="field__label">…o número de vídeos de la playlist (opcional)</span>
        <input type="number" name="target_video_count" min="1" max="500" inputmode="numeric"
               placeholder="Ej: 5" value="${task?.target_video_count ?? ""}">
        <span class="field__hint">Solo con playlist. Si rellenas esto, gana sobre el objetivo en minutos.</span>
      </label>
      <fieldset class="field avoid-fields" id="avoid-fields" hidden>
        <legend class="field__label">Textos de la notificación</legend>
        <label class="field">
          <span class="field__label">Pregunta</span>
          <input type="text" name="avoid_question" maxlength="120"
                 placeholder="¿Has caído hoy?" value="${esc(task?.avoid_question || "")}">
        </label>
        <div class="field-row">
          <label class="field">
            <span class="field__label">Botón "lo evité"</span>
            <input type="text" name="avoid_success_label" maxlength="32"
                   placeholder="Sigo con la racha" value="${esc(task?.avoid_success_label || "")}">
          </label>
          <label class="field">
            <span class="field__label">Botón "caí"</span>
            <input type="text" name="avoid_fail_label" maxlength="32"
                   placeholder="Romper racha" value="${esc(task?.avoid_fail_label || "")}">
          </label>
        </div>
        <span class="field__hint">Déjalos en blanco para usar los de por defecto.</span>
      </fieldset>

      <fieldset class="field">
        <legend class="field__label">Repetir</legend>
        <div class="repeat-options">${repeatOptions}</div>
      </fieldset>

      <label class="field" id="interval-field" hidden>
        <span class="field__label">Cada cuántos</span>
        <span class="interval-row">
          <input type="number" name="interval" min="1" step="1" inputmode="numeric"
                 value="${task?.interval || 1}">
          <span id="interval-unit">días</span>
        </span>
      </label>

      <fieldset class="field" id="custom-days-field" hidden>
        <legend class="field__label">Qué días</legend>
        <div class="repeat-options">${dayOptions}</div>
      </fieldset>

      <div class="task-form__actions">
        <button type="submit" class="primary-btn">Guardar</button>
        ${uuid ? '<button type="button" class="ghost-btn ghost-btn--danger" id="delete">Eliminar</button>' : ""}
      </div>
    </form>`;

  const subField = document.getElementById("sub-field");
  const focusSubField = document.getElementById("focus-sub-field");
  const focusTargetField = document.getElementById("focus-target-field");
  const videoSourceField = document.getElementById("video-source-field");
  const sportModeField = document.getElementById("sport-mode-field");
  const runningGoalField = document.getElementById("running-goal-field");
  const videoField = document.getElementById("video-field");
  const localVideoField = document.getElementById("local-video-field");
  const playlistField = document.getElementById("playlist-field");
  const videoTargetMinutesField = document.getElementById("video-target-minutes-field");
  const videoTargetCountField = document.getElementById("video-target-count-field");
  const avoidFields = document.getElementById("avoid-fields");
  const syncSub = () => {
    const cat = view.querySelector('[name="category"]:checked')?.value;
    subField.hidden = cat !== "sport";
    focusSubField.hidden = cat !== "work";
    focusTargetField.hidden = cat !== "work";

    // Deporte: el método se elige aquí, al crear la tarea. Qué métodos
    // valen depende del subtipo — correr no se hace con circuitos. La
    // cámara ya vale también en tren inferior (sentadillas, por ángulo
    // de rodilla con MediaPipe), igual que en tren superior.
    const esDeporte = cat === "sport";
    const sub = esDeporte ? view.querySelector('[name="subcategory"]:checked')?.value || "" : "";
    const esCarrera = sub === "running";
    const modosPorSub = { upper_body: ["camera", "circuit", "video"], lower_body: ["camera", "circuit", "video"] };
    const modosValidos = modosPorSub[sub] || [];

    sportModeField.hidden = !modosValidos.length;
    runningGoalField.hidden = !esCarrera;

    // Si el modo marcado ya no vale (cambiaste de subtipo), se pasa al
    // primero válido en vez de quedarse en un estado imposible.
    let hayMarcadoValido = false;
    view.querySelectorAll("[data-mode-option]").forEach((opt) => {
      const vale = modosValidos.includes(opt.dataset.modeOption);
      opt.hidden = !vale;
      const input = opt.querySelector("input");
      if (!vale) input.checked = false;
      else if (input.checked) hayMarcadoValido = true;
    });
    if (modosValidos.length && !hayMarcadoValido) {
      const primero = view.querySelector(`[data-mode-option="${modosValidos[0]}"] input`);
      if (primero) primero.checked = true;
    }
    const modoActual = view.querySelector('[name="sport_mode"]:checked')?.value || "";

    const esEnfoque = cat === "work";
    const esEstudio = cat === "study";
    const videoEnDeporte = esDeporte && modoActual === "video";
    sportModeField.hidden = !modosValidos.length;
    videoSourceField.hidden = !(esEnfoque || videoEnDeporte);
    const fuente = view.querySelector('[name="video_source"]:checked')?.value || "youtube";
    videoField.hidden = !(esEstudio || ((esEnfoque || videoEnDeporte) && fuente === "youtube"));
    localVideoField.hidden = !((esEnfoque || videoEnDeporte) && fuente === "local");

    // Playlist / vídeos largos: solo para estudiar (clases, cursos,
    // idiomas) — Enfoque ya tiene su vídeo simple, y no hay playlists
    // de 40h de dominadas.
    playlistField.hidden = !esEstudio;
    videoTargetMinutesField.hidden = !esEstudio;
    videoTargetCountField.hidden = !esEstudio;
    avoidFields.hidden = cat !== "avoid";

    // Una antitarea no "vence": se te pregunta. Y como se repite a
    // diario, la fecha es solo el punto de partida, no un final.
    const esAnti = cat === "avoid";
    document.getElementById("label-date").textContent = esAnti ? "Empieza el" : "Fecha";
    document.getElementById("label-time").textContent = esAnti ? "Hora del aviso" : "Hora límite";
    const hd = document.getElementById("hint-date");
    hd.hidden = !esAnti;
    hd.textContent = esAnti ? "Si la repites, sigue indefinidamente." : "";
    document.getElementById("hint-time").textContent = esAnti
      ? "A esta hora te preguntamos si has caído."
      : "Si pasa sin marcarla → auto no hecha. También es la hora del aviso.";
  };
  view.querySelectorAll('[name="category"]').forEach((r) => r.addEventListener("change", syncSub));
  view.querySelectorAll('[name="video_source"]').forEach((r) => r.addEventListener("change", syncSub));
  // Delegado de refuerzo, igual que en la web: por si el clic en algún
  // radio concreto no dispara su propio 'change' en algún dispositivo.
  const categoryOptionsEl = view.querySelector(".category-options");
  if (categoryOptionsEl) {
    categoryOptionsEl.addEventListener("click", () => setTimeout(syncSub, 0));
  }
  videoSourceField.addEventListener("click", () => setTimeout(syncSub, 0));
  sportModeField.addEventListener("click", () => setTimeout(syncSub, 0));
  // TODOS los radios de subcategoría, no solo el primero (que era el
  // bug: solo escuchaba a uno de los tres). Delegado por clic también,
  // mismo refuerzo que ya lleva categoría.
  view.querySelectorAll('[name="subcategory"]').forEach((r) => r.addEventListener("change", syncSub));
  subField.addEventListener("click", () => setTimeout(syncSub, 0));
  syncSub();

  // Mismo comportamiento que la web: el intervalo solo tiene sentido si
  // la tarea se repite, y los días sueltos solo con repetición "custom".
  const intervalField = document.getElementById("interval-field");
  const intervalUnit = document.getElementById("interval-unit");
  const customField = document.getElementById("custom-days-field");
  const UNITS = { daily: "días", weekly: "semanas", monthly: "meses", yearly: "años", custom: "semanas" };
  const syncRepeat = () => {
    const v = view.querySelector('[name="repeat"]:checked')?.value || "none";
    intervalField.hidden = v === "none";
    customField.hidden = v !== "custom";
    if (UNITS[v]) intervalUnit.textContent = UNITS[v];
  };
  view.querySelectorAll('[name="repeat"]').forEach((r) => r.addEventListener("change", syncRepeat));
  syncRepeat();

  // ------------------------------------------------------- vídeo local
  // Mismo motivo que en la web: una tarea nueva no tiene uuid hasta que
  // se guarda, y el plugin nativo necesita una clave YA para saber a
  // qué tarea pertenece el archivo copiado. Se genera aquí y se manda
  // en el envío; el servidor lo respeta en vez de inventarse uno.
  const clientUuidInput = document.getElementById("client-uuid-input");
  const hasLocalVideoInput = document.getElementById("has-local-video-input");
  const pickLocalBtn = document.getElementById("pick-local-file-btn");
  const localFileStatus = document.getElementById("local-file-status");
  const localFileUnsupported = document.getElementById("local-file-unsupported");
  const localVideoPlugin = window.Capacitor?.Plugins?.LocalVideo || null;

  if (!clientUuidInput.value && window.crypto?.randomUUID) {
    clientUuidInput.value = crypto.randomUUID();
  }
  if (!localVideoPlugin) {
    pickLocalBtn.disabled = true;
    localFileUnsupported.hidden = false;
  }
  pickLocalBtn.addEventListener("click", async () => {
    if (!localVideoPlugin) return;
    pickLocalBtn.disabled = true;
    localFileStatus.textContent = "Abriendo la galería…";
    try {
      const res = await localVideoPlugin.pickAndStoreVideo({ taskKey: clientUuidInput.value });
      if (res?.path) {
        hasLocalVideoInput.value = "1";
        localFileStatus.textContent = "✓ Vídeo elegido.";
      }
    } catch {
      localFileStatus.textContent = "No se pudo usar ese vídeo.";
    } finally {
      pickLocalBtn.disabled = false;
    }
  });

  document.getElementById("task-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    // Un solo campo en el servidor (target_minutes) sirve para dos
    // cosas distintas según cuál aplique — aquí se decide cuál de los
    // dos inputs del formulario es el que de verdad toca, igual que en
    // la web.
    const hasVideo = Boolean(fd.get("youtube_video_id") || fd.get("youtube_playlist_id") || fd.get("has_local_video"));
    const payload = {
      title: fd.get("title"),
      notes: fd.get("notes"),
      category: fd.get("category"),
      subcategory: fd.get("subcategory") || "",
      target_minutes: (hasVideo ? fd.get("video_target_minutes") : fd.get("target_minutes")) || null,
      youtube_video_id: fd.get("youtube_video_id") || "",
      youtube_playlist_id: fd.get("youtube_playlist_id") || "",
      target_video_count: fd.get("target_video_count") || null,
      has_local_video: Boolean(fd.get("has_local_video")),
      sport_mode: fd.get("sport_mode") || "",
      target_distance_km: fd.get("target_distance_km") || null,
      target_steps: fd.get("target_steps") || null,
      max_pace_seconds_per_km: fd.get("max_pace_seconds_per_km") || null,
      uuid: fd.get("client_uuid") || undefined,
      due_date: fd.get("due_date") || null,
      due_time: fd.get("due_time") || null,
      repeat: fd.get("repeat"),
      interval: parseInt(fd.get("interval"), 10) || 1,
      custom_days: fd.getAll("custom_days"),
      is_important: Boolean(fd.get("is_important")),
      avoid_question: fd.get("avoid_question") || "",
      avoid_success_label: fd.get("avoid_success_label") || "",
      avoid_fail_label: fd.get("avoid_fail_label") || "",
    };
    try {
      if (uuid) await api.updateTask(uuid, payload);
      else await api.createTask(payload);
      location.hash = "#/";
    } catch (err) {
      toast(err.message, "error");
      refreshQueueBanner();
    }
  });

  // Confirmación en dos pasos en vez de confirm(): si el WebView no
  // muestra el diálogo nativo, confirm() devuelve false al instante y el
  // botón parecía no hacer nada. Así no depende de nada del sistema.
  const delBtn = document.getElementById("delete");
  if (delBtn) {
    let armed = false;
    delBtn.addEventListener("click", async () => {
      if (!armed) {
        armed = true;
        delBtn.textContent = "¿Seguro? Se conserva el historial. Pulsa otra vez";
        delBtn.classList.add("ghost-btn--armed");
        setTimeout(() => {
          armed = false;
          delBtn.textContent = "Eliminar";
          delBtn.classList.remove("ghost-btn--armed");
        }, 4000);
        return;
      }
      delBtn.disabled = true;
      delBtn.textContent = "Eliminando…";
      try {
        await api.deleteTask(uuid);
        toast("Tarea eliminada. Su historial y estadísticas se conservan.");
      } catch (err) {
        if (err.queued) {
          toast("Sin conexión: se eliminará al volver la red.");
        } else {
          toast(err.message, "error");
          delBtn.disabled = false;
          delBtn.textContent = "Eliminar";
          return;
        }
      }
      api.clearCache();
      location.hash = "#/";
    });
  }
}

async function viewStats() {
  loading();
  const { data, fromCache } = await api.stats();
  showOffline(fromCache);
  view.innerHTML = `
    ${topbar("historial", "Rachas")}
    ${weekSummary(data.weekly)}
    ${
      data.stats.length
        ? `<ul class="stats-list">${data.stats
            .map(
              (s) => `<li class="stats-card">
          <a href="#/stats/${encodeURIComponent(s.series_id)}" class="stats-card__link">
            <div class="stats-card__top">
              <p class="stats-card__title">${esc(s.title)}</p>
              <span class="stats-card__rate">${s.rate}%</span>
            </div>
            <div class="stats-bar"><div class="stats-bar__done" style="width:${s.rate}%"></div></div>
            <div class="stats-card__counts">
              <span class="count-pill count-pill--done">${s.done} hechas</span>
              <span class="count-pill count-pill--not-done">${s.not_done} no hechas</span>
              ${s.current_streak > 0 ? `<span class="count-pill count-pill--streak">🔥 ${s.current_streak} racha</span>` : ""}
              ${s.max_streak > 0 ? `<span class="count-pill count-pill--max">⭐ ${s.max_streak} máx</span>` : ""}
            </div>
          </a>
        </li>`
            )
            .join("")}</ul>
        <div class="task-form__actions">
          <button class="ghost-btn ghost-btn--danger" id="stats-delete-all">Borrar todas las estadísticas</button>
        </div>`
        : `<p class="empty">Todavía no hay historial. Marca tareas como hechas o no hechas para ver tus estadísticas aquí.</p>`
    }`;

  // Confirmación en dos pasos, igual que al borrar una tarea (ver
  // viewTaskList): confirm() puede no aparecer en el WebView.
  const delAllBtn = document.getElementById("stats-delete-all");
  if (delAllBtn) {
    let armed = false;
    delAllBtn.addEventListener("click", async () => {
      if (!armed) {
        armed = true;
        delAllBtn.textContent = "¿Seguro? Pulsa otra vez";
        delAllBtn.classList.add("ghost-btn--armed");
        setTimeout(() => {
          armed = false;
          delAllBtn.textContent = "Borrar todas las estadísticas";
          delAllBtn.classList.remove("ghost-btn--armed");
        }, 4000);
        return;
      }
      delAllBtn.disabled = true;
      delAllBtn.textContent = "Borrando…";
      try {
        await api.deleteStats();
        toast("Estadísticas eliminadas.");
      } catch (err) {
        if (err.queued) {
          toast("Sin conexión: se eliminarán al volver la red.");
        } else {
          toast(err.message, "error");
          delAllBtn.disabled = false;
          delAllBtn.textContent = "Borrar todas las estadísticas";
          return;
        }
      }
      api.clearCache();
      router();
    });
  }
}

/**
 * Detalle de una serie: igual que stats_detail.html en la web — los
 * mismos totales/rachas que ya se ven en la tarjeta de /stats, más el
 * historial completo, ocurrencia a ocurrencia (ver api.statsDetail /
 * tasks.api.stats_detail en el servidor).
 */
async function viewStatsDetail(seriesId) {
  loading();
  const { data, fromCache } = await api.statsDetail(seriesId);
  showOffline(fromCache);
  view.innerHTML = `
    ${topbar("historial", data.title, "#/stats")}
    <div class="stamp-row">
      <div class="stamp stamp--done">
        <span class="stamp__number">${data.done_count}</span>
        <span class="stamp__label">hechas</span>
      </div>
      <div class="stamp stamp--undone">
        <span class="stamp__number">${data.not_done_count}</span>
        <span class="stamp__label">no hechas</span>
      </div>
      <div class="stamp stamp--rate">
        <span class="stamp__number">${data.success_rate}%</span>
        <span class="stamp__label">cumplido</span>
      </div>
    </div>
    <div class="streak-row">
      <div class="streak-card streak-card--current">
        <span class="streak-card__icon">🔥</span>
        <span class="streak-card__number">${data.current_streak}</span>
        <span class="streak-card__label">Racha actual</span>
      </div>
      <div class="streak-card streak-card--max">
        <span class="streak-card__icon">⭐</span>
        <span class="streak-card__number">${data.max_streak}</span>
        <span class="streak-card__label">Racha máxima</span>
      </div>
    </div>
    <section class="task-section">
      <h2 class="task-section__title">Historial</h2>
      <ul class="history-list">
        ${data.occurrences
          .map(
            (occ) => `<li class="history-row history-row--${occ.result}">
          <span class="history-dot"></span>
          <span class="history-date">${esc(formatHistoryDate(occ.recorded_at))}</span>
          <span class="history-result">${esc(occ.result_display)}${occ.auto_expired ? " (auto)" : ""}</span>
        </li>`
          )
          .join("")}
      </ul>
    </section>
    <div class="task-form__actions">
      <button class="ghost-btn ghost-btn--danger" id="stats-delete-series">Borrar estas estadísticas</button>
    </div>`;

  // Mismo patrón de confirmación en dos pasos que en viewStats.
  const delBtn = document.getElementById("stats-delete-series");
  if (delBtn) {
    let armed = false;
    delBtn.addEventListener("click", async () => {
      if (!armed) {
        armed = true;
        delBtn.textContent = "¿Seguro? Se conserva el historial. Pulsa otra vez";
        delBtn.classList.add("ghost-btn--armed");
        setTimeout(() => {
          armed = false;
          delBtn.textContent = "Borrar estas estadísticas";
          delBtn.classList.remove("ghost-btn--armed");
        }, 4000);
        return;
      }
      delBtn.disabled = true;
      delBtn.textContent = "Borrando…";
      try {
        await api.deleteStatsDetail(seriesId);
        toast("Estadísticas eliminadas.");
      } catch (err) {
        if (err.queued) {
          toast("Sin conexión: se eliminarán al volver la red.");
        } else {
          toast(err.message, "error");
          delBtn.disabled = false;
          delBtn.textContent = "Borrar estas estadísticas";
          return;
        }
      }
      api.clearCache();
      location.hash = "#/stats";
    });
  }
}

/**
 * "d de mes, Y · H:i" en español, sin depender de Intl.DateTimeFormat
 * con locale (Android WebView no siempre trae el paquete de idioma es
 * instalado, y ahí locale "es-ES" calla y usa inglés sin avisar) — mismo
 * formato que occ.recorded_at|date:"d \d\e F, Y · H:i" en la web.
 */
function formatHistoryDate(iso) {
  const MESES = [
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
  ];
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const dia = String(d.getDate()).padStart(2, "0");
  const mes = MESES[d.getMonth()];
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${dia} de ${mes}, ${d.getFullYear()} · ${hh}:${mm}`;
}

/**
 * Perfil: avatar, nombre y datos corporales (nacimiento, altura, peso, peso
 * objetivo), y debajo "Editar perfil" y "Ajustes" (la pantalla de ajustes
 * de siempre cuelga de aquí, ya no tiene pestaña propia). Los datos viven
 * en el servidor (/api/profile/, ver tasks/profile.py).
 */
const fmtKg = (n) => String(n).replace(".", ",");

async function viewProfile() {
  loading();
  const { data, fromCache } = await api.get("/profile/");
  showOffline(fromCache);
  const p = data.profile;
  const opts = Object.assign({ emojis: [], colors: [], name_max: 40 }, data.options || {});
  const today = new Date().toISOString().slice(0, 10);
  const hist = p.weight_history || [];
  const change =
    p.weight_change ? ` · ${p.weight_change > 0 ? "▲" : "▼"} ${fmtKg(Math.abs(p.weight_change))}` : "";
  const toGoal =
    p.to_goal_kg == null ? "—" : p.to_goal_kg === 0 ? "✓" : (p.to_goal_kg > 0 ? "+" : "") + fmtKg(p.to_goal_kg);
  const val = (v) => (v == null ? "" : esc(v));
  view.innerHTML = `
    ${topbar("tú", "Perfil")}

    <section class="profile-hero">
      <div class="avatar" id="avatar-preview" style="--avatar-color:${esc(p.avatar_color)}">${esc(p.avatar_emoji)}</div>
      <div>
        <h2 class="profile-hero__name${p.display_name ? "" : " profile-hero__name--empty"}" id="name-preview">${esc(p.shown_name)}</h2>
        ${p.age != null ? `<p class="profile-hero__meta">${p.age} años</p>` : ""}
      </div>
    </section>

    <h2 class="section-title">Cuerpo</h2>
    <section class="profile-stats">
      <div class="profile-stat"><strong>${p.body_weight_kg ? fmtKg(p.body_weight_kg) : "—"}</strong><span>Peso (kg)${change}</span></div>
      <div class="profile-stat"><strong>${p.bmi ? fmtKg(p.bmi) : "—"}</strong><span>IMC</span></div>
      <div class="profile-stat"><strong>${toGoal}</strong><span>Hasta objetivo (kg)</span></div>
    </section>
    ${
      hist.length > 1
        ? `<ul class="kv-list" style="margin-top:10px">${hist
            .map((w) => `<li><span>${esc(w.date)}</span><strong>${fmtKg(w.kg)} kg</strong></li>`)
            .join("")}</ul>`
        : ""
    }

    <div class="menu-list">
      <button type="button" class="menu-row" id="profile-edit-toggle">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>
        <span class="menu-row__label">Editar perfil</span>
        <span class="menu-row__chev">›</span>
      </button>
      <a class="menu-row" href="#/ajustes">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.5-2.4 1a7 7 0 0 0-1.7-1L14.5 3h-4l-.3 2.6a7 7 0 0 0-1.7 1l-2.4-1-2 3.5 2 1.5a7 7 0 0 0 0 2l-2 1.5 2 3.5 2.4-1a7 7 0 0 0 1.7 1l.3 2.6h4l.3-2.6a7 7 0 0 0 1.7-1l2.4 1 2-3.5-2-1.5c.06-.33.1-.66.1-1z"/></svg>
        <span class="menu-row__label">Ajustes</span>
        <span class="menu-row__chev">›</span>
      </a>
    </div>

    <form class="task-form" id="profile-form" hidden style="margin-top:16px">
      <h3 class="form-section">Perfil</h3>
      <label class="field">
        <span class="field__label">Nombre</span>
        <input type="text" name="display_name" id="f-name" maxlength="${opts.name_max}"
               value="${esc(p.display_name)}" placeholder="Cómo quieres que te llame" autocomplete="nickname">
      </label>
      <fieldset class="field">
        <span class="field__label">Avatar</span>
        <div class="pick-grid">
          ${opts.emojis
            .map((e) => `<label><input type="radio" name="avatar_emoji" value="${esc(e)}"${e === p.avatar_emoji ? " checked" : ""}><span class="pick-emoji">${esc(e)}</span></label>`)
            .join("")}
        </div>
      </fieldset>
      <fieldset class="field">
        <span class="field__label">Color</span>
        <div class="pick-grid">
          ${opts.colors
            .map((c) => `<label><input type="radio" name="avatar_color" value="${esc(c)}"${c === p.avatar_color ? " checked" : ""}><span class="pick-color" style="--c:${esc(c)}"></span></label>`)
            .join("")}
        </div>
      </fieldset>

      <h3 class="form-section">Cuerpo</h3>
      <label class="field">
        <span class="field__label">Fecha de nacimiento</span>
        <input type="date" name="birth_date" min="1900-01-01" max="${today}" value="${esc(p.birth_date)}">
      </label>
      <div class="field-row">
        <label class="field">
          <span class="field__label">Altura (cm)</span>
          <input type="number" name="height_cm" min="100" max="250" step="1" inputmode="numeric"
                 value="${val(p.height_cm)}" placeholder="175">
        </label>
        <label class="field">
          <span class="field__label">Peso (kg)</span>
          <input type="number" name="body_weight_kg" min="30" max="300" step="0.1" inputmode="decimal"
                 value="${val(p.body_weight_kg)}" placeholder="70">
        </label>
      </div>
      <label class="field">
        <span class="field__label">Peso objetivo (kg)</span>
        <input type="number" name="goal_weight_kg" min="30" max="300" step="0.1" inputmode="decimal"
               value="${val(p.goal_weight_kg)}" placeholder="Opcional">
        <span class="field__hint">
          El peso se usa para estimar las calorías de cada ejercicio (vacío = 70 kg) y cada cambio queda
          en tu historial. El IMC es solo una referencia aproximada.
        </span>
      </label>

      <div class="task-form__actions">
        <button type="submit" class="primary-btn">Guardar perfil</button>
      </div>
      <p id="profile-result" class="field__hint"></p>
    </form>`;

  const form = document.getElementById("profile-form");
  document.getElementById("profile-edit-toggle").addEventListener("click", () => {
    form.hidden = !form.hidden;
    if (!form.hidden) form.scrollIntoView({ behavior: "smooth", block: "start" });
  });

  // Vista previa en vivo, igual que en la web.
  const avatar = document.getElementById("avatar-preview");
  const nameEl = document.getElementById("name-preview");
  document.getElementById("f-name").addEventListener("input", (e) => {
    const v = e.target.value.trim();
    nameEl.textContent = v || "Tu nombre";
    nameEl.classList.toggle("profile-hero__name--empty", !v);
  });
  form.querySelectorAll('input[name="avatar_emoji"]').forEach((r) =>
    r.addEventListener("change", () => { avatar.textContent = r.value; })
  );
  form.querySelectorAll('input[name="avatar_color"]').forEach((r) =>
    r.addEventListener("change", () => avatar.style.setProperty("--avatar-color", r.value))
  );

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const payload = {};
    for (const k of [
      "display_name", "avatar_emoji", "avatar_color",
      "birth_date", "height_cm", "body_weight_kg", "goal_weight_kg",
    ]) payload[k] = fd.get(k) ?? "";
    const out = document.getElementById("profile-result");
    out.textContent = "Guardando…";
    try {
      await api.post("/profile/", payload, { queueable: false });
      toast("Perfil guardado.");
      viewProfile();
    } catch (err) {
      out.textContent = "✗ " + err.message;
    }
  });
}

async function viewSettings() {
  const cfg = api.getConfig();
  view.innerHTML = `
    ${topbar("configuración", "Ajustes", api.isConfigured() ? "#/perfil" : "")}
    <form class="task-form" id="cfg-form">
      <label class="field">
        <span class="field__label">Dirección del servidor</span>
        <input type="url" name="baseUrl" placeholder="https://tuusuario.pythonanywhere.com"
               value="${esc(cfg.baseUrl || "")}" autocomplete="url" required>
        <span class="field__hint">La misma que usas en el navegador, sin barra final.</span>
      </label>
      <label class="field">
        <span class="field__label">Usuario</span>
        <input type="text" name="user" autocapitalize="none" autocomplete="username" value="${esc(cfg.user || "")}">
      </label>
      <label class="field">
        <span class="field__label">Contraseña</span>
        <input type="password" name="password" autocomplete="current-password" value="${esc(cfg.password || "")}">
        <span class="field__hint">Los mismos que te pide el navegador al entrar en la web.</span>
      </label>
      <div class="task-form__actions">
        <button type="submit" class="primary-btn">Guardar y probar</button>
      </div>
      <p id="cfg-result" class="field__hint"></p>
    </form>

    <h2 class="section-title">Apariencia</h2>
    <div class="task-form__actions">
      <button type="button" class="ghost-btn" id="theme-toggle-mobile">
        ${localStorage.getItem("theme") === "light" ? "☀️ Modo claro" : "🌙 Modo oscuro"}
      </button>
    </div>

    <h2 class="section-title">Entrenamiento con cámara</h2>
    <div class="task-form__actions">
      <button type="button" class="ghost-btn" id="voice-toggle">
        ${localStorage.getItem("libreta.voiceReps") === "0" ? "🔇 Voz al contar: apagada" : "🔊 Voz al contar: encendida"}
      </button>
    </div>
    <p class="field__hint">
      Dice cada repetición en voz alta mientras cuentas dominadas, sentadillas o
      fondos con la cámara — para saber cuántas llevas sin tener que mirar la
      pantalla. Sube el volumen del móvil si no se oye lo bastante fuerte: la app
      no puede subirlo por ti, solo pedir que suene al máximo posible.
    </p>

    <h2 class="section-title">Salud y actividad</h2>
    <p class="field__hint">
      Si das permiso, Strive lee tus carreras y caminatas de Health Connect
      (Samsung Health, Garmin, Fitbit, Strava, Mi Fitness…) y marca solas las
      tareas de correr o andar cuando cumples tu objetivo. Solo lectura: no
      escribe nada.
    </p>
    <div class="settings-actions">
      <button class="ghost-btn" id="health-permission">Dar permiso</button>
      <button class="ghost-btn" id="health-settings">Ajustes de Health Connect</button>
      <button class="ghost-btn" id="health-resync">Volver a importar</button>
      <button class="ghost-btn" id="health-diagnose">Diagnosticar</button>
    </div>
    <p class="field__hint" id="health-status"></p>

    <h2 class="section-title">Créditos</h2>
    <p class="credits">
      Las ilustraciones de ejercicios son de
      <strong>Everkinetic</strong>, bajo licencia
      Creative Commons Attribution-ShareAlike 3.0.
      El seguimiento de postura usa MediaPipe (Google).
    </p>

    <h2 class="section-title">Lectura</h2>
    ${
      window.Capacitor?.Plugins?.ReadingUsage
        ? `<form class="task-form" id="reading-form">
            <label class="field">
              <span class="field__label">Paquete de tu app de lectura</span>
              <input type="text" name="app_package" autocapitalize="none" autocorrect="off"
                     placeholder="com.adobe.reader" id="reading-package">
              <span class="field__hint">
                Ej: com.adobe.reader (Adobe Acrobat), com.amazon.kindle (Kindle),
                com.google.android.apps.books (Play Libros).
              </span>
            </label>
            <div class="task-form__actions">
              <button type="submit" class="primary-btn">Guardar</button>
            </div>
            <p id="reading-result" class="field__hint"></p>
          </form>
          <div class="settings-actions">
            <button class="ghost-btn" id="reading-permission">Comprobar / activar permiso de uso</button>
          </div>`
        : `<p class="field__hint">
            Esto necesita el plugin nativo de "tiempo en la app", que todavía no está
            compilado en esta build de la app. Mientras tanto, las tareas de lectura
            solo tienen el cronómetro manual.
          </p>`
    }

    <h2 class="section-title">Vídeos de circuitos</h2>
    <p class="field__hint">
      Para que un ejercicio cronometrado reproduzca un vídeo de YouTube en vez de la cuenta
      atrás en blanco: pega el enlace del vídeo en el ejercicio desde el admin de Django
      (<code>/admin/</code> → Exercises → el ejercicio → «Youtube video id» — vale el enlace
      completo, se limpia solo). Se reproduce en streaming; no se descarga nada.
    </p>

    <h2 class="section-title">Mantenimiento</h2>
    <div class="settings-actions">
      <button class="ghost-btn" id="flush">Enviar pendientes (${api.queueLength()})</button>
      <button class="ghost-btn" id="clear-cache">Vaciar caché</button>
      <button class="ghost-btn" id="test-notif">Probar notificaciones</button>
    </div>
    <p class="field__hint">
      Versión instalada en este móvil: <strong>${esc(APP_VERSION)}</strong> --
      compárala con el número que subiste en <code>version.js</code> antes de
      compilar, para saber si de verdad tienes la última build en el teléfono.
    </p>`;

  // ------------------------------------------------ Health Connect
  const healthStatus = document.getElementById("health-status");
  (async () => {
    // Diagnóstico: qué plugins ve la app de verdad al arrancar. Si
    // "Health" no sale en esta lista, el plugin no llegó a registrarse
    // en el arranque nativo (compilado pero no registrado), que es
    // distinto de "Health Connect no está en el móvil".
    const disponibles = Object.keys(window.Capacitor?.Plugins || {});
    const av = await healthSync.checkAvailability();
    healthStatus.innerHTML = av.available
      ? "Health Connect disponible en este dispositivo."
      : `No disponible: ${av.reason || "desconocido"}<br>
         <small>Plugins detectados: ${disponibles.join(", ") || "ninguno"}</small><br>
         <small>Capacitor: ${window.Capacitor ? "sí" : "NO"} · nativo: ${window.Capacitor?.isNativePlatform?.() ? "sí" : "no"}</small>`;
  })();

  document.getElementById("health-permission").addEventListener("click", async () => {
    healthStatus.textContent = "Pidiendo permiso…";
    try {
      await healthSync.requestPermissions();
      healthStatus.textContent = "Permiso concedido. Se importará al abrir Tareas.";
    } catch (err) {
      healthStatus.textContent = `No se pudo: ${err.message || err}`;
    }
  });

  document.getElementById("health-settings").addEventListener("click", () => {
    healthSync.openSettings().catch(() => {});
  });

  document.getElementById("health-resync").addEventListener("click", async () => {
    healthSync.resetSyncPoint();
    healthStatus.textContent = "Marca de sincronización borrada — abre Tareas para reimportar.";
  });

  document.getElementById("health-diagnose").addEventListener("click", async () => {
    healthStatus.textContent = "Diagnosticando…";
    const d = await healthSync.diagnose();
    if (d.error) {
      healthStatus.textContent = d.error;
      return;
    }
    const lineas = [];
    lineas.push(`Disponibilidad: ${JSON.stringify(d.disponibilidad ?? "?")}`);
    lineas.push(`Última sincronización guardada: ${d.ultimaSincronizacion}`);
    lineas.push(`Pasos de hoy (agregados): ${d.pasosHoy ?? "?"}`);
    lineas.push("");
    lineas.push(`Sesiones en Health Connect (últimos 14 días, sin filtrar tipo): ${d.workoutsSinFiltrar?.length ?? 0}`);
    (d.workoutsSinFiltrar || []).forEach((w, i) => {
      lineas.push(
        `  ${i + 1}. tipo=${w.tipo} · ${w.inicio} → ${w.fin} · ${w.duracion_s ?? "?"}s · ` +
          `directa=${w.distancia_directa_m != null ? (w.distancia_directa_m / 1000).toFixed(2) + "km" : "vacía"} · ` +
          `recuperada=${(w.distancia_recuperada_m / 1000).toFixed(2)}km · origen=${w.origen || "?"}`
      );
    });
    if (d.errores?.length) {
      lineas.push("");
      lineas.push("Errores:");
      d.errores.forEach((e) => lineas.push("  - " + e));
    }
    const texto = lineas.join("\n");
    console.log(texto);
    alert(texto);
    healthStatus.textContent = "Diagnóstico mostrado — cópialo si hace falta compartirlo.";
  });

  document.getElementById("theme-toggle-mobile").addEventListener("click", () => {
    const isLight = document.documentElement.getAttribute("data-theme") === "light";
    const next = isLight ? "dark" : "light";
    if (next === "light") document.documentElement.setAttribute("data-theme", "light");
    else document.documentElement.removeAttribute("data-theme");
    document.getElementById("color-scheme-meta")?.setAttribute("content", next);
    localStorage.setItem("theme", next);
    viewSettings(); // repinta para que el botón enseñe el estado nuevo
  });

  document.getElementById("voice-toggle").addEventListener("click", () => {
    const off = localStorage.getItem("libreta.voiceReps") === "0";
    localStorage.setItem("libreta.voiceReps", off ? "1" : "0");
    viewSettings();
  });

  document.getElementById("cfg-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    api.setConfig({
      baseUrl: (fd.get("baseUrl") || "").trim().replace(/\/+$/, ""),
      user: fd.get("user") || "",
      password: fd.get("password") || "",
    });
    const out = document.getElementById("cfg-result");
    out.textContent = "Probando…";
    try {
      await api.testConnection();
      META = null;
      out.textContent = "✓ Conectado correctamente.";
      tabbar.hidden = false;
    } catch (err) {
      out.textContent = "✗ " + err.message;
    }
  });

  document.getElementById("flush").addEventListener("click", async () => {
    const n = await api.flushQueue();
    refreshQueueBanner();
    toast(n ? `Enviados ${n} cambio(s).` : "No se pudo enviar (sin conexión).");
  });
  document.getElementById("clear-cache").addEventListener("click", () => {
    api.clearCache();
    toast("Caché vaciada.");
  });
  document.getElementById("test-notif").addEventListener("click", async () => {
    if (!notifications.available()) {
      return toast("Las notificaciones solo funcionan dentro de la app instalada, no en el navegador.", "error");
    }
    const ok = await notifications.setup();
    if (!ok) return toast("Permiso denegado. Actívalo en los ajustes del móvil.", "error");
    const pend = await notifications.pending();
    await notifications.testFire();
    toast(
      `Permiso OK. Avisos programados ahora mismo: ${pend ? pend.length : 0}. ` +
      "Te llegará uno de prueba en 10 segundos — cierra la app para verlo.",
    );
  });

  const readingPlugin = window.Capacitor?.Plugins?.ReadingUsage;
  const readingForm = document.getElementById("reading-form");
  if (readingPlugin && readingForm) {
    readingPlugin
      .getConfiguredPackage()
      .then((res) => {
        document.getElementById("reading-package").value = res?.package || "";
      })
      .catch(() => {});

    readingForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const pkg = document.getElementById("reading-package").value.trim();
      const out = document.getElementById("reading-result");
      try {
        await readingPlugin.setConfiguredPackage({ package: pkg });
        out.textContent = pkg ? `✓ Guardado: ${pkg}` : "✓ Quitado.";
      } catch (err) {
        out.textContent = "✗ No se pudo guardar.";
      }
    });

    document.getElementById("reading-permission").addEventListener("click", async () => {
      try {
        const res = await readingPlugin.hasPermission();
        if (res?.granted) {
          toast("✓ El permiso de uso ya está activado.");
        } else {
          await readingPlugin.openUsageSettings();
        }
      } catch {
        toast("No se pudo comprobar el permiso.", "error");
      }
    });
  }
}

// ------------------------------------------------------------- router

const routes = [
  [/^\/$/, viewTasks],
  [/^\/nueva$/, () => viewTaskForm(null)],
  [/^\/editar\/(.+)$/, (m) => viewTaskForm(m[1])],
  [/^\/stats$/, viewStats],
  [/^\/stats\/([^/]+)$/, (m) => viewStatsDetail(m[1])],
  [/^\/planes$/, () => import("./plan-view.js").then((v) => v.renderPlanList())],
  [/^\/plan-nuevo$/, () => import("./plan-view.js").then((v) => v.renderPlanForm(null))],
  [/^\/plan-ia$/, () => import("./plan-view.js").then((v) => v.renderPlanAI())],
  [/^\/plan-editar\/([^/]+)$/, (m) => import("./plan-view.js").then((v) => v.renderPlanForm(m[1]))],
  [/^\/plan-cerrar\/([^/]+)$/, (m) => import("./plan-view.js").then((v) => v.renderPlanClose(m[1]))],
  [/^\/revision$/, () => import("./plan-view.js").then((v) => v.renderWeeklyReview())],
  [/^\/retos$/, () => import("./challenges-view.js").then((v) => v.renderChallengesList())],
  [/^\/retos\/sally-pushups$/, () => import("./challenges-view.js").then((v) => v.renderSallyPushupsIntro())],
  [/^\/retos\/pullups-100$/, () => import("./challenges-view.js").then((v) => v.renderPullups100Intro())],
  [/^\/retos\/cindy$/, () => import("./challenges-view.js").then((v) => v.renderCindyIntro())],
  [/^\/plan\/([^/]+)$/, (m) => import("./plan-view.js").then((v) => v.renderPlan(m[1]))],
  [/^\/plan\/([^/]+)\/objetivo-nuevo$/, (m) =>
    import("./plan-view.js").then((v) => v.renderPlanItemForm(m[1], null))],
  [/^\/plan\/([^/]+)\/objetivo\/([^/]+)$/, (m) =>
    import("./plan-view.js").then((v) => v.renderPlanItemForm(m[1], m[2]))],
  [/^\/plan-sesion\/([^/]+)\/([^/]+)$/, (m) =>
    import("./plan-view.js").then((v) => v.renderPlanSession(m[1], m[2]))],
  [/^\/perfil$/, viewProfile],
  [/^\/ajustes$/, viewSettings],
  // El selector de ejercicio y la pantalla de cámara necesitan URLs
  // DISTINTAS. Antes compartían "#/entreno/<uuid>", y como el botón de
  // volver apuntaba a la misma dirección en la que ya estabas, el
  // navegador no disparaba hashchange y el botón no hacía nada.
  [/^\/entreno\/([^/]+)$/, (m) => import("./workout-view.js").then((v) => v.render(m[1]))],
  [/^\/calentamiento\/([^/?]+)(?:\?(.*))?$/, (m) =>
    import("./warmup-view.js").then((v) => v.renderWarmup(m[1], new URLSearchParams(m[2] || "").get("next")))],
  [/^\/enfriamiento\/([^/]+)$/, (m) => import("./warmup-view.js").then((v) => v.renderCooldown(m[1]))],
  [/^\/enfoque\/([^/?]+)(?:\?(.*))?$/, (m) =>
    import("./focus-view.js").then((v) => v.render(m[1], new URLSearchParams(m[2] || "").get("mode")))],
  [/^\/video\/([^/?]+)(?:\?(.*))?$/, (m) =>
    import("./video-view.js").then((v) => v.render(m[1], new URLSearchParams(m[2] || "").get("v")))],
  [/^\/entreno\/([^/]+)\/camara\/([^/]+)$/, (m) =>
    import("./workout-view.js").then((v) => v.renderCamera(m[1], m[2]))],
  [/^\/entreno\/([^/]+)\/manual\/([^/]+)$/, (m) =>
    import("./workout-view.js").then((v) => v.renderManual(m[1], m[2]))],
  [/^\/circuito\/([^/]+)\/([^/]+)$/, (m) =>
    import("./workout-view.js").then((v) => v.renderCircuit(m[1], m[2]))],
  [/^\/circuitos\/nuevo(?:\?(.*))?$/, (m) => {
    const q = new URLSearchParams(m[1] || "");
    return import("./workout-view.js").then((v) =>
      v.renderRoutineForm(null, q.get("back"), q.get("sub") || ""));
  }],
  [/^\/circuitos\/([^/?]+)(?:\?(.*))?$/, (m) => {
    const q = new URLSearchParams(m[2] || "");
    return import("./workout-view.js").then((v) =>
      v.renderRoutineForm(m[1], q.get("back"), q.get("sub") || ""));
  }],
];

// Recuerda desde dónde se navega, para poder deshacer un cambio de hash
// si __currentViewGuard (ver más abajo) pide confirmación y el usuario
// decide quedarse.
let currentHash = location.hash || "#/";
let revertingHash = false;

async function router() {
  if (revertingHash) {
    // Este hashchange es el que provoca nuestro propio location.hash de
    // más abajo al deshacer una salida cancelada -- no es una navegación
    // real, no hay nada que pintar ni que preguntar otra vez.
    revertingHash = false;
    currentHash = location.hash || "#/";
    return;
  }

  // Igual que __currentViewCleanup de aquí abajo, pero para poder
  // BLOQUEAR la salida en vez de solo limpiar al salir -- una sesión de
  // ejercicios en marcha (ver session-runner.js/start()) registra aquí
  // una función que pregunta "¿seguro que quieres salir?" antes de dejar
  // pasar la navegación. El botón físico atrás de Android, el enlace
  // "← Volver" de la topbar, otra pestaña... todo pasa por un cambio de
  // hash y por tanto por aquí. Si la respuesta es que no, se deshace el
  // cambio de hash y no se toca la pantalla para nada.
  if (window.__currentViewGuard && !window.__currentViewGuard()) {
    revertingHash = true;
    location.hash = currentHash;
    return;
  }
  currentHash = location.hash || "#/";

  const path = (location.hash || "#/").slice(1) || "/";

  if (!api.isConfigured() && path !== "/ajustes") {
    location.hash = "#/ajustes";
    return;
  }
  tabbar.hidden = !api.isConfigured();

  // Salir de una pantalla con cámara/voz en marcha (plancha, dominadas,
  // un circuito…) por CUALQUIER camino que no sea sus propios botones de
  // Cancelar/Terminar — el enlace "← Volver" de la topbar, el botón
  // físico atrás de Android, o cualquier otra pestaña — pasaba
  // directamente por aquí, machacando view.innerHTML sin más: la cámara
  // y la voz seguían encendidas de fondo, hablando de un ejercicio que
  // ya no se ve en pantalla (justo lo que se reportó). Cada pantalla que
  // necesita limpieza al salir deja aquí su función (ver workout-view.js
  // /renderCamera, /renderCircuit, y challenges-view.js/
  // runSallyPushups) — se llama justo antes de dar paso a la siguiente
  // ruta, y se olvida en cuanto se usa, tanto si la pantalla siguiente
  // deja una nueva como si no.
  window.__currentViewCleanup?.();
  window.__currentViewCleanup = null;

  view.querySelectorAll("*").forEach(() => {});
  document.querySelectorAll("[data-tab]").forEach((a) => {
    // Ajustes ya no tiene pestaña: cuelga de Perfil, que sigue marcada.
    a.classList.toggle("active", a.dataset.tab === path || (a.dataset.tab === "/perfil" && path === "/ajustes"));
  });

  for (const [re, handler] of routes) {
    const m = path.match(re);
    if (m) {
      try {
        await handler(m);
      } catch (err) {
        errorView(err);
      }
      playViewTransition();
      return;
    }
  }
  view.innerHTML = `<p class="empty">Pantalla no encontrada.</p>`;
  playViewTransition();
}

// Cada pantalla es un innerHTML nuevo del mismo #view, sin ningún tipo
// de transición — cambiaba de golpe. Esto la reproduce cada vez: quita
// la clase, fuerza que el navegador recalcule el layout (si no, como ya
// "había" puesto esa clase, no vuelve a disparar la animación) y la
// vuelve a poner.
function playViewTransition() {
  view.classList.remove("view-enter");
  void view.offsetWidth;
  view.classList.add("view-enter");
}

window.addEventListener("hashchange", router);

// Sin esto, un fallo dentro de una promesa no mostraba NADA: la pantalla
// se quedaba con el último texto puesto (el famoso "Iniciando…") y no
// había forma de saber qué había pasado. Ahora cualquier error suelto se
// ve en pantalla.
window.addEventListener("unhandledrejection", (e) => {
  console.error("Error no capturado:", e.reason);
  const msg = e.reason?.message || String(e.reason);
  const box = document.createElement("div");
  box.className = "queue-banner";
  box.style.background = "var(--danger-soft)";
  box.style.color = "var(--danger)";
  box.textContent = `Error: ${msg}`;
  document.body.prepend(box);
  setTimeout(() => box.remove(), 8000);
});
window.addEventListener("online", async () => {
  showOffline(false);
  await api.flushQueue();
  refreshQueueBanner();
  router();
});
window.addEventListener("offline", () => showOffline(true));

async function boot() {
  refreshQueueBanner();
  checkForAppUpdate().catch(() => {});
  if (notifications.available()) {
    notifications.setup().catch(() => {});
    // El botón físico "atrás" de Android cierra la app de golpe si no se
    // controla; aquí navega hacia atrás y solo sale desde la raíz.
    window.Capacitor?.Plugins?.App?.addListener("backButton", ({ canGoBack }) => {
      // En pantalla completa de cámara, "atrás" solo sale de ella.
      if (window.__exitCameraFullscreen?.()) return;
      if (location.hash && location.hash !== "#/") history.back();
      else if (!canGoBack) window.Capacitor.Plugins.App.exitApp();
    });
  }
  // Si sales de la app (botón de inicio, multitarea, otra app) a media
  // frase de voz, esa frase seguía sonando de fondo -- con NativeTts el
  // motor de verdad vive en Android, no en este WebView, así que sigue
  // hablando aunque el WebView deje de pintar. "pause" es el evento del
  // ciclo de vida de Capacitor para "la app deja de estar en primer
  // plano"; solo corta la voz en curso (stopSpeaking(), la misma función
  // que ya usa stopCamera) -- no toca la cámara, el contador de reps ni
  // nada de lo que se guarda: al volver a la app, todo sigue donde
  // estaba, simplemente sin esa frase a medias. Import dinámico para no
  // cargar workout.js (pesado) hasta que haga falta, y porque cargarlo
  // aquí arriba de forma estática se ejecutaría antes de que la línea 33
  // marque window.__LIBRETA_APP__, disparando el auto-arranque pensado
  // para la web.
  window.Capacitor?.Plugins?.App?.addListener("pause", () => {
    import("./workout.js").then((w) => w.stopSpeaking()).catch(() => {});
  });
  await api.flushQueue().catch(() => {});
  refreshQueueBanner();
  router();
}

boot();

// ---------------------------------------------------- tirar para refrescar
// No existía ningún gesto para recargar: al ser una sola página que no
// se recarga sola, la única forma de traer datos nuevos era navegar a
// otra pestaña y volver. Esto reusa exactamente el router — vuelve a
// pedir y pintar lo que sea que esté en pantalla ahora mismo, sea la
// lista, un plan o donde sea.
(function setupPullToRefresh() {
  const THRESHOLD = 70;   // px que hay que tirar para que se dispare
  const BAR_HEIGHT = 50;
  let startY = null;
  let dragging = false;

  const indicator = document.createElement("div");
  indicator.className = "pull-refresh";
  indicator.innerHTML = `<span class="pull-refresh__spinner"></span>`;
  document.body.prepend(indicator);

  // Solo cuenta si ya estás arriba del todo — si no, es scroll normal.
  const atTop = () => (document.scrollingElement || document.documentElement).scrollTop <= 0;

  document.addEventListener("touchstart", (e) => {
    startY = atTop() ? e.touches[0].clientY : null;
    dragging = false;
  }, { passive: true });

  document.addEventListener("touchmove", (e) => {
    if (startY === null || indicator.classList.contains("is-spinning")) return;
    const dy = e.touches[0].clientY - startY;
    if (dy <= 0 || !atTop()) return;
    dragging = true;
    const progress = Math.min(1, dy / THRESHOLD);
    indicator.style.transform = `translateY(${-BAR_HEIGHT + BAR_HEIGHT * progress}px)`;
    indicator.classList.toggle("is-ready", progress >= 1);
  }, { passive: true });

  document.addEventListener("touchend", async () => {
    if (!dragging) { startY = null; return; }
    const ready = indicator.classList.contains("is-ready");
    dragging = false;
    startY = null;
    if (!ready) {
      indicator.style.transform = "";
      return;
    }
    indicator.style.transform = "translateY(0)";
    indicator.classList.add("is-spinning");
    try {
      await router();
    } finally {
      indicator.classList.remove("is-spinning", "is-ready");
      indicator.style.transform = "";
    }
  });
})();

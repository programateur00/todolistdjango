/**
 * Avisos locales de la app: antitareas (nocturno) y recordatorio de
 * cualquier tarea con hora (como Google Calendar).
 *
 * Diseño (ver la conversación de diseño):
 *  - El MÓVIL es el único que notifica. La web no lo hace nunca, así no
 *    hay que coordinar nada ni salen avisos duplicados.
 *  - Antitareas: la notificación lleva dos botones ("No he caído" / "He
 *    caído") para responder desde la persiana sin abrir la app. Si la
 *    ignoras, cuenta como éxito — el DATO lo resuelve el servidor por
 *    fecha, así que aunque el móvil esté apagado el resultado acaba
 *    siendo el mismo (ver Task.mark_expired en el servidor).
 *  - Tareas normales (freestyle o generadas por un plan): un aviso a la
 *    hora límite con un botón para marcarla hecha al momento. Si la
 *    ignoras, NO hace falta tocar nada — igual que las antitareas, el
 *    servidor la marca sola como no hecha al pasar la hora
 *    (Task.expire_overdue), así que aquí no hay botón de "no hecha": ya
 *    pasa sola.
 *  - TODOS los avisos (se repitan o no) son PUNTUALES ("at": un
 *    instante concreto), nunca recurrentes a nivel de Android
 *    ("on: {hour, minute}" sin más). A propósito, tras un bug repetido:
 *    un "on" recurrente vive dentro del propio AlarmManager de Android
 *    y, en cuanto suena una vez, SE REPROGRAMA SOLO para el día
 *    siguiente por dentro del sistema operativo (ver
 *    TimedNotificationPublisher.rescheduleNotificationIfNeeded en el
 *    plugin nativo) — completamente al margen de la app. cancelNow()
 *    puede cancelar la alarma de HOY, pero si esa cancelación no
 *    llega a tiempo o el fabricante (Xiaomi/MIUI en el móvil de
 *    pruebas) no la respeta del todo, el aviso recurrente sigue vivo
 *    por su cuenta y vuelve a sonar días después aunque la tarea ya
 *    esté marcada — el bug reportado. Con un aviso puntual por día no
 *    hay nada que se reprograme solo: cancelarlo lo mata de verdad, sin
 *    condiciones, y schedule() (se llama cada vez que se abre la lista
 *    de tareas) programa el de mañana desde cero si sigue tocando. El
 *    coste: si NO se reabre la app antes de la hora de mañana, no
 *    sonará — aceptable para una lista de tareas que se abre a diario,
 *    y mucho mejor que un aviso zombi que ya no se puede apagar.
 *  - Una tarea que se repite se ancla a la SERIE (no a la fila de hoy,
 *    que cambia de uuid cada día) para que el botón de la notificación
 *    siga apuntando a "la pendiente actual" vía task_mark_by_series en
 *    la API. Una tarea suelta (no se repite) usa su propio uuid, que sí
 *    es estable.
 *  - Multi-móvil: un aviso local solo sabe lo que pasó en SU propio
 *    móvil, así que marcar la tarea en uno no cancela nada en otro por
 *    sí solo. Por eso cada aviso lleva también una comprobación previa
 *    (ver schedulePreCheck/AvoidPreCheckReceiver más abajo) que, unos
 *    minutos antes de la hora, le pregunta al SERVIDOR si sigue
 *    pendiente -- y si ya se marcó desde CUALQUIER móvil, se cancela
 *    sin llegar a sonar. Esto sigue siendo un aviso 100% local (no hace
 *    falta un servidor de push), solo que con una comprobación de red
 *    de última hora antes de mostrarlo.
 *
 * Requiere el plugin @capacitor/local-notifications.
 */

import { api } from "./api.js";

const ACTION_TYPE_ID = "ANTITAREA";
const CHANNEL_ID = "antitareas";
const TIMER_CHANNEL_ID = "temporizador";
// Un id fijo por tarea permite reemplazar el aviso del día anterior en
// vez de ir acumulando notificaciones viejas en la persiana.
const ID_BASE = 41000;
// Rango aparte para las notificaciones de "se acabó el tiempo" — tiene
// que quedar FUERA del rango 41000-140999 de arriba: schedule() cancela
// todo lo que caiga ahí dentro cada vez que se abre la lista de tareas,
// así que si se solapasen, cancelaría avisos de temporizador en marcha
// sin volver a programarlos.
const TIMER_ID_BASE = 200000;

// Recordatorio genérico ("toca hacer esta tarea"), para cualquier tarea
// con hora que no sea antitarea. Rango propio, fuera de los dos de
// arriba, para poder cancelar solo los suyos sin tocar los demás.
const TASK_ACTION_TYPE_ID = "TAREA";
const TASK_CHANNEL_ID = "tareas";
const TASK_ID_BASE = 300000;

let LocalNotifications = null;

async function plugin() {
  if (LocalNotifications) return LocalNotifications;
  if (!window.Capacitor?.Plugins?.LocalNotifications) return null;
  LocalNotifications = window.Capacitor.Plugins.LocalNotifications;
  return LocalNotifications;
}

/**
 * Hash simple y estable de un string (uuid de tarea o de serie) -> entero
 * pequeño. El plugin exige ids numéricos; lo importante es que el MISMO
 * string dé siempre el mismo id, para poder reemplazar y cancelar.
 */
function hashId(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h * 31 + str.charCodeAt(i)) % 100000;
  }
  return h;
}

function idFor(id) {
  return ID_BASE + hashId(id);
}

/**
 * Segunda red de seguridad, aparte de cancelNow(): un aviso local solo
 * sabe lo que pasó en ESTE móvil. Si la app está instalada en más de
 * uno, marcar la tarea en el móvil A no cancela nada en el B -- cada
 * uno programa sus propios avisos sin enterarse de los demás. Para
 * eso, además de la notificación en sí, se programa una alarma nativa
 * propia (AvoidPreCheckReceiver, en el proyecto de Android) unos
 * minutos ANTES de la hora: le pregunta al SERVIDOR "¿sigue
 * pendiente esto?" y, si ya no hace falta (se marcó desde cualquier
 * móvil), cancela el aviso antes de que llegue a sonar. Sin red o sin
 * respuesta a tiempo, no se cancela nada -- se deja sonar (fail open).
 * Si el plugin nativo no está (build vieja sin recompilar, o
 * ejecutando en el navegador), esto no hace nada y el aviso se
 * comporta como antes.
 */
const PRECHECK_LEAD_MS = 3 * 60 * 1000;

async function preCheckPlugin() {
  return window.Capacitor?.Plugins?.AvoidPreCheck || null;
}

function buildCheckUrl(params) {
  if (!api.isConfigured()) return null;
  const qs = new URLSearchParams(params).toString();
  return api._url(`/notify-pending/?${qs}`);
}

async function schedulePreCheck(id, atMillis, params) {
  const PC = await preCheckPlugin();
  if (!PC) return;
  // Sin margen real de un par de minutos no compensa: la comprobación
  // tardaría casi lo mismo que esperar a que suene el aviso de verdad.
  const checkAt = atMillis - PRECHECK_LEAD_MS;
  if (checkAt <= Date.now() + 10000) return;
  const checkUrl = buildCheckUrl(params);
  if (!checkUrl) return;
  const authHeader = api._headers().Authorization || "";
  await PC.schedule({ notifId: id, atMillis: checkAt, checkUrl, authHeader }).catch(() => {});
}

async function cancelPreCheck(id) {
  const PC = await preCheckPlugin();
  if (!PC) return;
  await PC.cancel({ notifId: id }).catch(() => {});
}

function timerIdFor(taskUuid) {
  return TIMER_ID_BASE + hashId(taskUuid);
}

function taskReminderIdFor(key) {
  return TASK_ID_BASE + hashId(key);
}

// Ya NO decide si el aviso es un "on" nativo recurrente (ver el
// comentario de cabecera -- eso se quito del todo). Solo decide si el
// id/accion de la notificacion se ancla a la SERIE (para que el boton
// siga sirviendo aunque la fila de hoy cambie de uuid manana) o al
// uuid suelto de la propia tarea.
function isEveryDay(t) {
  return t.repeat === "daily" && (t.interval || 1) === 1;
}

/**
 * Notificaciones de recordatorio (no antitareas) a programar para las
 * tareas pendientes con hora. Separado de schedule() para que se pueda
 * leer de un tirón qué criterio decide cada caso.
 */
function buildTaskReminderNotifications(tasks) {
  const candidates = tasks.filter((t) => !t.is_avoid && !t.is_done && t.due_time);
  if (!candidates.length) return [];

  const now = Date.now();
  const notifs = [];
  for (const t of candidates) {
    const [hh, mm] = t.due_time.split(":").map(Number);
    const body = t.plan_name ? `Toca: ${t.plan_name}` : "Tu recordatorio de hoy.";

    // Un aviso PUNTUAL anclado al día que toca (hoy si no tiene fecha) —
    // NUNCA uno recurrente a nivel de Android (ver el comentario de
    // cabecera: un "on" recurrente se reprograma solo dentro del
    // sistema operativo en cuanto suena una vez, al margen de la app, y
    // cancelarlo al marcar la tarea no siempre lo mata de verdad). Si la
    // hora ya ha pasado hoy, no tiene sentido programarlo — la tarea ya
    // se habrá resuelto sola, o se resolverá antes de que llegue.
    const base = t.due_date ? new Date(`${t.due_date}T00:00:00`) : new Date();
    const at = new Date(base);
    at.setHours(hh, mm, 0, 0);
    if (at.getTime() <= now) continue;

    // Ancla a la SERIE si la tarea se repite cada día (su uuid cambia
    // de fila en fila, así que el botón de la notificación necesita
    // apuntar a "la pendiente actual" vía markBySeries); una tarea
    // suelta o con huecos usa su propio uuid, estable para ese día.
    const anchoredToSeries = isEveryDay(t);
    notifs.push({
      id: anchoredToSeries ? taskReminderIdFor(t.series_id) : taskReminderIdFor(t.uuid),
      title: `⏰ ${t.title}`,
      body,
      actionTypeId: TASK_ACTION_TYPE_ID,
      channelId: TASK_CHANNEL_ID,
      extra: anchoredToSeries
        ? { kind: "reminder", seriesId: t.series_id }
        : { kind: "reminder", taskUuid: t.uuid },
      schedule: { at, allowWhileIdle: true },
      autoCancel: true,
    });
  }
  return notifs;
}

function isOurs(id) {
  return (
    (id >= ID_BASE && id < ID_BASE + 100000) ||
    (id >= TASK_ID_BASE && id < TASK_ID_BASE + 100000)
  );
}

export const notifications = {
  available() {
    return Boolean(window.Capacitor?.Plugins?.LocalNotifications);
  },

  /** Pide permiso (obligatorio desde Android 13) y registra los botones. */
  async setup() {
    const LN = await plugin();
    if (!LN) return false;

    const perm = await LN.requestPermissions();
    if (perm.display !== "granted") return false;

    // Canal propio: en Android 8+ los ajustes de sonido y prioridad
    // cuelgan del canal, no de cada notificación.
    if (LN.createChannel) {
      await LN.createChannel({
        id: CHANNEL_ID,
        name: "Antitareas",
        description: "Recordatorio nocturno para confirmar si has caído",
        importance: 4,
        visibility: 1,
      });
      await LN.createChannel({
        id: TASK_CHANNEL_ID,
        name: "Tareas",
        description: "Recordatorio a la hora límite de cualquier tarea",
        importance: 4,
        visibility: 1,
      });
      // Canal aparte para "se acabó el tiempo" — sonido e importancia
      // altos a propósito, como el temporizador nativo del reloj: si
      // has dejado el móvil en otra habitación, tiene que oírse.
      await LN.createChannel({
        id: TIMER_CHANNEL_ID,
        name: "Temporizador",
        description: "Aviso al cumplirse el tiempo de una sesión de Enfoque",
        importance: 5,
        visibility: 1,
        sound: "default",
        vibration: true,
      });
    }

    await LN.registerActionTypes({
      types: [
        {
          id: ACTION_TYPE_ID,
          actions: [
            { id: "avoided", title: "No he caído" },
            { id: "failed", title: "He caído", destructive: true },
          ],
        },
        {
          // Sin "no hecha": si la ignoras, el servidor ya la marca sola
          // al pasar la hora (Task.expire_overdue) — el único botón que
          // aporta algo aquí es adelantarlo a mano.
          id: TASK_ACTION_TYPE_ID,
          actions: [{ id: "done", title: "Marcar hecha" }],
        },
      ],
    });

    // Al pulsar un botón se registra el resultado sin abrir la app. Si
    // no hay red, api.write lo deja en la cola y se manda luego.
    LN.addListener("localNotificationActionPerformed", async (event) => {
      const extra = event.notification?.extra || {};

      if (extra.kind === "reminder") {
        if (event.actionId !== "done") return;
        if (extra.seriesId) {
          await api.markBySeries(extra.seriesId, "done").catch(() => {});
        } else if (extra.taskUuid) {
          await api.markTask(extra.taskUuid, "done").catch(() => {});
        }
        return;
      }

      // Antitarea: por serie, no por tarea concreta — ver el comentario
      // de cabecera y task_mark_by_series() en la API.
      const seriesId = extra.seriesId;
      if (!seriesId) return;
      if (event.actionId === "avoided") {
        await api.markBySeries(seriesId, "done").catch(() => {});
      } else if (event.actionId === "failed") {
        await api.markBySeries(seriesId, "failed").catch(() => {});
      }
    });

    return true;
  },

  /**
   * Reprograma los avisos de todas las tareas pendientes con hora
   * (antitareas + recordatorio normal). Se llama al abrir la app y
   * después de cada cambio: es idempotente, cancela lo anterior y
   * vuelve a programar desde cero, así no quedan avisos huérfanos de
   * tareas ya borradas o ya hechas.
   */
  async schedule(tasks) {
    const LN = await plugin();
    if (!LN) return 0;

    const pending = await LN.getPending();
    const ours = pending.notifications.filter((n) => isOurs(n.id));
    if (ours.length) {
      await LN.cancel({ notifications: ours.map((n) => ({ id: n.id })) });
      await Promise.all(ours.map((n) => cancelPreCheck(n.id)));
    }

    const avoidTasks = tasks.filter((t) => t.is_avoid && !t.is_done && t.due_time);
    let scheduled = 0;

    if (avoidTasks.length) {
      // Un tipo de acción por SERIE, no por tarea del día, y el id de la
      // notificación también sale de la serie: apunta a "esta antitarea
      // recurrente", no a la fila concreta de hoy (que cambia de uuid
      // cada día en cuanto se resuelve). Así, aunque el aviso se
      // reprograma día a día (ver más abajo, ya no es un "on" nativo),
      // el botón de la notificación sigue sirviendo sin que la app
      // tenga que recordar qué uuid tocaba hoy.
      const actionTypes = avoidTasks.map((t) => ({
        id: `${ACTION_TYPE_ID}_${idFor(t.series_id)}`,
        actions: [
          { id: "avoided", title: t.avoid_success_label || "Sigo con la racha" },
          { id: "failed", title: t.avoid_fail_label || "Romper racha", destructive: true },
        ],
      }));
      await LN.registerActionTypes({ types: actionTypes });

      const nowMs = Date.now();
      const toSchedule = [];
      for (const t of avoidTasks) {
        const [hh, mm] = t.due_time.split(":").map(Number);
        const grace = t.avoid_grace_hours ?? 2;
        const base = {
          id: idFor(t.series_id),
          title: t.title,
          body: `${t.avoid_question || "¿Has caído hoy?"} Si no contestas en ${grace}h, se dará por evitado.`,
          actionTypeId: `${ACTION_TYPE_ID}_${idFor(t.series_id)}`,
          channelId: CHANNEL_ID,
          extra: { kind: "avoid", seriesId: t.series_id },
          // Se descarta sola pasado el margen: si no contestaste, el
          // servidor ya lo dio por evitado y el aviso viejo solo estorba.
          autoCancel: true,
          ongoing: false,
        };

        // Un aviso PUNTUAL para el día que TOCA (hoy si no tiene fecha) —
        // NUNCA uno recurrente a nivel de Android, ni siquiera para
        // "cada día". Ver el comentario de cabecera: un "on" recurrente
        // se reprograma solo dentro del propio Android en cuanto suena
        // una vez, al margen por completo de la app, así que cancelarlo
        // al marcar la antitarea no siempre lo mata de verdad — es la
        // causa real del aviso que seguía sonando después de marcada.
        const day = t.due_date ? new Date(`${t.due_date}T00:00:00`) : new Date();
        const at = new Date(day);
        at.setHours(hh, mm, 0, 0);
        if (at.getTime() <= nowMs) continue;
        toSchedule.push({ ...base, schedule: { at, allowWhileIdle: true } });
      }

      if (toSchedule.length) {
        await LN.schedule({ notifications: toSchedule });
        scheduled += toSchedule.length;
        await Promise.all(
          toSchedule.map((n) => schedulePreCheck(n.id, n.schedule.at.getTime(), { series: n.extra.seriesId }))
        );
      }
    }

    const taskNotifs = buildTaskReminderNotifications(tasks);
    if (taskNotifs.length) {
      await LN.schedule({ notifications: taskNotifs });
      scheduled += taskNotifs.length;
      await Promise.all(
        taskNotifs.map((n) =>
          schedulePreCheck(
            n.id,
            n.schedule.at.getTime(),
            n.extra.seriesId ? { series: n.extra.seriesId } : { task: n.extra.taskUuid }
          )
        )
      );
    }

    return scheduled;
  },

  async cancelAll() {
    const LN = await plugin();
    if (!LN) return;
    const pending = await LN.getPending();
    const ours = pending.notifications.filter((n) => isOurs(n.id));
    if (ours.length) {
      await LN.cancel({ notifications: ours.map((n) => ({ id: n.id })) });
      await Promise.all(ours.map((n) => cancelPreCheck(n.id)));
    }
  },

  /**
   * Cancela YA el aviso de UNA tarea concreta, sin esperar a que se
   * recargue la lista de tareas (que es cuando schedule() reconcilia
   * todo desde cero — ver su comentario). Se llama nada más marcar una
   * tarea como hecha/fallada/no-hecha, para que un cambio de pantalla,
   * estar sin conexión, o simplemente no reabrir la app antes de la
   * hora, no deje sonar un aviso de algo que ya se resolvió.
   *
   * Como todos los avisos son puntuales ("at", nunca "on" recurrente —
   * ver el comentario de cabecera), esto los cancela de verdad, sin
   * condiciones: no hay ninguna alarma nativa que pueda reprogramarse
   * sola por dentro de Android después de esto. Para una tarea "cada
   * día" el id cancelado es el de la SERIE (el mismo para todos los
   * días); la próxima vez que se abra la lista con la tarea de mañana
   * ya pendiente, schedule() programa la de mañana desde cero.
   */
  async cancelNow(task) {
    if (!task) return;
    const LN = await plugin();
    if (!LN) return;
    const rawIds = [];
    if (task.is_avoid) rawIds.push(idFor(task.series_id || task.uuid));
    if (isEveryDay(task)) rawIds.push(taskReminderIdFor(task.series_id || task.uuid));
    else rawIds.push(taskReminderIdFor(task.uuid));
    await LN.cancel({ notifications: rawIds.map((id) => ({ id })) }).catch(() => {});
    // La alarma de comprobación previa (ver su comentario más arriba)
    // también hay que apagarla aquí: si no, seguiría preguntando al
    // servidor dentro de un rato por algo que ya se acaba de resolver
    // en este mismo móvil -- inofensivo (el servidor ya diría "no
    // pendiente"), pero es una llamada de red que sobra.
    await Promise.all(rawIds.map((id) => cancelPreCheck(id)));
  },

  /**
   * Programa el aviso de "se acabó el tiempo" — como el temporizador
   * normal del reloj del móvil: si sales de la app, bloqueas la
   * pantalla o te pones a hacer otra cosa, salta igual, con sonido y
   * vibración, porque vive en el sistema operativo, no en la pestaña
   * del navegador.
   *
   * Un id por tarea (no por sesión): empezar una sesión nueva de la
   * misma tarea reemplaza cualquier aviso anterior sin duplicar.
   */
  async scheduleTimerDone(taskUuid, title, secondsFromNow) {
    const LN = await plugin();
    if (!LN || secondsFromNow <= 0) return false;
    await LN.schedule({
      notifications: [{
        id: timerIdFor(taskUuid),
        title: "⏱️ Tiempo cumplido",
        body: title,
        channelId: TIMER_CHANNEL_ID,
        schedule: { at: new Date(Date.now() + secondsFromNow * 1000), allowWhileIdle: true },
        sound: "default",
        autoCancel: true,
      }],
    });
    return true;
  },

  /** Al pausar o guardar antes de tiempo — si no se cancela, saltaría
   *  igual más tarde por una sesión que ya se dejó o se guardó. */
  async cancelTimerDone(taskUuid) {
    const LN = await plugin();
    if (!LN) return;
    await LN.cancel({ notifications: [{ id: timerIdFor(taskUuid) }] });
  },

  /** Diagnóstico: qué avisos hay realmente programados en el sistema.
   *  Sirve para distinguir "no se programó" de "el móvil lo bloqueó". */
  async pending() {
    const LN = await plugin();
    if (!LN) return null;
    const p = await LN.getPending();
    return p.notifications.filter((n) => isOurs(n.id));
  },

  /** Lanza un aviso de prueba a los 10 segundos, con los mismos botones
   *  que el real. Si este no llega, el problema es del móvil. */
  async testFire() {
    const LN = await plugin();
    if (!LN) return false;
    await LN.schedule({
      notifications: [{
        id: ID_BASE + 99999,
        title: "Prueba de aviso",
        body: "Si ves esto, las notificaciones funcionan.",
        actionTypeId: ACTION_TYPE_ID,
        channelId: CHANNEL_ID,
        schedule: { at: new Date(Date.now() + 10000), allowWhileIdle: true },
      }],
    });
    return true;
  },
};

/**
 * Ilustraciones de ejercicios.
 *
 * Dibujos reales (siluetas anatómicas) del proyecto Everkinetic. Cada
 * ejercicio tiene dos posturas: inicio y final.
 *
 * Se muestran ALTERNÁNDOSE en el mismo sitio, no una al lado de otra:
 * enseñar el movimiento como una animación se lee mucho mejor que dos
 * viñetas, y ocupa la mitad de ancho — que en un móvil importa.
 *
 * Licencia: Creative Commons Attribution-ShareAlike 3.0, autor
 * Everkinetic. El crédito tiene que seguir visible en la app (está en
 * la pantalla de Ajustes).
 */

const BASE = "assets/exercises";

// Ejercicios con ilustración propia. El resto cae al respaldo.
const AVAILABLE = new Set([
  "crunch", "leg-raise", "superman", "bicycle-crunch", "plank",
  "squat", "situp", "pullup", "push-up", "side-plank", "dips", "lunge",
]);

// Isométricos: las dos posturas son la misma imagen a propósito. No hay
// movimiento que enseñar, así que se marca "mantener" en vez de fingir
// una animación que no existe.
const STATIC = new Set(["plank", "side-plank", "wall-sit", "kneehold-bar", "dead-hang", "superman-hold"]);

// Variantes que comparten dibujo: el movimiento es el mismo y solo
// cambia el agarre (ancho, supino) o si añades peso o impulso. Repetir
// la ilustración es más honesto que dejar un hueco.
//
// kneehold-bar: colgado de la barra con los brazos estirados — misma
// postura de partida que las dominadas (pullup), solo que en vez de
// subir y bajar se suben las rodillas y se aguantan; reutiliza esa
// silueta.
// dead-hang: mismo criterio que kneehold-bar (re-añadido en
// 0082_readd_dead_hang.py) — también se cuelga de la barra con los
// brazos estirados y sube rodillas/cadera; reutiliza la silueta de
// dominadas.
// weighted-squat: mismo movimiento que squat, solo que con peso añadido
// (chaleco/discos) — igual criterio que weighted-pullup/weighted-dips.
//
// handstand (el pino) NO tiene alias: ninguna silueta de Everkinetic que
// tenemos (todas de pie o tumbadas) se parece a un cuerpo invertido, así
// que cae al respaldo genérico de solo texto (ver hasIllustration/
// exerciseIcon más abajo) en vez de tomar prestado un dibujo que
// confundiría más de lo que ayuda.
// handstand-push-up: mismo motivo que handstand -- también invertido,
// tampoco tiene alias, cae al mismo respaldo genérico.
// pistol-squat: sentadilla a UNA pierna de frente -- la silueta de "squat" (dos piernas, de perfil)
// enseñaría otra cosa, así que tampoco tiene alias y cae al respaldo genérico de solo texto.
const ALIAS = {
  "wide-pullup": "pullup",
  "chinup": "pullup",
  "weighted-pullup": "pullup",
  "jumping-pullup": "pullup",
  "weighted-dips": "dips",
  "double-crunch": "situp",
  "scissor-kick": "leg-raise",
  "wall-sit": "squat",
  "superman-hold": "superman",
  "kneehold-bar": "pullup",
  "dead-hang": "pullup",
  "weighted-squat": "squat",
  "archer-pullup": "pullup",
  "scapular-pull": "pullup",
  "wide-weighted-pullup": "pullup",
  "weighted-crunch": "crunch",
  "incline-push-up": "push-up",
  "pike-push-up": "push-up",
  "bench-dip": "dips",
};

const LABELS = {
  plank: "Plancha", crunch: "Crunch", "leg-raise": "Elevación de piernas",
  "bicycle-crunch": "Bicicleta",
  superman: "Superman", squat: "Sentadillas", situp: "Abdominales",
  pullup: "Dominadas", "push-up": "Flexiones", "side-plank": "Plancha lateral",
  dips: "Fondos", lunge: "Zancadas",
  "wide-pullup": "Dominadas anchas", chinup: "Chin ups",
  "weighted-pullup": "Dominadas con peso", "jumping-pullup": "Dominadas con salto",
  "weighted-dips": "Fondos con peso", "kneehold-bar": "Kneehold Bar",
  "dead-hang": "Dead Hang",
  handstand: "Handstand", "weighted-squat": "Sentadillas con peso",
  "handstand-push-up": "Flexiones en pino",
  "pistol-squat": "Pistol squat",
  "double-crunch": "Doble crunch", "scissor-kick": "Scissor Kicks",
  "wall-sit": "Silla en pared", "archer-pullup": "Dominadas de arquero",
  "scapular-pull": "Dominadas escapulares",
  "wide-weighted-pullup": "Dominadas anchas con peso",
  "weighted-crunch": "Weighted crunch",
  "incline-push-up": "Flexiones inclinadas", "pike-push-up": "Pike push-ups", "dumbbell-curl": "Curl con mancuernas",
  "bench-dip": "Fondos en banco",
  "l-sit": "L-sit en paralelas", "l-sit-hold": "L-sit en paralelas (hold)",
  "superman-hold": "Superman (hold)",
  "elephant-steps": "Elephant steps",
};

function resolve(slug) {
  return ALIAS[slug] || slug;
}

export function hasIllustration(slug) {
  return AVAILABLE.has(resolve(slug));
}

/**
 * Bloque con el ejercicio. Las dos posturas se alternan solas.
 * `compact` para listados, donde solo hace falta reconocerlo de un vistazo.
 */
export function exerciseIcon(slug, { compact = false } = {}) {
  const label = LABELS[slug] || "Ejercicio";
  const art = resolve(slug);   // las variantes reutilizan el dibujo base

  if (!AVAILABLE.has(art)) {
    return `<div class="ex-fig ex-fig--empty" role="img" aria-label="${label}"><span>${label}</span></div>`;
  }

  // OJO: se comprueba el SLUG original, no `art` — un ejercicio puede
  // tomar prestado el dibujo de otro que no es isométrico (kneehold-bar
  // reutiliza el de pullup, que sí tiene dos posturas de movimiento) y
  // aun así necesitar el badge "mantener" él mismo.
  const isStatic = STATIC.has(slug);
  const cls = [
    "ex-fig",
    compact ? "ex-fig--compact" : "",
    isStatic ? "ex-fig--static" : "",
  ].filter(Boolean).join(" ");

  return `<div class="${cls}" role="img" aria-label="${label}">
    <img src="${BASE}/${art}-1.svg" alt="">
    <img src="${BASE}/${art}-2.svg" alt="">
    ${isStatic ? '<span class="ex-fig__hold">mantener</span>' : ""}
  </div>`;
}

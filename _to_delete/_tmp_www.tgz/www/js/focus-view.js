/**
 * Temporizador de Enfoque: leer, estudiar, estirar…
 *
 * El cronómetro manual es igual que el de la web (JS puro, cuenta hacia
 * arriba). Lo único que no tiene equivalente en la web es "Tiempo en la
 * app": para tareas de lectura, además del cronómetro se puede usar el
 * tiempo real que ha estado abierta tu app de lectura (Adobe, Kindle…),
 * vía un plugin nativo — ver /mnt del proyecto para las instrucciones
 * de compilación. Si el plugin no está instalado, el botón lo explica
 * en vez de fallar en silencio.
 */
import { api } from "./api.js";
import { notifications } from "./notifications.js";

const view = document.getElementById("view");

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

function topbar(eyebrow, title, backHref) {
  return `
    <header class="topbar">
      <div class="topbar__title">
        <span class="topbar__eyebrow">${esc(eyebrow)}</span>
        <h1>${esc(title)}</h1>
      </div>
      ${backHref ? `<a href="${backHref}" class="stats-link">← Volver</a>` : ""}
    </header>`;
}

async function keepAwake(on) {
  const KA = window.Capacitor?.Plugins?.KeepAwake;
  if (!KA) return;
  try {
    if (on) await KA.keepAwake();
    else await KA.allowSleep();
  } catch {
    /* si el plugin no está, seguimos igual */
  }
}

/** El plugin nativo de uso de apps. Puede no existir todavía — ver
 *  el aviso al usuario en startAppUsage() si es el caso. */
function usagePlugin() {
  return window.Capacitor?.Plugins?.ReadingUsage || null;
}

function fmt(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
}

async function saveSession(taskUuid, minutes, source, appPackage) {
  const { data } = await api.saveFocus(taskUuid, {
    minutes,
    source,
    app_package: appPackage || "",
  });
  return data;
}

export async function render(taskUuid, mode) {
  view.innerHTML = `<p class="app-loading">Cargando…</p>`;
  const { data } = await api.get(`/tasks/${taskUuid}/`);
  const task = data.task;

  // Solo Estudio ofrece elegir entre vídeo y temporizador — lectura y
  // estiramientos siguen yendo directas al cronómetro, como siempre.
  if (task.subcategory === "study_session" && mode !== "timer") {
    return renderChooser(taskUuid, task);
  }
  return renderTimer(taskUuid, task);
}

/**
 * Selector de "¿cómo vas a estudiar?": un vídeo guardado, uno nuevo, o
 * el temporizador manual de siempre. Se elige aquí, cada vez — no
 * queda fijado en la tarea, así una tarea que se repite puede ir un
 * día con vídeo y otro con temporizador.
 */
async function renderChooser(taskUuid, task) {
  const { data } = await api.savedVideos("study_session");
  const videos = data.videos;

  view.innerHTML = `
    ${topbar("enfoque", task.title, "#/")}
    <p class="exercise-picker__hint">O sigue un vídeo</p>
    <ul class="exercise-picker" id="video-list">
      ${
        videos.length
          ? videos
              .map(
                (v) => `<li>
                  <a class="exercise-picker__item" href="#/video/${taskUuid}?v=${v.youtube_video_id}">
                    <span class="exercise-picker__name">${esc(v.title || v.youtube_video_id)}</span>
                    <span class="exercise-picker__mode">YouTube</span>
                  </a>
                  <form class="inline-delete" data-del-video="${v.uuid}">
                    <button type="button" class="ghost-btn ghost-btn--danger" title="Quitar de la lista">✕</button>
                  </form>
                </li>`
              )
              .join("")
          : `<li class="exercise-picker__empty">Todavía no tienes vídeos guardados aquí.</li>`
      }
    </ul>
    <form class="video-add-form" id="video-add-form">
      <input type="text" name="youtube_video_id" placeholder="Pega un enlace de YouTube…" required>
      <input type="text" name="title" placeholder="Título (opcional)" maxlength="120">
      <button type="submit" class="ghost-btn">+ Añadir y reproducir</button>
    </form>
    <p class="exercise-picker__hint exercise-picker__hint--routines">O usa el temporizador de siempre</p>
    <a class="exercise-picker__item exercise-picker__item--ghost" href="#/enfoque/${taskUuid}?mode=timer">
      <span class="exercise-picker__name">Empezar temporizador manual</span>
    </a>`;

  document.getElementById("video-add-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      const { data: created } = await api.createSavedVideo({
        scope: "study_session",
        youtube_video_id: fd.get("youtube_video_id"),
        title: fd.get("title") || "",
      });
      location.hash = `#/video/${taskUuid}?v=${created.video.youtube_video_id}`;
    } catch (err) {
      window.__toast?.(err.message, "error");
    }
  });
  view.querySelectorAll("[data-del-video]").forEach((form) => {
    form.querySelector("button").addEventListener("click", async () => {
      try {
        await api.deleteSavedVideo(form.dataset.delVideo);
        renderChooser(taskUuid, task);
      } catch (err) {
        window.__toast?.(err.message, "error");
      }
    });
  });
}

async function renderTimer(taskUuid, task) {
  const targetMinutes = task.target_minutes;
  const isReading = task.subcategory === "reading";

  view.innerHTML = `
    ${topbar("enfoque", task.title, "#/")}
    <div class="focus-timer" id="focus-timer">
      <p class="focus-timer__display" id="focus-display">00:00</p>
      ${
        targetMinutes
          ? `<p class="focus-timer__target">Objetivo: ${targetMinutes} min</p>
             <div class="stats-bar"><div class="stats-bar__done" id="focus-progress" style="width:0%"></div></div>`
          : `<p class="focus-timer__target">Sesión libre, sin objetivo</p>`
      }
      <div class="focus-timer__actions">
        <button type="button" class="primary-btn" id="focus-toggle">Empezar</button>
        <button type="button" class="ghost-btn" id="focus-save" hidden>Guardar sesión</button>
      </div>
      ${
        isReading
          ? `<button type="button" class="ghost-btn focus-timer__alt" id="focus-app-usage">
               Usar el tiempo en mi app de lectura, en vez del cronómetro
             </button>`
          : ""
      }
      <p class="field__hint" id="focus-hint">Dale a «Empezar» cuando te pongas con ello.</p>
    </div>`;

  const display = document.getElementById("focus-display");
  const progress = document.getElementById("focus-progress");
  const toggleBtn = document.getElementById("focus-toggle");
  const saveBtn = document.getElementById("focus-save");
  const hint = document.getElementById("focus-hint");
  const appUsageBtn = document.getElementById("focus-app-usage");

  let seconds = 0;
  let running = false;
  let timer = null;

  function tick() {
    seconds += 1;
    display.textContent = fmt(seconds);
    if (targetMinutes && progress) {
      progress.style.width = Math.min(100, Math.round((100 * seconds) / (targetMinutes * 60))) + "%";
    }
  }

  toggleBtn.addEventListener("click", () => {
    running = !running;
    if (running) {
      keepAwake(true);
      timer = setInterval(tick, 1000);
      toggleBtn.textContent = "Pausar";
      hint.textContent = "En marcha — puedes pausar si te interrumpen.";
      saveBtn.hidden = false;
      // Como el temporizador del reloj: si hay objetivo, el aviso salta
      // solo cuando toque, aunque salgas de la app o bloquees el móvil.
      if (targetMinutes) {
        const restantes = targetMinutes * 60 - seconds;
        notifications.scheduleTimerDone(taskUuid, task.title, restantes).catch(() => {});
      }
    } else {
      keepAwake(false);
      clearInterval(timer);
      toggleBtn.textContent = "Reanudar";
      hint.textContent = "En pausa. Reanuda cuando sigas, o guarda si has terminado.";
      // Si no se cancela, el aviso saltaría igual más tarde para una
      // sesión que ya se ha dejado a medias.
      notifications.cancelTimerDone(taskUuid).catch(() => {});
    }
  });

  saveBtn.addEventListener("click", async () => {
    clearInterval(timer);
    keepAwake(false);
    notifications.cancelTimerDone(taskUuid).catch(() => {});
    toggleBtn.disabled = true;
    saveBtn.disabled = true;
    saveBtn.textContent = "Guardando…";
    const minutes = Math.max(1, Math.round(seconds / 60));
    try {
      await saveSession(taskUuid, minutes, "manual");
      api.clearCache();
      location.hash = "#/";
    } catch (err) {
      saveBtn.disabled = false;
      toggleBtn.disabled = false;
      saveBtn.textContent = "Guardar sesión";
      hint.textContent = "No se pudo guardar — inténtalo otra vez.";
    }
  });

  // ---------------------------------------------- tiempo en la app

  if (appUsageBtn) {
    appUsageBtn.addEventListener("click", () => startAppUsage(taskUuid, targetMinutes));
  }
}

/**
 * Bracket + consulta: se marca el instante de inicio, el usuario sale a
 * leer a su app, y al volver se pregunta al plugin nativo cuánto tiempo
 * ha estado esa app en primer plano DENTRO de ese margen — no hace
 * falta ningún servicio corriendo en segundo plano, así que no debería
 * chocar con el ahorro de batería de HyperOS.
 */
async function startAppUsage(taskUuid, targetMinutes) {
  const plugin = usagePlugin();
  if (!plugin) {
    window.__toast?.(
      "Esto necesita el plugin nativo, que todavía no está compilado en esta app.",
      "error"
    );
    return;
  }

  let pkg = "";
  try {
    const pref = await plugin.getConfiguredPackage();
    pkg = pref?.package || "";
  } catch {
    /* sin preferencia guardada todavía */
  }
  if (!pkg) {
    window.__toast?.("Configura primero tu app de lectura en Ajustes.", "error");
    return;
  }

  let hasPermission = false;
  try {
    const res = await plugin.hasPermission();
    hasPermission = Boolean(res?.granted);
  } catch {
    hasPermission = false;
  }
  if (!hasPermission) {
    view.innerHTML = `
      ${topbar("enfoque", "Falta un permiso", "#/")}
      <p class="workout__note">
        Para contar el tiempo en tu app de lectura, Android pide activar
        "Acceso de uso" a mano — no se puede pedir con un aviso normal.
      </p>
      <div class="task-form__actions">
        <button type="button" class="primary-btn" id="open-usage-settings">Abrir ajustes de Android</button>
      </div>`;
    document.getElementById("open-usage-settings").addEventListener("click", async () => {
      try {
        await plugin.openUsageSettings();
      } catch {
        window.__toast?.("No se pudo abrir la pantalla de ajustes.", "error");
      }
    });
    return;
  }

  const startedAt = Date.now();
  view.innerHTML = `
    ${topbar("enfoque", "Lectura en marcha", "#/")}
    <div class="focus-timer">
      <p class="focus-timer__target">Ve a tu app de lectura. Cuando termines, vuelve aquí y pulsa «He terminado».</p>
      <div class="focus-timer__actions">
        <button type="button" class="primary-btn" id="finish-app-usage">He terminado</button>
      </div>
      <p class="field__hint">Contamos solo el tiempo real que esa app estuvo en pantalla, no lo que tardes en volver.</p>
    </div>`;

  document.getElementById("finish-app-usage").addEventListener("click", async (e) => {
    const btn = e.target;
    btn.disabled = true;
    btn.textContent = "Calculando…";
    try {
      const res = await plugin.getUsageMinutes({ packageName: pkg, sinceMillis: startedAt });
      const minutes = Math.max(1, Math.round(res?.minutes || 0));
      await saveSession(taskUuid, minutes, "app_usage", pkg);
      api.clearCache();
      window.__toast?.(`Sesión guardada: ${minutes} min en tu app de lectura.`);
      location.hash = "#/";
    } catch {
      btn.disabled = false;
      btn.textContent = "He terminado";
      window.__toast?.("No se pudo leer el tiempo de uso — inténtalo otra vez.", "error");
    }
  });
}

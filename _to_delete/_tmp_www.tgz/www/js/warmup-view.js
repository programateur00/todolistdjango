/**
 * Calentamiento y enfriamiento RECOMENDADOS (no obligatorios) de toda
 * sesión de Deporte (salvo running, que ya se valida solo con datos
 * reales — ver needsWarmup). Antes esto ofrecía un vídeo fijo de
 * YouTube; ahora, igual que en la web (ver _warmup_routine_for en
 * tasks/views.py), se ofrece el circuito (Routine con
 * is_warmup_bookend=True) que tengas montado para la subcategoría de la
 * tarea — mismos ejercicios de cámara + estiramientos cronometrados que
 * en la web, no un vídeo genérico. Sigue sin ser obligatorio: quizás ya
 * has calentado por tu cuenta, así que primero se pregunta, y solo si
 * hace falta se ofrece el circuito — se puede saltar en cualquier
 * momento. Mismo mecanismo en las dos puntas de la sesión.
 *
 * Equivalente al backend Django: WarmupStatus / _require_warmup /
 * task_warmup / task_cooldown en tasks/views.py, y los endpoints
 * /api/warmup/ y /api/tasks/<uuid>/warmup-routine/ en tasks/api.py. El
 * estado de "cuándo calentaste" es el mismo en la app y en la web
 * (mismo usuario, mismo WarmupStatus): decir "sí, ya he calentado" aquí
 * cuenta igual que en la web, así que no se vuelve a preguntar en las
 * próximas horas (WarmupStatus.FRESH_WINDOW). El circuito en sí
 * también es el mismo Routine que edites/actives en la web — no hay
 * uno "de la app" aparte.
 */

import { api } from "./api.js";

const view = document.getElementById("view");

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

function topbar(eyebrow, title) {
  return `
    <header class="topbar">
      <div class="topbar__title">
        <span class="topbar__eyebrow">${esc(eyebrow)}</span>
        <h1>${esc(title)}</h1>
      </div>
    </header>`;
}

/**
 * ¿Hace falta preguntar si has calentado antes de esta tarea? Running
 * queda fuera: ya se valida solo con datos reales (distancia/tiempo,
 * Health Connect...), no con un circuito. Se llama desde
 * workout-view.js (render/renderCamera/renderCircuit) y plan-view.js
 * (renderPlanSession) — los sitios por los que se puede empezar a
 * entrenar.
 */
export async function needsWarmup(task) {
  if (task.category !== "sport" || task.subcategory === "running") return false;
  const { data } = await api.warmupStatus();
  return !data.fresh;
}

/** Mantiene la pantalla encendida mientras se juega el circuito. Misma
 *  copia local que workout-view.js -- demasiado pequeño para que
 *  merezca la pena compartirlo con un import. */
async function keepAwake(on) {
  const KA = window.Capacitor?.Plugins?.KeepAwake;
  if (!KA) return;
  try {
    if (on) await KA.keepAwake();
    else await KA.allowSleep();
  } catch {
    /* si el plugin no está, seguimos igual */
  }
}

/**
 * Reproduce el circuito de calentamiento/estiramiento de principio a
 * fin, con lo que tenga cada ejercicio (cámara contando reps, o
 * cronómetro con cámara comprobando postura para los estiramientos) —
 * mismo motor que un circuito cualquiera (ver workout-view.js
 * renderCircuit), en el orden guardado (sin aleatorio: es una rutina
 * pensada de arriba a abajo del cuerpo, no un circuito suelto). Se
 * puede saltar en cualquier momento con "Saltar calentamiento".
 */
async function renderStretchCircuit({ taskUuid, eyebrow, title, routine, skipLabel, onDone }) {
  const items = routine.items;
  const hasCamera = items.some((i) => i.mode === "pose");
  // Clave para poder retomar este calentamiento/enfriamiento si hay que
  // salir a medias -- ver session-runner.js/saveDraft().
  const draftKey = `warmup:${taskUuid}:${eyebrow}`;
  let __mod;
  try {
    __mod = await import("./session-runner.js");
  } catch (impErr) {
    throw new Error(`No se pudo cargar ./session-runner.js: ${impErr.message}`);
  }
  const { SessionRunner, loadSessionDraft, clearSessionDraft } = __mod;
  const draft = loadSessionDraft(draftKey);

  view.innerHTML = `
    ${topbar(eyebrow, title)}
    <p class="exercise-picker__hint">${routine.name} · ${items.length} ejercicios</p>
    <ul class="run-preview">
      ${items
        .map(
          (i) => `<li><span>${esc(i.name)}</span><span>${
            i.mode === "pose" ? `${i.target_sets} × ${i.target_reps} reps` : `${i.work}s`
          }</span></li>`
        )
        .join("")}
    </ul>
    ${
      hasCamera
        ? `<p class="field__hint">Los ejercicios de cámara cuentan repeticiones; los cronometrados van a tiempo. Cada uno con lo suyo.</p>`
        : ""
    }
    <div class="task-form__actions">
      <button type="button" class="ghost-btn" id="stretch-skip">${esc(skipLabel)}</button>
      <button type="button" class="primary-btn" id="stretch-start">Empezar</button>
    </div>
    <div id="run-host"></div>`;

  document.getElementById("stretch-skip").addEventListener("click", async () => {
    document.getElementById("stretch-skip").disabled = true;
    await onDone();
  });

  // Calentamiento (no enfriamiento): a petición de Alex (2026-09-25), al
  // terminar el circuito se pasa directo a la sesión de deporte sin la
  // pantalla-resumen ni el botón "Guardar y volver" de SessionRunner --
  // aquí no hay nada que guardar de verdad (solo api.markWarmupDone(),
  // que ya hace el propio onDone). El enfriamiento sigue con la pantalla
  // de resumen normal (no se ha pedido tocarlo).
  const autoFinish = eyebrow === "calentamiento";

  const begin = (resume) => {
    document.getElementById("stretch-start").hidden = true;
    document.getElementById("stretch-skip").textContent = "Saltar y continuar";
    keepAwake(true);

    const runner = new SessionRunner(
      document.getElementById("run-host"),
      resume ? resume.items : [...items],
      async () => {
        // Circuito terminado de verdad -- la limpieza la hace este mismo
        // callback, no window.__currentViewCleanup (pensado para una
        // salida a medias).
        window.__currentViewCleanup = null;
        keepAwake(false);
        await onDone();
      },
      draftKey,
      autoFinish
    );
    // Si sales del calentamiento a medias (← Volver, atrás…), el router
    // llama a esto antes de pintar la siguiente pantalla -- para el
    // circuito, cámara, voz y cronómetros.
    window.__currentViewCleanup = () => {
      runner.destroy();
      keepAwake(false);
    };
    runner.start(resume ? { index: resume.index, breakdown: resume.breakdown, elapsedMs: resume.elapsedMs } : null);
  };

  document.getElementById("stretch-start").addEventListener("click", () => begin(null));

  // ¿Hay un calentamiento/enfriamiento sin terminar de una vez anterior?
  // Se ofrece continuar por donde se dejó -- mismo mecanismo que en
  // plan-view.js/workout-view.js (renderCircuit).
  if (draft) {
    if (confirm(`Tienes un ${eyebrow} sin terminar. ¿Quieres continuar donde lo dejaste?`)) {
      begin(draft);
    } else {
      clearSessionDraft(draftKey);
    }
  }
}

/**
 * Circuito de calentamiento/estiramiento para esta tarea, si el usuario
 * tiene uno montado para su subcategoría (ver
 * api.warmupRoutine/_warmup_routine_for). Si no tiene ninguno -- por
 * ejemplo, todavía no se ha creado ningún circuito marcado como
 * calentamiento en esa subcategoría -- se degrada a un simple aviso, ni
 * bloquea ni ofrece nada que no exista, igual que hacía antes un vídeo
 * que no llegaba a cargar.
 */
async function renderBookendCircuit(taskUuid, { eyebrow, skipLabel, onDone }) {
  view.innerHTML = `<p class="app-loading">Cargando…</p>`;
  const [{ data: t }, { data: r }] = await Promise.all([
    api.get(`/tasks/${taskUuid}/`),
    api.warmupRoutine(taskUuid),
  ]);
  const title = t.task.title;
  const routine = r.routine;

  if (!routine) {
    view.innerHTML = `
      ${topbar(eyebrow, title)}
      <p class="exercise-picker__hint">Todavía no tienes ningún circuito de calentamiento/estiramiento montado para esta subcategoría — puedes crear uno desde Circuitos en la web o la app y marcarlo como calentamiento.</p>
      <div class="task-form__actions">
        <button type="button" class="primary-btn" id="stretch-continue">Continuar</button>
      </div>`;
    document.getElementById("stretch-continue").addEventListener("click", async (e) => {
      e.target.disabled = true;
      await onDone();
    });
    return;
  }

  renderStretchCircuit({ taskUuid, eyebrow, title, routine, skipLabel, onDone });
}

export async function renderWarmup(taskUuid, next) {
  view.innerHTML = `<p class="app-loading">Cargando…</p>`;
  const { data } = await api.get(`/tasks/${taskUuid}/`);
  const title = data.task.title;

  view.innerHTML = `
    ${topbar("calentamiento", title)}
    <p class="exercise-picker__hint">¿Ya has calentado?</p>
    <div class="task-form__actions">
      <button type="button" class="ghost-btn" id="warmup-no">No, quiero calentar</button>
      <button type="button" class="primary-btn" id="warmup-yes">Sí, ya he calentado</button>
    </div>`;

  document.getElementById("warmup-yes").addEventListener("click", async (e) => {
    e.target.disabled = true;
    try {
      await api.markWarmupDone();
    } catch {
      // Si falla el POST no bloqueamos, se volvería a preguntar la
      // próxima vez, nada más.
    }
    location.hash = next || `#/entreno/${taskUuid}`;
  });
  document.getElementById("warmup-no").addEventListener("click", () => {
    renderBookendCircuit(taskUuid, {
      eyebrow: "calentamiento",
      skipLabel: "Saltar y empezar ya",
      onDone: async () => {
        try {
          await api.markWarmupDone();
        } catch {
          // Igual que arriba: si falla el POST no bloqueamos.
        }
        location.hash = next || `#/entreno/${taskUuid}`;
      },
    });
  });
}

function finishCooldown(taskUuid) {
  return (async () => {
    try {
      await api.markTask(taskUuid, "done");
      api.clearCache();
      window.__toast?.("Sesión terminada.");
    } catch (err) {
      window.__toast?.(
        err.queued ? "Sin conexión: se cerrará sola en cuanto vuelva." : err.message,
        err.queued ? "info" : "error"
      );
    }
    location.hash = "#/";
  })();
}

export async function renderCooldown(taskUuid) {
  view.innerHTML = `<p class="app-loading">Cargando…</p>`;
  const { data } = await api.get(`/tasks/${taskUuid}/`);
  const title = data.task.title;

  view.innerHTML = `
    ${topbar("enfriamiento", title)}
    <p class="exercise-picker__hint">Ya está todo guardado. ¿Quieres estirar antes de terminar?</p>
    <div class="task-form__actions">
      <button type="button" class="ghost-btn" id="cooldown-no">No, terminar ya</button>
      <button type="button" class="primary-btn" id="cooldown-yes">Sí, quiero estirar</button>
    </div>`;

  document.getElementById("cooldown-yes").addEventListener("click", () => {
    renderBookendCircuit(taskUuid, {
      eyebrow: "enfriamiento",
      skipLabel: "Saltar y terminar ya",
      onDone: () => finishCooldown(taskUuid),
    });
  });
  document.getElementById("cooldown-no").addEventListener("click", (e) => {
    e.target.disabled = true;
    finishCooldown(taskUuid);
  });
}

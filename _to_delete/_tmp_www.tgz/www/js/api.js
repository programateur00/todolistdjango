/**
 * Cliente de la API + capa de funcionamiento sin conexión.
 *
 * Tres responsabilidades:
 *  1. Hablar con Django (autenticación Basic incluida).
 *  2. Cachear la última respuesta buena de cada GET, para que la app
 *     enseñe algo cuando no hay cobertura en vez de una pantalla vacía.
 *  3. Encolar las escrituras que fallan por falta de red y reenviarlas
 *     luego, para que terminar una serie en un sótano no se pierda.
 *
 * La configuración (URL del servidor y credenciales) la mete el usuario
 * en la pantalla de ajustes; se guarda en localStorage.
 */

const CONFIG_KEY = "libreta.config";
const CACHE_PREFIX = "libreta.cache.";
const QUEUE_KEY = "libreta.queue";

export const api = {
  // ----------------------------------------------------------- config

  getConfig() {
    try {
      return JSON.parse(localStorage.getItem(CONFIG_KEY)) || {};
    } catch {
      return {};
    }
  },

  setConfig(cfg) {
    localStorage.setItem(CONFIG_KEY, JSON.stringify(cfg));
  },

  isConfigured() {
    const c = this.getConfig();
    return Boolean(c.baseUrl);
  },

  _headers() {
    const cfg = this.getConfig();
    const h = { "Content-Type": "application/json" };
    // BasicAuthMiddleware protege TODO el proyecto, así que si hay
    // usuario/contraseña configurados hay que mandarlos en cada llamada.
    // Se manda a mano en vez de dejar que el WebView enseñe la ventanita
    // emergente del navegador, que dentro de la app queda fatal.
    if (cfg.user && cfg.password) {
      h["Authorization"] = "Basic " + btoa(`${cfg.user}:${cfg.password}`);
    }
    return h;
  },

  _url(path) {
    const base = (this.getConfig().baseUrl || "").replace(/\/+$/, "");
    return `${base}/api${path}`;
  },

  // ------------------------------------------------------------ caché

  _cacheGet(path) {
    try {
      const raw = localStorage.getItem(CACHE_PREFIX + path);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },

  _cacheSet(path, data) {
    try {
      localStorage.setItem(CACHE_PREFIX + path, JSON.stringify(data));
    } catch {
      // Si no cabe (cuota llena), seguir sin cachear no es grave.
    }
  },

  clearCache() {
    Object.keys(localStorage)
      .filter((k) => k.startsWith(CACHE_PREFIX))
      .forEach((k) => localStorage.removeItem(k));
  },

  // -------------------------------------------------------- peticiones

  /**
   * GET con red primero y caché de reserva. Devuelve
   * { data, fromCache } para que la interfaz pueda avisar de que está
   * enseñando datos viejos en lugar de mentir.
   */
  async get(path) {
    try {
      const resp = await fetch(this._url(path), { headers: this._headers() });
      if (resp.status === 401) throw new AuthError();
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      this._cacheSet(path, data);
      return { data, fromCache: false };
    } catch (err) {
      if (err instanceof AuthError) throw err;
      const cached = this._cacheGet(path);
      if (cached) return { data: cached, fromCache: true };
      throw err;
    }
  },

  /**
   * Escritura. Si falla por falta de red, se guarda en la cola y se
   * reintenta más tarde — el usuario no pierde lo que acaba de hacer.
   * `queueable` en false para operaciones que no tienen sentido diferir.
   */
  async write(method, path, payload, { queueable = true } = {}) {
    try {
      const resp = await fetch(this._url(path), {
        method,
        headers: this._headers(),
        body: payload === undefined ? undefined : JSON.stringify(payload),
      });
      if (resp.status === 401) throw new AuthError();
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        // Un 400 es culpa de los datos, no de la red: reintentarlo daría
        // igual, así que no se encola.
        const e = new Error(data.error || `HTTP ${resp.status}`);
        e.permanent = true;
        throw e;
      }
      return data;
    } catch (err) {
      if (err instanceof AuthError || err.permanent) throw err;
      if (queueable) {
        this._enqueue({ method, path, payload, ts: Date.now() });
        const e = new Error("Sin conexión — guardado para enviar luego.");
        e.queued = true;
        throw e;
      }
      throw err;
    }
  },

  post(path, payload, opts) {
    return this.write("POST", path, payload, opts);
  },
  patch(path, payload, opts) {
    return this.write("PATCH", path, payload, opts);
  },
  del(path, opts) {
    return this.write("DELETE", path, undefined, opts);
  },

  // -------------------------------------------------------- cola offline

  _queue() {
    try {
      return JSON.parse(localStorage.getItem(QUEUE_KEY)) || [];
    } catch {
      return [];
    }
  },

  _saveQueue(q) {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(q));
  },

  _enqueue(item) {
    const q = this._queue();
    // Si ya hay en la cola una escritura al MISMO método+ruta y es de
    // un tipo "colapsable" (ver abajo), no se apila una segunda: se
    // sustituye por esta.
    //
    // Esto es lo que evita el bug de la racha que se come días de más:
    // sin conexión, cada toque del tick (o cada pulsación del botón de
    // la notificación) que fallaba por falta de red quedaba encolado
    // como una entrada NUEVA. Para una tarea normal (uuid fijo) daba
    // igual — el backend ya es idempotente por día — pero para las
    // antitareas, que se marcan por serie (ver api.markBySeries /
    // task_mark_by_series en el backend), cada envío de la cola resuelve
    // "la tarea pendiente ACTUAL de la serie" en el momento de enviarse.
    // Con 3 copias en la cola, la 1ª resolvía hoy, la 2ª ya encontraba
    // mañana (recién generada al resolver la 1ª) y la 3ª pasado mañana:
    // 3 toques por no ver confirmación sin red acababan marcando 3 días
    // reales y metiendo 3 de más en la racha. Quedándonos solo con el
    // envío más reciente por ruta, 3 toques del mismo tick siguen
    // resolviendo UN solo día, tantas veces como se repita.
    //
    // OJO: esto NO vale para cualquier método+ruta. Un POST a
    // "/tasks/create/", "/plans/create/", "/routines/", "/videos/" o
    // "/plans/<uuid>/items/" es una colección compartida — cada llamada
    // crea un recurso NUEVO con esa misma ruta, así que colapsarlas
    // borraría tareas/rutinas/vídeos distintos creados sin conexión.
    // Lo que sí se puede colapsar sin perder nada:
    //  - PATCH y DELETE: van siempre contra un recurso YA existente,
    //    identificado por su uuid en la propia ruta (ej. "/tasks/<uuid>/"),
    //    así que repetir el mismo método+ruta es, por definición, la
    //    misma edición o el mismo borrado.
    //  - POST a un endpoint de "mark" (".../mark/<acción>/"): son los
    //    de marcar hecha/fallada/reabierta, por tarea o por serie. Es
    //    justo el caso de la racha que se comía días de más (ver más
    //    abajo).
    const collapsible =
      item.method === "PATCH" ||
      item.method === "DELETE" ||
      (item.method === "POST" && item.path.includes("/mark/"));

    const idx = collapsible
      ? q.findIndex((it) => it.method === item.method && it.path === item.path)
      : -1;

    if (idx !== -1) {
      if (item.method === "PATCH") {
        // Una edición parcial no debe borrar la anterior si tocaba otros
        // campos: se combinan, con el cambio más reciente ganando campo
        // a campo.
        item.payload = Object.assign({}, q[idx].payload, item.payload);
      }
      q[idx] = item;
    } else {
      q.push(item);
    }
    this._saveQueue(q);
  },

  queueLength() {
    return this._queue().length;
  },

  /**
   * Reenvía lo pendiente. Se llama al arrancar y al recuperar conexión.
   * Para en el primer fallo de red para no perder el orden: si la serie 2
   * se enviara antes que la 1, el historial quedaría desordenado.
   */
  async flushQueue() {
    let q = this._queue();
    let sent = 0;
    while (q.length) {
      const item = q[0];
      try {
        const resp = await fetch(this._url(item.path), {
          method: item.method,
          headers: this._headers(),
          body: item.payload === undefined ? undefined : JSON.stringify(item.payload),
        });
        if (!resp.ok && resp.status >= 500) break; // servidor caído: reintentar luego
        // Un 4xx significa que ese envío nunca va a funcionar (datos
        // inválidos, tarea borrada...): se descarta para no bloquear la
        // cola con algo que jamás pasará.
        q.shift();
        sent += 1;
        this._saveQueue(q);
      } catch {
        break; // sin red
      }
    }
    return sent;
  },

  // ------------------------------------------------------- endpoints

  meta: () => api.get("/meta/"),
  // Calentamiento obligatorio (ver WarmupStatus / _require_warmup en
  // el backend): fresh dice si hace falta calentar todavía, compartido
  // con la web (mismo usuario, mismo estado).
  warmupStatus: () => api.get("/warmup/"),
  markWarmupDone: () => api.post("/warmup/", {}),
  // Circuito de calentamiento/estiramiento (Routine is_warmup_bookend) para
  // la tarea -- sustituye al vídeo fijo (ver warmup-view.js). null si el
  // usuario no tiene ninguno montado para la subcategoría de esa tarea.
  warmupRoutine: (taskUuid) => api.get(`/tasks/${taskUuid}/warmup-routine/`),
  tasks: (category) => api.get(`/tasks/${category ? `?category=${category}` : ""}`),
  createTask: (data) => api.post("/tasks/create/", data),
  updateTask: (uuid, data) => api.patch(`/tasks/${uuid}/`, data),
  deleteTask: (uuid) => api.del(`/tasks/${uuid}/`),
  markTask: (uuid, action) => api.post(`/tasks/${uuid}/mark/${action}/`),
  // Para las notificaciones: la serie no cambia cada día, la tarea sí.
  markBySeries: (seriesId, action) => api.post(`/series/${seriesId}/mark/${action}/`),
  exercises: (bodyArea) => api.get(`/exercises/${bodyArea ? `?body_area=${bodyArea}` : ""}`),
  exerciseTarget: (slug) => api.get(`/exercises/${slug}/target/`),
  routines: (sub) => api.get(`/routines/${sub ? `?subcategory=${sub}` : ""}`),
  createRoutine: (data) => api.post("/routines/", data),
  deleteRoutine: (uuid) => api.del(`/routines/${uuid}/`),
  saveWorkout: (uuid, data) => api.post(`/tasks/${uuid}/workout/`, data),
  saveWorkoutManual: (uuid, data) => api.post(`/tasks/${uuid}/workout-manual/`, data),
  importRunning: (uuid, data) => api.post(`/tasks/${uuid}/running-import/`, data),
  saveCircuit: (uuid, routineUuid, data) => api.post(`/tasks/${uuid}/circuit/${routineUuid}/`, data),
  saveFocus: (uuid, data) => api.post(`/tasks/${uuid}/focus/`, data),
  // minutes es opcional -- si se manda, el backend lo guarda en
  // Occurrence.minutes_watched (mismo dato que ya registra la web desde
  // su reproductor). Sin esto, un vídeo completado desde el móvil se
  // marcaba hecho igual, solo que sin ese dato informativo.
  saveVideo: (uuid, minutes) => api.post(`/tasks/${uuid}/video/`, minutes != null ? { minutes } : undefined),
  savedVideos: (scope) => api.get(`/videos/${scope ? `?scope=${scope}` : ""}`),
  createSavedVideo: (data) => api.post("/videos/", data),
  deleteSavedVideo: (uuid) => api.del(`/videos/${uuid}/`),
  stats: () => api.get("/stats/"),
  statsDetail: (seriesId) => api.get(`/stats/${seriesId}/`),
  deleteStats: () => api.del("/stats/delete/"),
  deleteStatsDetail: (seriesId) => api.del(`/stats/${seriesId}/delete/`),
  weeklyReview: () => api.get("/review/weekly/"),
  plans: () => api.get("/plans/"),
  plan: (uuid) => api.get(`/plans/${uuid}/`),
  createPlan: (data) => api.post("/plans/create/", data),
  // No es "queueable": si no hay red ahora mismo, no tiene sentido
  // encolarlo para más tarde — el usuario está esperando delante de la
  // pantalla a que la IA responda, no puede quedar "pendiente de enviar".
  generatePlan: (data) => api.post("/plans/generate/", data, { queueable: false }),
  // Estudio · Idiomas: borrador y confirmación, igual de "no queueable"
  // que generatePlan -- el usuario está delante esperando la respuesta
  // (asignación del catálogo / expansión de vídeos), no tiene sentido
  // dejarlo "pendiente de enviar" sin red.
  planLanguageOptions: () => api.get("/plans/language-options/"),
  planLanguageDraft: (data) => api.post("/plans/language-draft/", data, { queueable: false }),
  planLanguageSave: (data) => api.post("/plans/language-save/", data, { queueable: false }),
  updatePlan: (uuid, data) => api.patch(`/plans/${uuid}/`, data),
  deletePlan: (uuid) => api.del(`/plans/${uuid}/`),
  closePlan: (uuid) => api.post(`/plans/${uuid}/close/`),
  createPlanItem: (planUuid, data) => api.post(`/plans/${planUuid}/items/`, data),
  updatePlanItem: (planUuid, itemId, data) => api.patch(`/plans/${planUuid}/items/${itemId}/`, data),
  deletePlanItem: (planUuid, itemId) => api.del(`/plans/${planUuid}/items/${itemId}/`),
  planSession: (taskUuid, planUuid) => api.get(`/tasks/${taskUuid}/plan/${planUuid}/`),
  savePlanSession: (taskUuid, planUuid, data) =>
    api.post(`/tasks/${taskUuid}/plan/${planUuid}/save/`, data),

  /** Comprueba que la URL y las credenciales son correctas. */
  async testConnection() {
    const resp = await fetch(this._url("/meta/"), { headers: this._headers() });
    if (resp.status === 401) throw new AuthError();
    if (!resp.ok) throw new Error(`El servidor respondió ${resp.status}`);
    await resp.json();
    return true;
  },
};

export class AuthError extends Error {
  constructor() {
    super("Usuario o contraseña incorrectos.");
    this.name = "AuthError";
  }
}

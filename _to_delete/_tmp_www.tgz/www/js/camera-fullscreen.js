/**
 * Pantalla completa para TODAS las cámaras de entreno (.workout__camera):
 * ejercicio suelto, circuitos/planes y retos. Un botón para entrar y otro
 * para salir; en pantalla completa solo se ve la cámara (sin datos, sin
 * botones, sin barra de pestañas) y cubre toda la pantalla tanto en
 * vertical como en horizontal.
 *
 * Se engancha solo: un MutationObserver sobre #view añade los botones a
 * cualquier .workout__camera que aparezca, así no hay que tocar cada vista.
 * Si la cámara desaparece (cambio de pantalla, re-render) se sale sola.
 *
 * En la app nativa además oculta la barra de estado y la de navegación de
 * Android (plugin NativeImmersive, ImmersivePlugin.java). Si el plugin no
 * está (navegador), basta el overlay CSS.
 */

const CLS_FULL = "workout__camera--full";
const CLS_BODY = "cam-fullscreen";

const ICON_ENTER =
  '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>';
const ICON_EXIT =
  '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';

function immersive(on) {
  try {
    const p = window.Capacitor?.Plugins?.NativeImmersive;
    if (!p) return;
    (on ? p.enter() : p.exit())?.catch?.(() => {});
  } catch (_) { /* extra visual, nunca debe romper el entreno */ }
}

function isFull() {
  return document.body.classList.contains(CLS_BODY);
}

function setFull(cam, on) {
  cam.classList.toggle(CLS_FULL, on);
  document.body.classList.toggle(CLS_BODY, on);
  immersive(on);
}

function exitFull() {
  const cam = document.querySelector("." + CLS_FULL);
  if (cam) cam.classList.remove(CLS_FULL);
  const was = isFull();
  document.body.classList.remove(CLS_BODY);
  if (was) immersive(false);
  return was;
}

// El botón físico "atrás" de Android (app.js) llama a esto primero:
// si estaba en pantalla completa, sale de ella y no navega.
window.__exitCameraFullscreen = exitFull;

function decorate() {
  document.querySelectorAll(".workout__camera:not([data-fs])").forEach((cam) => {
    cam.dataset.fs = "1";
    cam.insertAdjacentHTML(
      "beforeend",
      `<button type="button" class="cam-fs-btn cam-fs-btn--enter" aria-label="Pantalla completa" title="Pantalla completa">${ICON_ENTER}</button>` +
      `<button type="button" class="cam-fs-btn cam-fs-btn--exit" aria-label="Salir de pantalla completa" title="Salir de pantalla completa">${ICON_EXIT}<span>Salir</span></button>`
    );
    cam.querySelector(".cam-fs-btn--enter").addEventListener("click", () => setFull(cam, true));
    cam.querySelector(".cam-fs-btn--exit").addEventListener("click", () => exitFull());
  });
  // La cámara que estaba en pantalla completa ha desaparecido. Puede ser
  // un cambio automático de ejercicio (session-runner.js reconstruye el
  // circuito de calentamiento/entreno y crea un .workout__camera nuevo)
  // o un cambio real de vista (sin cámara). En el primer caso se
  // mantiene la pantalla completa en la cámara nueva; en el segundo se
  // sale, para no dejar la app sin barras ni scroll.
  if (isFull() && !document.querySelector("." + CLS_FULL)) {
    const cam = document.querySelector(".workout__camera");
    if (cam) cam.classList.add(CLS_FULL);
    else exitFull();
  }
}

let scheduled = false;
function schedule() {
  if (scheduled) return;
  scheduled = true;
  requestAnimationFrame(() => { scheduled = false; decorate(); });
}

const target = document.getElementById("view");
if (target) {
  new MutationObserver(schedule).observe(target, { childList: true, subtree: true });
  decorate();
}

// Al girar el móvil algunos Android devuelven las barras: se vuelven a ocultar.
window.addEventListener("resize", () => { if (isFull()) immersive(true); });

/**
 * Sincronización con Health Connect (Android).
 *
 * Lee las carreras y caminatas que hayan registrado OTRAS apps —
 * Samsung Health, Garmin, Fitbit, Strava, Mi Fitness, Polar…— y se las
 * manda al servidor, que decide si cumplen el objetivo de la tarea y la
 * marca como hecha. La decisión vive en el servidor a propósito: así la
 * regla está en un solo sitio y cambiarla no obliga a actualizar la app.
 *
 * Health Connect es el almacén de salud del propio Android (el
 * equivalente a Apple Health), no algo de Samsung: leyendo de aquí se
 * cubren todas esas apps de golpe, en vez de integrarse con cada una. Y
 * funciona igual en cinta que al aire libre, porque quien registra la
 * sesión es el reloj o el móvil, no la cinta.
 *
 * Requiere el plugin @capgo/capacitor-health (ver README del proyecto).
 * Si no está instalado, todo esto se queda quieto sin romper nada: la
 * app sigue funcionando con la entrada manual de siempre.
 */
import { api } from "./api.js";

/**
 * Tipos de sesión de Health Connect que cuentan como "running" en
 * Strive. Es una sola subcategoría a propósito: si es carrera o paseo
 * lo decide el ritmo que se cumplió, no el tipo de sesión — así que se
 * piden todos juntos, sin distinguir de antemano.
 */
const DISTANCE_TYPES = ["running", "runningTreadmill", "walking", "hiking"];

/** Cuándo fue la última sincronización, para no releer lo mismo. */
const LAST_SYNC_KEY = "healthLastSync";

function plugin() {
  return window.Capacitor?.Plugins?.Health || null;
}

export function isSupported() {
  return Boolean(plugin());
}

/**
 * ¿Está Health Connect disponible en este móvil? En Android 14+ viene
 * de serie; en versiones anteriores hay que instalarlo de Play Store.
 */
export async function checkAvailability() {
  const p = plugin();
  if (!p) return { available: false, reason: "Plugin no instalado en esta build." };
  try {
    return await p.isAvailable();
  } catch (err) {
    return { available: false, reason: err?.message || String(err) };
  }
}

/**
 * Pide permiso de LECTURA solamente — Strive no escribe nada en Health
 * Connect, y pedir permisos que no se usan es mala práctica (y hace que
 * la gente desconfíe al ver la lista).
 */
export async function requestPermissions() {
  const p = plugin();
  if (!p) throw new Error("Health Connect no está disponible en esta build.");
  return p.requestAuthorization({
    read: ["workouts", "steps", "distance"],
    write: [],
  });
}

export async function openSettings() {
  await plugin()?.openHealthConnectSettings?.();
}

/**
 * Diagnóstico de verdad: qué ve Strive en Health Connect ahora mismo,
 * sin filtrar por tipo ni por fecha de la última sincronización — para
 * saber si el problema es "no hay permiso", "no hay nada que leer" o
 * "hay datos pero no los que esperábamos", en vez de adivinar a
 * ciegas. Se enseña en un cuadro de diálogo desde Ajustes.
 */
export async function diagnose() {
  const p = plugin();
  if (!p) return { error: "El plugin de salud no está en esta build (¿npx cap sync?)." };

  const out = { pasos: [], errores: [] };

  try {
    out.disponibilidad = await p.isAvailable();
  } catch (e) {
    out.errores.push("isAvailable: " + (e?.message || e));
  }

  // Sin filtrar tipo ni ceñirse a la última sincronización — los
  // últimos 14 días completos, para no dejar fuera nada reciente.
  const startDate = new Date(Date.now() - 14 * 86400000).toISOString();
  const endDate = new Date().toISOString();

  try {
    const res = await p.queryWorkouts({ startDate, endDate, limit: 50 });
    out.workoutsSinFiltrar = [];
    for (const w of res?.workouts || []) {
      const distanciaRecuperada = await distanceForWorkout(p, w);
      out.workoutsSinFiltrar.push({
        tipo: w.workoutType,
        inicio: w.startDate,
        fin: w.endDate,
        duracion_s: w.duration,
        distancia_directa_m: w.totalDistance ?? null,
        distancia_recuperada_m: distanciaRecuperada,
        origen: w.sourceName,
        id: w.platformId,
      });
    }
  } catch (e) {
    out.errores.push("queryWorkouts sin filtro: " + (e?.message || e));
  }

  try {
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    const agg = await p.queryAggregated({
      dataType: "steps", startDate: hoy.toISOString(), endDate, bucket: "day", aggregation: "sum",
    });
    out.pasosHoy = (agg?.samples || []).reduce((s, x) => s + (x.value || 0), 0);
  } catch (e) {
    out.errores.push("queryAggregated steps: " + (e?.message || e));
  }

  out.ultimaSincronizacion = localStorage.getItem(LAST_SYNC_KEY) || "(nunca)";
  return out;
}

/**
 * Convierte una sesión de Health Connect al formato que espera el
 * servidor. `platformId` es el identificador único de esa sesión: es lo
 * que evita importar la misma carrera dos veces.
 */
function toRun(workout, distanceMeters) {
  return {
    external_id: workout.platformId || "",
    // Cuándo ocurrió de verdad: el servidor lo usa para saber a qué DÍA
    // pertenece (si no, una caminata de hace 3 días contaría como de hoy).
    started_at: workout.startDate || null,
    distance_km: distanceMeters ? distanceMeters / 1000 : null,
    duration_seconds: workout.duration || null,
    exercise: "running",
  };
}

/**
 * La distancia de una sesión, sumando lo que haga falta.
 *
 * queryWorkouts() no siempre trae totalDistance relleno — Health
 * Connect guarda la sesión (ExerciseSessionRecord) y la distancia
 * (DistanceRecord) como dos registros INDEPENDIENTES, solo
 * relacionados por coincidir en el tiempo, y este plugin no los une
 * solo (confirmado con datos reales: el Detector de Actividad escribe
 * ambos, pero la sesión llega "sin distancia"). Así que si no viene ya
 * puesta, se pide aparte, acotada exactamente al inicio y fin de esa
 * sesión — puede venir partida en más de un bloque si la sesión cruza
 * una hora en punto, por eso se suman todos los que haya.
 */
// Cache de UNA sincronización (se vacía al empezar syncRuns): con la
// ventana de varios días, la misma sesión se consultaría dos veces
// (al importar y al restar del resumen del día).
const distCache = new Map();

async function distanceForWorkout(p, workout) {
  if (workout.totalDistance) return workout.totalDistance;
  const key = workout.platformId || `${workout.startDate}|${workout.endDate}`;
  if (distCache.has(key)) return distCache.get(key);
  try {
    const agg = await p.queryAggregated({
      dataType: "distance",
      startDate: workout.startDate,
      endDate: workout.endDate,
      bucket: "hour",
      aggregation: "sum",
    });
    const total = (agg?.samples || []).reduce((sum, s) => sum + (s.value || 0), 0);
    distCache.set(key, total);
    return total;
  } catch (err) {
    console.error("queryAggregated distance", err);
    return 0;
  }
}

/**
 * Lee las sesiones desde la última sincronización y las manda al
 * servidor para la tarea indicada.
 *
 * Se piden carreras Y paseos a la vez, sin distinguir: es la propia
 * tarea (con su objetivo de ritmo) la que decide si lo que se importó
 * cuenta como cumplido, no el tipo de sesión.
 *
 * @param {string} taskUuid  La tarea de running a la que atribuirlas.
 * @param {number} daysBack  Cuántos días mirar atrás la primera vez.
 */
/**
 * Sesiones a pie (o cualquier cosa con distancia que NO sea claramente
 * otro deporte) entre dos fechas. Antes se pedía tipo por tipo
 * (running, walking…): si el reloj o la app guardaba la sesión con otro
 * tipo ("other", "trackAndField", "mixedCardio"…) no se leía nada. Ahora
 * se piden TODAS y solo se descartan las que claramente no son andar o
 * correr — la tarea decide después, por ritmo y distancia.
 */
const NO_A_PIE = /cycl|biking|swim|rowing|paddl|sail|surf|ski|skat|wheelchair|handCycling/i;

async function queryFootWorkouts(p, startDate, endDate, errores) {
  try {
    const res = await p.queryWorkouts({ startDate, endDate, limit: 100 });
    return (res?.workouts || []).filter((w) => !NO_A_PIE.test(w.workoutType || ""));
  } catch (err) {
    console.error("queryWorkouts", err);
    errores?.push("queryWorkouts: " + (err?.message || err));
    return [];
  }
}

/**
 * Sesiones a pie de los últimos `days` días (hoy incluido), pidiendo cada
 * día por separado.
 *
 * Antes se leía "desde la última sincronización". Eso pierde para siempre
 * cualquier sesión que el Detector de Actividad pueda escribir DESPUÉS de esa
 * marca pero con hora de fin anterior (lo escribe tarde, al detectar que
 * terminaste de andar): la siguiente lectura ya empieza más tarde y no la
 * ve nunca. Releer una ventana fija es inocuo: el servidor reconoce cada
 * sesión por su external_id y se salta las que ya tiene sin cambios.
 * Por día, y no de golpe, para no tropezar con el límite de resultados
 * de una sola consulta (el Detector genera decenas de sesiones al día).
 */
const WINDOW_DAYS = 3;

async function queryFootWorkoutsWindow(p, days, errores) {
  const out = [];
  const seen = new Set();
  for (let i = 0; i < days; i++) {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - i);
    const end = i === 0 ? new Date() : new Date(start.getTime() + 86400000);
    for (const w of await queryFootWorkouts(p, start.toISOString(), end.toISOString(), errores)) {
      // Una sesión que cruza la medianoche sale en dos días: una sola vez.
      const key = w.platformId || `${w.startDate}|${w.endDate}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(w);
    }
  }
  return out;
}

let permisoPedido = false;

/**
 * Comprueba (sin molestar) que hay permiso de lectura y, si falta, lo
 * pide UNA vez por arranque de la app. Antes solo se pedía con el botón
 * de Ajustes: si nunca se pulsó o se revocó, la lectura fallaba en
 * silencio y no se importaba nada.
 */
async function ensureReadPermission(p) {
  const opts = { read: ["workouts", "steps", "distance"], write: [] };
  try {
    const st = await p.checkAuthorization(opts);
    if (!(st?.readDenied || []).length) return true;
  } catch (err) {
    console.error("checkAuthorization", err);
  }
  if (permisoPedido) return false;
  permisoPedido = true;
  try {
    const st = await p.requestAuthorization(opts);
    return !(st?.readDenied || []).length;
  } catch (err) {
    console.error("requestAuthorization", err);
    return false;
  }
}

export async function syncRuns(taskUuid, daysBack = 7) {
  const p = plugin();
  if (!p) return { ok: false, reason: "no-plugin" };
  if (!(await ensureReadPermission(p))) return { ok: false, reason: "sin-permiso" };
  const errores = [];

  distCache.clear();
  const endDate = new Date().toISOString();

  // Ventana fija, no "desde la última sincronización" (ver
  // queryFootWorkoutsWindow). `daysBack` ya no se usa.
  const workouts = await queryFootWorkoutsWindow(p, WINDOW_DAYS, errores);

  const runs = [];
  for (const w of workouts) {
    const distanceMeters = await distanceForWorkout(p, w);
    const run = toRun(w, distanceMeters);
    if (run.distance_km || run.duration_seconds) runs.push(run);
  }

  // Además de las sesiones "de ejercicio" completas, se manda un resumen
  // del día entero (pasos y distancia) como red de seguridad — no solo
  // cuando no se detectó ninguna sesión con distancia, como antes. El
  // Detector de Actividad no siempre sube una caminata como sesión
  // completa (ExerciseSessionRecord) — una caminata corta a veces se
  // queda solo en pasos/distancia sueltos, sin sesión asociada — así que
  // si ese día ya había otra caminata que sí generó sesión, esta se
  // perdía entera: `runs.length` ya no era 0 y nunca se miraba el resto
  // del día. Para no contar dos veces lo que ya viene por sesión, se
  // vuelven a mirar TODAS las sesiones de HOY (no solo las de desde la
  // última sincronización) y se resta su distancia de la del día entero
  // — lo que sobra es justo la actividad que no tiene sesión propia.
  try {
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    const hoyISO = hoy.toISOString();

    let sesionesHoyDistanciaMetros = 0;
    for (const w of await queryFootWorkouts(p, hoyISO, endDate, errores)) {
      sesionesHoyDistanciaMetros += (await distanceForWorkout(p, w)) || 0;
    }

    const [aggPasos, aggDistancia] = await Promise.all([
      p.queryAggregated({ dataType: "steps", startDate: hoyISO, endDate, bucket: "day", aggregation: "sum" }),
      p.queryAggregated({ dataType: "distance", startDate: hoyISO, endDate, bucket: "day", aggregation: "sum" }),
    ]);
    const totalPasos = (aggPasos?.samples || []).reduce((sum, s) => sum + (s.value || 0), 0);
    const totalDistanciaMetros = (aggDistancia?.samples || []).reduce((sum, s) => sum + (s.value || 0), 0);
    const distanciaSueltaMetros = Math.max(0, totalDistanciaMetros - sesionesHoyDistanciaMetros);

    if (totalPasos > 0 || distanciaSueltaMetros > 0) {
      runs.push({
        // Un id por día: reimportar el mismo día actualiza (el servidor
        // sobrescribe el registro existente en vez de saltárselo).
        external_id: `steps-${hoyISO.slice(0, 10)}`,
        steps: Math.round(totalPasos),
        distance_km: distanciaSueltaMetros > 0 ? Math.round((distanciaSueltaMetros / 1000) * 100) / 100 : null,
        exercise: "running",
      });
    }
  } catch (err) {
    console.error("queryAggregated dia", err);
    errores.push("queryAggregated dia: " + (err?.message || err));
  }

  if (!runs.length) return { ok: true, imported: 0, reason: errores.length ? "error-lectura" : "sin-actividad", errores };

  const { data } = await api.importRunning(taskUuid, {
    source: "health_connect",
    runs,
  });
  // Solo se avanza la marca de tiempo si el envío fue bien: si falla,
  // la próxima vez se vuelve a intentar el mismo periodo en vez de
  // saltárselo y perder esas carreras para siempre.
  localStorage.setItem(LAST_SYNC_KEY, endDate);
  return { ok: true, ...data };
}

/** Olvida la marca de sincronización, para forzar una lectura completa. */
export function resetSyncPoint() {
  localStorage.removeItem(LAST_SYNC_KEY);
}

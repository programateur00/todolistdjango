/**
 * Pantalla de vídeo: tareas que llevan un YouTube embebido en vez de
 * pasar por el selector de ejercicios o el temporizador.
 *
 * Además del embed, Deporte/Enfoque pueden usar un vídeo del propio
 * móvil (plugin nativo LocalVideoPlugin) — se elige una vez con el
 * selector de Android y se queda guardado para las próximas veces, sin
 * volver a preguntar. Es un añadido, no un sustituto: si no hay vídeo
 * local, se ve el de YouTube exactamente igual que siempre.
 *
 * Formas de darla por hecha, según lo que traiga la tarea:
 *   - Sin objetivo -> verlo entero (evento ENDED, en cualquiera de los dos).
 *   - target_minutes -> acumular ese tiempo viendo de verdad (cuenta
 *     solo mientras se reproduce), aunque el vídeo siga.
 *   - target_video_count (con playlist de YouTube) -> ver esa cantidad
 *     de vídeos de la lista.
 */
import { api } from "./api.js";

const view = document.getElementById("view");

// Igual que en app.js/plan-view.js/session-runner.js/workout-view.js:
// el título de la tarea es texto que en teoría no debería tener HTML,
// pero se escapa igual antes de meterlo en innerHTML — por si acaso,
// no porque hoy exista una vía conocida para colar algo ahí.
const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

function topbar(eyebrow, title, backHref) {
  return `
    <header class="topbar">
      <div class="topbar__title">
        <span class="topbar__eyebrow">${esc(eyebrow)}</span>
        <h1>${esc(title)}</h1>
      </div>
      ${backHref ? `<a href="${backHref}" class="stats-link">← Volver</a>` : ""}
    </header>`;
}

/** Carga la IFrame Player API de YouTube una sola vez por sesión de la app. */
let ytApiPromise = null;
function loadYouTubeApi() {
  if (window.YT && window.YT.Player) return Promise.resolve(window.YT);
  if (ytApiPromise) return ytApiPromise;
  ytApiPromise = new Promise((resolve, reject) => {
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      prev?.();
      resolve(window.YT);
    };
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    tag.onerror = () => reject(new Error("No se pudo cargar la API de YouTube"));
    document.head.appendChild(tag);
    setTimeout(() => reject(new Error("Tardó demasiado en cargar YouTube")), 10000);
  });
  return ytApiPromise;
}

const fmtMin = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

export async function render(taskUuid, overrideVideoId) {
  view.innerHTML = `<p class="app-loading">Cargando…</p>`;
  const { data } = await api.get(`/tasks/${taskUuid}/`);
  const task = data.task;

  // Un vídeo elegido al vuelo (desde el selector de tren superior/
  // inferior/estudio) siempre es suelto y sin objetivo — el objetivo,
  // la playlist y el vídeo local solo aplican al vídeo fijado en la
  // propia tarea.
  const videoId = overrideVideoId || task.youtube_video_id;
  const playlistId = overrideVideoId ? "" : task.youtube_playlist_id || "";
  const targetMinutes = overrideVideoId ? null : task.target_minutes || null;
  const targetVideoCount =
    (overrideVideoId ? null : task.target_video_count) ||
    (playlistId && !targetMinutes ? 1 : null);
  // Solo con un objetivo de Estudio con seguimiento de progreso (ver
  // Plan._study_playlist_progress en el backend) -- en qué posición de
  // la playlist hay que empezar hoy, para no volver siempre al vídeo 1.
  const playlistStartIndex = overrideVideoId ? null : (task.playlist_start_index ?? null);
  // Igual que en la web: solo Deporte/Enfoque, y solo si el vídeo está
  // fijado en la tarea (no en uno elegido al vuelo).
  const allowLocal = !overrideVideoId && (task.category === "work" || task.category === "sport");
  // Tarea "solo vídeo local" (se eligió así al crearla, sin YouTube de
  // respaldo) — no hay a qué volver si el archivo no aparece.
  const localOnly = !overrideVideoId && task.has_local_video;
  const localPlugin = window.Capacitor?.Plugins?.LocalVideo || null;

  view.innerHTML = `
    ${topbar("vídeo", task.title, "#/")}
    <div class="video-embed">
      <div id="video-player" class="video-embed__player"></div>
      <video id="local-video-player" class="video-embed__player" playsinline controls hidden></video>
      ${targetMinutes || targetVideoCount ? `<div class="stats-bar"><div class="stats-bar__done" id="video-progress" style="width:0%"></div></div>` : ""}
      <p class="field__hint" id="video-hint">Cargando…</p>
      ${allowLocal && localPlugin ? `<p class="field__hint" id="local-video-actions"></p>` : ""}
    </div>`;

  const hint = document.getElementById("video-hint");
  const progressBar = document.getElementById("video-progress");
  const ytContainer = document.getElementById("video-player");
  const localVideoEl = document.getElementById("local-video-player");
  const localActions = document.getElementById("local-video-actions");

  let saved = false;
  let elapsedSeconds = 0;
  let videosWatched = 0;
  let pollId = null;
  let player = null;
  let usingLocal = false;

  function updateProgressLabel() {
    if (targetVideoCount) {
      hint.textContent = `${videosWatched} de ${targetVideoCount} vídeos vistos.`;
      if (progressBar) progressBar.style.width = `${Math.min(100, Math.round((100 * videosWatched) / targetVideoCount))}%`;
    } else if (targetMinutes) {
      hint.textContent = `${fmtMin(elapsedSeconds)} de ${targetMinutes} min.`;
      if (progressBar) progressBar.style.width = `${Math.min(100, Math.round((100 * elapsedSeconds) / (targetMinutes * 60)))}%`;
    }
  }

  async function saveDone() {
    if (saved) return;
    saved = true;
    clearInterval(pollId);
    hint.textContent = "Guardando…";
    try {
      await api.saveVideo(taskUuid, elapsedSeconds ? Math.round(elapsedSeconds / 60) : null);
      api.clearCache();
      // Un vídeo de Deporte no se da por completado aquí: falta el
      // enfriamiento obligatorio (ver warmup-view.js) — el backend
      // (api.video_save) tampoco la marca hecha en ese caso.
      if (task.category === "sport") {
        location.hash = `#/enfriamiento/${taskUuid}`;
        return;
      }
      window.__toast?.("Vídeo visto — tarea completada.");
      location.hash = "#/";
    } catch (err) {
      saved = false;
      hint.textContent = "No se pudo guardar — inténtalo otra vez.";
      window.__toast?.(err.message, "error");
    }
  }

  /** Si la playlist se acaba antes de llegar al objetivo, no hay más
   *  que dar — cuenta como hecho igual. */
  function isLastInPlaylist() {
    if (!playlistId || !player || typeof player.getPlaylist !== "function") return true;
    const list = player.getPlaylist() || [];
    const idx = player.getPlaylistIndex();
    return !list.length || idx < 0 || idx + 1 >= list.length;
  }

  async function startYouTube() {
    if (!videoId && !playlistId) {
      hint.textContent = "Esta tarea no tiene vídeo asignado.";
      return;
    }
    let YT;
    try {
      YT = await loadYouTubeApi();
    } catch {
      hint.textContent = "Sin conexión con YouTube — inténtalo con internet.";
      return;
    }

    updateProgressLabel();
    if (!targetMinutes && !targetVideoCount) {
      hint.textContent = "Al terminar el vídeo, la tarea se marca hecha sola.";
    }

    const playerVars = { autoplay: 1, playsinline: 1, rel: 0, modestbranding: 1 };
    const config = { playerVars };
    if (playlistId) {
      playerVars.listType = "playlist";
      playerVars.list = playlistId;
      if (playlistStartIndex !== null) playerVars.index = playlistStartIndex;
    } else {
      config.videoId = videoId;
    }

    config.events = {
      onReady: () => {
        pollId = setInterval(() => {
          if (!player || typeof player.getPlayerState !== "function") return;
          if (player.getPlayerState() === YT.PlayerState.PLAYING) {
            elapsedSeconds += 1;
            if (targetMinutes) {
              updateProgressLabel();
              if (elapsedSeconds >= targetMinutes * 60) saveDone();
            }
          }
        }, 1000);
      },
      onStateChange: (e) => {
        if (e.data === YT.PlayerState.ENDED) {
          videosWatched += 1;
          updateProgressLabel();
          if (targetVideoCount && videosWatched >= targetVideoCount) {
            saveDone();
          } else if (!targetVideoCount && !targetMinutes) {
            saveDone(); // vídeo suelto sin objetivo: verlo entero basta
          } else if (isLastInPlaylist()) {
            saveDone(); // se acabó la lista antes de llegar al objetivo
          }
        }
      },
      onError: () => {
        clearInterval(pollId);
        hint.textContent = "Este vídeo no se pudo cargar.";
      },
    };

    player = new YT.Player("video-player", config);
  }

  function playLocalFile(path) {
    usingLocal = true;
    ytContainer.hidden = true;
    localVideoEl.hidden = false;
    localVideoEl.src = window.Capacitor.convertFileSrc(path);
    updateProgressLabel();
    if (!targetMinutes) hint.textContent = "Al terminar el vídeo, la tarea se marca hecha sola.";

    pollId = setInterval(() => {
      if (!localVideoEl.paused && !localVideoEl.ended) {
        elapsedSeconds += 1;
        if (targetMinutes) {
          updateProgressLabel();
          if (elapsedSeconds >= targetMinutes * 60) saveDone();
        }
      }
    }, 1000);

    localVideoEl.addEventListener("ended", () => saveDone());
    localVideoEl.play().catch(() => {
      hint.textContent = "Toca play en el vídeo para empezar.";
    });

    // "Solo local" no tiene a qué volver ni sentido tiene "olvidar" aquí
    // mismo (la tarea se quedaría sin vídeo) — eso se gestiona editando
    // la tarea, no desde esta pantalla.
    if (!localOnly) renderLocalActions(true);
  }

  function renderLocalActions(hasLocal) {
    if (!localActions) return;
    if (hasLocal) {
      localActions.innerHTML = `
        <button type="button" class="ghost-btn" id="use-youtube-instead">Ver el de YouTube en su lugar</button>
        <button type="button" class="ghost-btn ghost-btn--danger" id="forget-local">Olvidar este vídeo local</button>`;
      document.getElementById("use-youtube-instead")?.addEventListener("click", () => {
        usingLocal = false;
        clearInterval(pollId);
        localVideoEl.pause();
        localVideoEl.hidden = true;
        ytContainer.hidden = false;
        elapsedSeconds = 0;
        startYouTube();
        renderLocalActions(false);
      });
      document.getElementById("forget-local")?.addEventListener("click", async () => {
        try {
          await localPlugin.clearVideo({ taskKey: taskUuid });
        } catch {
          /* si ya no estaba, no pasa nada */
        }
        render(taskUuid, overrideVideoId);
      });
    } else {
      localActions.innerHTML = `<button type="button" class="ghost-btn" id="pick-local-video">+ Usar un vídeo de mi móvil en su lugar</button>`;
      document.getElementById("pick-local-video")?.addEventListener("click", pickLocalVideo);
    }
  }

  async function pickLocalVideo() {
    try {
      const res = await localPlugin.pickAndStoreVideo({ taskKey: taskUuid });
      if (!res?.path) throw new Error("Sin ruta");
      clearInterval(pollId);
      player = null;
      playLocalFile(res.path);
    } catch (err) {
      window.__toast?.("No se pudo usar ese vídeo.", "error");
    }
  }

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) return;
    if (player?.pauseVideo) player.pauseVideo();
    if (usingLocal && !localVideoEl.paused) localVideoEl.pause();
  });

  // ------------------------------------------------------------ boot
  if (localOnly) {
    if (!localPlugin) {
      hint.textContent = "Este vídeo es un archivo local, pero el plugin nativo no está disponible en esta build.";
    } else {
      try {
        const res = await localPlugin.getVideoPath({ taskKey: taskUuid });
        if (res?.path) {
          playLocalFile(res.path);
        } else {
          hint.textContent = "No se encuentra el vídeo — edita la tarea para volver a elegirlo.";
        }
      } catch {
        hint.textContent = "No se pudo abrir el vídeo — edita la tarea para volver a elegirlo.";
      }
    }
  } else if (allowLocal && localPlugin) {
    try {
      const res = await localPlugin.getVideoPath({ taskKey: taskUuid });
      if (res?.path) {
        playLocalFile(res.path);
      } else {
        await startYouTube();
        renderLocalActions(false);
      }
    } catch {
      await startYouTube();
      renderLocalActions(false);
    }
  } else {
    await startYouTube();
  }
}

/**
 * Pantallas de entreno: selector de ejercicio, cámara y circuitos.
 *
 * Aquí NO se ha tocado la lógica de conteo: workout.js y circuit.js se
 * reutilizan tal cual de la web. Lo único que cambia es de dónde salen
 * los datos (API en vez de plantilla de Django) y a dónde se envían.
 */

import { api } from "./api.js";
import * as healthSync from "./health-sync.js";
import { needsWarmup } from "./warmup-view.js";

const view = document.getElementById("view");

// Contadores implementados en workout.js. Un ejercicio de cámara sin
// contador está en el catálogo pero aún no se puede contar. Incluye
// tanto los de fuerza como los de calentamiento/estiramiento en modo
// "pose" (círculos de brazos, rotación de piernas, cuello…) — antes
// este set solo tenía los de fuerza, así que esos ejercicios existían
// en el catálogo y funcionaban dentro de un circuito (session-runner.js
// tiene su propia lista, ya correcta) pero al abrirlos sueltos desde
// "¿Qué toca hoy?" (p.ej. tarea de solo Estiramientos) caían siempre en
// el "todavía no tiene contador por cámara" de más abajo. Mismo
// criterio que COUNTERS en el backend Django (tasks/views.py).
const COUNTERS = new Set([
  "pullup", "dip", "pushup", "inclinepushup", "pikepushup", "squat", "splitsquat", "crunch", "legraise", "situp",
  "doublecrunch", "scissor", "dumbbellcurl", "archerpullup", "benchdip", "jumpingjack",
  "armcircles", "necklateral", "armscissors", "legrotation", "kneeraises", "heelkicks", "highlegraise",
  "hiplateral", "neckcircles", "neckhalfturn", "neckturn", "forearmrotation", 
  "hipforwardback", "lsit", "superman", "elephantsteps", "burpee", "scapularpull", "handstandpushup", "pistolsquat",
]);

// Plancha, plancha lateral, kneehold en barra, pino y los estiramientos
// mantenidos (brazo cruzado, tríceps por encima de la cabeza, isquios
// sentado, cuádriceps de pie): no cuentan reps, se aguantan — pero
// llevan cámara propia comprobando la postura, así que también se
// pueden abrir sueltos (fuera de un circuito). Antes le faltaban los 4
// estiramientos de aguante, que es justo la familia que hace que una
// tarea de solo "Estiramientos" tenga sentido suelta. Mismo criterio
// que POSTURE_COUNTERS en el backend Django (tasks/views.py) y en
// session-runner.js.
const POSTURE_COUNTERS = new Set([
  "plank", "sideplank", "wallsit", "kneeholdbar", "tucklever", "deadhang", "handstand", "lsithold", "supermanhold",
  "armcrossstretch", "tricepsoverheadstretch", "seatedhamstringstretch", "standingquadstretch",
  "elephantstepshold",
]);

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

function topbar(eyebrow, title, backHref) {
  return `
    <header class="topbar">
      <div class="topbar__title">
        <span class="topbar__eyebrow">${esc(eyebrow)}</span>
        <h1>${esc(title)}</h1>
      </div>
      ${backHref ? `<a href="${backHref}" class="stats-link">← Volver</a>` : ""}
    </header>`;
}

/** Mantiene la pantalla encendida durante el entreno. En la web esto no
 *  se podía: se te apagaba a media serie. */
async function keepAwake(on) {
  const KA = window.Capacitor?.Plugins?.KeepAwake;
  if (!KA) return;
  try {
    if (on) await KA.keepAwake();
    else await KA.allowSleep();
  } catch {
    /* si el plugin no está, seguimos igual */
  }
}

// ------------------------------------------------- selector de ejercicio

export async function render(taskUuid) {
  view.innerHTML = `<p class="app-loading">Cargando…</p>`;
  const { data: taskData } = await api.get(`/tasks/${taskUuid}/`);
  const task = taskData.task;
  if (await needsWarmup(task)) {
    location.hash = `#/calentamiento/${taskUuid}?next=${encodeURIComponent(`/entreno/${taskUuid}`)}`;
    return;
  }
  const sub = task.subcategory;
  const videoScope = sub === "lower_body" || sub === "upper_body" ? sub : null;
  // Correr y andar tienen su propia forma de registrarse: importando de
  // Health Connect (reloj, Samsung Health, Strava…) o a mano. La cámara
  // y los circuitos no pintan nada aquí.
  const esDistancia = sub === "running";

  const [{ data: exData }, { data: rtData }, videosData] = await Promise.all([
    api.exercises(sub),
    api.routines(sub),
    videoScope ? api.savedVideos(videoScope) : Promise.resolve({ data: { videos: [] } }),
  ]);

  // Los cronometrados no salen sueltos, salvo plancha y plancha lateral:
  // esas llevan cámara propia comprobando la postura y también se
  // pueden entrenar sueltas, igual que dominadas o sentadillas. El
  // resto de cronometrados (bicicleta…) solo tiene sentido en circuito.
  const exercises = exData.exercises.filter(
    (e) => e.mode !== "timed" || POSTURE_COUNTERS.has(e.counter_key)
  );
  const routines = rtData.routines;
  const videos = videosData.data.videos;

  view.innerHTML = `
    ${topbar("entreno", task.title, "#/")}
    ${
      esDistancia
        ? `<p class="exercise-picker__hint">¿Cómo lo registras?</p>
           <ul class="exercise-picker">
             <li><a class="exercise-picker__item" href="#" id="import-health">
               <span class="exercise-picker__name">Importar de Health Connect</span>
               <span class="exercise-picker__mode">Reloj / móvil</span>
             </a></li>
           </ul>
           <p class="field__hint" id="import-status"></p>`
        : ""
    }
    ${
      videoScope
        ? `<p class="exercise-picker__hint">O sigue un vídeo</p>
           <ul class="exercise-picker" id="video-list">
             ${
               videos.length
                 ? videos
                     .map(
                       (v) => `<li>
                         <a class="exercise-picker__item" href="#/video/${taskUuid}?v=${v.youtube_video_id}">
                           <span class="exercise-picker__name">${esc(v.title || v.youtube_video_id)}</span>
                           <span class="exercise-picker__mode">YouTube</span>
                         </a>
                         <form class="inline-delete" data-del-video="${v.uuid}">
                           <button type="button" class="ghost-btn ghost-btn--danger" title="Quitar de la lista">✕</button>
                         </form>
                       </li>`
                     )
                     .join("")
                 : `<li class="exercise-picker__empty">Todavía no tienes vídeos guardados aquí.</li>`
             }
           </ul>
           <form class="video-add-form" id="video-add-form">
             <input type="text" name="youtube_video_id" placeholder="Pega un enlace de YouTube…" required>
             <input type="text" name="title" placeholder="Título (opcional)" maxlength="120">
             <button type="submit" class="ghost-btn">+ Añadir y reproducir</button>
           </form>`
        : ""
    }
    <p class="exercise-picker__hint">¿Qué toca hoy?</p>
    <ul class="exercise-picker">
      ${
        exercises.length
          ? exercises
              .map(
                (e) => `<li><a class="exercise-picker__item" href="#" data-ex="${esc(e.slug)}"
                  data-mode="${esc(e.mode)}" data-counter="${esc(e.counter_key)}">
                  <span class="exercise-picker__name">${esc(e.name)}</span>
                  <span class="exercise-picker__mode">${esc(e.mode_display)}</span></a></li>`
              )
              .join("")
          : `<li class="exercise-picker__empty">Nada disponible para esta subcategoría.</li>`
      }
    </ul>
    <p class="exercise-picker__hint exercise-picker__hint--routines">O un circuito</p>
    <ul class="exercise-picker">
      ${
        routines.length
          ? routines
              .map(
                (r) => `<li class="routine-row">
                  <a class="exercise-picker__item" href="#/circuito/${taskUuid}/${r.uuid}">
                    <span class="exercise-picker__name">${esc(r.name)}</span>
                    <span class="exercise-picker__mode">${r.items.length} ejercicios · ${Math.round(
                  r.total_seconds / 60
                )} min</span>
                  </a>
                  <a class="routine-edit" href="#/circuitos/${r.uuid}?back=${encodeURIComponent(
                  `#/entreno/${taskUuid}`
                )}" title="Editar circuito" aria-label="Editar circuito">✎</a>
                </li>`
              )
              .join("")
          : `<li class="exercise-picker__empty">Todavía no has montado circuitos.</li>`
      }
      <li>
        <a class="exercise-picker__item exercise-picker__item--ghost"
           href="#/circuitos/nuevo?sub=${encodeURIComponent(sub || "")}&back=${encodeURIComponent(`#/entreno/${taskUuid}`)}">
          <span class="exercise-picker__name">+ Montar circuito nuevo</span>
        </a>
      </li>
    </ul>`;

  const importBtn = document.getElementById("import-health");
  if (importBtn) {
    const status = document.getElementById("import-status");
    importBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      if (!healthSync.isSupported()) {
        status.textContent = "Health Connect no está disponible en esta versión de la app.";
        return;
      }
      status.textContent = "Buscando actividad…";
      try {
        // Se pide permiso aquí mismo: si ya está concedido, Health
        // Connect no molesta y sigue de largo.
        await healthSync.requestPermissions();
        const res = await healthSync.syncRuns(taskUuid);
        if (res?.imported) {
          api.clearCache();
          window.__toast?.(
            res.task?.is_done ? "Importado — tarea completada." : "Importado.",
          );
          location.hash = "#/";
        } else {
          status.textContent = "No se encontró actividad nueva. Anótala a mano si prefieres.";
        }
      } catch (err) {
        status.textContent = `No se pudo importar: ${err.message || err}`;
      }
    });
  }

  view.querySelectorAll("[data-ex]").forEach((a) => {
    a.addEventListener("click", (e) => {
      e.preventDefault();
      const slug = a.dataset.ex;
      // Navegar por URL (y no llamar a la función directamente) es lo que
      // hace que el botón de volver funcione: cada pantalla tiene su
      // propia dirección y queda en el historial.
      if (a.dataset.mode === "distance") {
        location.hash = `#/entreno/${taskUuid}/manual/${slug}`;
      } else if (a.dataset.mode === "pose" && COUNTERS.has(a.dataset.counter)) {
        location.hash = `#/entreno/${taskUuid}/camara/${slug}`;
      } else if (a.dataset.mode === "timed" && POSTURE_COUNTERS.has(a.dataset.counter)) {
        location.hash = `#/entreno/${taskUuid}/camara/${slug}`;
      } else {
        window.__toast?.("Ese ejercicio todavía no tiene contador por cámara.", "error");
      }
    });
  });

  const addForm = document.getElementById("video-add-form");
  if (addForm) {
    addForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const fd = new FormData(addForm);
      try {
        const { data } = await api.createSavedVideo({
          scope: videoScope,
          youtube_video_id: fd.get("youtube_video_id"),
          title: fd.get("title") || "",
        });
        location.hash = `#/video/${taskUuid}?v=${data.video.youtube_video_id}`;
      } catch (err) {
        window.__toast?.(err.message, "error");
      }
    });
  }
  view.querySelectorAll("[data-del-video]").forEach((form) => {
    form.querySelector("button").addEventListener("click", async () => {
      try {
        await api.deleteSavedVideo(form.dataset.delVideo);
        render(taskUuid);
      } catch (err) {
        window.__toast?.(err.message, "error");
      }
    });
  });
}

// ------------------------------------------------------------- cámara

export async function renderCamera(taskUuid, exerciseSlug) {
  view.innerHTML = `<p class="app-loading">Preparando cámara…</p>`;
  const [{ data }, { data: exData }] = await Promise.all([
    api.get(`/tasks/${taskUuid}/`),
    api.exercises(),
  ]);
  const task = data.task;
  // DECIMOTERCER BUG REAL (2026-09-04): exerciseTarget busca por SLUG de
  // ejercicio, no por tarea — así que una tarea freestyle de fondos
  // enseñaba el objetivo (y el nombre) de un plan activo que también
  // entrena fondos, como si la tarea perteneciera a ese plan. Se pidió
  // que freestyle y plan queden del todo separados: solo se pide el
  // objetivo si ESTA tarea la generó un plan de verdad (task.plan_uuid,
  // ya viene en /tasks/<uuid>/ — ver task_json en tasks/api.py).
  // El objetivo SOLO si ESTA tarea la generó un plan; pero el historial de
  // reps por serie ("la última vez hiciste X") es tuyo, no de ningún plan,
  // así que se pide siempre y se usa también en entrenos sueltos.
  const targetAll = (await api.exerciseTarget(exerciseSlug).catch(() => ({ data: {} }))).data || {};
  const targetData = task.plan_uuid ? targetAll : {};
  const lastSets = Array.isArray(targetAll.last_sets) && targetAll.last_sets.length ? targetAll.last_sets : null;
  // Ejercicios cronometrados (plancha...): segundos aguantados por serie la última vez.
  const lastSeconds = Array.isArray(targetAll.last_seconds) && targetAll.last_seconds.length ? targetAll.last_seconds : null;
  if (await needsWarmup(task)) {
    location.hash = `#/calentamiento/${taskUuid}?next=${encodeURIComponent(`/entreno/${taskUuid}/camara/${exerciseSlug}`)}`;
    return;
  }
  // Qué contador usar y cada cuántas reps habla la voz lo dice el
  // ejercicio (counter_key / voice_step en el catálogo), no la pantalla
  // — igual que en la web (ver static/js/workout.js, this.voiceStep).
  const exerciseCatalogEntry = exData.exercises.find((e) => e.slug === exerciseSlug);
  const counterKey = exerciseCatalogEntry?.counter_key || "pullup";
  const voiceStep = exerciseCatalogEntry?.voice_step || 1;
  const hasTarget = targetData.target_sets && (targetData.target_reps || targetData.target_seconds);
  const objetivo = hasTarget
    ? (counterKey === "armcircles"
        ? `${targetData.target_reps} de cada sentido`
        : counterKey === "legrotation"
        ? `${targetData.target_reps} de cada pierna`
        : targetData.target_reps
        ? `${targetData.target_sets} × ${targetData.target_reps}`
        : `${targetData.target_sets} × ${targetData.target_seconds}s`)
    : null;

  view.innerHTML = `
    ${topbar(exerciseSlug, task.title, `#/entreno/${taskUuid}`)}
    <div id="workout-root" class="workout"
         data-save-url="local"
         data-cancel-url="#/"
         data-exercise-slug="${esc(exerciseSlug)}"
         data-counter-key="${esc(counterKey)}"
         data-voice-step="${voiceStep}"
         data-target-sets="${targetData.target_sets || ""}"
         data-target-reps="${targetData.target_reps || ""}"
         data-target-seconds="${targetData.target_seconds || ""}"
         data-last-sets="${lastSets ? esc(JSON.stringify(lastSets)) : ""}"
         data-last-seconds="${lastSeconds ? esc(JSON.stringify(lastSeconds)) : ""}">
      ${objetivo ? `<p class="run-target">Objetivo: <strong>${esc(objetivo)}</strong> ${
        targetData.plan_name ? `<span class="run-plan">plan «${esc(targetData.plan_name)}»</span>` : ""
      }</p>` : ""}
      <div class="workout__camera">
        <video id="workout-video" playsinline muted class="workout__video"></video>
        <canvas id="workout-canvas" class="workout__canvas"></canvas>
      </div>
      <p id="workout-goal-banner" class="workout__goal-banner" hidden></p>
      <p id="workout-last-hint" class="circuit__side-hint run-last-hint" hidden></p>
      <button type="button" id="workout-debug-export" class="workout__btn workout__btn--ghost">📋 Copiar registro de depuración</button>
      <p id="workout-debug-export-status" class="workout__debug"></p>
      <details class="workout__stats-toggle">
        <summary class="workout__stats-summary">Datos</summary>
        <div class="workout__stats">
        <div class="workout__stat"><span class="workout__stat-value" id="workout-reps">0</span><span class="workout__stat-label">${
          POSTURE_COUNTERS.has(counterKey) ? "segundos" : "reps"
        }</span></div>
        <div class="workout__stat"><span class="workout__stat-value" id="workout-sets">1</span><span class="workout__stat-label">serie</span></div>
        <div class="workout__stat"><span class="workout__stat-value" id="workout-timer">0:00</span><span class="workout__stat-label">sesión</span></div>
        <div class="workout__stat"><span class="workout__stat-value" id="workout-rest">0:00</span><span class="workout__stat-label">descanso</span></div>
        <div class="workout__stat"><span class="workout__stat-value" id="workout-last-rep">–</span><span class="workout__stat-label">última rep</span></div>
        </div>
      </details>
      <div class="workout__actions">
        <button type="button" id="workout-cancel" class="workout__btn workout__btn--ghost">Cancelar</button>
        <button type="button" id="workout-recalibrate" class="workout__btn workout__btn--ghost">↻ Recalibrar</button>
        <button type="button" id="workout-finish" class="workout__btn workout__btn--primary">Terminar</button>
      </div>
      ${counterKey === "pistolsquat" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de frente</strong> a ti, algo alejado, para que se vean las
        <strong>dos piernas enteras</strong>, de la cadera a los pies — la cabeza, los brazos y los hombros dan igual,
        puedes agarrarte a algo. Empieza de pie, quieto, mirando a la cámara, con las dos piernas apoyadas. Una repetición es <strong>bajar sobre una sola pierna</strong> con la otra estirada
        hacia delante y volver a subir — no hace falta que se vea el ángulo de la rodilla: la cámara nota cómo esa
        pierna se hace más corta. Cada pierna cuenta una repetición, la que tú quieras primero.</p>
      <p class="workout__note">Si pasan 8 segundos sin hacer ninguna repetición, la serie se cierra sola.</p>
      ` : ""}
      ${counterKey === "squat" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de lado</strong> (de perfil respecto a ti), no de frente —
        así se ve bien cuánto doblas la rodilla. Encuadra toda la pierna, de la cadera al tobillo — no hace falta
        que se vea la parte de arriba del cuerpo.</p>
      <p class="workout__note">Si pasan más de 1:00 sin contar ninguna repetición, la serie se cierra sola y empieza la siguiente.</p>
      ` : ""}
      ${counterKey === "pushup" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de lado</strong> (de perfil respecto a ti) y encuadra el cuerpo entero,
        de los hombros a los pies — así se ve bien cuánto doblas el codo. Túmbate <strong>boca abajo</strong>, en
        la posición de abajo de la flexión: <strong>manos a la altura del pecho</strong>, codos doblados y
        <strong>pegados al cuerpo</strong> (mirando hacia atrás, no hacia los lados, para que el ángulo se vea
        bien de perfil), y el cuerpo en línea recta.</p>
      <p class="workout__note">Si pasan más de 1:00 sin contar ninguna repetición, la serie se cierra sola y empieza la siguiente.</p>
      ` : ""}
      ${counterKey === "pikepushup" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de lado</strong> (de perfil respecto a ti) y encuadra el cuerpo entero,
        de las manos a los pies. Empieza en <strong>V invertida</strong>: manos y pies en el suelo, <strong>caderas en alto</strong>
        y brazos y piernas estirados, y quédate quieto un momento. Una repetición es <strong>bajar doblando los brazos</strong>
        mientras la cabeza baja hacia el suelo y <strong>volver a estirar los brazos</strong>. Para terminar una serie,
        ponte de pie o sal del encuadre.</p>
      ` : ""}
      ${counterKey === "dip" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de lado</strong> (de perfil respecto a ti) y encuadra el hombro,
        el codo y la muñeca del lado que mira a la cámara — no hace falta que se vean las piernas ni los pies.
        Agárrate a las paralelas con los brazos estirados, para empezar.</p>
      ` : ""}
      ${counterKey === "superman" || counterKey === "supermanhold" ? `
      <p class="workout__note">📐 Túmbate <strong>boca abajo</strong> y coloca el móvil <strong>de lado</strong> (de perfil respecto a ti),
        con el <strong>cuerpo entero</strong> en el encuadre, de las manos a los pies. Empieza <strong>completamente
        estirado</strong>: brazos al frente y piernas estiradas, todo apoyado en el suelo, y quédate quieto un momento
        para que la cámara aprenda tu posición de reposo.${counterKey === "superman" ? ` Después <strong>levanta a la vez los brazos
        y las piernas</strong> del suelo y vuelve a bajarlos: cuenta una repetición cada vez que los levantas (solo
        cuenta si suben los brazos <em>y</em> las piernas; para la siguiente hay que bajar los dos del todo). Para
        terminar una serie, levántate o sal del encuadre.` : ` Después <strong>levanta a la vez los brazos y las piernas</strong>
        y aguanta arriba. Aquí no se cuentan repeticiones: se cuentan los <strong>segundos aguantados</strong>. Si
        bajas los brazos o las piernas, te levantas o sales del encuadre un par de segundos, la serie se cierra sola.`}</p>
      ` : ""}
      ${counterKey === "lsit" || counterKey === "lsithold" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de lado</strong> (de perfil respecto a ti) y encuadra el
        <strong>cuerpo entero</strong>, de los hombros a los tobillos. Primero <strong>ponte de pie</strong> junto a las
        paralelas, un momento, para que la cámara aprenda tu altura; luego <strong>súbete</strong> con los brazos
        estirados${counterKey === "lsit" ? ` y sube y baja las piernas rectas, juntas, hasta la altura de la cadera (forma
        de L): cuenta una repetición cada vez que las subes a la L y las dejas colgar del todo. Para terminar una
        serie, bájate de las paralelas o sal del encuadre.` : ` y aguanta las piernas rectas en L, a la altura de la
        cadera. Aquí no se cuentan repeticiones: se cuentan los <strong>segundos aguantados</strong>. Si bajas las
        piernas, te bajas de las paralelas o sales del encuadre un par de segundos, la serie se cierra sola.`}</p>
      ` : ""}
      ${counterKey === "crunch" ? `
      <p class="workout__note">🛏️ Túmbate boca arriba y coloca el móvil <strong>a un lado</strong> (de perfil respecto a ti) —
        así se ve bien cuánto se levantan los hombros del suelo. Encuadra el hombro, la cadera y la rodilla —
        no hace falta que se vean los pies.</p>
      ` : counterKey === "legraise" ? `
      <p class="workout__note">🛏️ Túmbate boca arriba y coloca el móvil <strong>a un lado</strong> (de perfil respecto a ti) —
        así se ve bien cuánto suben las piernas. Encuadra el cuerpo entero, de los hombros a los tobillos.</p>
      ` : counterKey === "situp" ? `
      <p class="workout__note">🛏️ Túmbate boca arriba y coloca el móvil <strong>a un lado</strong> (de perfil respecto a ti) —
        así se ve bien cuánto te incorporas. Encuadra la cabeza, el hombro, la cadera y la muñeca (con manos
        detrás de la nuca o brazos cruzados sobre el pecho) — no hace falta que se vean ni las piernas ni los pies.
        Apoyar las manos en el suelo para impulsarte no cuenta.</p>
      ` : ""}
      ${counterKey === "doublecrunch" ? `
      <p class="workout__note">🛏️ Túmbate boca arriba y coloca el móvil <strong>a un lado</strong> (de perfil respecto a ti) —
        encuadra el hombro, la cadera y la rodilla — no hace falta que se vean los pies. El torso se queda
        levantado en una postura intermedia mientras las piernas van y vienen llevando las rodillas al pecho.</p>
      ` : counterKey === "scissor" ? `
      <p class="workout__note">🛏️ Túmbate boca arriba y coloca el móvil <strong>a un lado</strong> (de perfil respecto a ti) —
        encuadra el cuerpo entero, de los hombros a los tobillos. Las piernas se quedan a un palmo del suelo,
        alternando cuál sube más — como unas tijeras.</p>
      ` : ""}
      ${counterKey === "dumbbellcurl" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de lado</strong> (de perfil respecto a ti, como en
        flexiones o fondos), no de frente — así se ve bien cuánto doblas el codo. Encuadra el brazo entero, del
        hombro a la mano, y también la cadera del lado que mira a la cámara (se usa como referencia para saber si
        te balanceas). Ponte de pie, de perfil, con una mancuerna en la mano del lado que mira a la cámara,
        brazo estirado y codo pegado al cuerpo, para empezar.</p>
      <p class="workout__note">Solo cuenta como repetición si el codo se queda pegado al costado y la muñeca no
        sube por encima de la cara durante todo el movimiento — así no cuenta una repetición falsa si levantas
        las manos por otro motivo o miras el móvil a media serie. Si te quedas arriba sin bajar, sale un aviso de
        cuánto llevas aguantando: eso no cuenta como repetición hasta que vuelvas a estirar el brazo.</p>
      ` : counterKey === "pullup" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de frente</strong> a ti, algo alejado, para que se vean
        los hombros y los brazos enteros, hasta las manos, colgando de la barra — no hace falta que se vean las
        piernas ni los pies (solo se sigue la nariz, los hombros, los codos y las muñecas). Agárrate a la barra
        con los brazos estirados, para empezar. Soltar la barra o salir del encuadre un par de segundos cierra
        la serie sola.</p>
      ` : counterKey === "archerpullup" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de frente</strong> a ti, algo alejado, para que se vean
        los hombros y los brazos enteros, hasta las manos, colgando de la barra — no hace falta que se vean las
        piernas ni los pies (solo se sigue la nariz, los hombros, los codos y las muñecas). Agárrate a la barra
        con los brazos estirados; al subir, lleva un brazo a 90° y estira el otro, alternando de lado en cada
        repetición. Soltar la barra o salir del encuadre un par de segundos cierra la serie sola.</p>
      ` : counterKey === "kneeholdbar" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de frente</strong> a ti, algo alejado, para que quepa todo
        el cuerpo colgado en el encuadre, de las manos a las rodillas. Agárrate a la barra con los brazos estirados
        y dobla las rodillas, subiéndolas hasta dejarlas más o menos a la altura de la cadera.
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Soltar la barra o salir del encuadre un par de segundos cierra la serie sola.</p>
      ` : counterKey === "deadhang" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de frente</strong> a ti, algo alejado, para que quepa todo
        el cuerpo colgado en el encuadre, de las manos a las rodillas. Agárrate a la barra con los brazos estirados
        y dobla las piernas hacia atrás, de forma que no se te vean los tobillos (o sube las rodillas hacia el pecho).
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Soltar la barra o salir del encuadre un par de segundos cierra la serie sola.</p>
      ` : counterKey === "handstand" ? `
      <p class="workout__note">📐 Coloca el móvil de forma que se vean las manos, los brazos y la cadera — de frente,
        de lado o como te resulte más cómodo. Sube a un pino, con o sin apoyo en la pared, hasta que la cadera
        quede por encima de los hombros y los brazos por debajo de la cadera, aguantando el peso cerca del suelo.
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Bajar del pino o salir del encuadre un par de segundos cierra la serie sola.</p>
      ` : counterKey === "handstandpushup" ? `
      <p class="workout__note">📐 Coloca el móvil de forma que se vean las manos, los brazos y la cadera — de frente,
        de lado o como te resulte más cómodo. Sube a un pino, con o sin apoyo en la pared, hasta que la cadera
        quede por encima de los hombros y los brazos por debajo de la cadera, aguantando el peso cerca del suelo, con
        los brazos estirados. Dobla los codos para bajar la cabeza hacia el suelo y estira para volver a subir: eso
        cuenta una repetición. Bajar del pino o salir del encuadre un par de segundos cierra la serie sola.</p>
      ` : counterKey === "armcrossstretch" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de frente</strong> a ti, algo alejado, para que se vean los hombros, los codos y las muñecas
        — no hace falta que se vea el resto del cuerpo.
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Salir del encuadre o soltar la postura un par de segundos cierra la serie sola.</p>
      ` : counterKey === "tricepsoverheadstretch" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de frente</strong> a ti, algo alejado, para que se vean la cabeza, los hombros y los brazos
        — no hace falta que se vea el resto del cuerpo.
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Salir del encuadre o soltar la postura un par de segundos cierra la serie sola.</p>
      ` : counterKey === "standingquadstretch" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de frente</strong> a ti, algo alejado, para que se vean los hombros, las caderas y las piernas.
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Salir del encuadre o soltar la postura un par de segundos cierra la serie sola.</p>
      ` : counterKey === "seatedhamstringstretch" ? `
      <p class="workout__note">📐 Siéntate <strong>de perfil</strong> a la cámara, algo alejado, para que se vean la cadera, las rodillas y los tobillos
        de las dos piernas.
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Salir del encuadre o soltar la postura un par de segundos cierra la serie sola.</p>
      ` : counterKey === "wallsit" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de lado</strong> (de perfil respecto a ti), algo alejado, y encuadra la pierna entera, de la
        cadera al tobillo — no hace falta que se vea la parte de arriba del cuerpo.
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Salir del encuadre o soltar la postura un par de segundos cierra la serie sola.</p>
      ` : counterKey === "tucklever" ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de frente</strong> a ti, algo alejado, para que quepa todo el cuerpo colgado en el encuadre.
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Salir del encuadre o soltar la postura un par de segundos cierra la serie sola.</p>
      ` : POSTURE_COUNTERS.has(counterKey) ? `
      <p class="workout__note">📐 Coloca el móvil <strong>de lado</strong> y encuadra el cuerpo entero.
        Aquí no se cuentan reps: es una postura que se aguanta, y el contador de arriba marca los segundos.
        Levantarte o salir del encuadre cierra la serie sola.</p>
      ` : ""}
      <p class="workout__note">El vídeo no sale de tu móvil. Solo se guardan los números.</p>
    </div>`;

  // Sin await: si el plugin de pantalla encendida no responde, no debe
  // dejar el contador colgado en "Iniciando…". Es un extra, no un
  // requisito para entrenar.
  keepAwake(true);

  // workout.js habla con el servidor por su cuenta. En la app
  // interceptamos su envío para que pase por el cliente de API (con
  // credenciales, caché y cola offline) en vez de por un fetch pelado.
  window.__workoutSubmit = async (payload) => {
    keepAwake(false);
    // Se guarda con finish=false: el ejercicio queda registrado pero la
    // tarea NO se cierra todavía, para poder encadenar otro. Antes, al
    // terminar un ejercicio la sesión se acababa entera y no había forma
    // de hacer dos cosas seguidas.
    try {
      await api.saveWorkout(taskUuid, { ...payload, exercise: exerciseSlug, finish: false });
    } catch (err) {
      window.__toast?.(
        err.queued ? "Sin conexión: guardado y se enviará solo." : err.message,
        err.queued ? "info" : "error"
      );
      // Si no era un encolado offline, el guardado ha fallado de verdad
      // -- se deja el guardián puesto, sigue habiendo algo que perder.
      if (!err.queued) return;
    }
    // Ya se ha guardado (o encolado para reenviar solo) de verdad -- no
    // hace falta seguir preguntando si se sale.
    window.__currentViewGuard = null;
    renderSessionChoice(taskUuid, task, payload);
  };

  let __mod;
  try {
    __mod = await import("./workout.js");
  } catch (impErr) {
    throw new Error(`No se pudo cargar ./workout.js: ${impErr.message}`);
  }
  const { startWorkout } = __mod;
  const session = startWorkout();
  // "Cancelar" ya es en sí mismo una salida explícita y consciente -- no
  // hace falta preguntar otra vez. Se intercepta ANTES que el listener
  // propio de workout.js (mismo truco de captura + stopImmediatePropagation
  // que ya usa session-runner.js para su "Saltar"): si no, workout.js
  // pararía la cámara y cambiaría el hash él solo, sin pasar por el
  // guardián, dejando la pantalla a medias si luego se cancelara la
  // salida.
  document.getElementById("workout-cancel")?.addEventListener(
    "click",
    (e) => {
      e.stopImmediatePropagation();
      window.__currentViewGuard = null;
      session?.stopCamera?.();
      location.hash = "#/";
    },
    true
  );
  // Este ejercicio suelto no tiene "borrador" que retomar -- las reps de
  // la serie en curso solo existen dentro de workout.js/MediaPipe, no en
  // ningún sitio que se pueda guardar sin tocar el motor de conteo. Lo
  // que sí se puede hacer barato es no dejar salir sin avisar: cada
  // ejercicio ya terminado se guarda solo (ver __workoutSubmit), así que
  // lo único en juego al salir es la serie que tienes a medias ahora.
  window.__currentViewGuard = () =>
    confirm("¿Seguro que quieres salir? Perderás el progreso de este ejercicio (lo de antes, si lo hay, ya está guardado).");
  // Si sales de esta pantalla sin pasar por Cancelar/Terminar (el enlace
  // "← Volver" de arriba, el botón físico atrás, otra pestaña…), el
  // router (app.js) llama a esto antes de pintar la siguiente pantalla —
  // sin esto, la cámara y la voz seguían encendidas de fondo. stopCamera()
  // ya para también la voz (ver stopSpeaking() en workout.js).
  window.__currentViewCleanup = () => {
    session?.stopCamera?.();
    keepAwake(false);
    window.__currentViewGuard = null;
  };
}

/**
 * Pantalla intermedia tras guardar un ejercicio: seguir con otro o
 * cerrar la sesión. Es lo que convierte "un ejercicio = una sesión" en
 * "una sesión = los ejercicios que quieras".
 */
function renderSessionChoice(taskUuid, task, lastPayload) {
  const reps = lastPayload?.total_reps ?? 0;
  const sets = lastPayload?.total_sets ?? 0;

  view.innerHTML = `
    ${topbar("sesión", task.title, "#/")}
    <div class="session-choice">
      <p class="session-choice__done">✓ Guardado: ${reps} reps en ${sets} serie(s).</p>
      <p class="session-choice__hint">¿Sigues con otro ejercicio o cierras la sesión?</p>
      <div class="session-choice__actions">
        <button type="button" class="primary-btn" id="another">Otro ejercicio</button>
        <button type="button" class="ghost-btn" id="finish-session">Terminar sesión</button>
      </div>
      <p class="field__hint">
        La tarea sigue pendiente hasta que cierres la sesión, así puedes
        encadenar los ejercicios que quieras.
      </p>
    </div>`;

  document.getElementById("another").addEventListener("click", () => {
    location.hash = `#/entreno/${taskUuid}`;
  });

  document.getElementById("finish-session").addEventListener("click", (e) => {
    e.target.disabled = true;
    // No se marca hecha aquí — falta el enfriamiento obligatorio
    // (ver warmup-view.js), que es quien la cierra de verdad.
    location.hash = `#/enfriamiento/${taskUuid}`;
  });
}

// -------------------------------------------------------- running manual

export async function renderManual(taskUuid, slug) {
  view.innerHTML = `<p class="app-loading">Cargando…</p>`;
  const { data } = await api.get(`/tasks/${taskUuid}/`);
  const task = data.task;

  view.innerHTML = `
    ${topbar(slug, task.title, `#/entreno/${taskUuid}`)}
    <p class="workout__note">Apunta lo que te diga la cinta, el reloj o la app que uses.</p>
    <form class="task-form" id="manual-form">
      <div class="field-row">
        <label class="field"><span class="field__label">Distancia (km)</span>
          <input type="number" name="distance_km" step="0.01" min="0" inputmode="decimal" placeholder="5.20"></label>
        <label class="field"><span class="field__label">Duración (min)</span>
          <input type="number" name="duration_minutes" step="0.1" min="0" inputmode="decimal" placeholder="28"></label>
      </div>
      <label class="field"><span class="field__label">Pasos (opcional)</span>
        <input type="number" name="steps" step="1" min="0" inputmode="numeric" placeholder="6200"></label>
      <div class="task-form__actions"><button class="primary-btn" type="submit">Guardar</button></div>
    </form>`;

  document.getElementById("manual-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      const res = await api.saveWorkoutManual(taskUuid, {
        exercise: slug,
        distance_km: fd.get("distance_km"),
        duration_minutes: fd.get("duration_minutes"),
        steps: fd.get("steps"),
      });
      // El servidor solo cierra la tarea si se llegó al objetivo.
      if (res?.data?.goal_met === false) {
        window.__toast?.(
          `Guardado${res.data.progress_label ? ` (${res.data.progress_label})` : ""}. Aún no llegas al objetivo.`,
          "info",
        );
      }
      location.hash = "#/";
    } catch (err) {
      window.__toast?.(err.queued ? "Sin conexión: guardado y se enviará solo." : err.message, err.queued ? "info" : "error");
      if (err.queued) location.hash = "#/";
    }
  });
}

// ------------------------------------------------- constructor de circuitos

/**
 * Crear o editar un circuito. Sin arrastrar y soltar a propósito:
 * botones de subir/bajar son mucho más fiables con el dedo en una
 * pantalla pequeña.
 */
export async function renderRoutineForm(routineUuid, backHash, presetSub = "") {
  view.innerHTML = `<p class="app-loading">Cargando…</p>`;
  const back = backHash ? decodeURIComponent(backHash) : "#/";

  const [{ data: exData }, existing] = await Promise.all([
    api.exercises(),
    routineUuid ? api.get(`/routines/${routineUuid}/`) : Promise.resolve(null),
  ]);
  // Se ofrecen TODOS los ejercicios, no solo los cronometrados: un
  // circuito de tren superior (dominadas, anchas, chin ups) es tan
  // válido como uno de abdominales.
  const available = exData.exercises;
  const routine = existing?.data.routine || null;
  const subcategory = routine?.subcategory || presetSub || "";

  // Estado local del circuito que se está montando.
  let order = routine
    ? routine.items.map((i) => ({
        slug: i.slug, name: i.name, mode: i.mode,
        target_sets: i.target_sets, target_reps: i.target_reps,
        work_seconds: i.work, rest_seconds: i.rest,
      }))
    : [];

  view.innerHTML = `
    ${topbar("circuito", routine ? "Editar circuito" : "Nuevo circuito", back)}
    <form class="task-form" id="routine-form">
      <label class="field">
        <span class="field__label">Nombre</span>
        <input type="text" name="name" maxlength="64" required
               value="${esc(routine?.name || "Abdominales")}">
      </label>
      <div class="field-row">
        <label class="field">
          <span class="field__label">Trabajo (seg)</span>
          <input type="number" name="work" min="5" step="5" inputmode="numeric"
                 value="${routine?.default_work_seconds ?? 40}">
        </label>
        <label class="field">
          <span class="field__label">Descanso (seg)</span>
          <input type="number" name="rest" min="0" step="5" inputmode="numeric"
                 value="${routine?.default_rest_seconds ?? 20}">
        </label>
      </div>

      <fieldset class="field">
        <legend class="field__label">Ejercicios disponibles</legend>
        <ul class="routine-available">
          ${
            available.length
              ? available
                  .map(
                    (e) => `<li>
                      <span>${esc(e.name)}
                        <small class="routine-mode">${e.mode === "timed" ? "cronómetro" : "cámara"}</small>
                      </span>
                      <button type="button" class="ghost-btn" data-add="${esc(e.slug)}"
                              data-name="${esc(e.name)}">+ Añadir</button>
                    </li>`
                  )
                  .join("")
              : `<li>No hay ejercicios en el catálogo.</li>`
          }
        </ul>
      </fieldset>

      <fieldset class="field">
        <legend class="field__label">Tu circuito, en orden</legend>
        <p class="routine-empty" id="routine-empty">Todavía no has añadido ninguno.</p>
        <ol class="routine-selected" id="routine-selected"></ol>
        <span class="field__hint" id="routine-total"></span>
      </fieldset>

      <div class="task-form__actions">
        <button type="submit" class="primary-btn">Guardar circuito</button>
        ${routine ? '<button type="button" class="ghost-btn ghost-btn--danger" id="routine-delete">Eliminar</button>' : ""}
      </div>
    </form>`;

  const listEl = document.getElementById("routine-selected");
  const emptyEl = document.getElementById("routine-empty");
  const totalEl = document.getElementById("routine-total");

  function renderList() {
    emptyEl.hidden = order.length > 0;
    listEl.innerHTML = "";
    order.forEach((item, idx) => {
      const li = document.createElement("li");
      li.className = "routine-selected__item";

      const name = document.createElement("span");
      name.className = "routine-selected__name";
      name.textContent = `${idx + 1}. ${item.name}`;

      // Los de camara se configuran en series x reps; los cronometrados
      // heredan los segundos generales del circuito. Contar segundos de
      // dominadas no diria nada.
      if (item.mode === "pose") {
        const cfg = document.createElement("span");
        cfg.className = "routine-target";
        const sets = document.createElement("input");
        sets.type = "number"; sets.min = "1"; sets.value = item.target_sets;
        sets.setAttribute("aria-label", "Series");
        sets.addEventListener("input", () => { item.target_sets = parseInt(sets.value, 10) || 1; renderList(); });
        const reps = document.createElement("input");
        reps.type = "number"; reps.min = "1"; reps.value = item.target_reps;
        reps.setAttribute("aria-label", "Repeticiones");
        reps.addEventListener("input", () => { item.target_reps = parseInt(reps.value, 10) || 1; });
        const x = document.createElement("span"); x.textContent = "×";
        cfg.append(sets, x, reps);
        name.appendChild(cfg);
      }

      const actions = document.createElement("span");
      actions.className = "routine-selected__actions";
      const mk = (txt, label, fn) => {
        const b = document.createElement("button");
        b.type = "button";
        b.textContent = txt;
        b.setAttribute("aria-label", label);
        b.addEventListener("click", fn);
        return b;
      };
      actions.append(
        mk("↑", "Subir", () => swap(idx, -1)),
        mk("↓", "Bajar", () => swap(idx, 1)),
        mk("✕", "Quitar", () => { order.splice(idx, 1); renderList(); }),
      );

      li.append(name, actions);
      listEl.appendChild(li);
    });

    // Duración estimada, para no montar un circuito de 40 minutos sin darse cuenta.
    const work = parseInt(view.querySelector('[name="work"]').value, 10) || 0;
    const rest = parseInt(view.querySelector('[name="rest"]').value, 10) || 0;
    const total = order.reduce(
      (acc, o, i) =>
        acc +
        (o.mode === "pose" ? (o.target_sets || 1) * (o.target_reps || 1) * 4 : work) +
        (i < order.length - 1 ? rest : 0),
      0
    );
    totalEl.textContent = order.length
      ? `Duración estimada: ${Math.floor(total / 60)} min ${total % 60}s`
      : "";
  }

  function swap(idx, dir) {
    const t = idx + dir;
    if (t < 0 || t >= order.length) return;
    [order[idx], order[t]] = [order[t], order[idx]];
    renderList();
  }

  view.querySelectorAll("[data-add]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const slug = btn.dataset.add;
      if (order.some((o) => o.slug === slug)) return;
      const ex = available.find((e) => e.slug === slug);
      order.push({
        slug, name: btn.dataset.name, mode: ex?.mode || "timed",
        target_sets: 3, target_reps: 8,
      });
      renderList();
    });
  });
  ["work", "rest"].forEach((n) =>
    view.querySelector(`[name="${n}"]`).addEventListener("input", renderList)
  );
  renderList();

  document.getElementById("routine-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!order.length) {
      return window.__toast?.("Añade al menos un ejercicio.", "error");
    }
    const fd = new FormData(e.target);
    const payload = {
      name: fd.get("name"),
      subcategory,
      default_work_seconds: parseInt(fd.get("work"), 10) || 40,
      default_rest_seconds: parseInt(fd.get("rest"), 10) || 20,
      items: order.map((o) => ({
        slug: o.slug,
        target_sets: o.target_sets ?? 3,
        target_reps: o.target_reps ?? 8,
      })),
    };
    try {
      if (routineUuid) await api.patch(`/routines/${routineUuid}/`, payload);
      else await api.createRoutine(payload);
      api.clearCache();
      window.__toast?.("Circuito guardado.");
      location.hash = back;
    } catch (err) {
      window.__toast?.(err.message, "error");
    }
  });

  const delBtn = document.getElementById("routine-delete");
  if (delBtn) {
    let armed = false;
    delBtn.addEventListener("click", async () => {
      if (!armed) {
        armed = true;
        delBtn.textContent = "¿Seguro? Pulsa otra vez";
        delBtn.classList.add("ghost-btn--armed");
        setTimeout(() => {
          armed = false;
          delBtn.textContent = "Eliminar";
          delBtn.classList.remove("ghost-btn--armed");
        }, 4000);
        return;
      }
      try {
        await api.deleteRoutine(routineUuid);
        api.clearCache();
        window.__toast?.("Circuito eliminado.");
        location.hash = back;
      } catch (err) {
        window.__toast?.(err.message, "error");
      }
    });
  }
}

// ---------------------------------------------------------- circuitos

export async function renderCircuit(taskUuid, routineUuid) {
  view.innerHTML = `<p class="app-loading">Cargando circuito…</p>`;
  const [{ data: t }, { data: r }] = await Promise.all([
    api.get(`/tasks/${taskUuid}/`),
    api.get(`/routines/${routineUuid}/`),
  ]);
  const task = t.task;
  if (await needsWarmup(task)) {
    location.hash = `#/calentamiento/${taskUuid}?next=${encodeURIComponent(`/circuito/${taskUuid}/${routineUuid}`)}`;
    return;
  }
  const routine = r.routine;
  const items = routine.items;
  const hasCamera = items.some((i) => i.mode === "pose");

  view.innerHTML = `
    ${topbar(routine.name, task.title, `#/entreno/${taskUuid}`)}
    <div class="circuit__mode-select" id="mode-select">
      <p class="circuit__mode-hint">${items.length} ejercicios · ¿en orden o aleatorio?</p>
      <ul class="run-preview">
        ${items
          .map(
            (i) => `<li><span>${esc(i.name)}</span><span>${
              i.mode === "pose" ? `${i.target_sets} × ${i.target_reps} reps` : `${i.work}s`
            }</span></li>`
          )
          .join("")}
      </ul>
      <div class="circuit__mode-buttons">
        <button type="button" class="primary-btn" id="start-order">En orden</button>
        <button type="button" class="ghost-btn" id="start-random">Aleatorio</button>
      </div>
      ${
        hasCamera
          ? `<p class="field__hint">Los ejercicios de cámara cuentan repeticiones;
             los cronometrados van a tiempo. Cada uno con lo suyo.</p>`
          : ""
      }
    </div>
    <div id="run-host"></div>`;

  keepAwake(true);

  let __mod;
  try {
    __mod = await import("./session-runner.js");
  } catch (impErr) {
    throw new Error(`No se pudo cargar ./session-runner.js: ${impErr.message}`);
  }
  const { SessionRunner, loadSessionDraft, clearSessionDraft } = __mod;
  // Clave de esta sesión (tarea + circuito) para poder retomarla si hay
  // que salir a medias -- ver session-runner.js/saveDraft().
  const draftKey = `circuit:${taskUuid}:${routineUuid}`;
  const draft = loadSessionDraft(draftKey);

  const onFinish = async (breakdown, meta = {}) => {
    // El circuito ya ha terminado de verdad (llegó al final del guion) —
    // a partir de aquí la limpieza la hace este mismo callback más abajo,
    // no window.__currentViewCleanup (que apunta a destroy(), pensado
    // para una salida a medias, no para un circuito completo).
    window.__currentViewCleanup = null;
    try {
      // finish:false — la tarea no se cierra aquí, falta el
      // enfriamiento obligatorio (ver warmup-view.js).
      await api.saveCircuit(taskUuid, routineUuid, {
        breakdown, finish: false, session_seconds: meta.session_seconds,
      });
      api.clearCache();
    } catch (err) {
      window.__toast?.(
        err.queued ? "Sin conexión: guardado y se enviará solo." : err.message,
        err.queued ? "info" : "error"
      );
    }
    keepAwake(false);
    location.hash = `#/enfriamiento/${taskUuid}`;
  };

  const begin = (list) => {
    document.getElementById("mode-select").hidden = true;
    const runner = new SessionRunner(document.getElementById("run-host"), list, onFinish, draftKey);
    // Si sales del circuito a medias (← Volver, atrás, otra pestaña…), el
    // router llama a esto antes de pintar la siguiente pantalla — runner.
    // destroy() ya paraba cámara, voz y cronómetros, pero nada lo llamaba
    // nunca hasta ahora.
    window.__currentViewCleanup = () => {
      runner.destroy();
      keepAwake(false);
    };
    return runner;
  };

  // Circuito sin terminar de una vez anterior -- se ofrece continuar por
  // donde se dejó, en el mismo orden en que se estaba jugando entonces.
  if (draft) {
    if (confirm("Tienes un circuito sin terminar. ¿Quieres continuar donde lo dejaste?")) {
      begin(draft.items).start({ index: draft.index, breakdown: draft.breakdown, elapsedMs: draft.elapsedMs });
    } else {
      clearSessionDraft(draftKey);
    }
  }

  document.getElementById("start-order").addEventListener("click", () => begin([...items]).start());
  document.getElementById("start-random").addEventListener("click", () =>
    begin([...items].sort(() => Math.random() - 0.5)).start()
  );
}

import datetime as _dt
import math
import re
import uuid
from datetime import timedelta

from django.conf import settings
from django.db import models
from django.db.models import Case, DateField, F, Sum, When
from django.db.models.functions import Coalesce, TruncDate
from django.utils import timezone

# Formatos aceptados al pegar un vídeo de YouTube (RoutineItem.youtube_video_id):
# enlace completo (youtube.com/watch?v=, youtu.be/, youtube.com/shorts/,
# youtube.com/embed/) o directamente el ID de 11 caracteres. Así no hay que
# ir a buscar el ID a mano cada vez que se pega un enlace.
_YOUTUBE_ID_RE = re.compile(
    r"(?:youtu\.be/|youtube\.com/(?:watch\?v=|embed/|shorts/))([A-Za-z0-9_-]{11})"
)

# El ID de una playlist va en el parámetro ?list=... de cualquier URL de
# YouTube (a veces junto a un vídeo concreto, a veces solo). Empieza casi
# siempre por "PL", "UU", "LL" o "FL", pero no hace falta comprobarlo — con
# que aparezca list=algo ya vale.
_YOUTUBE_PLAYLIST_ID_RE = re.compile(r"[?&]list=([A-Za-z0-9_-]+)")

# Niveles MCER (A1→C2), a nivel de módulo porque tanto Task (el nivel del
# vídeo concreto de hoy) como Plan (el rango de nivel del curso entero) lo
# necesitan, y Task se define antes que Plan en este archivo.
CEFR_LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"]
CEFR_LEVEL_CHOICES = [(lvl, lvl) for lvl in CEFR_LEVELS]


# Por encima de este ritmo (segundos por km; 1200 = 20:00/km, unos 3 km/h) una
# sesión no es andar de verdad: son paradas, esperas, o el Detector de
# Actividad contando un rato casi quieto como sesión aparte.
MOVING_MAX_SECONDS_PER_KM = 1200


def day_average_pace(sessions):
    """
    Ritmo medio del día en segundos por km, o None si no se puede saber
    (ninguna sesión con distancia Y duración).

    Es la regla ÚNICA de "¿llegó al ritmo pedido?": la usan
    Task.auto_progress, api.running_import y PlanItem.distance_days, para que
    barra, tarea y plan no puedan discrepar.

    Solo se cronometran las sesiones en las que de verdad se andaba
    (<= MOVING_MAX_SECONDS_PER_KM): el Detector de Actividad trocea un
    paseo en una sesión grande y decenas de fragmentos de pocos metros en
    mucho tiempo (paradas). Con esos fragmentos dentro, 9,4 km a 12:53/km
    más 0,7 km "a 53:00/km" salían como 15:31/km de media y el día no
    contaba aunque el paseo real fuera más rápido que lo pedido. La
    distancia de esos fragmentos SÍ suma al total del día (la andaste);
    solo no entran a calcular el ritmo. Si TODAS las sesiones son más lentas
    que ese límite, se usan todas (andar a 25:00/km sigue sin cumplir).
    """
    timed = [
        (s.distance_km, s.session_duration_seconds)
        for s in sessions
        if s.distance_km and s.session_duration_seconds
    ]
    if not timed:
        return None
    moving = [(km, sec) for km, sec in timed if sec / km <= MOVING_MAX_SECONDS_PER_KM]
    use = moving or timed
    return sum(sec for _, sec in use) / sum(km for km, _ in use)


class Task(models.Model):
    REPEAT_NONE = "none"
    REPEAT_DAILY = "daily"
    REPEAT_WEEKLY = "weekly"
    REPEAT_MONTHLY = "monthly"
    REPEAT_YEARLY = "yearly"
    REPEAT_CUSTOM = "custom"

    REPEAT_CHOICES = [
        (REPEAT_NONE, "No se repite"),
        (REPEAT_DAILY, "Cada día"),
        (REPEAT_WEEKLY, "Cada semana"),
        (REPEAT_MONTHLY, "Cada mes"),
        (REPEAT_YEARLY, "Cada año"),
        (REPEAT_CUSTOM, "Personalizado"),
    ]

    # Tipos / categorías de tarea. Sirve para:
    # - agrupar / filtrar visualmente
    # - decidir qué tipo de "extras" se enganchan (timer para study,
    #   MediaPipe para sport, etc.). Se mantiene como CharField con choices
    #   para que añadir un tipo nuevo sea solo tocar esta lista.
    CATEGORY_GENERAL = "general"
    CATEGORY_STUDY = "study"
    CATEGORY_SPORT = "sport"
    CATEGORY_WORK = "work"
    CATEGORY_AVOID = "avoid"

    # "Personal" y "Otro" existieron sin usarse nunca (cero tareas reales
    # en ninguna de las dos) — se quitaron para no ofrecer más opciones
    # de las que hacen falta. Si algún día hace falta un cajón de sastre,
    # General ya cubre "tarea suelta sin extras".
    CATEGORY_CHOICES = [
        (CATEGORY_GENERAL, "General"),
        (CATEGORY_STUDY, "Estudio"),
        (CATEGORY_SPORT, "Deporte"),
        (CATEGORY_WORK, "Lectura"),
        (CATEGORY_AVOID, "Antitarea"),
    ]

    # Metadatos que describen qué "extras" admite cada categoría.
    # Útil para que la UI sepa si mostrar el botón de iniciar timer,
    # el panel de cámara de MediaPipe, etc.
    #
    # CATEGORY_WORK ("Lectura", antes "Enfoque") era antes "Trabajo" sin
    # ningún extra construido — se reutiliza el mismo hueco (misma clave
    # "work" en la base de datos, así las tareas que ya tuvieras no se
    # mueven de categoría). Al principio cronometraba cualquier cosa
    # (leer, estudiar, estirar…), pero "Estudio" y "Estiramientos" nunca
    # se llegaron a usar de verdad (ya cubiertos por Estudio normal y por
    # Deporte → cámara respectivamente), así que se dejó solo en Lectura.
    #
    # General no tiene entrada aquí a propósito: el cronómetro ahí es
    # opcional por tarea (ver Task.wants_timer), no algo que dependa de
    # la categoría entera — por eso lo decide workout_kind() mirando el
    # campo, no esta tabla.
    CATEGORY_CAPABILITIES = {
        CATEGORY_GENERAL: [],
        # "timer"/"app_usage": para "Curso de Udemy" (ver
        # SUBCATEGORY_UDEMY) — cronómetro igual que Lectura, y tiempo real
        # medido en el PC (TimerSession.SOURCE_PC_USAGE) en vez de a mano.
        # "Idiomas" (SUBCATEGORY_LANGUAGE) no usa ninguna de las dos, va
        # por su propio mecanismo de vídeos secuenciados (CourseModule).
        CATEGORY_STUDY: ["timer", "app_usage"],
        CATEGORY_SPORT: ["timer", "pose_tracking"],
        CATEGORY_WORK: ["timer", "app_usage"],
        CATEGORY_AVOID: [],
    }

    # Subcategorías de "Deporte": filtran qué ejercicios del catálogo
    # (Exercise.body_area) aparecen al entrenar.
    SUBCATEGORY_UPPER_BODY = "upper_body"
    SUBCATEGORY_LOWER_BODY = "lower_body"
    SUBCATEGORY_RUNNING = "running"
    # Subtipo temporal para probar ejercicios de calentamiento/estiramiento
    # por camara (jumping jacks, de momento) antes de decidir como se
    # engancha de verdad (idea: quitar este subtipo suelto y meter estos
    # ejercicios al principio/final de las tareas de Deporte en su lugar).
    SUBCATEGORY_WARMUP = "warmup"
    SPORT_SUBCATEGORY_CHOICES = [
        (SUBCATEGORY_UPPER_BODY, "Tren superior"),
        (SUBCATEGORY_LOWER_BODY, "Tren inferior"),
        (SUBCATEGORY_RUNNING, "Running"),
        (SUBCATEGORY_WARMUP, "Estiramientos y calentamientos"),
    ]

    # Subcategoría de "Lectura" (CATEGORY_WORK): de momento solo hay una
    # — "Estudio", "Estiramientos" y "Otro" existieron pero nunca se
    # usaron de verdad (Estudio ya tiene su propia categoría, y los
    # estiramientos se hacen por cámara en Deporte), así que se quitaron.
    # Se deja como lista de un elemento (en vez de un valor suelto) para
    # que Task.subcategory, el formulario y time_stats seguir montándose
    # igual que antes, sin casos especiales.
    #
    # Puede además usar el tiempo real en una app externa (Adobe,
    # Kindle…) cuando hay plugin nativo instalado — ver
    # TimerSession.SOURCE_APP_USAGE — o en el PC vía la extensión de
    # Chrome — ver TimerSession.SOURCE_PC_USAGE y watch_keyword.
    SUBCATEGORY_READING = "reading"
    FOCUS_SUBCATEGORY_CHOICES = [
        (SUBCATEGORY_READING, "Lectura"),
    ]

    # Cómo se sigue una tarea de Lectura (CATEGORY_WORK / SUBCATEGORY_READING):
    # - freestyle (de toda la vida): cronómetro manual (target_minutes) o la
    #   extensión de Chrome vigilando watch_keyword en el PDF que tengas en
    #   primer plano (ver workout_kind). No sabe en qué página vas.
    # - plan: visor de PDF propio (pdf.js) embebido a pantalla completa, con
    #   seguimiento de página real — ver reading_last_page/reading_target_weeks
    #   /reading_current_page y Task.record_reading_page/reading_plan_status.
    #   Ambos modos comparten subcategory='reading'; este campo es el que los
    #   distingue, igual que Plan.study_subtype distingue Idiomas de Estudio
    #   normal.
    READING_MODE_FREESTYLE = "freestyle"
    READING_MODE_PLAN = "plan"
    READING_MODE_CHOICES = [
        (READING_MODE_FREESTYLE, "Freestyle (cronómetro / extensión)"),
        (READING_MODE_PLAN, "Plan de lectura (visor propio con página)"),
    ]
    # Tope de velocidad para record_reading_page: como mínimo tienen que
    # pasar estos segundos reales por página, de media, entre el primer
    # aviso de una racha y el último -- no es ya solo "impedir un scroll
    # instantáneo", es que la página guardada tenga que ver con un rato
    # de verdad sentado leyendo. P.ej. con 45s/página, 33 páginas piden al
    # menos 24-25 minutos reales antes de darse por leídas -- ese margen
    # es aposta generoso (nadie necesita ir más despacio de eso para leer
    # de verdad), pero si de normal lees más rápido que esto, verás el
    # progreso quedarse un poco por detrás de por dónde vas de verdad
    # hasta que pase el tiempo mínimo -- se pone al día solo, sin perder
    # nada (ver el intervalo de "catch-up" en task_reading.html).
    READING_SECONDS_PER_PAGE = 45

    # Tope de segundos que un solo aviso del visor puede sumar al tiempo
    # real de lectura (ver record_reading_page/_flush_reading_time). El
    # hueco entre dos avisos es normalmente unos segundos/minutos (has
    # pasado de página), pero puede ser de HORAS o DÍAS si cierras el PDF
    # y sigues leyendo otro día -- sin este tope ese hueco se contaría
    # como si hubieras estado leyendo sin parar todo ese tiempo. 10
    # minutos es de sobra para una página lenta o una pausa corta real.
    READING_TIME_GAP_CAP_SECONDS = 600

    # Subcategorías de "Estudio": de momento solo "Idiomas" — un curso con
    # vídeos organizados por nivel (ver Plan.STUDY_SUBTYPE_LANGUAGE y
    # CourseModule), en vez del hábito diario simple de siempre. En
    # blanco sigue siendo el Estudio de toda la vida, sin curso detrás.
    SUBCATEGORY_LANGUAGE = "language"
    # Curso de Udemy: seguimiento de tiempo real (ver watch_keyword más
    # abajo y TimerSession.SOURCE_PC_USAGE) en vez de vídeos secuenciados
    # — la extensión de Chrome cuenta el tiempo con la pestaña de Udemy
    # en primer plano, y detecta el "100% completado" que reporta Udemy
    # para dar la tarea por terminada del todo (ver
    # Task.finish_recurring_series).
    SUBCATEGORY_UDEMY = "udemy"
    STUDY_SUBCATEGORY_CHOICES = [
        (SUBCATEGORY_LANGUAGE, "Idiomas"),
        (SUBCATEGORY_UDEMY, "Curso de Udemy"),
    ]

    SUBCATEGORY_CHOICES = SPORT_SUBCATEGORY_CHOICES + FOCUS_SUBCATEGORY_CHOICES + STUDY_SUBCATEGORY_CHOICES

    # Mismo MCER que Plan.CEFR_LEVEL_CHOICES (ver constante de módulo
    # arriba) — expuesto también aquí para leer/validar Task.level sin
    # tener que importar Plan.
    CEFR_LEVEL_CHOICES = CEFR_LEVEL_CHOICES

    WEEKDAYS = [
        ("0", "Lunes"),
        ("1", "Martes"),
        ("2", "Miércoles"),
        ("3", "Jueves"),
        ("4", "Viernes"),
        ("5", "Sábado"),
        ("6", "Domingo"),
    ]

    title = models.CharField(max_length=255)
    # Nace en una fase muy anterior del proyecto sin llegar a usarse —
    # revivido para "General": marca si esta tarea suelta quiere
    # cronómetro (ver workout_kind) en vez de ser una tarea normal de
    # marcar hecha/no hecha a mano. default=False para que cualquier
    # creación (incluida la de Plan.sync_task(), que nunca lo pone a
    # True) la rellene sola sin que nadie tenga que acordarse de ella.
    wants_timer = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    category = models.CharField(
        max_length=16,
        choices=CATEGORY_CHOICES,
        default=CATEGORY_GENERAL,
        db_index=True,
        help_text="Tipo de tarea. Define qué extras tendrá disponibles (timer, pose tracking, etc).",
    )
    subcategory = models.CharField(
        max_length=16,
        choices=SUBCATEGORY_CHOICES,
        blank=True,
        help_text="Deporte → qué entrenar. Enfoque → qué cronometrar. En el resto no se usa.",
    )
    # Idioma + nivel de ESTA tarea concreta — independiente de si viene de
    # un Plan de Idiomas o se crea suelta a mano (subcategory=SUBCATEGORY_LANGUAGE
    # en cualquiera de los dos casos). Un solo nivel, no un rango como en
    # Plan.level_from/level_to: una tarea es un vídeo del día, no un curso
    # entero. Si la tarea viene de Plan.sync_task(), este nivel es el del
    # CourseModule que toca hoy — puede no coincidir con el nivel objetivo
    # del plan (level_to), que es el destino final, no dónde estás ahora.
    language_name = models.CharField(max_length=40, blank=True)
    level = models.CharField(max_length=2, blank=True, choices=CEFR_LEVEL_CHOICES)
    target_minutes = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Objetivo en minutos para tareas de Enfoque (category='work'). Ej. 60 para 'leer una hora'.",
    )
    # Solo con subcategory=SUBCATEGORY_UDEMY: qué palabra buscar en el
    # título de la pestaña activa para saber que estás viendo ESTE curso
    # y no otro (ver la extensión de Chrome). En blanco por defecto se
    # sugiere el propio título de la tarea al crearla, pero es editable
    # por si el nombre del curso en Udemy no coincide literalmente.
    watch_keyword = models.CharField(
        max_length=120, blank=True,
        help_text="Solo para 'Curso de Udemy': palabra o frase que debe aparecer en el "
                   "título de la pestaña de Udemy para contar el tiempo en esta tarea.",
    )
    # Solo con subcategory=SUBCATEGORY_UDEMY: si el curso tiene poco
    # vídeo con sonido continuo (más ejercicios que clases habladas),
    # desactiva esto para que la extensión de Chrome cuente el tiempo
    # con la pestaña en primer plano + sin inactividad de ratón/teclado
    # (igual que ya hace con un PDF de Lectura, ver
    # IDLE_DETECTION_SECONDS en chrome-extension/background.js), en vez
    # de exigir que la pestaña esté sonando (tab.audible) como hace por
    # defecto -- esa exigencia es lo que distingue "viendo la clase" de
    # "en el Q&A/reseñas sin ver nada", pero un curso de solo-ejercicios
    # casi nunca suena, así que con el valor por defecto no contaría
    # nada. Solo se configura desde el objetivo de un Plan (ver
    # PlanItem.watch_requires_audio y Plan._study_target_fields) -- un
    # Udemy freestyle nunca lleva palabra clave (ver study_link_error
    # más abajo), así que ahí esto no tiene efecto.
    watch_requires_audio = models.BooleanField(default=True)
    # Se pone al llamar finish_recurring_series() — señal inequívoca de
    # "esto era un curso y Udemy lo reportó al 100%", distinta de
    # is_done/repeat=NONE (que también los ponen otras cosas, como una
    # tarea suelta sin repetición). La usa Plan.auto_close_expired() para
    # saber cuándo cerrar (y enseñar la recompensa de) un plan que iba
    # detrás de este curso.
    course_completed_at = models.DateTimeField(null=True, blank=True)
    # Cuánto lleva completado el curso SEGÚN Udemy (0-100), no cuántos
    # días de estudio has cumplido (eso ya lo mide Plan/PlanItem con las
    # Occurrence de siempre). Lo rellena la extensión de Chrome leyendo
    # las fracciones "x/x" de "Contenido del curso" (ver
    # detectCourseProgressInPage en background.js) cada vez que hace la
    # comprobación de "¿ya está al 100%?" — así de paso se puede enseñar
    # una barra de "cuánto te queda del curso" en la pantalla del plan
    # (ver PlanItem.current_course_progress_pct) en vez de nada hasta
    # que se termina del todo. None mientras no se ha detectado ninguna
    # fracción todavía (curso recién creado, o Udemy cambió su
    # maquetación y la extensión no la reconoce) — no se asume 0, que
    # sería mentir sobre "no has visto nada".
    course_progress_pct = models.PositiveIntegerField(null=True, blank=True)
    # Las fracciones en bruto detrás de course_progress_pct: lecciones
    # vistas / lecciones totales (suma de todos los "x/y" de "Contenido
    # del curso"), para poder enseñar "12 de 40 clases · quedan 28".
    course_lessons_done = models.PositiveIntegerField(null=True, blank=True)
    course_lessons_total = models.PositiveIntegerField(null=True, blank=True)
    youtube_video_id = models.CharField(
        max_length=255, blank=True,
        help_text="ID o URL de un vídeo de YouTube (ej. 'dQw4w9WgXcQ' o el enlace completo — "
                   "se limpia solo al guardar). Si está puesto, esta tarea NO pasa por el "
                   "selector de ejercicios ni por el temporizador: al darle a play se va "
                   "directa al vídeo embebido, y al terminar se marca como hecha ella sola. "
                   "Streaming en directo: no se descarga ni se guarda nada.",
    )
    youtube_playlist_id = models.CharField(
        max_length=255, blank=True,
        help_text="Alternativa a youtube_video_id: ID o URL de una playlist de YouTube "
                   "(el trozo list=... del enlace). Junto con target_minutes o "
                   "target_video_count decide cuándo se da por vista.",
    )
    target_video_count = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Solo con youtube_playlist_id: cuántos vídeos de la lista hay que ver "
                   "para dar la tarea por hecha (ej. 5). Si no se pone y tampoco hay "
                   "target_minutes, se da por hecha al terminar 1 vídeo de la lista.",
    )
    playlist_start_index = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Solo con youtube_playlist_id: en qué posición de la lista (0 = el "
                   "primero) hay que empezar a reproducir hoy, para no volver siempre al "
                   "principio de la playlist. Lo mantienen al día tanto Plan.sync_task() "
                   "(objetivos de Plan) como _spawn_next() (tareas sueltas repetidas), "
                   "usando playlist_videos_cache de abajo. En blanco = empezar por el "
                   "principio (playlist sin seguimiento, o recién puesta).",
    )
    # Caché de la playlist de arriba, propia de esta tarea (independiente
    # de PlanItem.playlist_videos_cache: una tarea suelta no tiene
    # PlanItem detrás) -- misma idea y mismo formato: la lista ORDENADA
    # de vídeos que tenía la playlist la última vez que se sincronizó,
    # con su duración -- [{"video_id": "...", "duration_seconds": 933}, ...].
    # Se rellena en sync_playlist_videos(), llamado al guardar la tarea
    # (vista o API) cuando youtube_playlist_id está puesto -- es lo que
    # permite saber "¿esto era el último vídeo de la lista?" para cerrar
    # la tarea sola (ver finish_recurring_series) y arrastrar la
    # posición día a día en vez de reiniciar la playlist cada vez.
    playlist_videos_cache = models.JSONField(default=list, blank=True)
    playlist_synced_at = models.DateTimeField(null=True, blank=True)
    # Cómo se completa una tarea de Deporte. Se elige al crearla, no cada
    # vez que se entrena: es una decisión de "qué es esta tarea", no de
    # "qué me apetece hoy". Qué modos valen depende del subtipo — el
    # conteo con cámara no tiene sentido en tren inferior, y correr no
    # se hace con circuitos.
    SPORT_MODE_CAMERA = "camera"
    SPORT_MODE_CIRCUIT = "circuit"
    SPORT_MODE_VIDEO = "video"
    SPORT_MODE_CHOICES = [
        (SPORT_MODE_CAMERA, "Conteo con la cámara"),
        (SPORT_MODE_CIRCUIT, "Circuito"),
        (SPORT_MODE_VIDEO, "Vídeo"),
    ]
    # Qué modos se ofrecen en cada subtipo. Running no aparece: se
    # resuelve siempre importando la actividad (Health Connect) o a mano.
    SPORT_MODES_BY_SUBCATEGORY = {
        "upper_body": [SPORT_MODE_CAMERA, SPORT_MODE_CIRCUIT, SPORT_MODE_VIDEO],
        "lower_body": [SPORT_MODE_CAMERA, SPORT_MODE_CIRCUIT, SPORT_MODE_VIDEO],
    }
    sport_mode = models.CharField(
        max_length=20, choices=SPORT_MODE_CHOICES, blank=True, default="",
        help_text="Solo Deporte (tren superior/inferior): cómo se completa la tarea.",
    )

    has_local_video = models.BooleanField(
        default=False,
        help_text="Alternativa a youtube_video_id: el vídeo es un archivo del propio "
                   "dispositivo (elegido con el selector nativo), no de YouTube. El "
                   "archivo en sí NO vive aquí — cada aparato guarda el suyo por su "
                   "cuenta (IndexedDB en la web, el plugin nativo en la app), este campo "
                   "solo le dice al servidor 'esta tarea se resuelve con un vídeo local' "
                   "para que workout_kind la trate como 'video' igual que si tuviera uno "
                   "de YouTube. Solo para category='sport'/'work' — Estudio no lo usa.",
    )

    # ------------------------------------------------ Plan de lectura (PDF)
    # Solo con category=CATEGORY_WORK, subcategory=SUBCATEGORY_READING y
    # reading_mode=READING_MODE_PLAN — ver workout_kind, reading_plan_status
    # y record_reading_page. El PDF en sí NO vive aquí, igual que
    # has_local_video: cada navegador lo guarda por su cuenta (File System
    # Access API + IndexedDB, ver tasks/reading_plan_form.html y
    # tasks/task_reading.html) — reading_pdf_key es solo la clave para
    # encontrar ese archivo guardado.
    reading_mode = models.CharField(
        max_length=10, choices=READING_MODE_CHOICES, blank=True, default=READING_MODE_FREESTYLE,
        help_text="Solo Lectura: 'freestyle' (cronómetro/extensión, de toda la vida) o "
                   "'plan' (visor de PDF propio con seguimiento de página).",
    )
    reading_pdf_key = models.CharField(
        # "reading-" + crypto.randomUUID() (36 caracteres) = 44 -- 40 se
        # quedaba corto y la vista lo truncaba en silencio ([:40] en
        # reading_plan_form), guardando una clave distinta de la que de
        # verdad quedó en IndexedDB del navegador (siempre la completa,
        # sin truncar) — el visor nunca la encontraba ("No hay ningún
        # PDF guardado..."). 64 deja margen de sobra.
        max_length=64, blank=True,
        help_text="Solo reading_mode='plan': clave para encontrar el archivo del PDF "
                   "guardado en IndexedDB en ESTE navegador — se genera al elegir el "
                   "archivo (ver reading_plan_form.html) y no cambia aunque se reelija "
                   "el PDF, para que el visor lo siga encontrando.",
    )
    reading_first_page = models.PositiveIntegerField(
        default=1,
        help_text="Solo reading_mode='plan': página real donde empieza el contenido, "
                   "después de portada/índice/prólogo... Con esto el ritmo y el % leído "
                   "(ver reading_plan_status) se calculan sobre las páginas de contenido "
                   "de verdad, no desde la 1 -- y el visor abre aquí la primera vez que "
                   "se abre el libro, en vez de en la portada. 1 por defecto (el libro "
                   "empieza al principio del archivo, como si no se hubiera puesto nada).",
    )
    reading_last_page = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Solo reading_mode='plan': última página real del contenido (excluye "
                   "glosario/apéndices) — cuándo se considera terminado el libro de "
                   "verdad, y con qué se compara reading_current_page.",
    )
    reading_target_weeks = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Solo reading_mode='plan': en cuántas semanas se quiere terminar el "
                   "libro. Con reading_last_page y reading_current_page decide el ritmo "
                   "(páginas/día) que enseña el visor — ver reading_plan_status. El plan "
                   "NO se cierra solo al pasar este plazo, sigue hasta la página real.",
    )
    reading_current_page = models.PositiveIntegerField(
        default=0,
        help_text="Solo reading_mode='plan': última página reportada por el visor de PDF "
                   "(ver record_reading_page) — mismo patrón que playlist_start_index, "
                   "pero de página en vez de vídeo. Se arrastra de un día al siguiente "
                   "vía _spawn_next, nunca se reinicia sola.",
    )
    reading_progress_at = models.DateTimeField(
        null=True, blank=True,
        help_text="Solo reading_mode='plan': cuándo se guardó por última vez "
                   "reading_current_page — referencia para topar cuánto puede "
                   "avanzar de golpe en un solo aviso del visor (ver "
                   "record_reading_page). Sin esto, arrastrar la barra de scroll "
                   "o pasar rapidísimo por encima de todas las páginas hasta el "
                   "final del archivo se guardaba igual que haberlo leído entero.",
    )
    reading_day_start_page = models.PositiveIntegerField(
        default=0,
        help_text="Solo reading_mode='plan': reading_current_page en el momento en que "
                   "se generó ESTA instancia diaria (ver _spawn_next) -- punto de partida "
                   "para medir cuánto se ha leído hoy en concreto (ver reading_today_status), "
                   "ya que reading_current_page es acumulado de todo el libro y no se reinicia.",
    )
    reading_day_goal = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Solo reading_mode='plan': páginas que tocaba leer HOY para ir al ritmo, "
                   "fijadas una sola vez al generarse esta instancia diaria (ver "
                   "_reading_day_goal_for) y nunca recalculadas mientras se lee -- así "
                   "reading_today_status puede pasar de 100% si se lee de más, en vez de "
                   "recortarse como reading_plan_status. None si todavía no se ha calculado "
                   "(instancias de antes de que existiera este campo -- ver "
                   "ensure_reading_day_goal).",
    )
    reading_day_baseline_date = models.DateField(
        null=True, blank=True,
        help_text="Solo reading_mode='plan': de qué día de calendario son "
                   "reading_day_start_page/reading_day_goal ahora mismo -- se rellenaba "
                   "asumiendo que solo se leía en el due_date de la instancia (ver "
                   "_spawn_next), pero el visor se puede abrir cualquier día desde "
                   "Planes (ver reading_session_ready). Sin este campo, leer 'adelantado' "
                   "un día que no tocaba dejaba esas páginas contando para el objetivo "
                   "del día que sí tocaba en cuanto llegaba. ensure_reading_day_goal "
                   "compara esto con hoy en cada apertura del visor y, si no coincide, "
                   "reinicia el punto de partida a la página actual -- cada día de "
                   "calendario acaba con su propio tramo, se haya leído el día que tocaba "
                   "o de más.",
    )
    reading_started_on = models.DateField(
        null=True, blank=True,
        help_text="Solo reading_mode='plan': fecha en que se creó el plan — con "
                   "reading_target_weeks fija el plazo, y con la fecha real de "
                   "finalización decide reading_final_pct si se termina tarde.",
    )
    reading_completed_at = models.DateTimeField(
        null=True, blank=True,
        help_text="Se pone al llegar de verdad a reading_last_page — señal de que el "
                   "plan se cerró (repeat pasa a REPEAT_NONE), distinta de is_done.",
    )
    reading_final_pct = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="% guardado al terminar el plan: 100 si se llegó a tiempo o antes, "
                   "menos si se tardó de más — ver record_reading_page para la fórmula "
                   "exacta (plazo previsto ÷ tiempo real).",
    )
    reading_pending_seconds = models.PositiveIntegerField(
        default=0,
        help_text="Solo reading_mode='plan': tiempo real de lectura ya medido (ver "
                   "record_reading_page) pero todavía sin volcar a un TimerSession — "
                   "se vacía en _flush_reading_time (Terminar sesión de hoy, o al "
                   "terminar el libro). Sin esto, el Plan de lectura no dejaba ningún "
                   "minuto en ningún sitio y 'Tiempo acumulado' (tasks/time_stats.py) "
                   "no tenía nada que sumar de Lectura salvo el cronómetro suelto.",
    )
    reading_time_anchor_at = models.DateTimeField(
        null=True, blank=True,
        help_text="Solo reading_mode='plan': última vez que record_reading_page midió "
                   "un hueco de tiempo real, aparte de reading_progress_at (que solo se "
                   "mueve cuando la página avanza de verdad, y no sirve para esto: "
                   "reutilizarlo recontaría el mismo hueco dos veces en un aviso que no "
                   "avanza página) — se actualiza en CADA aviso, avance o no.",
    )

    # Objetivos que permiten que la tarea se marque sola al importar de
    # Health Connect. Sin ninguno puesto, cualquier actividad importada
    # la da por hecha; con ellos, solo cuenta si de verdad se cumplió.
    target_steps = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Solo andar: pasos que hay que dar para darla por hecha (ej. 10000).",
    )
    target_distance_km = models.FloatField(
        null=True, blank=True,
        help_text="Solo running/andar: km que hay que recorrer para darla por hecha.",
    )
    max_pace_seconds_per_km = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Solo running: ritmo máximo permitido en segundos por km (ej. 360 = "
                   "6:00/km). Correr más lento que esto no cuenta como hecha. Se guarda "
                   "en segundos y no en minutos decimales porque 5,5 min/km se lee mal "
                   "(¿5:30 o 5:50?), mientras que 330 s/km es exacto.",
    )

    # Presets de ritmo en lenguaje llano — para quien no corre, "6:30/km"
    # no dice nada. El número entre paréntesis es solo para quien SÍ lo
    # sabe leer; la etiqueta lleva el peso para todos los demás.
    PACE_PRESETS = [
        (900, "Paseo tranquilo (15:00/km)"),
        (720, "Paseo normal (12:00/km)"),
        (600, "Andar a paso ligero (10:00/km)"),
        (480, "Trote suave (8:00/km)"),
        (390, "Correr (6:30/km)"),
        (330, "Correr a buen ritmo (5:30/km)"),
        (270, "Correr rápido (4:30/km)"),
        (210, "Correr muy rápido (3:30/km)"),
    ]
    PACE_PRESET_SECONDS = {seconds for seconds, _ in PACE_PRESETS}
    due_date = models.DateField(null=True, blank=True)
    due_time = models.TimeField(null=True, blank=True,
        help_text="Hora límite. Si pasa sin marcarla, se auto-marca como no hecha.")
    repeat = models.CharField(max_length=10, choices=REPEAT_CHOICES, default=REPEAT_NONE)
    interval = models.PositiveIntegerField(default=1)
    custom_days = models.CharField(max_length=20, blank=True)
    is_important = models.BooleanField(default=False)
    avoid_success_label = models.CharField(
        max_length=32, blank=True,
        help_text="Antitareas: texto del botón de la notificación para \"lo he evitado\". "
                   "En blanco usa \"Sigo con la racha\".",
    )
    avoid_fail_label = models.CharField(
        max_length=32, blank=True,
        help_text="Antitareas: texto del botón para \"he caído\". En blanco usa \"Romper racha\".",
    )
    avoid_question = models.CharField(
        max_length=120, blank=True,
        help_text="Antitareas: la pregunta de la notificación. En blanco usa \"¿Has caído hoy?\".",
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="tasks",
        help_text="Dueño de la tarea. Hoy siempre es el usuario por defecto "
                   "(ver tasks/utils.py:get_current_user) — preparado para cuando haya login real.",
    )

    series_id = models.UUIDField(default=uuid.uuid4, editable=False)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(
        null=True, blank=True,
        help_text="Borrado suave: si se borra de verdad, el otro dispositivo no puede "
                   "enterarse al sincronizar y la resucitaría.",
    )
    series_start_date = models.DateField(null=True, blank=True, editable=False)

    is_done = models.BooleanField(default=False)
    expired = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)
    reopened_at = models.DateTimeField(
        null=True, blank=True,
        help_text="Cuándo devolviste la tarea a pendientes a mano. Sirve para que el "
                   "barrido automático no vuelva a cerrarla en el acto.",
    )
    started_at = models.DateTimeField(
        null=True, blank=True,
        help_text="Cuándo entraste a hacer la tarea (entreno, vídeo, lectura...). Si "
                   "entras antes de la hora límite, no se auto-marca como no hecha "
                   "mientras la estás haciendo (ver Task.STARTED_GRACE_HOURS).",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["is_done", "due_date", "due_time", "-created_at"]

    def __str__(self):
        return self.title

    @property
    def category_capabilities(self):
        """Lista de extras disponibles para esta categoría."""
        return self.CATEGORY_CAPABILITIES.get(self.category, [])

    @property
    def current_streak(self):
        """
        Racha actual de esta serie — el mismo cálculo que ya se usa en
        Rachas, pero puesto aquí para que la tarjeta de la tarea lo
        pueda enseñar sin que haya que ir a buscarlo a otra pantalla.
        Solo tiene sentido para tareas que se repiten: una suelta no
        tiene "racha".
        """
        if self.repeat == self.REPEAT_NONE:
            return 0
        return Occurrence.streak_stats(self.series_id)["current_streak"]

    @property
    def plan(self):
        """El plan que generó esta tarea, si viene de uno."""
        return Plan.objects.filter(
            task_series_id=self.series_id, deleted_at__isnull=True
        ).first()

    @property
    def workout_kind(self):
        """
        Qué clase de sesión abre esta tarea, para que el botón de la lista
        no prometa algo que no va a pasar.

        En Deporte manda `sport_mode`, elegido al crear la tarea: cámara,
        circuito o vídeo. Antes esto se deducía del subtipo (y un vídeo
        puesto anulaba todo lo demás), lo que dejaba sin usar la cámara y
        los circuitos en cuanto había un vídeo — ahora es una elección
        explícita y no se pisan entre sí.
        """
        if self.category == self.CATEGORY_SPORT:
            if self.subcategory == self.SUBCATEGORY_RUNNING:
                return "distance"   # se importa de Health Connect, o a mano
            if self.sport_mode == self.SPORT_MODE_VIDEO:
                return "video"
            if self.sport_mode == self.SPORT_MODE_CIRCUIT:
                return "timer"
            if self.sport_mode == self.SPORT_MODE_CAMERA:
                return "camera"
            # Sin modo elegido (tareas de antes de este campo): se
            # mantiene el comportamiento que tenían, para no romperlas.
            if self.subcategory == self.SUBCATEGORY_LOWER_BODY:
                return "timer"
            return "camera"

        # Fuera de Deporte, un vídeo puesto define la tarea entera.
        if self.youtube_video_id or self.youtube_playlist_id or self.has_local_video:
            return "video"
        if self.category == self.CATEGORY_GENERAL:
            # Cronómetro opcional para una tarea suelta cualquiera — ver
            # wants_timer (campo que existía sin usarse desde hace mucho,
            # reutilizado aquí en vez de añadir uno nuevo). Sin marcar,
            # General se queda como lista de tareas de toda la vida.
            return "focus" if self.wants_timer else None
        if self.category == self.CATEGORY_WORK:
            if self.subcategory == self.SUBCATEGORY_READING and self.reading_mode == self.READING_MODE_PLAN:
                # Plan de lectura: visor de PDF propio, con su propia
                # pantalla (ver task_reading) — se completa sola al llegar
                # a reading_last_page, y mientras tanto se puede "Terminar
                # sesión de hoy" desde ahí mismo (ver task_reading_save).
                return "reading"
            if self.subcategory == self.SUBCATEGORY_READING and (self.watch_keyword or "").strip():
                # Lectura con palabra clave puesta: la vigila la extensión
                # de Chrome (PDF en primer plano) exactamente igual que un
                # curso de Udemy — se completa sola al llegar al objetivo
                # del día, nada que pulsar aquí. Sin palabra clave, sigue
                # siendo un Enfoque normal con cronómetro manual (o el
                # plugin de la app móvil) — no romper eso por defecto.
                return "auto"
            return "focus"          # temporizador de Enfoque: leer, estudiar, estirar…
        if self.category == self.CATEGORY_STUDY and self.subcategory == self.SUBCATEGORY_UDEMY:
            # Curso de Udemy: se completa sola cuando la extensión de
            # Chrome manda minutos suficientes — no hay nada que pulsar
            # aquí, igual que running ("distance") no ofrece nada porque
            # se completa sola al importar de Health Connect.
            return "auto"
        return None

    @property
    def auto_progress(self):
        """
        Progreso de HOY hacia el objetivo de una tarea que se completa
        sola (workout_kind "auto": Lectura con extensión/Curso de Udemy
        vía TimerSession.SOURCE_PC_USAGE, o "distance": Running vía
        WorkoutSession) — para poder enseñar una minibarra en la lista
        sin mandar al usuario a comprobarlo en otro sitio.

        Devuelve None si la tarea no es de este tipo, ya está resuelta,
        o no tiene ningún objetivo numérico que medir (sin objetivo no
        hay "cuánto falta" que dibujar). En otro caso, un dict con pct
        (0-100, recortado por arriba), y label ya formateado para la
        plantilla.

        Mismo criterio de "hoy" y de qué sesiones cuentan que usan
        api.focus_save (pc_usage) y api.workout_import_running/
        _plan_context al decidir si marcar la tarea hecha — si cambia
        ahí, hay que cambiarlo aquí también para que la barra no
        prometa algo distinto de lo que realmente hace falta.
        """
        kind = self.workout_kind
        if kind not in ("auto", "distance") or self.is_done or self.expired:
            return None
        hoy = timezone.localtime(timezone.now()).date()

        if kind == "auto":
            if not self.target_minutes:
                return None
            minutos_hoy = TimerSession.objects.filter(
                user=self.user, series_id=self.series_id,
                source=TimerSession.SOURCE_PC_USAGE,
                recorded_at__date=hoy, deleted_at__isnull=True,
            ).aggregate(m=Sum("minutes"))["m"] or 0
            pct = min(100, round(100 * minutos_hoy / self.target_minutes))
            return {
                "pct": pct,
                "label": f"{minutos_hoy}/{self.target_minutes} min",
            }

        # kind == "distance": running, por distancia o por pasos —
        # el ritmo mínimo (si lo hay) solo filtra qué sesiones cuentan,
        # no tiene su propia barra.
        if not self.target_distance_km and not self.target_steps:
            return None
        sesiones_hoy = WorkoutSession.objects.filter(
            user=self.user, series_id=self.series_id,
            recorded_at__date=hoy, deleted_at__isnull=True,
        )
        if self.target_distance_km:
            max_pace = self.max_pace_seconds_per_km
            km_hoy = sum(ws.distance_km for ws in sesiones_hoy if ws.distance_km)
            # El ritmo se comprueba en MEDIA sobre el día entero, no
            # sesión por sesión: el Detector de Actividad tarda un rato
            # en "engancharse" a la velocidad real al empezar a andar
            # (una caminata a ritmo constante puede arrancar marcando
            # 16 min/km y bajar a 12 min/km en el propio primer tramo),
            # así que exigir el ritmo en cada sesión suelta descartaba
            # caminatas hechas bien enteras por culpa de ese arranque.
            # Las sesiones sin duración (el resumen del día que manda
            # health-sync.js cuando no hay sesión propia) no se pueden
            # cronometrar, así que no entran en el cálculo del ritmo,
            # pero sí suman a la distancia una vez el ritmo ya cuadra.
            if max_pace is not None and km_hoy:
                ritmo_hoy = day_average_pace(sesiones_hoy)
                if ritmo_hoy is not None and ritmo_hoy > max_pace:
                    km_hoy = 0.0
            pct = min(100, round(100 * km_hoy / self.target_distance_km))
            return {
                "pct": pct,
                "label": f"{km_hoy:.1f}/{self.target_distance_km:g} km",
            }

        pasos_hoy = sesiones_hoy.aggregate(p=Sum("steps"))["p"] or 0
        pct = min(100, round(100 * pasos_hoy / self.target_steps))
        return {
            "pct": pct,
            "label": f"{pasos_hoy}/{self.target_steps} pasos",
        }

    @property
    def is_avoid(self):
        """
        True si es una antitarea (category='avoid'). Se calcula desde
        category en vez de ser un campo aparte — "antitarea" es un tipo
        de tarea más, no un check que se pone encima de otro tipo. Se
        queda como propiedad de solo lectura para no tener que tocar
        mark_expired()/mark_failed()/las plantillas, que ya comprobaban
        task.is_avoid antes de este cambio.
        """
        return self.category == self.CATEGORY_AVOID

    def has_capability(self, capability):
        return capability in self.category_capabilities

    def custom_days_list(self):
        if not self.custom_days:
            return []
        return [d.strip() for d in self.custom_days.split(",") if d.strip()]

    def custom_days_labels(self):
        labels = dict(self.WEEKDAYS)
        return [labels[d] for d in sorted(self.custom_days_list(), key=int)]

    def repeat_summary(self):
        n = self.interval or 1
        if self.repeat == self.REPEAT_NONE:
            return ""
        if self.repeat == self.REPEAT_DAILY:
            return "Cada día" if n == 1 else f"Cada {n} días"
        if self.repeat == self.REPEAT_WEEKLY:
            return "Cada semana" if n == 1 else f"Cada {n} semanas"
        if self.repeat == self.REPEAT_MONTHLY:
            return "Cada mes" if n == 1 else f"Cada {n} meses"
        if self.repeat == self.REPEAT_YEARLY:
            return "Cada año" if n == 1 else f"Cada {n} años"
        if self.repeat == self.REPEAT_CUSTOM:
            days = ", ".join(self.custom_days_labels())
            prefix = "Cada semana" if n == 1 else f"Cada {n} semanas"
            return f"{prefix} ({days})" if days else prefix
        return ""

    def deadline_datetime(self):
        """
        Momento límite como datetime naive, o None si no hay hora.

        Si la tarea no tiene fecha, la hora se ancla al día en que se
        creó. Sin ese ancla habría que comparar horas sueltas, y eso se
        rompe al pasar la medianoche: una tarea de las 19:45 de ayer,
        mirada a las 00:45, daba "21:45 < 00:45 = falso" y no vencía
        nunca. Con el ancla hay un instante absoluto y la comparación
        funciona siempre.
        """
        if not self.due_time:
            return None
        import datetime
        day = self.due_date
        if day is None:
            if not self.created_at:
                return None
            day = timezone.localtime(self.created_at).date()
        return datetime.datetime.combine(day, self.due_time)

    # Margen que se da a una antitarea DESPUÉS de la hora límite antes de
    # darla por buena sola. La notificación salta a la hora límite; este
    # margen es el rato que tienes para contestarla. Sin él, la tarea se
    # resolvía en el mismo instante en que sonaba el aviso, y contestar no
    # servía de nada.
    AVOID_GRACE_HOURS = 2
    # Si entraste a la tarea ANTES de su hora límite, tienes este margen
    # extra para terminarla y guardarla sin que se cierre como no hecha.
    STARTED_GRACE_HOURS = 3

    def resolve_datetime(self):
        """Momento a partir del cual la tarea se resuelve sola.

        Para una tarea normal es la hora límite. Para una antitarea es la
        hora límite MÁS el margen: a la hora límite salta el aviso, y solo
        si no contestas en ese rato se da por evitada.
        """
        dl = self.deadline_datetime()
        if dl is None:
            return None
        if self.is_avoid:
            return dl + timedelta(hours=self.AVOID_GRACE_HOURS)
        return dl

    def mark_started(self):
        """Apunta la primera entrada a la tarea, solo si es antes del límite."""
        if self.is_done or self.expired or self.started_at:
            return
        limit = self.resolve_datetime()
        now = timezone.now()
        now_local = timezone.localtime(now).replace(tzinfo=None)
        if limit is None or now_local > limit:
            return
        self.started_at = now
        self.save(update_fields=["started_at"])

    def in_progress_grace(self, limit, now_local):
        """True si empezaste antes del límite y aún estás dentro del margen."""
        if not self.started_at:
            return False
        started = timezone.localtime(self.started_at).replace(tzinfo=None)
        return started <= limit and now_local <= limit + timedelta(hours=self.STARTED_GRACE_HOURS)

    def is_overdue(self):
        """True si ya toca resolverla sola y sigue pendiente."""
        if self.is_done or self.expired:
            return False
        limit = self.resolve_datetime()
        if limit is None:
            return False
        now = timezone.localtime(timezone.now()).replace(tzinfo=None)
        if now > limit and self.in_progress_grace(limit, now):
            return False
        return now > limit

    def minutes_remaining(self):
        """Minutos hasta el deadline (negativo = ya pasó)."""
        dl = self.deadline_datetime()
        if dl is None:
            return None
        now = timezone.localtime(timezone.now()).replace(tzinfo=None)
        return int((dl - now).total_seconds() / 60)

    def next_due_date(self):
        if not self.due_date:
            return None
        base = self.due_date
        n = self.interval or 1

        if self.repeat == self.REPEAT_CUSTOM:
            marked_days = sorted(int(d) for d in self.custom_days_list())
            if not marked_days:
                return None
            anchor = self.series_start_date or base
            anchor_monday = anchor - timedelta(days=anchor.weekday())
            base_monday = base - timedelta(days=base.weekday())
            week_index = (base_monday - anchor_monday).days // 7
            current_weekday = base.weekday()
            if week_index % n == 0:
                for candidate in marked_days:
                    if candidate > current_weekday:
                        return base + timedelta(days=candidate - current_weekday)
            weeks_left = n - (week_index % n)
            next_monday = base_monday + timedelta(weeks=weeks_left)
            return next_monday + timedelta(days=marked_days[0])

        if self.repeat == self.REPEAT_DAILY:
            return base + timedelta(days=n)
        if self.repeat == self.REPEAT_WEEKLY:
            return base + timedelta(weeks=n)
        if self.repeat == self.REPEAT_MONTHLY:
            total = (base.month - 1) + n
            year = base.year + total // 12
            month = total % 12 + 1
            try:
                return base.replace(year=year, month=month)
            except ValueError:
                return base.replace(year=year, month=month, day=28)
        if self.repeat == self.REPEAT_YEARLY:
            try:
                return base.replace(year=base.year + n)
            except ValueError:
                return base.replace(year=base.year + n, day=28)
        return None

    def save(self, *args, **kwargs):
        if self.due_time is None:
            # Sin hora puesta, fin del día: así la notificación y el
            # cierre automático siempre tienen un momento límite.
            self.due_time = _dt.time(23, 59)
        if self.series_start_date is None and self.due_date is not None:
            self.series_start_date = self.due_date
        raw = (self.youtube_video_id or "").strip()
        if raw:
            m = _YOUTUBE_ID_RE.search(raw)
            self.youtube_video_id = m.group(1) if m else raw
        raw_pl = (self.youtube_playlist_id or "").strip()
        if raw_pl:
            m = _YOUTUBE_PLAYLIST_ID_RE.search(raw_pl)
            self.youtube_playlist_id = m.group(1) if m else raw_pl
        super().save(*args, **kwargs)

    def sync_playlist_videos(self):
        """
        Refresca playlist_videos_cache desde la API de YouTube -- mismo
        mecanismo que PlanItem.sync_playlist_videos(), pero para una
        tarea suelta (sin Plan detrás). Se llama SOLO al guardar la
        tarea (vista o API) cuando youtube_playlist_id está puesto o ha
        cambiado -- nunca en cada carga de la lista, que sería
        demasiado caro/lento llamando a la API de YouTube ahí.

        Sin youtube_playlist_id, limpia la caché (por si la tarea tenía
        una playlist antes y se ha quitado). Si la API de YouTube falla
        (sin YOUTUBE_API_KEY, cuota agotada, sin conexión...), se deja
        la caché tal cual estaba -- sin caché, la tarea simplemente no
        puede detectar "último vídeo" y se comporta como antes de que
        existiera esto (la playlist entera, sin cierre automático).
        """
        from .youtube_search import YouTubeSearchError, get_videos_details, list_playlist_items

        if not self.youtube_playlist_id:
            if self.playlist_videos_cache or self.playlist_synced_at:
                self.playlist_videos_cache = []
                self.playlist_synced_at = None
                self.save(update_fields=["playlist_videos_cache", "playlist_synced_at"])
            return

        try:
            items = list_playlist_items(self.youtube_playlist_id, max_results=500)
            video_ids = [it["video_id"] for it in items if it.get("video_id")]
            details = get_videos_details(video_ids) if video_ids else {}
        except YouTubeSearchError:
            return

        cache = []
        for vid in video_ids:
            d = details.get(vid) or {}
            if d.get("embeddable") is False:
                continue
            cache.append({"video_id": vid, "duration_seconds": d.get("duration_seconds")})

        self.playlist_videos_cache = cache
        self.playlist_synced_at = timezone.now()
        self.save(update_fields=["playlist_videos_cache", "playlist_synced_at"])

    def study_link_error(self):
        """
        Una tarea suelta (freestyle) de Estudio sin nada de verdad
        enlazado es indistinguible de una tarea General -- nunca hay
        forma de comprobar que se ha hecho ni de cerrarla sola cuando
        se acaba. Devuelve el mensaje de error, o None si esta bien.

        Udemy es la unica excepcion a proposito: en freestyle NUNCA
        lleva palabra clave (eso es cosa de un Plan) -- una tarea
        suelta de Udemy es el habito generico "pasar tiempo estudiando
        en Udemy", que la extension de Chrome ya sabe trackear sin
        palabra clave (cualquier pestaña de udemy.com).

        Usado tanto por el formulario web (tasks/views.py) como por la
        API (tasks/api.py) -- una sola fuente de verdad para esta regla.
        """
        if self.category != self.CATEGORY_STUDY:
            return None
        if self.subcategory == self.SUBCATEGORY_UDEMY:
            return None
        if not (self.youtube_video_id or self.youtube_playlist_id):
            return (
                "Una tarea de Estudio necesita algo enlazado para saber qué estudiar y "
                "cuándo se ha terminado: un vídeo o una playlist de YouTube (o Udemy, sin "
                "palabra clave, para un hábito genérico sin curso concreto)."
            )
        return None

    def is_last_playlist_video(self, index):
        """
        True si `index` (0-based) es el último vídeo conocido de
        playlist_videos_cache -- o si no hay caché fiable, en cuyo caso
        se opta por NO decir nunca "es el último" (falsos negativos,
        nunca falsos positivos: mejor que seguir repitiendo tareas ya
        acabadas a cerrar una serie que en realidad seguía teniendo
        vídeos por ver).
        """
        total = len(self.playlist_videos_cache or [])
        if not total:
            return False
        return index >= total - 1

    def _reading_pace(self, as_of_date):
        """
        Piezas compartidas por reading_plan_status y el objetivo diario
        (_reading_day_goal_for): páginas de contenido que quedan y días
        que quedan hasta el plazo, medidas desde `as_of_date` -- para que
        el objetivo de un día concreto se calcule con la fecha de ESE día
        (ver _spawn_next) y no siempre con "hoy".

        None si no es un plan de lectura con los tres datos que hacen
        falta (reading_last_page, reading_target_weeks, reading_started_on).
        """
        if self.reading_mode != self.READING_MODE_PLAN:
            return None
        if not (self.reading_last_page and self.reading_target_weeks and self.reading_started_on):
            return None
        # Sobre las páginas de CONTENIDO (reading_first_page..reading_last_page),
        # no desde la página 1 del archivo -- si no, un libro que empieza de
        # verdad en la página 12 (portada/índice/prólogo antes) infla el
        # total y hace parecer que falta más ritmo del que hace falta.
        first_page = self.reading_first_page or 1
        total_pages = max(1, self.reading_last_page - first_page + 1)
        pages_read = max(0, min(self.reading_current_page, self.reading_last_page) - first_page + 1)
        pages_left = max(0, total_pages - pages_read)
        deadline = self.reading_started_on + timedelta(weeks=self.reading_target_weeks)
        days_left = (deadline - as_of_date).days
        return {
            "first_page": first_page,
            "total_pages": total_pages,
            "pages_read": pages_read,
            "pages_left": pages_left,
            "deadline": deadline,
            "days_left": days_left,
        }

    @property
    def reading_plan_status(self):
        """
        Estado del Plan de lectura para pintarlo en el visor: páginas que
        faltan, días que quedan hasta el plazo objetivo, y el ritmo
        (páginas/día) recalculado con eso — se recalcula en caliente cada
        vez, nunca se guarda (si no, habría que corregirlo cada día aunque
        nadie tocara el plan). Distinto de reading_today_status: esto es
        el ritmo GENERAL para todo el libro, siempre recortado al 100%;
        reading_today_status es solo el objetivo de HOY, fijado una vez,
        que sí puede pasar de 100% si se lee de más.

        None si esto no es un plan de lectura con los tres datos que hacen
        falta para calcular algo (reading_last_page, reading_target_weeks,
        reading_started_on) — p.ej. un plan recién creado antes de
        guardarse del todo.
        """
        today = timezone.localtime(timezone.now()).date()
        pace = self._reading_pace(today)
        if pace is None:
            return None
        # Con el plazo ya cumplido (days_left <= 0) el ritmo se calcula
        # igual sobre 1 día -- no tiene sentido dividir por 0 ni por un
        # número negativo, y así el visor puede seguir enseñando "cuánto
        # te falta leer hoy para ponerte al día" en vez de un error.
        pace_per_day = pace["pages_left"] / max(pace["days_left"], 1)
        return {
            "pages_left": pace["pages_left"],
            "days_left": pace["days_left"],
            "is_overdue": pace["days_left"] < 0,
            "pace_per_day": round(pace_per_day, 1),
            "deadline": pace["deadline"],
            "current_page": self.reading_current_page,
            "last_page": self.reading_last_page,
            "first_page": pace["first_page"],
            "pct": min(100, round(100 * pace["pages_read"] / pace["total_pages"])),
        }

    def _reading_day_goal_for(self, as_of_date):
        """
        Cuántas páginas tocaba leer en el día `as_of_date` para ir al
        ritmo -- se llama UNA vez, al generarse esa instancia diaria (ver
        _spawn_next y ensure_reading_day_goal), y el resultado se guarda
        en reading_day_goal en vez de recalcularse mientras se lee: así
        "hoy" tiene un objetivo fijo que sí se puede superar.

        None si no hay datos suficientes (ver _reading_pace); 0 si ya no
        queda ninguna página por leer (nada que pedir para hoy).
        """
        pace = self._reading_pace(as_of_date)
        if pace is None:
            return None
        if pace["pages_left"] <= 0:
            return 0
        return max(1, math.ceil(pace["pages_left"] / max(pace["days_left"], 1)))

    @property
    def reading_today_status(self):
        """
        Progreso de HOY frente al objetivo fijado al generarse esta
        instancia diaria (reading_day_goal) -- a diferencia de
        reading_plan_status, que se recalcula en caliente y siempre se
        recorta al 100%, este objetivo se queda fijo durante todo el día,
        así que el % puede pasar de 100 sin ningún tope si se lee de más
        (decisión con Alex: mejor dejar ver que vas por delante que
        recortar la barra como si el objetivo de hoy ya no sirviera).

        None si esto no es un plan de lectura, si esta instancia todavía
        no tiene un objetivo de hoy calculado (ver ensure_reading_day_goal)
        o si due_date todavía no ha llegado (ver reading_session_ready):
        leer "adelantado" desde Planes antes de que toque es una sesión
        extra -- cuenta para reading_plan_status (el % del libro entero),
        pero no se representa en NINGÚN día concreto, ni ese día ni el que
        sí toca cuando llegue (decisión con Alex, 2026-09-28).
        """
        if self.reading_mode != self.READING_MODE_PLAN:
            return None
        if not self.reading_session_ready:
            return None
        if self.reading_day_goal is None:
            return None
        pages_today = max(0, self.reading_current_page - self.reading_day_start_page)
        goal = self.reading_day_goal
        if goal:
            pct = round(100 * pages_today / goal)
        else:
            # Objetivo 0 (no quedaba nada por leer cuando se generó el
            # día) -- cualquier página leída ya es "de más".
            pct = 100 if pages_today else 0
        return {
            "pages_today": pages_today,
            "goal": goal,
            "pct": pct,  # sin tope -- puede pasar de 100 si se lee de más
            "bar_pct": min(100, pct),  # para el ancho de la barra -- que no se salga del hueco
        }

    @property
    def reading_session_ready(self):
        """
        Si esta instancia de un plan de lectura YA se puede cerrar con
        "Terminar sesión de hoy" -- solo el día que toca (custom_days) o
        si se quedó atrasada, nunca uno futuro.

        Antes no había ningún tope aquí: el visor se puede abrir
        cualquier día desde "Planes" (esa es la gracia -- se puede leer
        cuando se quiera, sin esperar a que la tarea "toque" para
        entrar), pero cerrar la sesión de una instancia con due_date
        futuro hacía avanzar la serie igual que si hubiera tocado de
        verdad (ver _spawn_next) -- "adelantar" una lectura del finde así
        se comía el día real de la semana siguiente, que aparecía ya
        hecho (completado en el pasado) sin que nadie lo hubiera hecho
        ese día. Esto NO afecta a poder seguir pasando páginas
        (record_reading_page/task_reading_progress) ni a abrir el visor
        (task_reading) ningún día -- solo a cerrar el día con este botón.
        """
        if self.reading_mode != self.READING_MODE_PLAN or not self.due_date:
            return True
        today = timezone.localtime(timezone.now()).date()
        return self.due_date <= today

    def ensure_reading_day_goal(self):
        """
        Deja reading_day_start_page/reading_day_goal listos para HOY --
        se llama cada vez que se abre el visor (ver task_reading). No
        hace nada si ya hay un objetivo puesto Y es de hoy
        (reading_day_baseline_date == hoy, el camino normal: _spawn_next
        ya lo deja puesto para el due_date de la instancia).

        Si NO es de hoy, se recalcula tomando el estado actual como
        "inicio del día" -- pero SOLO si due_date ya ha llegado (ver
        reading_session_ready): abrir el visor antes de que toque es una
        sesión extra (ver reading_today_status), así que aquí no se toca
        nada -- ni se enseña ni se guarda ningún "inicio del día" para
        ese rato, precisamente para que esas páginas no queden fijadas
        como punto de partida de NINGÚN día (ni ese, ni el que sí toque
        cuando llegue). Antes esto se recalculaba fuera cual fuera el día,
        y una lectura adelantada del finde se colaba como "ya
        leído hoy" en cuanto llegaba el día real (decisión con Alex,
        2026-09-28).

        Una vez due_date sí ha llegado, se recalcula cada vez que cambia
        el día de calendario respecto a la última vez (
        reading_day_baseline_date) -- esto cubre tanto una instancia
        "legacy" de antes de que existiera este campo (None) como ir
        atrasado (se abrió ayer, sigue sin cerrarse, hoy toca recalcular
        el ritmo) como, sobre todo, que entre el momento en que se generó
        esta instancia (_spawn_next, con due_date todavía en el futuro)
        y que de verdad tocara, hubiera sesiones extra que subieron
        reading_current_page sin pasar por aquí -- de ahí que
        _spawn_next YA NO fije reading_day_baseline_date, para que este
        primer paso por aquí en el día real siempre recalcule desde la
        página en la que estés de verdad, descontando lo leído de más.
        """
        if self.reading_mode != self.READING_MODE_PLAN or not self.reading_session_ready:
            return
        today = timezone.localtime(timezone.now()).date()
        if self.reading_day_goal is not None and self.reading_day_baseline_date == today:
            return
        goal = self._reading_day_goal_for(today)
        if goal is None:
            return
        self.reading_day_start_page = self.reading_current_page
        self.reading_day_goal = goal
        self.reading_day_baseline_date = today
        self.save(update_fields=["reading_day_start_page", "reading_day_goal", "reading_day_baseline_date"])

    def recompute_reading_day_goal(self):
        """
        Recalcula el objetivo de HOY sin tocar reading_day_start_page --
        para cuando se edita el plazo/última página desde
        reading_plan_form a media semana: lo leído hoy sigue siendo lo
        leído hoy, pero el objetivo debe reflejar el ritmo nuevo. Quien
        llama a esto es quien guarda (añadir "reading_day_goal" al
        update_fields del save()).
        """
        if self.reading_mode != self.READING_MODE_PLAN:
            return
        today = timezone.localtime(timezone.now()).date()
        self.reading_day_goal = self._reading_day_goal_for(today)

    def record_reading_page(self, page):
        """
        Guarda la página actual de un Plan de lectura -- la llama el
        visor (tasks/task_reading.html) en cada cambio de página, mismo
        patrón que playlist_start_index/PlaylistProgress con los vídeos.

        Nunca retrocede (una página anterior reportada por error, o una
        recarga de una pestaña vieja, no debe "deshacer" el avance real).

        Dos topes para que esto siga significando "hasta aquí he leído de
        verdad" y no "hasta aquí he scrolleado":
        - Nunca pasa de reading_last_page (la última página REAL del
          contenido), aunque se reporte una página mayor -- si el PDF
          trae epílogo/apéndices/anexos detrás, o si se arrastra el
          scroll hasta el final físico del archivo, se guarda como si
          te hubieras parado justo en el final del contenido, no en la
          página del archivo donde aterrizó el scroll.
        - No puede avanzar más de un ritmo de READING_SECONDS_PER_PAGE
          segundos reales por página, contando desde el aviso anterior
          (reading_progress_at) -- no es ya un tope "de emergencia" para
          un scroll instantáneo, es que el número de páginas guardado
          tenga que corresponder con un rato de verdad transcurrido. El
          primer aviso de todos (reading_progress_at todavía vacío) no
          tiene con qué compararse, así que nunca se topa.

        Al llegar de verdad a reading_last_page, cierra el plan entero:
        para la serie (repeat=REPEAT_NONE, como finish_recurring_series,
        pero sin tocar course_completed_at -- ese campo es de Udemy) y
        calcula reading_final_pct con "plazo previsto ÷ tiempo real":
        100% si se llegó a tiempo o antes, menos si se tardó de más (ver
        Task.reading_plan_status para el ritmo mientras tanto, que es
        solo informativo y no afecta a esta cuenta).

        De paso mide tiempo real de lectura (reading_pending_seconds,
        con tope READING_TIME_GAP_CAP_SECONDS por aviso) para que
        tasks.time_stats tenga algo que sumar en Lectura — antes de
        esto el Plan de lectura no dejaba ningún minuto en ningún
        sitio, solo página y fechas. Se vuelca a un TimerSession en
        _flush_reading_time (Terminar sesión de hoy, o al terminar el
        libro aquí mismo), no en cada aviso.

        Devuelve True si esta llamada ha terminado el libro.
        """
        if self.reading_mode != self.READING_MODE_PLAN:
            return False
        page = max(0, int(page))
        now = timezone.now()
        if self.reading_progress_at:
            elapsed = max(0, (now - self.reading_progress_at).total_seconds())
            # entero hacia abajo a propósito -- con menos de
            # READING_SECONDS_PER_PAGE transcurridos esto da 0, así que
            # ese aviso no avanza nada (en vez de un "mínimo 1 página" que
            # dejaría colarse una página de más en cada aviso, por poco
            # que haya pasado -- con el "ping" periódico del visor cada
            # pocos segundos eso habría deshecho el tope entero).
            max_advance = int(elapsed // self.READING_SECONDS_PER_PAGE)
            page = min(page, self.reading_current_page + max_advance)
        if self.reading_last_page:
            page = min(page, self.reading_last_page)
        # Tiempo real: aparte de reading_progress_at (que solo se mueve
        # si la página avanza de verdad, ver más abajo) -- este anclaje
        # se mueve en CADA aviso, avance o no, para no recontar el mismo
        # hueco dos veces en un aviso que no llega a mover la página.
        if self.reading_time_anchor_at:
            gap = max(0, (now - self.reading_time_anchor_at).total_seconds())
            self.reading_pending_seconds += min(int(gap), self.READING_TIME_GAP_CAP_SECONDS)
        self.reading_time_anchor_at = now
        today = timezone.localtime(now).date()
        if not self.reading_started_on:
            self.reading_started_on = today
        # El reloj de reading_progress_at solo se reinicia cuando de
        # verdad se acepta una página nueva (o en el primerísimo aviso,
        # sin el que comparar) -- si se reiniciara en CADA aviso (incluido
        # uno que no avanza nada, como el "ping" periódico de arriba), el
        # tiempo transcurrido nunca llegaría a acumularse lo bastante
        # como para soltar la siguiente página, y esto se quedaría
        # atascado para siempre en cuanto tocara el tope.
        if page > self.reading_current_page or not self.reading_progress_at:
            self.reading_progress_at = now
        self.reading_current_page = max(self.reading_current_page, page)
        finished = bool(self.reading_last_page) and self.reading_current_page >= self.reading_last_page
        update_fields = [
            "reading_started_on", "reading_current_page", "reading_progress_at",
            "reading_pending_seconds", "reading_time_anchor_at",
        ]
        if finished and not self.reading_completed_at:
            dias_reales = max(1, (today - self.reading_started_on).days)
            semanas_reales = dias_reales / 7
            pct = 100
            if self.reading_target_weeks:
                pct = min(100, round(100 * self.reading_target_weeks / semanas_reales))
            self.reading_completed_at = timezone.now()
            self.reading_final_pct = pct
            self.repeat = self.REPEAT_NONE
            update_fields += ["reading_completed_at", "reading_final_pct", "repeat"]
        self.save(update_fields=update_fields)
        if finished:
            self._flush_reading_time()
            self.mark_done()
        return finished

    def _flush_reading_time(self):
        """
        Vuelca reading_pending_seconds a un TimerSession de verdad, para
        que tasks.time_stats.time_totals() lo sume como cualquier otra
        sesión de Lectura. La llaman task_reading_save ("Terminar sesión
        de hoy") y record_reading_page al terminar el libro -- mismos
        dos puntos de cierre que ya existían, no hace falta un tercero.

        Menos de 1 minuto pendiente no crea ningún TimerSession (no
        aportaría nada al total): se queda acumulado para la próxima
        vez. No hace nada si no hay nada pendiente.
        """
        if self.reading_pending_seconds < 60:
            return
        minutes = self.reading_pending_seconds // 60
        TimerSession.objects.create(
            task=self, user=self.user, series_id=self.series_id,
            subcategory=self.subcategory, source=TimerSession.SOURCE_MANUAL,
            minutes=minutes,
        )
        self.reading_pending_seconds -= minutes * 60
        self.save(update_fields=["reading_pending_seconds"])

    def _spawn_next(self):
        if self.repeat == self.REPEAT_NONE or not self.due_date:
            return
        next_date = self.next_due_date()
        # Idempotente a propósito: marcar, desmarcar y volver a marcar
        # llamaba aquí dos veces y dejaba DOS tareas idénticas en el
        # futuro. Si ya existe la de esa fecha en esta serie, no se crea
        # otra.
        if Task.objects.filter(series_id=self.series_id, due_date=next_date).exists():
            return
        Task.objects.create(
            title=self.title, notes=self.notes,
            category=self.category, subcategory=self.subcategory,
            due_date=next_date, due_time=self.due_time,
            repeat=self.repeat, interval=self.interval,
            custom_days=self.custom_days, is_important=self.is_important,
            avoid_success_label=self.avoid_success_label,
            avoid_fail_label=self.avoid_fail_label,
            avoid_question=self.avoid_question,
            series_id=self.series_id, series_start_date=self.series_start_date,
            user=self.user,
            # Estos se añadieron después de escribir esta función, y se
            # quedaban fuera — una tarea repetida con vídeo fijo, o de
            # running con objetivo, perdía todo eso en su siguiente
            # instancia. Los planes se recomponen solos en cada carga
            # (ver Plan.sync_all_tasks), pero una tarea suelta con estos
            # campos puestos a mano solo tiene este sitio para no perderlos.
            sport_mode=self.sport_mode,
            youtube_video_id=self.youtube_video_id,
            youtube_playlist_id=self.youtube_playlist_id,
            has_local_video=self.has_local_video,
            # Se quedaba fuera igual que los de arriba (ver comentario de
            # este mismo bloque) -- una tarea repetida de Udemy o de
            # Lectura con PDF perdia la palabra clave justo al generar el
            # dia siguiente, asi que la extension de Chrome dejaba de
            # verla como "trackeable" a partir del segundo dia.
            watch_keyword=self.watch_keyword,
            # Mismo motivo que watch_keyword: sin propagarlo aquí, la
            # barra de "cuánto llevas del curso" se reiniciaría a "sin
            # datos" cada mañana en cuanto se generase la tarea del día
            # siguiente, aunque Udemy siga reportando el mismo curso a
            # medias -- ver Task.record_course_progress.
            course_progress_pct=self.course_progress_pct,
            course_lessons_done=self.course_lessons_done,
            course_lessons_total=self.course_lessons_total,
            target_minutes=self.target_minutes,
            target_video_count=self.target_video_count,
            target_steps=self.target_steps,
            target_distance_km=self.target_distance_km,
            max_pace_seconds_per_km=self.max_pace_seconds_per_km,
            # Igual que watch_keyword arriba -- sin esto, una tarea suelta
            # repetida con playlist de YouTube perdia la cache y la
            # posicion cada dia, y volvia a reproducir desde el video 1
            # en vez de seguir por donde iba (y nunca podia detectar
            # "es el ultimo video" -- ver Task.is_last_playlist_video).
            playlist_start_index=self.playlist_start_index,
            playlist_videos_cache=self.playlist_videos_cache,
            playlist_synced_at=self.playlist_synced_at,
            # Plan de lectura: igual razón que watch_keyword/playlist_*
            # arriba -- sin esto, una tarea de Lectura con plan perdía el
            # PDF, la página por la que ibas y el plazo en cuanto se
            # generaba el día siguiente, y volvía a verse como recién
            # creada cada mañana.
            reading_mode=self.reading_mode,
            reading_pdf_key=self.reading_pdf_key,
            reading_first_page=self.reading_first_page,
            reading_last_page=self.reading_last_page,
            reading_target_weeks=self.reading_target_weeks,
            reading_current_page=self.reading_current_page,
            reading_progress_at=self.reading_progress_at,
            reading_started_on=self.reading_started_on,
            # Objetivo de HOY (de la instancia que se está creando, no de
            # esta) fijado de una vez -- ver _reading_day_goal_for/
            # reading_today_status. reading_day_start_page es el punto de
            # partida: la página en la que se quedó HOY se convierte en
            # el "inicio del día" de mañana.
            #
            # reading_day_baseline_date NO se fija aquí (se deja en su
            # default, None) a propósito -- a diferencia de start_page/
            # goal, que son una estimación válida para cuando llegue
            # next_date, ensure_reading_day_goal usa este campo para
            # decidir si hace falta recalcular. Si se fijara ya a
            # next_date, y entre hoy y next_date hubiera sesiones extra
            # (ver reading_session_ready) que subieran reading_current_page,
            # el primer open() del día real vería reading_day_baseline_date
            # == hoy y se saltaría el recálculo -- las páginas de más se
            # colarían como "ya leídas hoy". Dejándolo en None, ese primer
            # open() del día real siempre recalcula de cero.
            reading_day_start_page=self.reading_current_page,
            reading_day_goal=self._reading_day_goal_for(next_date),
        )

    def _record_occurrence(self, result, auto_expired=False, minutes_watched=None):
        """
        Registra el resultado del día en Occurrence, de forma idempotente.

        Si la tarea tiene due_date, el resultado de ESE día es un hecho
        único que se puede corregir, no un registro que se apila: marcar
        hecha, desmarcar y volver a marcar deja UNA sola ocurrencia con el
        último valor, no tres. Antes se creaba una fila cada vez, lo que
        descuadraba las rachas (ya había un duplicado real en la BD).

        Además es lo que permite que web y móvil resuelvan el mismo día
        por separado sin duplicarlo: los dos hacen update_or_create sobre
        la misma clave y el resultado final es el mismo.

        Sin due_date (tareas sueltas de "cuando pueda") no hay día al que
        anclarlo, así que ahí sí se crea una fila normal.

        minutes_watched es opcional y solo lo mandan las tareas de vídeo
        (ver task_video.html) — se guarda tal cual para que salga en el
        historial/estadísticas, no cambia si el día cuenta como hecho o no
        (eso ya lo decidió quien llamó a mark_done()).
        """
        if self.due_date is None:
            return Occurrence.objects.create(
                task=self, series_id=self.series_id, title=self.title,
                result=result, due_date=None, auto_expired=auto_expired,
                user=self.user, minutes_watched=minutes_watched,
            )
        obj, _ = Occurrence.objects.update_or_create(
            series_id=self.series_id, due_date=self.due_date,
            defaults=dict(
                task=self, title=self.title, result=result,
                auto_expired=auto_expired, user=self.user,
                minutes_watched=minutes_watched,
            ),
        )
        return obj

    def mark_done(self, minutes_watched=None):
        self.is_done = True
        self.expired = False
        self.completed_at = timezone.now()
        self.reopened_at = None
        self.save()
        self._record_occurrence(Occurrence.RESULT_DONE, minutes_watched=minutes_watched)
        self._spawn_next()
        # Si esta tarea viene de un Plan (Deporte/Estudio/General) y
        # esta sesión era justo la que lo terminaba (ver
        # Plan.close_if_finished), se cierra AQUÍ, no en silencio en la
        # próxima carga de la lista (ver Plan.auto_close_expired, que
        # sigue existiendo como red de seguridad para cuando nadie pasó
        # por aquí). Se devuelve el plan recién cerrado para que quien
        # llamó pueda mandar a la pantalla de cierre/celebración
        # (plan_close) en vez de a donde fuera a mandar normalmente —
        # None si no venía de ningún plan o si esta sesión no lo
        # terminaba todavía.
        plan = self.plan
        if plan and plan.close_if_finished():
            return plan
        return None

    def reopen(self, delete_sessions=False):
        """
        Deshace el haber marcado la tarea, dejándolo TODO como estaba.

        Es distinto de mark_not_done(), que registra un "no la hice" (y
        por tanto cuenta como fallo en la racha). Esto es "me equivoqué al
        marcarla", así que hay que revertir las tres cosas que provocó
        marcarla:

          1. La tarea vuelve a pendiente.
          2. Se BORRA la ocurrencia de ese día — no se cambia a "no
             hecha", se elimina. Si no, la racha seguiría contando ese día
             como registrado y las estadísticas no volverían a su sitio.
          3. Se borra la instancia siguiente que se generó al marcarla
             (mañana, la semana que viene...), siempre que nadie la haya
             tocado todavía. Sin esto quedaría una tarea duplicada
             flotando en el futuro.

        Las sesiones de entreno se conservan por defecto: las
        repeticiones las hiciste de verdad aunque te equivocaras al
        marcar la tarea.
        """
        # 3. La instancia futura de la serie, si sigue intacta.
        if self.repeat != self.REPEAT_NONE and self.due_date:
            (
                Task.objects.filter(
                    series_id=self.series_id,
                    due_date__gt=self.due_date,
                    is_done=False,
                    expired=False,
                )
                .exclude(pk=self.pk)
                .delete()
            )

        # 2. La ocurrencia de este día.
        if self.due_date is not None:
            Occurrence.objects.filter(series_id=self.series_id, due_date=self.due_date).delete()
        else:
            Occurrence.objects.filter(series_id=self.series_id, task=self).delete()

        if delete_sessions:
            self.workout_sessions.all().delete()

        # 1. La tarea vuelve a estar disponible.
        self.is_done = False
        self.expired = False
        self.completed_at = None
        self.reopened_at = timezone.now()
        self.started_at = None
        self.save()

    def finish_recurring_series(self):
        """
        Da la tarea de hoy por hecha y detiene la serie entera: no se
        genera ninguna instancia futura (ver _spawn_next, que ya no hace
        nada en cuanto repeat=REPEAT_NONE).

        Pensado para "Curso de Udemy" (ver SUBCATEGORY_UDEMY): cuando la
        extensión de Chrome detecta que Udemy reporta el curso al 100%,
        ya no tiene sentido seguir pidiendo "estudiar este curso" cada
        día que tocaba — a diferencia de mark_done(), que asume que la
        serie sigue y prepara la siguiente repetición.

        Idempotente: si ya estaba en REPEAT_NONE y ya hecha, no hace nada
        raro (mark_done() con la tarea ya hecha simplemente la repite,
        pero aquí ni se llega a eso).
        """
        if self.repeat != self.REPEAT_NONE or not self.course_completed_at:
            self.repeat = self.REPEAT_NONE
            self.course_completed_at = self.course_completed_at or timezone.now()
            self.save(update_fields=["repeat", "course_completed_at"])
        if not self.is_done:
            self.mark_done()

    def record_course_progress(self, pct, done=None, total=None):
        """
        Guarda el % de curso de Udemy detectado por la extensión de
        Chrome (ver checkCourseCompletion/detectCourseProgressInPage en
        background.js), para poder enseñar una barra de "cuánto te
        queda del curso" en la pantalla del plan.

        Independiente de finish_recurring_series()/course_completed_at:
        ese sigue siendo el único que cierra la tarea/serie, y sigue
        usando su propia detección (todas las fracciones cuadran) — más
        estricta a propósito. Esto es solo para enseñar un número
        mientras tanto, así que un 99% aquí no cierra nada por su cuenta.
        """
        try:
            pct = max(0, min(100, round(float(pct))))
        except (TypeError, ValueError):
            return
        self.course_progress_pct = pct
        fields = ["course_progress_pct"]
        try:
            if done is not None and total is not None and int(total) > 0:
                self.course_lessons_total = int(total)
                self.course_lessons_done = max(0, min(int(done), int(total)))
                fields += ["course_lessons_done", "course_lessons_total"]
        except (TypeError, ValueError):
            pass
        self.save(update_fields=fields)

    def mark_not_done(self):
        """
        Se usa para "Desmarcar" una tarea ya hecha (volver a pendiente) y
        también para loguear un "no" desde pendientes sin resolver el día.
        A propósito NO genera la siguiente ocurrencia — si lo hiciera,
        "Desmarcar" ya no podría deshacer nada (is_done volvería a True
        en el mismo instante). Para antitareas, el botón "he caído hoy"
        usa mark_failed() en su lugar, que sí resuelve el día.
        """
        self.is_done = False
        self.expired = False
        self.completed_at = None
        self.reopened_at = timezone.now()
        self.save()
        self._record_occurrence(Occurrence.RESULT_NOT_DONE)

    def mark_failed(self):
        """
        Para antitareas: "he caído hoy". A diferencia de mark_not_done()
        (que deja is_done=False porque también sirve para deshacer una
        tarea ya hecha), esto SÍ resuelve el día como mark_done() —
        is_done=True y genera la siguiente ocurrencia si se repite. Sin
        esto, una antitarea diaria se quedaría colgada la primera vez que
        cayeras, en vez de seguir pidiéndote el check-in cada noche.
        """
        self.is_done = True
        self.expired = False
        self.completed_at = timezone.now()
        self.reopened_at = None
        self.save()
        self._record_occurrence(Occurrence.RESULT_NOT_DONE)
        self._spawn_next()

    def _record_plan_miss(self):
        """
        Si esta tarea es la sesión de un plan y expira sin haber jugado
        nada, el día queda invisible para el plan: sin ninguna
        WorkoutSession ese día, successes_and_streak() ni se entera de
        que faltó — no cuenta como fallo, no mueve la racha, no dispara
        el deload (bajar el objetivo tras varios fallos seguidos). Aquí
        se deja constancia expresa: una sesión a 0% por cada ejercicio
        del plan, con el objetivo que tocaba ese día. Si ya hay alguna
        sesión de esta tarea (jugaste algo aunque no llegaras a marcarla
        hecha a tiempo), no se toca nada — esto es solo para el silencio
        total.
        """
        plan = self.plan
        if not plan or WorkoutSession.objects.filter(task=self).exists():
            return
        for item in plan.items.select_related("exercise").filter(exercise__isnull=False):
            t = item.current_target()
            WorkoutSession.objects.create(
                task=self, user=self.user, plan=plan, series_id=self.series_id,
                exercise=item.exercise.slug,
                total_reps=0, total_sets=0, session_duration_seconds=0,
                target_sets=t.get("sets"), target_reps=t.get("reps"),
                target_seconds=t.get("seconds"),
            )

    def mark_expired(self):
        """
        Llamado cuando pasa la hora límite sin que se haya marcado nada.

        Para una tarea normal, silencio = no lo hiciste (fallo). Para una
        antitarea (is_avoid=True) es justo al revés: silencio = no caíste,
        así que cuenta como éxito. La única diferencia está en qué
        resultado se guarda; is_done/expired se comportan igual en ambos
        casos (la tarea se resuelve sola, sin que tengas que tocar nada).
        """
        self.is_done = True
        self.expired = True
        self.completed_at = timezone.now()
        self.reopened_at = None
        self.save()
        result = Occurrence.RESULT_DONE if self.is_avoid else Occurrence.RESULT_NOT_DONE
        self._record_occurrence(result, auto_expired=True)
        self._record_plan_miss()
        self._spawn_next()

    @classmethod
    def for_today(cls, qs=None):
        """
        Las tareas pendientes que TOCAN HOY.

        Al resolver una tarea repetida se genera ya la del día siguiente,
        y sin este filtro aparecía en la lista al instante: podías
        marcarla otra vez el mismo día y contaba doble en las
        estadísticas. Una tarea con fecha futura no es de hoy.

        Las vencidas (fecha pasada y sin resolver) sí se muestran, que
        para eso están pendientes. Y las que no tienen fecha también,
        porque son de "cuando pueda".
        """
        today = timezone.localtime(timezone.now()).date()
        base = qs if qs is not None else cls.objects.all()
        return base.filter(
            models.Q(due_date__isnull=True) | models.Q(due_date__lte=today)
        )

    @classmethod
    def _with_completed_day(cls, qs):
        """
        Día al que pertenece una tarea hecha en la lista de Hechas.

        Normalmente es el de completed_at (o created_at si falta). Pero
        una tarea CADUCADA sola a las 23:59 recibe completed_at = 00:00 del
        día siguiente (ver mark_expired), y así aparecía en la lista de
        Hechas de mañana. Para esas se usa su due_date, que es el día al
        que de verdad pertenecen.
        """
        return qs.annotate(
            _completed_day=Case(
                When(expired=True, due_date__isnull=False, then=F("due_date")),
                default=TruncDate(Coalesce("completed_at", "created_at")),
                output_field=DateField(),
            ),
        )

    @classmethod
    def completed_today(cls, qs=None):
        """
        Lo cerrado hoy.

        La lista de hechas es "lo que he hecho hoy", no un registro
        permanente: con una tarea diaria se iba acumulando una entrada
        por día hasta llenarla de ruido. El historial completo está en
        las estadísticas.

        Antes, una tarea sin completed_at (dato atípico -- creada a mano,
        por fixture, o de antes de que existiera el campo) se colaba
        SIEMPRE, en el "hoy" de cualquier día para siempre, en vez de
        irse igual que las demás -- así es como unas tareas de prueba de
        un fin de semana se quedaban apareciendo como "hechas hoy"
        indefinidamente. Con Coalesce, esa tarea cuenta por su
        created_at (la mejor fecha que tenemos) y se va al día siguiente
        igual que cualquier otra, en vez de tener un día distinto para
        siempre.
        """
        today = timezone.localtime(timezone.now()).date()
        base = qs if qs is not None else cls.objects.all()
        return cls._with_completed_day(
            base.filter(is_done=True)
        ).filter(_completed_day=today)

    # ── Selector Hoy / Esta semana / Este mes / Todas (pantalla de Tareas) ──
    #
    # Un único control que amplía la ventana en ambas secciones a la vez:
    # en Pendientes hacia delante (qué más entra), en Hechas hacia atrás
    # (qué más se ha completado). for_today/completed_today de arriba
    # siguen existiendo tal cual (las usa RANGE_TODAY) para no tocar el
    # comportamiento por defecto que ya había.

    RANGE_TODAY = "today"
    RANGE_WEEK = "week"
    RANGE_MONTH = "month"
    RANGE_ALL = "all"

    RANGE_CHOICES = [
        (RANGE_TODAY, "Hoy"),
        (RANGE_WEEK, "Esta semana"),
        (RANGE_MONTH, "Este mes"),
        (RANGE_ALL, "Todas"),
    ]

    @classmethod
    def _week_bounds(cls, today):
        """Lunes a domingo de la semana de `today` — mismo criterio que
        Occurrence.weekly_completion, para que "esta semana" signifique
        siempre lo mismo en toda la app."""
        start = today - timedelta(days=today.weekday())
        return start, start + timedelta(days=6)

    @classmethod
    def _month_bounds(cls, today):
        """Día 1 al último día del mes de `today`."""
        start = today.replace(day=1)
        if start.month == 12:
            next_month = start.replace(year=start.year + 1, month=1)
        else:
            next_month = start.replace(month=start.month + 1)
        return start, next_month - timedelta(days=1)

    @classmethod
    def for_range(cls, qs=None, range_key=RANGE_TODAY):
        """
        Pendientes según el rango elegido (Hoy/Semana/Mes/Todas).

        Las vencidas y las que no tienen fecha se ven SIEMPRE, en
        cualquier rango: ampliar la ventana es para asomarte a lo que
        viene, no para esconder lo que ya tocaba. Lo único que cambia
        entre rangos es hasta qué fecha futura se deja entrar.
        """
        base = qs if qs is not None else cls.objects.all()
        if range_key == cls.RANGE_ALL:
            return base

        today = timezone.localtime(timezone.now()).date()
        if range_key == cls.RANGE_WEEK:
            _, limit = cls._week_bounds(today)
        elif range_key == cls.RANGE_MONTH:
            _, limit = cls._month_bounds(today)
        else:
            limit = today  # RANGE_TODAY (y cualquier valor no reconocido)

        return base.filter(
            models.Q(due_date__isnull=True) | models.Q(due_date__lte=limit)
        )

    @classmethod
    def completed_in_range(cls, qs=None, range_key=RANGE_TODAY):
        """
        Hechas según el mismo selector, mirando hacia atrás por
        completed_at. Una tarea sin completed_at (dato antiguo/atípico,
        o creada a mano sin pasar por mark_done()) cuenta por su
        created_at en vez de colarse siempre en cualquier rango -- ver
        completed_today, mismo criterio.
        """
        base = qs if qs is not None else cls.objects.all()
        base = cls._with_completed_day(base.filter(is_done=True))

        today = timezone.localtime(timezone.now()).date()
        if range_key == cls.RANGE_ALL:
            start = end = None
        elif range_key == cls.RANGE_WEEK:
            start, end = cls._week_bounds(today)
        elif range_key == cls.RANGE_MONTH:
            start, end = cls._month_bounds(today)
        else:
            start = end = today  # RANGE_TODAY

        if start is not None:
            base = base.filter(_completed_day__range=(start, end))
        return base.order_by("-completed_at", "-created_at")

    # Cuántas fechas se enseñan sueltas antes de esconder el resto tras
    # un "+N más" — ver project_pending_series.
    PROJECTION_PREVIEW = 8
    # Red de seguridad para no iterar sin fin si algo en next_due_date()
    # fuera raro (mismo espíritu que el tope de expire_overdue).
    PROJECTION_MAX_ITER = 60

    @classmethod
    def project_pending_series(cls, tasks, range_key, reference_date=None):
        """
        Sección "Por generar": para cada tarea repetida en `tasks`
        (normalmente pending_tasks ya filtradas), calcula qué más se
        generaría durante el rango elegido — SIN crear ninguna Task
        real. Usa la misma cuenta que _spawn_next()/next_due_date()
        para saber cuándo tocaría la siguiente, pero aquí es solo una
        simulación de cara al usuario: así no se reintroduce el riesgo
        de duplicados que el spawn de una en una evita a propósito.

        "Todas" no tiene un límite de calendario en el que parar de
        contar — ahí, si la tarea sigue repitiéndose, se marca
        infinite=True en vez de intentar enumerar fechas para siempre.

        `reference_date` permite fijar qué día se considera "hoy" (lo
        usa Occurrence.weekly_completion, que a su vez acepta el suyo
        para los tests) — sin esto, el total proyectado de una semana
        simulada con una fecha de referencia distinta a la real quedaría
        descuadrado con sus propios límites de semana.
        """
        today = reference_date or timezone.localtime(timezone.now()).date()
        if range_key == cls.RANGE_WEEK:
            _, limit = cls._week_bounds(today)
        elif range_key == cls.RANGE_MONTH:
            _, limit = cls._month_bounds(today)
        else:
            limit = None  # RANGE_ALL (o "today", que no debería llegar aquí)

        rows = []
        for task in tasks:
            if task.repeat == cls.REPEAT_NONE or not task.due_date:
                continue

            if limit is None:
                shadow = cls(
                    due_date=task.due_date, repeat=task.repeat, interval=task.interval,
                    custom_days=task.custom_days, series_start_date=task.series_start_date,
                )
                if shadow.next_due_date() is None:
                    continue  # ej. "personalizado" sin días marcados: no repite de verdad
                rows.append({
                    "task": task, "infinite": True,
                    "preview_dates": [], "extra_dates": [], "extra_count": 0,
                })
                continue

            dates = []
            cursor = max(task.due_date, today)
            for _ in range(cls.PROJECTION_MAX_ITER):
                shadow = cls(
                    due_date=cursor, repeat=task.repeat, interval=task.interval,
                    custom_days=task.custom_days, series_start_date=task.series_start_date,
                )
                nxt = shadow.next_due_date()
                if nxt is None or nxt > limit:
                    break
                dates.append(nxt)
                cursor = nxt

            if not dates:
                continue
            rows.append({
                "task": task, "infinite": False,
                "preview_dates": dates[:cls.PROJECTION_PREVIEW],
                "extra_dates": dates[cls.PROJECTION_PREVIEW:],
                "extra_count": max(0, len(dates) - cls.PROJECTION_PREVIEW),
            })
        return rows

    @classmethod
    def expire_overdue(cls, dry_run=False):
        """
        Cierra las tareas vencidas y registra su resultado.

        Se repite hasta que no quede nada por cerrar: al cerrar una tarea
        repetida se genera la siguiente, y si esa TAMBIÉN está vencida hay
        que cerrarla igual. Sin este bucle, pasar cuatro días sin abrir la
        app registraba un solo día en vez de cuatro — justo lo contrario
        de lo que se busca, porque los huecos aparecían cuando peor lo
        habías hecho.

        El tope de vueltas es una red de seguridad: si algo hiciera que
        una tarea nunca deje de estar vencida, esto se para en vez de
        colgar la página.
        """
        expired_tasks = []
        for _ in range(400):   # ~un año de tareas diarias atrasadas
            done_this_round = cls._expire_pass(dry_run=dry_run)
            expired_tasks.extend(done_this_round)
            # En dry_run no se marca nada, así que la siguiente vuelta
            # encontraría lo mismo: una pasada es suficiente.
            if not done_this_round or dry_run:
                break
        return expired_tasks

    @classmethod
    def _expire_pass(cls, dry_run=False):
        """
        Una sola pasada. Revisa las tareas pendientes con hora límite y
        marca como expiradas las que ya han pasado esa hora.

        Se llama "en caliente" desde la vista de la lista cada vez que
        se abre la página — así funciona sin depender de un cron
        externo (útil en hostings gratuitos que no lo ofrecen).
        Devuelve la lista de tareas expiradas en esta pasada.
        """
        import datetime as _dt

        now_local = timezone.localtime(timezone.now()).replace(tzinfo=None)
        now_time = now_local.time()

        candidates = cls.objects.filter(is_done=False, expired=False, due_time__isnull=False)

        expired_tasks = []
        for task in candidates:
            # Ahora TODAS las tareas con hora tienen un momento límite
            # absoluto (las que no llevan fecha se anclan a su día de
            # creación — ver deadline_datetime), así que no hace falta la
            # comparación de horas sueltas que fallaba al pasar la
            # medianoche.
            limit = task.resolve_datetime()
            if limit is None:
                continue

            # Si devolviste la tarea a pendientes DESPUÉS de su hora
            # límite, es que ya decidiste tú: no se auto-resuelve.
            #
            # Se usa una marca explícita (reopened_at) y no "cuándo se
            # modificó por última vez", porque una tarea CREADA después
            # de su hora límite también se habría modificado después, y
            # nunca llegaría a expirar.
            if task.reopened_at is not None:
                reopened = timezone.localtime(task.reopened_at).replace(tzinfo=None)
                if reopened > limit:
                    continue

            # resolve_datetime ya incluye el margen de las antitareas: a
            # la hora límite salta el aviso, y solo pasado ese rato sin
            # respuesta se resuelve sola.
            if now_local > limit:
                if task.in_progress_grace(limit, now_local):
                    continue
                if not dry_run:
                    task.mark_expired()
                expired_tasks.append(task)

        return expired_tasks


class Exercise(models.Model):
    """
    Catálogo de ejercicios disponibles. Es la pieza base para poder montar
    rutinas (ej. "Upper body" = dominadas + fondos + abdominales) sin tener
    que crear una Task por cada ejercicio.

    `mode` dice qué tipo de seguimiento necesita:
      - pose:     la cámara cuenta las reps (MediaPipe). Necesita counter_key.
      - manual:   el usuario escribe las reps/peso a mano (ej. mancuernas).
      - timed:    solo se mide duración (ej. plancha).
      - distance: cardio — distancia + tiempo (ej. correr).

    `counter_key` identifica qué contador de workout.js usar cuando mode es
    "pose" (ej. "pullup"). Varios ejercicios pueden compartir contador con
    distinta config: "dominadas" y "dominadas anchas" usan el mismo
    contador de dominadas, solo cambia `config` (umbrales, etc.).
    """
    MODE_POSE = "pose"
    MODE_MANUAL = "manual"
    MODE_TIMED = "timed"
    MODE_DISTANCE = "distance"

    MODE_CHOICES = [
        (MODE_POSE, "Cámara (pose tracking)"),
        (MODE_MANUAL, "Manual (reps a mano)"),
        (MODE_TIMED, "Cronometrado"),
        (MODE_DISTANCE, "Distancia (cardio)"),
    ]

    # Nivel para generar planes de deporte automáticamente (pedido por
    # Alex, 2026-09-28). Solo 3 niveles a propósito, sin intermedios
    # como "principiante-intermedio" -- si un ejercicio está a caballo,
    # se fuerza a uno de los tres. Vacío ("", el default) para los dos
    # casos que quedan FUERA de este sistema: calentamiento/estiramientos
    # (body_area="warmup", más "elephant-steps" en lower_body -- se
    # siguen usando como calentamiento antes de la tarea, o sueltos, pero
    # no entran en la selección por nivel) y running (tiene su propio
    # sistema de nivel vía el plan -- no tocado aquí a propósito).
    LEVEL_BEGINNER = "beginner"
    LEVEL_INTERMEDIATE = "intermediate"
    LEVEL_ADVANCED = "advanced"

    LEVEL_CHOICES = [
        (LEVEL_BEGINNER, "Principiante"),
        (LEVEL_INTERMEDIATE, "Intermedio"),
        (LEVEL_ADVANCED, "Avanzado"),
    ]

    # Variantes del catálogo que llevan peso añadido (lastre, chaleco...)
    # — son muy pocas frente al resto del catálogo (peso corporal), así
    # que en vez de un campo en la base de datos (con su migración) para
    # algo que casi nunca se usa, es una lista fija aquí. Sirve para que
    # los formularios de objetivo (plan_item_form, plan_item_bulk_form)
    # solo enseñen los campos de peso cuando el ejercicio elegido de
    # verdad lo usa, en vez de para todo el catálogo. Si se añade un
    # ejercicio con peso nuevo al catálogo, su slug va aquí.
    WEIGHTED_SLUGS = {"weighted-pullup", "wide-weighted-pullup", "weighted-dips", "weighted-squat"}
    # Cada ejercicio con peso -> su versión sin peso. Define las "familias"
    # que usa weighted_first() para ordenar la sesión: con peso primero,
    # dentro de su familia (dominadas con peso antes que dominadas, etc.).
    # Si se añade un ejercicio con peso nuevo, su slug va aquí Y en
    # WEIGHTED_SLUGS.
    WEIGHTED_BASE = {
        "weighted-pullup": "pullup",
        "wide-weighted-pullup": "wide-pullup",
        "weighted-dips": "dips",
        "weighted-squat": "squat",
    }

    name = models.CharField(max_length=64)
    slug = models.SlugField(max_length=64, unique=True)
    mode = models.CharField(max_length=16, choices=MODE_CHOICES, default=MODE_MANUAL)
    body_area = models.CharField(
        max_length=16,
        choices=Task.SPORT_SUBCATEGORY_CHOICES,
        blank=True,
        db_index=True,
        help_text="A qué subcategoría de Deporte pertenece (tren superior/inferior/running). "
                   "Vacío = aparece en el selector pase lo que pase.",
    )
    counter_key = models.CharField(
        max_length=32, blank=True,
        help_text="Qué contador de workout.js usar (solo aplica si mode='pose'). Ej: 'pullup'.",
    )
    level = models.CharField(
        max_length=12, choices=LEVEL_CHOICES, blank=True, db_index=True,
        help_text="Para generar planes de deporte automáticamente por nivel. Vacío = calentamiento/"
                   "estiramientos (no entran en la selección por nivel) o running (nivel propio, no aplica).",
    )
    config = models.JSONField(
        default=dict, blank=True,
        help_text="Umbrales/ajustes propios de este ejercicio para el contador (opcional).",
    )
    is_active = models.BooleanField(default=True)
    order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["order", "name"]

    def __str__(self):
        return self.name

    @property
    def voice_step(self):
        """
        Cada cuántas repeticiones habla la voz (ver DEFAULT_VOICE_STEP/
        speakRep en workout.js). Por defecto 1 (anuncia cada rep) --
        pensado para ejercicios de fuerza a ritmo controlado (dominadas,
        fondos, flexiones, sentadillas...). Los pocos ejercicios de
        cadencia muy rápida (jumping jacks, círculos de brazos, talones
        al glúteo, rodillas altas) llevan config={"voice_step": 5} para
        que la voz no se quede atrás del ritmo real -- pedido
        explícitamente por el usuario, ajustable desde el admin sin
        tocar código.
        """
        try:
            return int(self.config.get("voice_step", 1)) or 1
        except (AttributeError, TypeError, ValueError):
            return 1


class Routine(models.Model):
    """
    Circuito reutilizable de ejercicios cronometrados (ej. "Abdominales
    completo"): una lista ordenada de Exercise con su tiempo de trabajo y
    descanso, para no tener que montarlo cada vez desde cero. Pensada para
    ejercicios mode='timed' (plancha, crunch…), aunque no se fuerza aquí —
    quien monta la rutina decide qué mete.
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="routines",
    )
    name = models.CharField(max_length=64)
    subcategory = models.CharField(
        max_length=16, choices=Task.SPORT_SUBCATEGORY_CHOICES, blank=True,
        help_text="Para poder ofrecer esta rutina desde el selector de esa subcategoría de Deporte.",
    )
    default_work_seconds = models.PositiveIntegerField(default=40)
    default_rest_seconds = models.PositiveIntegerField(default=20)
    # Si True, este es EL circuito que task_warmup/task_cooldown ofrecen
    # como calentamiento/estiramiento para su subcategoría (ver
    # views._warmup_routine_for) -- sustituye al vídeo fijo de YouTube
    # que había antes. Solo tiene sentido uno marcado por
    # usuario+subcategoría a la vez; _save_routine desmarca los demás de
    # la misma subcategoría al guardar uno nuevo, para que no haya
    # ambigüedad sobre cuál se ofrece.
    is_warmup_bookend = models.BooleanField(
        default=False,
        help_text="Usar este circuito como calentamiento/estiramiento antes y después de "
                   "las sesiones de esta subcategoría, en vez del vídeo genérico.",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name

    @property
    def total_seconds(self):
        """Duración estimada del circuito completo, en orden (sin contar
        que el usuario pueda saltarse o repetir ejercicios).

        Los ejercicios de cámara no tienen duración fija — dependen de lo
        rápido que hagas las reps — así que se estiman a 4 segundos por
        repetición, solo para dar una idea del tamaño del circuito.
        """
        items = list(self.items.select_related("exercise"))
        total = 0
        for i, item in enumerate(items):
            if item.exercise.mode == Exercise.MODE_POSE:
                total += item.target_sets * item.target_reps * 4
            else:
                total += item.effective_work_seconds
            if i < len(items) - 1:
                total += item.effective_rest_seconds
        return total


class RoutineItem(models.Model):
    """Un ejercicio dentro de una Routine, con su orden y tiempos propios
    (si se dejan en blanco, usa los defaults de la rutina).

    Un circuito puede mezclar los dos tipos de ejercicio, y cada uno se
    mide con lo que le corresponde:
      - Cronometrados (plancha, crunch): work_seconds / rest_seconds.
      - De cámara (dominadas, fondos): target_sets x target_reps. Contar
        segundos de dominadas no dice nada; lo que importa son las reps.

    Los objetivos son además la base del "planning" progresivo: subir de
    3x8 a 3x9 la semana siguiente es cambiar un número aquí.
    """
    routine = models.ForeignKey(Routine, on_delete=models.CASCADE, related_name="items")
    exercise = models.ForeignKey(Exercise, on_delete=models.CASCADE)
    order = models.PositiveIntegerField(default=0)
    work_seconds = models.PositiveIntegerField(null=True, blank=True)
    rest_seconds = models.PositiveIntegerField(null=True, blank=True)
    target_sets = models.PositiveIntegerField(
        default=3, help_text="Solo para ejercicios de cámara: series objetivo."
    )
    target_reps = models.PositiveIntegerField(
        default=8, help_text="Solo para ejercicios de cámara: repeticiones por serie."
    )

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return f"{self.routine.name} #{self.order}: {self.exercise.name}"

    @property
    def effective_work_seconds(self):
        return self.work_seconds if self.work_seconds is not None else self.routine.default_work_seconds

    @property
    def effective_rest_seconds(self):
        return self.rest_seconds if self.rest_seconds is not None else self.routine.default_rest_seconds

    def plan_entry(self, user=None):
        """
        El ejercicio dentro de un plan activo, si lo hay.

        Es lo que permite convivir plan y "freestyle": si este ejercicio
        forma parte de un plan en marcha, manda el plan; si no, mandan los
        objetivos fijos del circuito y entrenas a tu aire.
        """
        owner = user or self.routine.user
        return (
            PlanItem.objects
            .filter(
                exercise=self.exercise,
                plan__is_active=True,
                plan__deleted_at__isnull=True,
                plan__user=owner,
            )
            .select_related("plan")
            .order_by("-plan__started_on")
            .first()
        )

    def resolved_target(self, user=None):
        """
        Lo que toca hacer hoy en este ejercicio, mire quien lo mire.

        Devuelve también de dónde sale el número (`source`), porque en
        pantalla no es lo mismo "3x8 porque lo pusiste en el circuito"
        que "3x9 porque tu plan va por ahí" — y el usuario necesita
        entender por qué le pide eso.
        """
        entry = self.plan_entry(user)
        if entry:
            target = entry.current_target()
            successes, _ = entry.successes_and_streak()
            return {
                "sets": target["sets"],
                "reps": target["reps"],
                "seconds": target["seconds"] or self.effective_work_seconds,
                "weight_kg": target.get("weight_kg") or 0,
                "source": "plan",
                "plan_name": entry.plan.name,
                "plan_uuid": str(entry.plan.uuid),
                "session_index": successes + 1,
                "sessions_to_goal": entry.sessions_to_goal(),
            }
        return {
            "sets": self.target_sets,
            "reps": self.target_reps,
            "seconds": self.effective_work_seconds,
            "weight_kg": 0,
            "source": "routine",
            "plan_name": None,
            "plan_uuid": None,
            "session_index": None,
            "sessions_to_goal": None,
        }


def weighted_first(items):
    """
    Reordena objetivos de un plan: el ejercicio CON peso va antes que su
    versión normal (dominadas con peso -> dominadas, fondos con peso ->
    fondos...), llegando fresco al trabajo pesado y dejando el de peso
    corporal para cuando ya hay fatiga.

    "Por tipo": las familias siguen el orden en que aparece por primera
    vez cualquiera de sus miembros en la lista de entrada (o sea, el orden
    en que se fueron añadiendo o movieron a mano). Dominadas, dominadas
    con peso, fondos, fondos con peso -> dominadas con peso, dominadas,
    fondos con peso, fondos. Solo se intercambia DENTRO de cada familia;
    el resto (y los objetivos sin ejercicio) conservan su sitio. La
    ordenación es estable: dos objetivos del mismo ejercicio no se cruzan.
    """
    items = list(items)

    def slug_of(it):
        return it.exercise.slug if it.exercise_id and it.exercise else None

    def family(it):
        slug = slug_of(it)
        if slug is None:
            return ("item", it.pk)          # sin ejercicio: familia propia
        return ("ex", Exercise.WEIGHTED_BASE.get(slug, slug))

    rank = {}
    for it in items:
        rank.setdefault(family(it), len(rank))
    return sorted(
        items,
        key=lambda it: (rank[family(it)], 0 if slug_of(it) in Exercise.WEIGHTED_BASE else 1),
    )


class Plan(models.Model):
    """
    Un objetivo con progresión: "ponerme en forma", "preparar el DALF".

    Cuelga del OBJETIVO, no de un circuito, porque es lo que la gente
    quiere de verdad — nadie se propone "hacer 8 repeticiones", se
    propone estar más en forma. Los circuitos y ejercicios son las
    tácticas; el plan es hacia dónde van.

    Puede abarcar varios ejercicios de varios circuitos a la vez.
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="plans",
    )
    name = models.CharField(max_length=80)
    notes = models.TextField(blank=True)
    started_on = models.DateField(default=_dt.date.today)
    weeks = models.PositiveIntegerField(
        default=12, help_text="Duración prevista. 12 semanas por defecto (12 Week Year).",
    )
    is_active = models.BooleanField(default=True)

    # Qué clase de plan es, y por tanto cómo se resuelve su tarea diaria.
    # Deporte: como siempre, objetivos de ejercicio (con cámara/circuito,
    # y ahora también running — ver PlanItem). Estudio: sin "objetivo"
    # aparte que añadir — el propio vídeo/playlist/temporizador de la
    # tarea diaria ES el objetivo, y el progreso se mide en si la
    # completaste cada día. General: igual que Estudio pero sin vídeo,
    # solo cumplimiento simple (un hábito cualquiera).
    PLAN_TYPE_SPORT = "sport"
    PLAN_TYPE_STUDY = "study"
    PLAN_TYPE_GENERAL = "general"
    PLAN_TYPE_CHOICES = [
        (PLAN_TYPE_SPORT, "Deporte"),
        (PLAN_TYPE_STUDY, "Estudio"),
        (PLAN_TYPE_GENERAL, "General"),
    ]
    plan_type = models.CharField(max_length=10, choices=PLAN_TYPE_CHOICES, default=PLAN_TYPE_SPORT)

    # Subtipo de "Estudio": 'general' es el hábito diario de siempre (un
    # vídeo/playlist fijo o un temporizador, sin más). 'language' es un
    # curso de verdad: una secuencia de vídeos reales de YouTube,
    # ordenados de nivel MCER más bajo a más alto y repartidos en las
    # semanas del plan — ver CourseModule más abajo. Solo tiene sentido
    # cuando plan_type='study'; en Deporte/General se queda en blanco.
    STUDY_SUBTYPE_GENERAL = "general"
    STUDY_SUBTYPE_LANGUAGE = "language"
    STUDY_SUBTYPE_CHOICES = [
        (STUDY_SUBTYPE_GENERAL, "Hábito simple"),
        (STUDY_SUBTYPE_LANGUAGE, "Idioma (curso con vídeos por nivel)"),
    ]
    study_subtype = models.CharField(
        max_length=10, choices=STUDY_SUBTYPE_CHOICES, blank=True, default=STUDY_SUBTYPE_GENERAL,
    )

    # Niveles del Marco Común Europeo de Referencia — mismo orden que se
    # usa para clasificar y ordenar los CourseModule de un curso de
    # idioma. Constante a nivel de módulo (ver arriba del archivo) porque
    # Task.level también la necesita y Task se define antes que Plan;
    # se deja también como atributo de clase aquí para no romper el
    # código existente que escribe Plan.CEFR_LEVELS / Plan.CEFR_LEVEL_CHOICES.
    CEFR_LEVELS = CEFR_LEVELS
    CEFR_LEVEL_CHOICES = CEFR_LEVEL_CHOICES

    # Solo con study_subtype='language'. En blanco, level_from se trata
    # como A1 (empezar desde cero) y level_to como "sin techo" (llega
    # hasta donde dé el número de semanas).
    language_name = models.CharField(
        max_length=40, blank=True,
        help_text="Solo con study_subtype='language': el idioma del curso, ej. 'francés'.",
    )
    level_from = models.CharField(max_length=2, blank=True, choices=CEFR_LEVEL_CHOICES)
    level_to = models.CharField(max_length=2, blank=True, choices=CEFR_LEVEL_CHOICES)

    # Qué idiomas ya domina el usuario, en sus propias palabras (ej.
    # "inglés, italiano"). El PRIMERO que escribe es el que se usa como
    # "idioma nativo" para filtrar el catálogo (ver
    # api._catalog_entries_for_language): solo entran cursos explicados
    # en ese idioma, o cursos neutros sin idioma de explicación fijado
    # (CoursePlaylist.native_language en blanco) — nunca uno pensado
    # para hablantes de otro idioma distinto. También da contexto a las
    # notas del plan (comparar gramática con un idioma que ya conoces).
    # Ya es obligatorio en el formulario — nunca queda en blanco.
    known_languages = models.CharField(max_length=200, blank=True)

    # Cuántos minutos de vídeo al día quiere ver el usuario — objetivo
    # DIARIO del plan, no la duración de un vídeo concreto (eso vive en
    # CourseModule.duration_seconds). Se copia tal cual a Task.target_minutes
    # en _language_target_fields(). En blanco, la tarea diaria exige ver
    # el vídeo entero (comportamiento de siempre, sin objetivo en minutos).
    language_daily_minutes = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Solo con study_subtype='language': minutos de vídeo al día. En blanco, "
                   "exige ver el vídeo del día entero.",
    )

    # Cada cuántos vídeos vistos se genera un test de repaso — lo decide
    # el usuario al crear el plan (gastar IA en un test por vídeo no es
    # lo mismo que uno cada 5). En blanco, no se generan tests
    # automáticos. El disparo vive en api.maybe_trigger_quiz(), llamado
    # desde views.task_video_save justo después de marcar el vídeo como
    # visto — ver CourseQuiz más abajo para el resultado y la racha.
    quiz_every_n_videos = models.PositiveIntegerField(null=True, blank=True)

    # Cuándo toca entrenar. El plan crea y mantiene su propia tarea con
    # estos datos, para que el usuario no tenga que crear una a mano ni
    # entender qué es un "circuito": crea el plan y le sale la tarea.
    repeat = models.CharField(max_length=10, default="custom")
    interval = models.PositiveIntegerField(default=1)
    custom_days = models.CharField(
        max_length=20, blank=True, default="0,2,4",
        help_text="Días de la semana, como en las tareas. Por defecto lunes, miércoles y viernes.",
    )
    due_time = models.TimeField(null=True, blank=True)

    # La tarea que representa este plan en la lista del día.
    task_series_id = models.UUIDField(null=True, blank=True, editable=False)

    created_at = models.DateTimeField(auto_now_add=True)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    # Cierre del ciclo: distinto de borrar. Un plan cerrado deja de
    # generar tareas y sale de la lista de activos, pero se queda para
    # poder mirar atrás — borrar (deleted_at) es para "esto no debería
    # haber existido"; cerrar (closed_at) es para "esto terminó bien".
    closed_at = models.DateTimeField(null=True, blank=True)
    reward = models.CharField(
        max_length=200, blank=True,
        help_text="La recompensa que te prometes al empezar el ciclo (opcional). "
                   "Se enseña en la pantalla de cierre si la has puesto — y solo si "
                   "el plan llega al umbral de completado.",
    )
    # Foto del progreso en el momento de cerrar (manual o automático). No
    # se recalcula después: una vez cerrado, el plan ya no acumula más
    # sesiones, así que sería el mismo número — pero guardarlo evita
    # tener que volver a calcularlo cada vez que se enseña la lista de
    # cerrados, y dEja constancia de con qué dato se decidió.
    final_progress_pct = models.PositiveIntegerField(null=True, blank=True)

    # A partir de qué porcentaje un cierre cuenta como "completado" en
    # vez de "terminado incompleto". Un ciclo que no lo alcanza se
    # cierra igual (o se auto-cierra al pasar las semanas), pero no
    # desbloquea la recompensa ni se celebra igual.
    COMPLETION_THRESHOLD_PCT = 70

    class Meta:
        ordering = ["-is_active", "-started_on"]

    def __str__(self):
        return self.name

    @property
    def ends_on(self):
        return self.started_on + timedelta(weeks=self.weeks)

    @property
    def week_number(self):
        """En qué semana del plan estamos (1 = la primera)."""
        days = (timezone.localtime(timezone.now()).date() - self.started_on).days
        return max(1, days // 7 + 1)

    @property
    def is_completed(self):
        """
        Si el cierre cuenta como éxito o como "terminado incompleto".

        Usa la foto guardada al cerrar si ya está cerrado; si todavía
        está abierto, calcula con el progreso de ahora mismo — así la
        pantalla de cierre puede avisar de antemano de en qué lado vas
        a caer antes de que confirmes.
        """
        pct = self.final_progress_pct if self.closed_at else self.progress_pct()
        return pct is not None and pct >= self.COMPLETION_THRESHOLD_PCT

    def _is_finished_now(self):
        """
        Criterio de "este plan ya ha llegado a su fin" — extraído de
        auto_close_expired (que lo usa para el barrido silencioso en
        cada carga de la lista) y reutilizado por close_if_finished
        (que lo usa disparado al momento, justo al guardar la sesión
        que lo termina). Mismo criterio en los dos sitios a propósito:
        que el plan se cierre "ya" en vez de "en la próxima carga de la
        lista" no debe cambiar CUÁNDO se considera terminado, solo
        cuándo se nota.

        Deporte/General: "su fin" es que se cumplan las semanas
        (`ends_on`), como siempre. Estudio · Idiomas es distinto a
        propósito: el objetivo es terminar el temario asignado, no una
        fecha — `weeks` ahí es solo una ESTIMACIÓN del ritmo elegido
        (ver api.build_language_plan_draft), no un plazo. Si el ritmo
        real va más lento de lo estimado, el plan sigue abierto en vez
        de cerrarse a medias; si el temario se acaba antes de lo
        estimado (playlist corta), se cierra en cuanto se ve el último
        vídeo en vez de seguir repitiéndolo hasta que pasen las
        semanas que sobran.

        Estudio · Hábito simple con una playlist SEGUIDA (con caché de
        vídeos, ver PlanItem.playlist_videos_cache /
        Plan._study_playlist_progress): mismo criterio que Idiomas —
        se cierra al terminar la playlist entera, no al cumplir
        `weeks`. Sin playlist, o con un vídeo suelto/temporizador
        (sin seguimiento posible), sigue siendo un hábito que se repite
        y se cierra por semanas, como toda la vida.
        """
        is_language = (
            self.plan_type == self.PLAN_TYPE_STUDY and self.study_subtype == self.STUDY_SUBTYPE_LANGUAGE
        )
        head = self.headline if self.plan_type == self.PLAN_TYPE_STUDY else None
        has_tracked_playlist = bool(
            head and not is_language and head.youtube_playlist_id and head.playlist_videos_cache
        )
        has_udemy_course = bool(head and not is_language and head.watch_keyword)
        if is_language:
            progress = self.course_progress()
            return progress["total"] > 0 and progress["pct"] >= 100
        if has_tracked_playlist:
            progress = self._study_playlist_progress(head)
            return progress["total"] > 0 and progress["finished"]
        if has_udemy_course:
            # Igual que Idiomas/playlist: el fin es terminar el curso,
            # no cumplir `weeks` — lo dice course_completed_at en la
            # tarea vigente, puesto por finish_recurring_series() cuando
            # la extensión de Chrome detecta el 100% en Udemy.
            current_task = Task.objects.filter(series_id=self.task_series_id).order_by("-due_date").first()
            return bool(current_task and current_task.course_completed_at)
        today = timezone.localtime(timezone.now()).date()
        return today >= self.ends_on or self._all_items_reached_goal()

    def _all_items_reached_goal(self):
        """
        True si TODOS los objetivos de este plan tienen un destino real
        definido (ver PlanItem.sessions_to_goal) y ya lo han alcanzado
        -- permite cerrar el plan antes de que se cumplan las semanas
        cuando ya no queda "más camino" que subir en ninguno.

        "Cumplimiento" (objetivo fijo) y "al fallo" sin peso objetivo
        puesto (y cualquier progresión sin goal_* configurado, sea cual
        sea su tipo) no tienen techo por diseño -- sessions_to_goal()
        ya devuelve None para todos esos casos (mira "done" en cada
        escalón, y esos nunca lo marcan), así que basta con usar ese
        mismo método aquí para los cuatro tipos de progresión a la vez,
        sin repetir el switch por tipo. Si el plan no tiene ningún
        objetivo, o si aunque sea UNO no tiene techo, esto es False sin
        más -- ese objetivo está pensado para repetirse todo el ciclo,
        no tiene un "ya terminé" que detectar, así que el plan entero
        se queda esperando a que se cumplan las semanas, como toda la
        vida (llamado desde _is_finished_now, arriba).
        """
        items = list(self.items.all())
        if not items:
            return False
        return all(
            (remaining := item.sessions_to_goal()) is not None and remaining == 0
            for item in items
        )

    def close_if_finished(self):
        """
        Si este plan ya ha llegado a su fin (ver _is_finished_now) y
        todavía no estaba cerrado, lo cierra AQUÍ MISMO — misma foto de
        progreso / closed_at / is_active / sync_task que el cierre
        manual (ver la vista plan_close) o que el barrido en segundo
        plano (auto_close_expired), solo que disparado en el instante
        en que se guarda la sesión que lo termina en vez de quedar
        cerrado en silencio hasta la próxima vez que se cargue la lista
        de tareas. Lo llama Task.mark_done() con el plan de la tarea
        que se acaba de marcar, y devuelve el plan a quien llamó para
        que pueda mandar a la pantalla de cierre/celebración en vez de
        a la lista de siempre.

        Idempotente: si ya estaba cerrado, no hace nada y devuelve
        False — así da igual que auto_close_expired lo vuelva a
        comprobar más tarde para el resto de planes vencidos.
        """
        if self.closed_at:
            return False
        if not self._is_finished_now():
            return False
        self.final_progress_pct = self.progress_pct()
        self.closed_at = timezone.now()
        self.is_active = False
        self.save(update_fields=["final_progress_pct", "closed_at", "is_active", "updated_at"])
        self.sync_task()
        return True

    @classmethod
    def auto_close_expired(cls, user=None):
        """
        Cierra solos los planes que ya han llegado a su fin (ver
        close_if_finished / _is_finished_now para el criterio).

        Sin scheduler en este hosting, así que se comprueba de gorra
        cada vez que se abre la lista de tareas — mismo criterio que
        Task.expire_overdue(): barato, y no hace falta que nadie entre
        a "planes" para que un ciclo vencido deje de generar tareas.
        Es la red de seguridad para cuando nadie ha pasado por
        Task.mark_done() de la sesión que lo terminaba (por ejemplo, un
        plan de Estudio · Idiomas cuyo temario se completó por otra vía)
        — el caso normal ya se cierra al momento, ver close_if_finished.
        """
        qs = cls.objects.filter(deleted_at__isnull=True, closed_at__isnull=True, is_active=True)
        if user is not None:
            qs = qs.filter(user=user)
        for plan in qs:
            plan.close_if_finished()

    def custom_days_list(self):
        if not self.custom_days:
            return []
        return [d.strip() for d in self.custom_days.split(",") if d.strip()]

    def _running_target_fields(self):
        """
        Si el objetivo principal de este plan es running, los campos que
        hay que copiar a la tarea diaria (distancia/ritmo del escalón
        actual) — o un dict vacío si no aplica. Se recalcula siempre
        desde cero en vez de guardarse aparte: el escalón sube solo con
        las sesiones cumplidas, así que "el objetivo de hoy" cambia sin
        que nadie tenga que tocar nada.
        """
        head = self.headline
        if not head or not head.exercise or head.exercise.mode != Exercise.MODE_DISTANCE:
            return {}
        t = head.current_target()
        return {
            "subcategory": Task.SUBCATEGORY_RUNNING,
            "target_distance_km": t.get("distance_km"),
            "max_pace_seconds_per_km": t.get("pace_seconds_per_km"),
        }

    def _sport_mode_fields(self):
        """
        Si el objetivo principal tiene un modo elegido (cámara, circuito,
        vídeo), lo copia a la tarea diaria — es lo que hace que
        workout_kind() sepa a qué pantalla mandar al pulsar play, en vez
        de asumir siempre circuito como pasaba antes de que esto
        existiera. Sin modo elegido (objetivos de antes de este campo),
        no se toca nada — se quedan tal como estaban, yendo al circuito.
        """
        head = self.headline
        if not head or not head.sport_mode:
            return {}
        fields = {"sport_mode": head.sport_mode}
        if head.sport_mode == PlanItem.SPORT_MODE_VIDEO:
            fields.update(
                youtube_video_id=head.youtube_video_id,
                youtube_playlist_id=head.youtube_playlist_id,
                target_minutes=head.target_minutes,
                target_video_count=head.target_video_count,
            )
        return fields

    def _study_playlist_progress(self, head):
        """
        Por dónde vas en la playlist de un objetivo de Estudio · Hábito
        simple con caché (head.playlist_videos_cache) — usado tanto por
        `_study_target_fields` (qué vídeo toca hoy) como por
        `auto_close_expired` (si ya se acabó la lista entera).

        Se mide siempre en VÍDEOS COMPLETOS consumidos, tanto si el
        objetivo es "N vídeos al día" como si es "N minutos al día":
          - con target_video_count: cada día cumplido consume esa
            cantidad de vídeos (mismo tipo de conteo que
            `_language_completed_count`, pero contando Occurrence en vez
            de CourseModule.watched_at, y multiplicado por cuántos
            vídeos tocan por sesión).
          - con target_minutes (y sin target_video_count): se suman los
            minutos REALES vistos (Occurrence.minutes_watched, no un
            cálculo teórico) desde que se sincronizó la playlist, y se
            recorre la lista de vídeos acumulando su duración hasta
            gastar esos minutos — un vídeo cuenta como "consumido" solo
            si su duración entera ya cupo en lo visto hasta ahora. No
            se reanuda a mitad de vídeo (decisión explícita): el
            siguiente día siempre empieza el próximo vídeo sin ver
            desde el principio, aunque eso signifique pasarse un poco
            de los minutos exactos algunos días.

        `since` (desde cuándo cuentan las Occurrence) es
        `playlist_synced_at` si existe — así cambiar de playlist
        reinicia el avance solo, sin guardar un índice aparte — y si no,
        `started_on` del plan (compatibilidad con cachés antiguas).
        """
        videos = head.playlist_videos_cache or []
        total = len(videos)
        if not total:
            return {"total": 0, "index": 0, "finished": False}

        since = (
            timezone.localtime(head.playlist_synced_at).date()
            if head.playlist_synced_at else self.started_on
        )
        done_occurrences = Occurrence.objects.filter(
            series_id=self.task_series_id, result=Occurrence.RESULT_DONE,
            deleted_at__isnull=True, recorded_at__date__gte=since,
        ) if self.task_series_id else Occurrence.objects.none()

        if head.target_video_count:
            consumed = done_occurrences.count() * head.target_video_count
        else:
            watched_seconds = sum((o.minutes_watched or 0) for o in done_occurrences) * 60
            consumed = 0
            cumulative = 0
            for v in videos:
                cumulative += (v.get("duration_seconds") or 0)
                if cumulative > watched_seconds:
                    break
                consumed += 1

        finished = consumed >= total
        return {"total": total, "index": min(consumed, total - 1), "finished": finished}

    def _study_target_fields(self):
        """
        Si el plan es de Estudio, los campos de vídeo/playlist/temporizador
        que hay que copiar a la tarea diaria — viven en el objetivo
        (PlanItem), no en el plan, igual que el peso o las repeticiones
        viven en el objetivo de un plan de Deporte. Sin objetivo puesto
        todavía, la tarea diaria sale como Estudio simple, sin vídeo —
        no como un error, solo como "todavía no configurado".

        Con una playlist ya sincronizada (head.playlist_videos_cache,
        ver PlanItem.sync_playlist_videos), la tarea sigue embebiendo la
        PLAYLIST ENTERA (no un vídeo suelto) pero indicándole al
        reproductor por dónde empezar hoy (`playlist_start_index`, ver
        task_video.html) — así un objetivo de "2 vídeos al día" sigue
        pudiendo ver varios seguidos en la misma sesión, solo que ya no
        vuelve a repetir desde el vídeo 1 cada vez. Sin caché todavía
        (playlist recién puesta y sin guardar aún, o la sincronización
        con YouTube falló), cae al comportamiento de siempre: la
        playlist entera, siempre desde el principio.
        """
        head = self.headline
        if not head:
            return {}
        fields = {
            "youtube_video_id": head.youtube_video_id,
            "youtube_playlist_id": head.youtube_playlist_id,
            "watch_keyword": head.watch_keyword,
            "watch_requires_audio": head.watch_requires_audio,
            "target_minutes": head.target_minutes,
            "target_video_count": head.target_video_count,
            "playlist_start_index": None,
        }
        if head.youtube_playlist_id and head.playlist_videos_cache:
            progress = self._study_playlist_progress(head)
            if progress["total"]:
                fields["playlist_start_index"] = progress["index"]
        return fields

    def _language_completed_count(self):
        """
        Cuántos vídeos del temario se han visto de verdad hasta ahora —
        decide qué CourseModule toca a continuación. La fuente real es
        CourseModule.watched_at (lo pone `mark_current_module_watched`,
        llamado justo después de guardar la Occurrence del día — ver
        views.task_video_save), NO el número de días/Occurrence: una
        sola sesión de estudio puede encadenar varios vídeos cortos
        seguidos hasta llenar el objetivo diario en minutos (ver
        task_video.html), así que el curso puede avanzar más de un
        vídeo por día.
        """
        return self.course_modules.filter(watched_at__isnull=False).count()

    def _language_target_fields(self):
        """
        Si el plan es de Estudio · Idiomas, qué vídeo de CourseModule
        toca HOY — el siguiente sin ver según `_language_completed_count`.
        Al llegar al final del temario se queda enseñando el último
        vídeo en vez de dejar la tarea sin vídeo (más newsletter que un
        error: el curso se acabó, no hay más que "fallar" mostrando
        nada). Sin ningún CourseModule todavía (curso recién creado y
        algo falló al expandirlo, o borrado a mano), sale como Estudio
        simple sin vídeo — igual que _study_target_fields en ese caso.
        """
        # El idioma del plan se enseña siempre, aunque el temario esté
        # vacío todavía (curso recién creado a mano, sin cursos elegidos
        # aún) — es contexto barato y útil por sí solo. El nivel, en
        # cambio, es el del vídeo concreto que toca: sin CourseModule no
        # hay ninguno que enseñar.
        fields = {"language_name": self.language_name}
        modules = list(self.course_modules.all())
        if not modules:
            return fields
        index = min(self._language_completed_count(), len(modules) - 1)
        module = modules[index]
        fields.update({
            "youtube_video_id": module.youtube_video_id,
            "youtube_playlist_id": "",
            # Objetivo DIARIO del usuario (ej. "1h al día"), no la
            # duración del vídeo — task_video.html decide con esto si
            # corta al llegar al objetivo o deja terminar el vídeo (ver
            # el margen de sobra en el propio JS). En blanco, exige ver
            # el vídeo entero, como antes de que existiera este campo.
            "target_minutes": self.language_daily_minutes,
            "target_video_count": None,
            "level": module.level,
        })
        return fields

    def course_progress(self):
        """
        Para la pantalla del plan: vídeos vistos / totales y cuál toca
        ahora, calculado exactamente igual que decide la tarea diaria
        (`_language_target_fields`) — para que nunca se desincronicen.
        """
        modules = list(self.course_modules.all())
        total = len(modules)
        if not total:
            return {"total": 0, "watched": 0, "pct": 0, "next": None}
        watched = min(self._language_completed_count(), total)
        return {
            "total": total,
            "watched": watched,
            "pct": round(100 * watched / total),
            "next": modules[min(watched, total - 1)],
        }

    def upcoming_course_queue(self, max_videos=40):
        """
        Vídeos del temario a partir de HOY (el que toca, incluido) para
        que task_video.html pueda encadenarlos en la misma sesión sin
        volver al servidor — hasta llenar el objetivo diario en minutos
        (Task.target_minutes) o hasta que se acabe el curso. `max_videos`
        es solo un tope de sensatez: ninguna sesión real encadena tantos.
        """
        modules = list(self.course_modules.all())
        if not modules:
            return []
        index = min(self._language_completed_count(), len(modules) - 1)
        return [
            {"video_id": m.youtube_video_id, "duration_seconds": m.duration_seconds}
            for m in modules[index:index + max_videos] if m.youtube_video_id
        ]

    def mark_current_module_watched(self, count=None):
        """
        Marca como vistos los próximos `count` módulos del temario que
        todavía no lo estaban — llamada justo después de guardar la
        Occurrence del día (ver views.task_video_save). `count` es
        cuántos vídeos se completaron de verdad en esa sesión: una
        sesión de idioma puede encadenar varios vídeos cortos seguidos
        hasta llenar el objetivo diario en minutos (ver task_video.html),
        así que no siempre es 1. Sin dato (None, cliente antiguo sin
        este contador) se asume 1, el comportamiento de siempre; con 0
        (la sesión se cortó antes de terminar ningún vídeo del todo) no
        se avanza nada — no hay que "comerse" un vídeo a medias.
        """
        if count is None:
            count = 1
        elif count <= 0:
            return None
        modules = list(
            self.course_modules.filter(watched_at__isnull=True).order_by("order")[:count]
        )
        if not modules:
            return None
        CourseModule.objects.filter(pk__in=[m.pk for m in modules]).update(watched_at=timezone.now())
        return modules[-1]

    def quiz_streak_stats(self):
        """
        Racha de tests de idioma aprobados (ver CourseQuiz) — aparte de
        `course_progress`, que es solo vídeos vistos. Un test flojo no
        toca el progreso del curso (el vídeo ya contó como visto al
        verlo), pero SÍ rompe esta racha: es el "empujón" para que se
        preste atención de verdad, sin poder atascar el curso en sí.
        """
        return CourseQuiz.streak_stats(self.pk)

    def _first_task_due_date(self):
        """
        La fecha de la PRIMERA tarea del plan (solo se usa al crearla,
        una vez -- las siguientes las decide next_due_date() a partir de
        esta).

        ANTES: `max(started_on, hoy)` a secas -- si hoy no es uno de los
        `custom_days_list()` marcados (p.ej. plan creado en sábado con
        lunes/miércoles/viernes), la tarea salía igualmente HOY, un día
        que ni siquiera está seleccionado. Reportado por Alex: "he creado
        el plan hoy sábado y lo he puesto L-X-V, ¿por qué me sale hoy?".
        Ahora se avanza hasta el primer día marcado a partir de ahí --
        como mucho una semana entera de margen (7), así que si el plan
        se crea el sábado con L-X-V, la primera tarea sale el lunes, no
        el sábado.
        """
        candidate = max(self.started_on, timezone.localtime(timezone.now()).date())
        marked_days = sorted(int(d) for d in self.custom_days_list())
        if not marked_days:
            return candidate
        for offset in range(7):
            day = candidate + timedelta(days=offset)
            if day.weekday() in marked_days:
                return day
        return candidate

    def sync_task(self):
        """
        Crea o actualiza la tarea que representa este plan en la lista
        del día.

        Es lo que evita que el usuario tenga que aprender tres conceptos
        (tarea, circuito y plan): crea el plan y le aparece la tarea, le
        da al play y entrena. El plan ya decidió qué ejercicios y con qué
        objetivo, que es para lo que existe.

        Qué categoría lleva la tarea, y qué campos extra se copian,
        depende de plan_type — ver el comentario junto al campo.

        Si el plan se pausa o se borra, su tarea pendiente desaparece —
        pero el historial de lo ya hecho se conserva.
        """
        pending = Task.objects.filter(
            series_id=self.task_series_id, is_done=False, expired=False,
        ) if self.task_series_id else Task.objects.none()

        if not self.is_active or self.deleted_at:
            pending.delete()
            return None

        category = {
            self.PLAN_TYPE_SPORT: Task.CATEGORY_SPORT,
            self.PLAN_TYPE_STUDY: Task.CATEGORY_STUDY,
            self.PLAN_TYPE_GENERAL: Task.CATEGORY_GENERAL,
        }[self.plan_type]

        fields = dict(
            title=self.name,
            category=category,
            # Solo Estudio · Idiomas lleva subcategoría propia — el resto
            # se queda en blanco, igual que antes de que esto existiera.
            subcategory=(
                Task.SUBCATEGORY_LANGUAGE
                if self.plan_type == self.PLAN_TYPE_STUDY and self.study_subtype == self.STUDY_SUBTYPE_LANGUAGE
                else ""
            ),
            repeat=self.repeat,
            interval=self.interval,
            custom_days=self.custom_days,
            # Sin hora límite, expire_overdue() nunca la toca — se
            # quedaría pendiente indefinidamente si un día no la juegas
            # y podrías completarla días después como si tal cosa, sin
            # que cuente como fallo para el plan. Con las 23:59 de por
            # defecto, si no la juegas ese día se resuelve sola por la
            # noche (ver mark_expired). Si el plan sí tiene una hora
            # propia puesta, esa manda.
            due_time=self.due_time or _dt.time(23, 59),
            user=self.user,
            # Puestos aquí, en la base, para que cambiar de objetivo (de
            # uno con vídeo a uno sin modo elegido, o de running a
            # fuerza) LIMPIE lo que ya no aplica en vez de dejarlo
            # pegado de una sincronización anterior — _study_target_fields
            # y _sport_mode_fields solo escriben lo que SÍ aplica, así
            # que sin este reseteo de base lo viejo se quedaría ahí.
            sport_mode="",
            youtube_video_id="",
            youtube_playlist_id="",
            watch_keyword="",
            watch_requires_audio=True,
            target_minutes=None,
            target_video_count=None,
            playlist_start_index=None,
            target_distance_km=None,
            max_pace_seconds_per_km=None,
            language_name="",
            level="",
        )

        if self.plan_type == self.PLAN_TYPE_STUDY:
            if self.study_subtype == self.STUDY_SUBTYPE_LANGUAGE:
                fields.update(self._language_target_fields())
            else:
                fields.update(self._study_target_fields())
                # Curso de Udemy: no es un study_subtype aparte, es que
                # el objetivo (headline) tiene palabra clave puesta en
                # vez de vídeo/playlist — igual que un headline con
                # youtube_video_id hace que la tarea sea "de vídeo".
                if fields.get("watch_keyword"):
                    fields["subcategory"] = Task.SUBCATEGORY_UDEMY
        elif self.plan_type == self.PLAN_TYPE_SPORT:
            fields.update(self._running_target_fields())
            fields.update(self._sport_mode_fields())

        task = pending.first()
        if task:
            for k, v in fields.items():
                setattr(task, k, v)
            task.save()
        else:
            task = Task.objects.create(
                due_date=self._first_task_due_date(),
                **fields,
            )
            self.task_series_id = task.series_id
            Plan.objects.filter(pk=self.pk).update(task_series_id=task.series_id)

        # General no tiene un paso aparte de "añadir objetivo": la propia
        # tarea diaria (completarla o no cada día) ES el objetivo, y no
        # hay nada más que configurar — así que se crea aquí, una vez,
        # un PlanItem de cumplimiento apuntando a esta misma serie.
        # Estudio SÍ necesita ese paso (el objetivo lleva el
        # vídeo/playlist/temporizador, hay que rellenarlo), así que ahí
        # no se crea nada solo — se añade desde el formulario de
        # objetivo, igual que en Deporte.
        if self.plan_type == self.PLAN_TYPE_GENERAL:
            PlanItem.objects.get_or_create(
                plan=self, series_id=self.task_series_id, exercise=None,
                defaults=dict(progression=PlanItem.PROG_COMPLETION, is_headline=True),
            )

        return task

    @classmethod
    def sync_all_tasks(cls, user=None):
        """
        Refresca la tarea de todos los planes activos.

        Hace falta más allá de crear/editar el plan: un plan de running
        sube de escalón con las sesiones cumplidas, y sin esto la tarea
        del día siguiente se generaría con el objetivo de ayer en vez
        del que toca hoy. Barato de llamar en cada carga de la lista,
        igual que Task.expire_overdue().
        """
        qs = cls.objects.filter(deleted_at__isnull=True, is_active=True)
        if user is not None:
            qs = qs.filter(user=user)
        for plan in qs:
            plan.sync_task()

    @property
    def task(self):
        """La tarea pendiente de este plan, si la hay."""
        if not self.task_series_id:
            return None
        return Task.objects.filter(
            series_id=self.task_series_id, is_done=False, expired=False,
        ).first()

    def ordered_items(self):
        """
        Los objetivos del plan en el orden en que se entrenan: el de
        PlanItem.order de siempre, pero con cada ejercicio con peso antes
        que su versión normal (ver weighted_first).
        """
        return weighted_first(self.items.select_related("exercise"))

    def session_items(self):
        """
        Los ejercicios de la sesión de hoy, en el formato que espera el
        reproductor. Sale del plan directamente: no hace falta circuito.
        """
        items = []
        for it in self.ordered_items():
            if not it.exercise:
                continue          # los objetivos de tarea no se "entrenan"
            if it.exercise.mode == Exercise.MODE_DISTANCE:
                continue          # running no se "juega" en el circuito — se importa
            t = it.current_target()
            items.append({
                "last_sets": it.last_session_set_reps(),
                "slug": it.exercise.slug,
                "name": it.display_name,
                "mode": it.exercise.mode,
                "counter_key": it.exercise.counter_key,
                "voice_step": it.exercise.voice_step,
                "target_sets": t["sets"],
                "target_reps": t["reps"],
                "target_weight_kg": t["weight_kg"],
                # Antes: "t['seconds'] or 40" -- un 40 inventado para
                # CUALQUIER ejercicio sin segundos objetivo, incluidos los
                # "al fallo" (PROG_FAILURE: t["seconds"] siempre None, ver
                # target_for_step) donde NO hay objetivo de tiempo que
                # cumplir por diseño. Eso hacía que un ejercicio al fallo
                # cronometrado (plancha, dead hang...) mostrara "3 × 40s"
                # en vez de "al fallo", y que el reproductor tratara los
                # 40s inventados como una cuenta atrás real en vez de
                # dejar contar libremente hasta que el usuario decida que
                # ha llegado al fallo (ver runTimer/runTimerWithPosture en
                # session-runner.js/circuit.js/plan-session.js, que ahora
                # tratan work=None como modo "al fallo" explícito).
                "work": t["seconds"],
                "rest": 30,
                "target_source": "plan",
                "plan_name": self.name,
                "is_headline": it.is_headline,
            })
        return items

    @property
    def headline(self):
        """
        La medida que define el plan.

        El objetivo de verdad ("estar en forma") es difuso y no se puede
        medir. Lo que sí se mide es una prueba concreta de que vas hacia
        él: llegar a 4x12 con 20 kg. Esa es la medida principal; el resto
        de ejercicios son el camino.

        Ya no hay una "estrella" que se marque a mano: es la primera por
        orden (en Estudio, la única) -- SALVO que el plan tenga un objetivo
        de andar/correr (distancia): ese manda siempre, esté en la
        posición que esté. De él salen la distancia y el ritmo que se
        copian a la tarea diaria (ver _running_target_fields); si dejara
        de ser el "principal" por reordenar objetivos, la tarea se quedaría
        sin objetivo y dejaría de autocompletarse al importar de Health
        Connect.
        """
        items = list(self.items.select_related("exercise"))
        if not items:
            return None
        for it in items:
            if it.exercise_id and it.exercise.mode == Exercise.MODE_DISTANCE:
                return it
        return items[0]

    @property
    def support_items(self):
        """Los ejercicios que te llevan al objetivo, sin ser la medida."""
        head = self.headline
        items = self.ordered_items()
        return [i for i in items if i.pk != head.pk] if head else items

    def progress_pct(self):
        """
        Cuánto llevas del plan — la MEDIA del progreso de TODOS los
        objetivos, no solo de la medida principal.

        ANTES: esto solo miraba `headline`, así que si tenías un plan
        con 8 ejercicios (típico tras "Añadir varios") y uno solo estaba
        marcado como medida principal, el % del plan entero dependía de
        ESE, y los otros 7 podían llevar cada uno su propio progreso por
        dentro (su propia barra en el "camino") sin que contara para
        nada a nivel de plan — reportado por Alex como "una tontería":
        si añades varios ejercicios a la vez, los varios deberían
        decidir el plan, no solo el que se marcó como principal.
        (Ya no existe ejercicio "estrella" en los planes de Deporte:
        todos cuentan igual y se ordenan libremente.)

        Cada objetivo aporta su propio `own_progress_pct()` (ver ahí el
        detalle de cumplimiento vs. escalones) y aquí se promedian todos
        los que se pueden medir — un objetivo sin destino definido
        (`own_progress_pct()` devuelve None) se queda fuera de la media
        en vez de contar como 0, igual que antes un plan sin destino no
        enseñaba ninguna barra en vez de una clavada en 0%.

        Estudio · Idiomas no tiene PlanItem (su medida es CourseModule,
        no un ejercicio con escalones) — se delega en `course_progress`,
        que ya calcula vídeos vistos/totales con el mismo criterio
        (Occurrence cumplida, no semanas pasadas).
        """
        if self.plan_type == self.PLAN_TYPE_STUDY and self.study_subtype == self.STUDY_SUBTYPE_LANGUAGE:
            return self.course_progress()["pct"]
        values = [p for p in (item.own_progress_pct() for item in self.items.all()) if p is not None]
        if not values:
            return None
        return round(sum(values) / len(values))

    def weekly_completion(self):
        """
        Ejecución de ESTA semana para el plan: de las sesiones que le
        tocaban de lunes a domingo, cuántas se han resuelto y cuántas
        de esas se cumplieron.

        No es un cálculo aparte: se apoya en las mismas Occurrence que
        genera la tarea del plan (ver sync_task / task_series_id), así
        que un plan sin tarea todavía (nunca activado) no tiene nada
        que enseñar aquí.
        """
        if not self.task_series_id:
            return None
        return Occurrence.weekly_completion(self.user, series_id=self.task_series_id)


class PlanItem(models.Model):
    """
    Una cosa que se persigue dentro de un plan.

    Puede ser un EJERCICIO (dominadas, plancha) o una TAREA cualquiera
    (estudiar francés, no fumar), porque un plan de verdad mezcla las dos
    cosas: "ponerme en forma" y "aprender francés" caben en el mismo
    trimestre.

    Y sobre todo: no todo progresa igual. Estudiar 2 horas no se
    convierte en 2 horas y media hasta el infinito — lo que se mide es si
    lo cumpliste. Por eso hay tres formas de avanzar:

      - cumplimiento: objetivo fijo. Se mide cuántas veces lo cumpliste.
        Para estudiar, antitareas, hábitos.
      - repeticiones: sube hasta un techo y ahí se queda. Para
        abdominales, plancha, resistencia — y también para fuerza con
        peso (dominadas/fondos/sentadillas con lastre): si el ejercicio
        lleva peso y se pone un "peso objetivo", entonces sube dentro de
        un rango de repeticiones y, al llegar arriba, AÑADE PESO y
        vuelve abajo del rango — así hasta llegar al peso objetivo. Sin
        peso objetivo puesto, el peso (si lo hay) se queda fijo y solo
        suben las repeticiones, como cualquier otro ejercicio.
        (Esto antes era una progresión "doble" aparte — PROG_DOUBLE
        sigue existiendo solo para reconocer objetivos ya guardados con
        ese valor; ya no se puede elegir en el formulario porque muy
        pocos ejercicios del catálogo llevan peso, y era una opción más
        a explicar para casi nadie.)
      - al fallo: cada serie se hace hasta el fallo (hasta que no
        puedas más), así que no hay un número de repeticiones que pedir
        de antemano — sería inventado, y encima lo normal es que la
        serie 2 rinda menos que la 1 por la fatiga acumulada, así que
        comparar reps contra reps penalizaría algo que es fisiológico,
        no un fallo de constancia. Lo único que se prescribe y progresa
        es el número de SERIES; las repeticiones se siguen guardando
        (para verlas en el historial, motivación/PR) pero no cuentan
        para el % de cumplimiento. El peso funciona igual que en
        repeticiones: fijo sin peso objetivo, o sube por ciclos de
        series con uno puesto.

    Sin la vuelta al suelo del rango al añadir peso, una progresión
    lineal de solo repeticiones divergiría sin sentido: subiendo 1
    repetición cada 2 sesiones, a los seis meses el plan pediría 3x47
    dominadas. Por eso, con peso objetivo puesto, lo que sube de verdad
    es la carga y las repeticiones vuelven siempre al suelo del rango.
    """
    PROG_COMPLETION = "completion"
    PROG_REPS = "reps"
    PROG_DOUBLE = "double"  # legado: ya no elegible, ver comentario arriba
    PROG_DISTANCE = "distance"
    PROG_FAILURE = "failure"

    PROGRESSION_CHOICES = [
        (PROG_COMPLETION, "Cumplimiento (objetivo fijo)"),
        (PROG_REPS, "Repeticiones (sube hasta un techo; con peso objetivo, sube peso por ciclos)"),
        (PROG_DISTANCE, "Distancia (running: sube km y baja ritmo)"),
        (PROG_FAILURE, "Al fallo (series sin objetivo de repeticiones)"),
    ]

    plan = models.ForeignKey(Plan, on_delete=models.CASCADE, related_name="items")

    # Una de las dos: a qué se refiere este objetivo.
    exercise = models.ForeignKey(
        Exercise, on_delete=models.CASCADE, null=True, blank=True,
        help_text="Para objetivos de ejercicio.",
    )
    series_id = models.UUIDField(
        null=True, blank=True,
        help_text="Para objetivos de tarea (estudiar, no fumar). Es la serie de la tarea.",
    )
    label = models.CharField(
        max_length=80, blank=True,
        help_text="Cómo llamarlo. En blanco usa el nombre del ejercicio o la tarea.",
    )

    progression = models.CharField(
        max_length=12, choices=PROGRESSION_CHOICES, default=PROG_REPS,
    )

    # Punto de partida
    start_sets = models.PositiveIntegerField(default=3)
    start_reps = models.PositiveIntegerField(default=8)
    start_seconds = models.PositiveIntegerField(default=40)
    start_weight_kg = models.FloatField(default=0)

    # Destino: hasta dónde quieres llegar. Sin esto el plan no sabría
    # cuándo ha terminado y subiría para siempre.
    goal_sets = models.PositiveIntegerField(null=True, blank=True)
    goal_reps = models.PositiveIntegerField(null=True, blank=True)
    goal_seconds = models.PositiveIntegerField(null=True, blank=True)
    goal_weight_kg = models.FloatField(null=True, blank=True)

    # Solo progresión "distance" (running): partida y destino, en km y
    # en segundos por km — mismo formato que Task.max_pace_seconds_per_km,
    # para poder copiarlo tal cual a la tarea diaria sin traducir nada.
    start_distance_km = models.FloatField(default=1.0)
    start_pace_seconds_per_km = models.PositiveIntegerField(
        default=420, help_text="Ritmo de partida, en segundos por km (420 = 7:00/km).",
    )
    goal_distance_km = models.FloatField(null=True, blank=True)
    goal_pace_seconds_per_km = models.PositiveIntegerField(
        null=True, blank=True, help_text="Ritmo de destino — más bajo es más rápido.",
    )
    distance_increment_km = models.FloatField(
        default=0.5, help_text="Cuánto sube la distancia en cada escalón.",
    )
    pace_decrement_seconds = models.PositiveIntegerField(
        default=10, help_text="Cuántos segundos por km se acelera el ritmo en cada escalón.",
    )

    # Solo objetivos de Deporte: cómo se hace el ejercicio — cámara,
    # circuito, o vídeo (reutiliza los mismos campos de youtube que
    # Estudio, justo abajo). Sin esto, el ejercicio caía siempre en
    # cámara/circuito, sin poder elegir vídeo como ya podían las
    # tareas sueltas.
    SPORT_MODE_CAMERA = "camera"
    SPORT_MODE_CIRCUIT = "circuit"
    SPORT_MODE_VIDEO = "video"
    SPORT_MODE_CHOICES = [
        (SPORT_MODE_CAMERA, "Conteo con la cámara"),
        (SPORT_MODE_CIRCUIT, "Circuito"),
        (SPORT_MODE_VIDEO, "Vídeo"),
    ]
    sport_mode = models.CharField(max_length=20, choices=SPORT_MODE_CHOICES, blank=True, default="")

    # El vídeo/playlist/temporizador propiamente dicho — para un
    # objetivo de Estudio (siempre) o de Deporte con sport_mode='video'
    # (opcional). Solo YouTube, no archivo local: el vídeo local se
    # guarda por UUID de tarea, y la tarea de un plan se regenera cada
    # día con un UUID distinto — perdería el archivo a la mañana
    # siguiente, así que no tiene sentido ofrecerlo aquí.
    youtube_video_id = models.CharField(max_length=255, blank=True)
    youtube_playlist_id = models.CharField(max_length=255, blank=True)
    # Alternativa a vídeo/playlist, solo Estudio · Hábito simple: si se
    # pone, la tarea diaria que genera el plan sale como "Curso de
    # Udemy" (Task.SUBCATEGORY_UDEMY) con esta palabra clave, y se
    # completa exactamente igual que una tarea suelta de Udemy — ver
    # Plan._study_target_fields() y Plan.auto_close_expired().
    watch_keyword = models.CharField(max_length=120, blank=True)
    # Igual que Task.watch_requires_audio (mismo significado) -- se
    # copia a la tarea diaria en Plan._study_target_fields().
    watch_requires_audio = models.BooleanField(default=True)
    # Progreso del curso guardado EN el propio objetivo (lo manda la
    # extensión de Chrome desde la API de Udemy). No depende de que la
    # tarea diaria del plan exista/tenga la misma serie/palabra clave.
    course_progress_pct = models.PositiveIntegerField(null=True, blank=True)
    course_lessons_done = models.PositiveIntegerField(null=True, blank=True)
    course_lessons_total = models.PositiveIntegerField(null=True, blank=True)
    target_minutes = models.PositiveIntegerField(null=True, blank=True)
    target_video_count = models.PositiveIntegerField(null=True, blank=True)

    # Caché de la playlist de arriba (solo Estudio · Hábito simple, con
    # youtube_playlist_id puesto): la lista ORDENADA de vídeos que tenía
    # la playlist la última vez que se sincronizó, con su duración —
    # [{"video_id": "...", "duration_seconds": 933}, ...]. Se rellena en
    # sync_playlist_videos(), llamado SOLO al guardar el objetivo (vista
    # o API) -- NUNCA desde Plan.sync_task()/_study_target_fields(), que
    # se ejecuta en cada carga de la lista de tareas y sería demasiado
    # caro/lento si llamara a la API de YouTube ahí. Es lo que permite
    # que la tarea diaria sepa qué vídeo concreto toca hoy (ver
    # Plan._study_playlist_progress) en vez de reiniciar la playlist
    # entera cada día. Sin caché (playlist recién puesta y aún sin
    # guardar, o la API de YouTube falló al sincronizar), el plan cae al
    # comportamiento de siempre: la playlist entera, sin seguimiento.
    playlist_videos_cache = models.JSONField(default=list, blank=True)
    # Cuándo se sincronizó la caché de arriba por última vez -- también
    # marca desde cuándo cuentan las Occurrence para calcular el avance
    # (Plan._study_playlist_progress): cambiar de playlist reinicia el
    # progreso sin más estado que mantener, porque el conteo simplemente
    # empieza a contar desde esta fecha en vez de desde el inicio del plan.
    playlist_synced_at = models.DateTimeField(null=True, blank=True)

    # Cómo avanza
    sessions_per_step = models.PositiveIntegerField(
        default=2, help_text="Cada cuántas sesiones cumplidas se sube un escalón.",
    )
    reps_increment = models.PositiveIntegerField(default=1)
    weight_increment_kg = models.FloatField(
        default=2.5,
        help_text="Solo si hay peso objetivo puesto (reps o al fallo, en un ejercicio con peso): "
                  "cuánto se añade al completar el rango/ciclo.",
    )
    rep_range_low = models.PositiveIntegerField(
        default=6,
        help_text="Solo en repeticiones con peso objetivo puesto: a cuántas repeticiones se vuelve al subir peso.",
    )
    # reps_increment/weight_increment_kg/rep_range_low (arriba) son del
    # modo antiguo -- un objetivo con weekly_linear=True ya no los usa,
    # se quedan solo por compatibilidad con objetivos creados antes de
    # esto. Ver weekly_linear más abajo y target_for_step.
    weekly_linear = models.BooleanField(
        default=False,
        help_text="Reparte el objetivo linealmente entre las semanas del plan (de partida a "
                  "destino, a partes iguales) en vez de subir por ciclos con incremento manual. "
                  "Solo aplica a 'repeticiones' y 'al fallo'. Por defecto en objetivos nuevos "
                  "(plan_item_form/plan_item_bulk_form); los antiguos se quedan en False para no "
                  "cambiarles el objetivo de un día para otro.",
    )

    # El toque de entrenador
    deload_after_failures = models.PositiveIntegerField(
        default=3,
        help_text="Tras estas sesiones seguidas sin llegar al objetivo, se baja un escalón. "
                   "0 lo desactiva.",
    )

    is_headline = models.BooleanField(
        default=False,
        help_text="La medida que define si el plan se ha conseguido. "
                   "\"Estar en forma\" no se puede medir; \"4x12 con 20 kg\" sí — "
                   "esa es la prueba de que vas hacia el objetivo. El resto de "
                   "ejercicios son el camino, progresan pero no deciden.",
    )
    order = models.PositiveIntegerField(default=0)

    class Meta:
        # "pk" al final no es cosmético: con casi todos los PlanItem
        # empatados a order=0 (nadie los ha reordenado con las flechas),
        # sin un desempate explícito el orden entre ellos no estaría
        # garantizado por Django/SQL — hoy "funciona" porque así es como
        # SQLite devuelve las filas empatadas en la práctica, pero eso es
        # un detalle de implementación, no una garantía. Con "pk" se
        # asegura el orden de creación de verdad mientras nadie reordene
        # a mano — y una vez que sí lo hacen, "order" ya no tiene
        # empates entre ellos (plan_item_move los renumera 0,1,2...) así
        # que "pk" deja de intervenir.
        # Ya NO hay ejercicio "estrella" que se cuele el primero: el orden
        # es solo `order` (lo que se ve en pantalla y lo que sigue la
        # sesión), así se puede subir/bajar cualquier ejercicio.
        ordering = ["order", "pk"]

    def save(self, *args, **kwargs):
        # Un objetivo nuevo se pone al final del plan. Sin esto todos
        # nacían con order=0 y, una vez renumerados los demás (0,1,2...),
        # el nuevo se colaba en segunda posición por el empate con el 0.
        # Solo actúa si order=0 choca con uno que ya existe (así un order
        # puesto a mano, o el primer objetivo del plan, no se toca).
        if self._state.adding and not self.order and self.plan_id:
            siblings = PlanItem.objects.filter(plan_id=self.plan_id)
            if siblings.filter(order=0).exists():
                self.order = siblings.aggregate(m=models.Max("order"))["m"] + 1
        # Mismo trato que Task: si pegas la URL entera, se limpia sola a
        # la hora de guardar. Sin esto, un objetivo de Estudio guardaría
        # la URL completa en vez del id, aunque la tarea que genera el
        # plan sí saliera bien (Task.save() ya lo limpia por su lado) —
        # inconsistente y confuso si algún día se enseña este dato aquí.
        raw = (self.youtube_video_id or "").strip()
        if raw:
            m = _YOUTUBE_ID_RE.search(raw)
            self.youtube_video_id = m.group(1) if m else raw
        raw_pl = (self.youtube_playlist_id or "").strip()
        if raw_pl:
            m = _YOUTUBE_PLAYLIST_ID_RE.search(raw_pl)
            self.youtube_playlist_id = m.group(1) if m else raw_pl
        super().save(*args, **kwargs)

    def sync_playlist_videos(self):
        """
        Refresca playlist_videos_cache desde la API de YouTube — se llama
        SOLO al guardar el objetivo (vista o API), nunca desde
        Plan.sync_task()/_study_target_fields() (eso se ejecuta en cada
        carga de la lista de tareas, y una llamada a la API ahí sería
        demasiado cara/lenta). Cambiar de playlist reinicia el avance
        sin más estado que mantener: playlist_synced_at pasa a ahora, y
        Plan._study_playlist_progress() solo cuenta lo hecho desde esa
        fecha en adelante.

        Sin youtube_playlist_id, limpia la caché (por si el objetivo
        tenía una playlist antes y se ha quitado). Si la API de YouTube
        falla (sin YOUTUBE_API_KEY, cuota agotada, sin conexión...), se
        deja la caché tal cual estaba — _study_target_fields ya sabe
        caer al comportamiento de siempre (playlist entera, sin
        seguimiento) cuando no hay caché.
        """
        from .youtube_search import YouTubeSearchError, get_videos_details, list_playlist_items

        if not self.youtube_playlist_id:
            if self.playlist_videos_cache or self.playlist_synced_at:
                self.playlist_videos_cache = []
                self.playlist_synced_at = None
                self.save(update_fields=["playlist_videos_cache", "playlist_synced_at"])
            return

        try:
            items = list_playlist_items(self.youtube_playlist_id, max_results=500)
            video_ids = [it["video_id"] for it in items if it.get("video_id")]
            details = get_videos_details(video_ids) if video_ids else {}
        except YouTubeSearchError:
            return

        cache = []
        for vid in video_ids:
            d = details.get(vid) or {}
            if d.get("embeddable") is False:
                continue  # no se podría incrustar en la tarea — se salta, como en los cursos de idioma
            cache.append({"video_id": vid, "duration_seconds": d.get("duration_seconds")})

        self.playlist_videos_cache = cache
        self.playlist_synced_at = timezone.now()
        self.save(update_fields=["playlist_videos_cache", "playlist_synced_at"])

    def __str__(self):
        return f"{self.plan.name}: {self.display_name}"

    @property
    def display_name(self):
        if self.label:
            return self.label
        if self.exercise:
            return self.exercise.name
        occ = Occurrence.objects.filter(series_id=self.series_id).first()
        return occ.title if occ else "Objetivo"

    @property
    def is_timed(self):
        return bool(self.exercise and self.exercise.mode == Exercise.MODE_TIMED)

    def current_course_progress_pct(self):
        """
        Solo para un objetivo de "Curso de Udemy" (watch_keyword puesto,
        sin ejercicio): el % de curso completado que reportó Udemy la
        última vez que la extensión de Chrome lo comprobó (ver
        Task.course_progress_pct/record_course_progress). None si esto
        no es un objetivo de Udemy, o si es uno pero todavía no ha
        llegado ningún dato (curso recién creado, o Udemy cambió su
        maquetación y la extensión no la reconoce) — nunca se inventa
        un 0 de partida.
        """
        info = self.course_progress()
        return info["pct"] if info else None

    def record_course_progress(self, pct, done=None, total=None):
        try:
            pct = max(0, min(100, round(float(pct))))
        except (TypeError, ValueError):
            return
        self.course_progress_pct = pct
        fields = ["course_progress_pct"]
        try:
            if done is not None and total is not None and int(total) > 0:
                self.course_lessons_total = int(total)
                self.course_lessons_done = max(0, min(int(done), int(total)))
                fields += ["course_lessons_done", "course_lessons_total"]
        except (TypeError, ValueError):
            pass
        self.save(update_fields=fields)

    def course_progress(self):
        """
        {pct, done, total, left} del curso de Udemy según las fracciones
        "x/y" que leyó la extensión, o None si aún no hay ningún dato.
        Mira la última tarea de la serie QUE TENGA dato (no simplemente
        la de fecha más reciente: la del día siguiente nace vacía).
        """
        if not self.watch_keyword:
            return None
        if self.course_progress_pct is not None:
            done, total = self.course_lessons_done, self.course_lessons_total
            return {
                "pct": self.course_progress_pct, "done": done, "total": total,
                "left": (total - done) if (done is not None and total) else None,
            }
        if not self.series_id:
            return None
        task = (
            Task.objects.filter(series_id=self.series_id, course_progress_pct__isnull=False)
            .order_by("-due_date").first()
        )
        if not task:
            return None
        done, total = task.course_lessons_done, task.course_lessons_total
        return {
            "pct": task.course_progress_pct,
            "done": done,
            "total": total,
            "left": (total - done) if (done is not None and total) else None,
        }

    def display_target_text(self):
        """
        Qué decir en "Hoy te toca" para un objetivo de TAREA (sin
        ejercicio: Estudio · Hábito simple o General) -- current_target()
        siempre devuelve start_sets/start_reps para PROG_COMPLETION
        porque el modelo necesita algún valor por defecto, pero
        mostrarlos tal cual en la pantalla no significa nada ("3 × 8" de
        una tarea de estudiar francés) — ni siquiera es un bug solo de
        Udemy, cualquier objetivo de cumplimiento sin ejercicio lo
        arrastraba. Las plantillas llaman a esto en vez de leer
        pack.target.sets/reps cuando self.exercise es None.
        """
        if self.watch_keyword:
            pct = self.current_course_progress_pct()
            return f"{pct}% del curso completado" if pct is not None else "sigue el curso de Udemy"
        if self.youtube_playlist_id:
            progress = self.plan._study_playlist_progress(self)
            if progress["total"]:
                return f"vídeo {progress['index'] + 1} de {progress['total']}"
            return "sigue la playlist"
        if self.youtube_video_id:
            return "ver el vídeo de hoy"
        if self.target_minutes:
            return f"estudiar {self.target_minutes} min"
        return "cumplir hoy"

    # ------------------------------------------------------- historial

    def _sessions(self):
        """Sesiones de este objetivo dentro del plan, en orden."""
        if not self.exercise:
            return WorkoutSession.objects.none()
        return WorkoutSession.objects.filter(
            plan=self.plan, exercise=self.exercise.slug, deleted_at__isnull=True
        ).order_by("recorded_at")

    def _occurrences(self):
        """Para objetivos de tarea: los días registrados de esa serie."""
        if not self.series_id:
            return Occurrence.objects.none()
        return Occurrence.objects.filter(
            series_id=self.series_id, deleted_at__isnull=True,
            recorded_at__date__gte=self.plan.started_on,
        ).order_by("recorded_at")

    @property
    def is_distance(self):
        """Objetivo de correr/caminar (mide km y ritmo, no series)."""
        return bool(self.exercise_id and self.exercise.mode == Exercise.MODE_DISTANCE)

    def distance_days(self):
        """
        Para objetivos de distancia: UN resultado por DÍA (de más antiguo a
        más nuevo), sumando todas las sesiones de ese día.

        Health Connect / el móvil pueden mandar varias sesiones el mismo
        día (paseos partidos, resincronizaciones...) y el plan pide una
        cosa al día ("10 km a 15 min/km"), así que el día cuenta como
        cumplido si entre todas las sesiones suman la distancia pedida Y
        el ritmo medio del día llega al ritmo pedido (si lo hay).
        """
        by_day = {}
        for s in self._sessions():
            by_day.setdefault(timezone.localtime(s.recorded_at).date(), []).append(s)
        # Solo cuentan los días en que el plan pide algo (p.ej. lunes a
        # viernes). Health Connect manda TODO lo que el móvil detecta, también
        # un paseo suelto del sábado; sin este filtro ese día salía en el plan
        # como una sesión fallada (0,1 km de 10) y hundía la racha, a pesar de
        # que ese día no toca nada.
        plan_days = set()
        if self.plan_id and self.plan.repeat == "custom":
            plan_days = {int(d) for d in self.plan.custom_days_list()}
        rows = []
        for day in sorted(by_day):
            if plan_days and day.weekday() not in plan_days:
                continue
            ss = by_day[day]
            dist = sum(s.distance_km or 0 for s in ss)
            tgt = next((s for s in reversed(ss) if s.target_distance_km), None)
            if tgt:
                pct = round(100 * dist / tgt.target_distance_km)
                pace = day_average_pace(ss)
                tp = tgt.target_pace_seconds_per_km
                # Ritmo desconocido (sesión sin duración) NO es incumplirlo:
                # mismo criterio que running_import y Task.auto_progress.
                if tp and pace is not None and pace > tp:
                    pct = 0
            else:
                pct = max(((s.achievement_pct or 0) for s in ss), default=0)
                pace = None
            rows.append({
                "date": day, "distance": dist, "pace": pace, "pct": min(200, pct),
                "met": pct >= 100,
                "target_km": tgt.target_distance_km if tgt else None,
                "target_pace": tgt.target_pace_seconds_per_km if tgt else None,
            })
        return rows

    def session_count(self):
        """Sesiones que cuentan para el objetivo (días, si es de distancia)."""
        return len(self.distance_days()) if self.is_distance else self._sessions().count()

    def last_session_set_reps(self):
        """
        Repeticiones de CADA serie en la última sesión guardada de este
        objetivo, p. ej. [12, 10, 9] -- para cualquier objetivo de un
        ejercicio con repeticiones (con o sin reps objetivo, al fallo o
        no). Sirve para decir por voz (y enseñar) al empezar cada serie
        "la última vez hiciste X en esta serie", serie por serie.

        None si no aplica o si no hay ninguna sesión anterior con las
        reps por serie guardadas (las sesiones previas a este campo solo
        tienen el total, no se puede inventar el reparto).

        Ver last_set_reps(): primero se mira lo hecho dentro de este mismo
        plan y, si ahí no hay nada, la última vez que se hizo el ejercicio
        en cualquier sitio (entreno suelto, otro plan).
        """
        if not self.exercise_id:
            return None
        if self.exercise.mode == Exercise.MODE_DISTANCE:
            return None
        return last_set_reps(self.plan.user, self.exercise.slug, plan=self.plan)

    def successes_and_streak(self):
        """
        Cuántas veces se cumplió el objetivo, y cuántos fallos seguidos
        van al final. Lo segundo es lo que dispara la bajada de escalón.
        """
        if self.is_distance and not (self.progression == self.PROG_COMPLETION and self.series_id):
            results = [d["met"] for d in self.distance_days()]
        elif self.progression == self.PROG_COMPLETION:
            results = [
                o.result == Occurrence.RESULT_DONE for o in self._occurrences()
            ] if self.series_id else [
                (s.achievement_pct or 0) >= 100 for s in self._sessions()
            ]
        else:
            results = [(s.achievement_pct or 0) >= 100 for s in self._sessions()]

        successes = sum(1 for r in results if r)
        streak = 0
        for r in reversed(results):
            if r:
                break
            streak += 1
        return successes, streak

    def current_step(self):
        """
        En qué escalón estás.

        Avanza con las sesiones CUMPLIDAS, no con las hechas: si te
        quedas corto, el objetivo no sube — que es justo lo que haría un
        entrenador. Y si fallas varias veces seguidas, baja uno, para no
        quedarte atascado para siempre en un número que hoy no puedes.
        """
        successes, failure_streak = self.successes_and_streak()
        step = successes // max(1, self.sessions_per_step)
        if self.deload_after_failures and failure_streak >= self.deload_after_failures:
            step = max(0, step - 1)
        return step

    def sessions_to_next_step(self):
        """
        Cuántas sesiones cumplidas más hacen falta para subir al
        siguiente escalón (y por tanto para que suban las reps/peso de
        hoy).

        Para "cumplimiento" no hay escalón que subir (progress_pct ya se
        mide distinto ahí), así que no aplica.

        Es lo que le faltaba a la pantalla del plan para que 3 sesiones
        al 100% con sessions_per_step=4 no se sintieran como "no cuenta
        nada": antes solo se veía el objetivo de hoy sin cambiar, sin
        decir que ya llevabas 3 de las 4 que hacían falta.
        """
        if self.progression == self.PROG_COMPLETION or self.is_flat:
            return None
        successes, _ = self.successes_and_streak()
        per_step = max(1, self.sessions_per_step)
        return per_step - (successes % per_step)

    @property
    def is_flat(self):
        """
        True si el objetivo no cambia nunca de escalón a escalón — el
        caso de running "sin progresión" (incremento y desaceleración a
        cero, sin destino), pero también cualquier otra progresión sin
        techo/destino puesto que por eso se queda fija en el punto de
        partida para siempre (ver target_for_step).

        Sirve para no enseñar pistas de "sube al siguiente escalón" ni
        una tabla de 60 filas idénticas cuando en realidad no hay ningún
        escalón que subir: antes de esto, cualquier progresión sin
        destino (`sessions_to_goal() is None`) caía en el mismo tope fijo
        de 60 filas como red de seguridad — pensado para progresiones que
        SÍ siguen cambiando sin límite (reps sin techo), no para una que
        ya no cambia nunca (p. ej. un plan de running de 10 km todos los
        días).
        """
        return self.target_for_step(0) == self.target_for_step(1)

    # -------------------------------------------------------- objetivo

    def _sets_for_progress(self, frac):
        """
        Cuántas series tocan según lo avanzado que vas (`frac`: 0 = en
        el punto de partida, 1 = ya en el destino), interpolando en
        línea recta entre `start_sets` y `goal_sets`.

        Antes esto no existía: `target_for_step` usaba directamente
        `goal_sets or start_sets`, así que las series saltaban al
        destino desde el primer día sin importar el escalón — un plan
        de 2×5 a 4×12 enseñaba "4×5" nada más empezar. Sin meta de
        series, se quedan fijas en las de partida (no hay destino con
        el que interpolar).
        """
        if self.goal_sets is None:
            return self.start_sets
        return round(self.start_sets + frac * (self.goal_sets - self.start_sets))

    @staticmethod
    def _progress_fraction(value, start, ceiling):
        """De 0 a 1: cuánto camino hay entre `start` y `ceiling` ya
        recorrido en `value`. Sin techo definido no hay destino con el
        que medir el progreso, así que se queda en 0 (series fijas)."""
        if not ceiling:
            return 0.0
        if ceiling <= start:
            return 1.0 if value >= ceiling else 0.0
        return min(1.0, max(0.0, (value - start) / (ceiling - start)))

    def _weekly_fraction(self, step):
        """
        De 0 a 1: en qué punto del plan estás, para repartir el objetivo
        linealmente entre las semanas (weekly_linear) en vez de por
        ciclos con incremento manual.

        Un escalón = una semana: sessions_per_step se pone igual a las
        sesiones/semana del plan al crear el objetivo (plan_item_form /
        plan_item_bulk_form), así que `step` (0 = primera semana) avanza
        exactamente una vez por semana cumplida. En la ÚLTIMA semana
        (step == weeks - 1) ya vale 1.0, así que el destino se alcanza
        siempre en esa semana — sea cual sea la distancia entre inicio y
        destino, sin necesidad de calcular "cuánto subir cada vez" a
        mano, que es justo lo que pedía Alex ("matemática simple").
        """
        weeks = self.plan.weeks if self.plan_id and self.plan.weeks else 1
        return min(1.0, (step + 1) / max(1, weeks))

    def target_for_step(self, step):
        """El objetivo en el escalón `step` (0 = el primero)."""
        if self.progression == self.PROG_COMPLETION:
            return {
                "sets": self.start_sets, "reps": self.start_reps,
                "seconds": self.start_seconds if self.is_timed else None,
                "weight_kg": self.start_weight_kg, "done": False,
                "distance_km": None, "pace_seconds_per_km": None,
            }

        if self.progression == self.PROG_DISTANCE:
            distance = self.start_distance_km + step * self.distance_increment_km
            if self.goal_distance_km:
                distance = min(distance, self.goal_distance_km)
            pace = self.start_pace_seconds_per_km - step * self.pace_decrement_seconds
            if self.goal_pace_seconds_per_km:
                # Un ritmo MENOR es más rápido — "llegar" es no bajar de ahí.
                pace = max(pace, self.goal_pace_seconds_per_km)
            done = bool(
                self.goal_distance_km and distance >= self.goal_distance_km
                and self.goal_pace_seconds_per_km and pace <= self.goal_pace_seconds_per_km
            )
            return {
                "sets": None, "reps": None, "seconds": None, "weight_kg": None,
                "distance_km": round(distance, 2), "pace_seconds_per_km": pace, "done": done,
            }

        if self.progression == self.PROG_FAILURE:
            # No hay reps que pedir (esa es la idea de ir al fallo) — lo
            # que sube es el número de series, igual de despacio que en
            # PROG_REPS (un paso = un escalón de start_sets a goal_sets).
            #
            # El peso es aparte y sigue la misma regla que cualquier otro
            # destino del plan: sin "peso objetivo" puesto, no hay con qué
            # medir cuánto subir, así que se queda fijo en el inicial para
            # siempre (esto es lo que quiere quien no pone incremento de
            # peso — dominadas/fondos siempre con el mismo lastre, o sin
            # peso ninguno).
            if self.weekly_linear:
                # Reparto lineal por semanas del plan (ver weekly_linear):
                # nada de ciclos ni de pedir "cada cuántas sesiones sube" o
                # "cuánto añadir" a mano — un escalón = una semana
                # (sessions_per_step se pone igual a las sesiones/semana
                # del plan al crear el objetivo) y series y peso suben A
                # LA VEZ, en línea recta desde el inicio hasta el destino,
                # cada uno con el suyo (sin destino puesto, ese en
                # concreto se queda fijo, igual que en el modo antiguo).
                frac = self._weekly_fraction(step)
                sets = self._sets_for_progress(frac)
                weight = (
                    self.start_weight_kg + frac * (self.goal_weight_kg - self.start_weight_kg)
                    if self.goal_weight_kg is not None else self.start_weight_kg
                )
                sets_ok = self.goal_sets is None or sets >= self.goal_sets
                weight_ok = self.goal_weight_kg is None or weight >= self.goal_weight_kg
                done = bool(frac >= 1.0 and sets_ok and weight_ok and (self.goal_sets or self.goal_weight_kg is not None))
                return {
                    "sets": sets, "reps": None, "seconds": None,
                    "weight_kg": round(weight, 1), "done": done,
                    "distance_km": None, "pace_seconds_per_km": None,
                }
            # Modo antiguo (objetivos creados antes de weekly_linear): con
            # un peso objetivo puesto, se completa un ciclo entero de
            # series (start_sets→goal_sets) al peso actual y, al llegar
            # arriba, se añade el peso y las series vuelven a empezar
            # desde start_sets — así hasta llegar al peso objetivo.
            if self.goal_weight_kg is not None and self.weight_increment_kg:
                total_steps = (
                    self.goal_sets - self.start_sets
                    if (self.goal_sets and self.goal_sets > self.start_sets) else 0
                )
                span = total_steps + 1
                cycles, within = divmod(step, span)
                frac = min(1.0, within / total_steps) if total_steps else 1.0
                sets = self._sets_for_progress(frac)
                weight = min(
                    self.start_weight_kg + cycles * self.weight_increment_kg,
                    self.goal_weight_kg,
                )
                sets_ok = self.goal_sets is None or sets >= self.goal_sets
                done = bool(weight >= self.goal_weight_kg and sets_ok)
            else:
                if self.goal_sets and self.goal_sets > self.start_sets:
                    total_steps = self.goal_sets - self.start_sets
                    frac = min(1.0, step / total_steps) if total_steps else 1.0
                else:
                    frac = 0.0
                sets = self._sets_for_progress(frac)
                weight = self.start_weight_kg
                done = bool(self.goal_sets and sets >= self.goal_sets)
            return {
                "sets": sets, "reps": None, "seconds": None,
                "weight_kg": round(weight, 1), "done": done,
                "distance_km": None, "pace_seconds_per_km": None,
            }

        # PROG_REPS (y el antiguo PROG_DOUBLE, que ya no se puede elegir en
        # el formulario pero sigue funcionando igual en objetivos guardados
        # con ese valor): sube hasta el techo y ahí se queda. No aplica a
        # algo cronometrado — aguantar con peso no tiene esta mecánica de
        # rango de repeticiones, así que ahí el peso (si lo hay) va
        # siempre fijo.
        if self.weekly_linear:
            # Mismo reparto lineal por semanas que en PROG_FAILURE (ver
            # el comentario de ahí) — reps/segundos y peso suben a la vez,
            # en línea recta, cada uno con su propio destino.
            frac = self._weekly_fraction(step)
            if self.is_timed:
                seconds = (
                    round(self.start_seconds + frac * (self.goal_seconds - self.start_seconds))
                    if self.goal_seconds else self.start_seconds
                )
                done = bool(self.goal_seconds and frac >= 1.0)
                return {
                    "sets": self._sets_for_progress(frac), "reps": None,
                    "seconds": seconds, "weight_kg": self.start_weight_kg,
                    "done": done,
                    "distance_km": None, "pace_seconds_per_km": None,
                }
            reps = (
                round(self.start_reps + frac * (self.goal_reps - self.start_reps))
                if self.goal_reps else self.start_reps
            )
            weight = (
                self.start_weight_kg + frac * (self.goal_weight_kg - self.start_weight_kg)
                if self.goal_weight_kg is not None else self.start_weight_kg
            )
            done = bool(frac >= 1.0 and (self.goal_reps or self.goal_weight_kg is not None))
            return {
                "sets": self._sets_for_progress(frac), "reps": reps,
                "seconds": None, "weight_kg": round(weight, 1), "done": done,
                "distance_km": None, "pace_seconds_per_km": None,
            }

        if self.is_timed:
            seconds = self.start_seconds + step * self.reps_increment
            ceiling = self.goal_seconds
            if ceiling:
                seconds = min(seconds, ceiling)
            frac = self._progress_fraction(seconds, self.start_seconds, ceiling)
            return {
                "sets": self._sets_for_progress(frac), "reps": None,
                "seconds": seconds, "weight_kg": self.start_weight_kg,
                "done": bool(ceiling and seconds >= ceiling),
                "distance_km": None, "pace_seconds_per_km": None,
            }

        # El peso es opcional, con la misma idea que en "al fallo": sin
        # "peso objetivo" puesto, no hay con qué medir cuánto subir, y se
        # queda fijo en el inicial — solo suben las repeticiones, como
        # cualquier ejercicio sin peso. Con uno puesto (esto es lo que
        # antes hacía falta elegir "Doble" aparte para conseguir), se sube
        # dentro de un rango de repeticiones y, al completarlo, se añade
        # peso y las repeticiones vuelven al suelo del rango — así hasta
        # llegar al peso objetivo.
        ceiling = self.goal_reps
        if self.goal_weight_kg is not None and self.weight_increment_kg:
            top = ceiling or (self.rep_range_low + 6)
            low = min(self.rep_range_low, top)
            span = max(1, top - low + 1)
            cycles, within = divmod(step, span)
            reps = low + within
            weight = self.start_weight_kg + cycles * self.weight_increment_kg
            if weight >= self.goal_weight_kg:
                # Llegado el peso objetivo, se deja de añadir carga y solo
                # quedan las repeticiones que falten para cerrar el plan.
                weight = self.goal_weight_kg
                reps = min(low + within, top)
            done = bool(weight >= self.goal_weight_kg and reps >= top)
            frac = self._progress_fraction(weight, self.start_weight_kg, self.goal_weight_kg)
            return {
                "sets": self._sets_for_progress(frac), "reps": reps,
                "seconds": None, "weight_kg": round(weight, 1), "done": done,
                "distance_km": None, "pace_seconds_per_km": None,
            }

        reps = self.start_reps + step * self.reps_increment
        if ceiling:
            reps = min(reps, ceiling)
        frac = self._progress_fraction(reps, self.start_reps, ceiling)
        return {
            "sets": self._sets_for_progress(frac), "reps": reps,
            "seconds": None, "weight_kg": self.start_weight_kg,
            "done": bool(ceiling and reps >= ceiling),
            "distance_km": None, "pace_seconds_per_km": None,
        }

    def current_target(self):
        return self.target_for_step(self.current_step())

    def schedule(self, count=12):
        """La tabla de progresión, para ver el camino antes de empezar."""
        rows = []
        for i in range(count):
            row = dict(step=i + 1, **self.target_for_step(i))
            rows.append(row)
            if row["done"]:
                break      # llegado el destino, no hay más que enseñar
        return rows

    def weekly_schedule(self, weeks, sessions_per_week):
        """
        Lo mismo que `schedule()` pero por SEMANA en vez de por escalón —
        "semana 1: tanto, semana 2: tanto más" en vez de "escalón 3".

        No toca la base de datos (como `schedule()`): sirve igual para un
        objetivo ya guardado que para uno todavía sin guardar, que es
        justo lo que hace falta para enseñar la vista previa de un plan
        generado por IA antes de confirmarlo.

        La conversión semana → escalón es la misma cuenta que ya hace la
        calculadora de "¿en cuántas semanas quieres llegar?" del
        formulario (sessions_per_step sesiones por escalón, tantas
        sesiones a la semana como días tenga el plan).
        """
        rows = []
        for week in range(1, weeks + 1):
            total_sessions = week * max(1, sessions_per_week)
            step = max(0, round(total_sessions / max(1, self.sessions_per_step)) - 1)
            row = dict(week=week, **self.target_for_step(step))
            rows.append(row)
            if row["done"]:
                break
        return rows

    def history(self, limit=20):
        """
        Lo que pasó de verdad: qué te pedía cada sesión, qué hiciste y el
        porcentaje. El objetivo sale de la propia sesión (se guardó
        entonces), no se recalcula — si se recalculara, un entreno de
        hace un mes se compararía con el objetivo de hoy.
        """
        if self.progression == self.PROG_COMPLETION and self.series_id:
            return [
                {
                    "date": o.due_date or o.recorded_at.date(),
                    "target": "cumplir",
                    "done": "sí" if o.result == Occurrence.RESULT_DONE else "no",
                    "pct": 100 if o.result == Occurrence.RESULT_DONE else 0,
                    "auto": o.auto_expired,
                }
                for o in self._occurrences().order_by("-recorded_at")[:limit]
            ]

        if self.is_distance:
            def _pace(sec):
                mm, ss = divmod(int(round(sec)), 60)
                return f"{mm}:{ss:02d}/km"

            def _km(v):
                return (f"{v:.2f}".rstrip("0").rstrip(".") if v else "0") + " km"

            rows = []
            for d in reversed(self.distance_days()):
                pedia = "—"
                if d["target_km"]:
                    pedia = _km(d["target_km"]) + (f" a {_pace(d['target_pace'])}" if d["target_pace"] else "")
                hecho = _km(d["distance"]) + (f" a {_pace(d['pace'])}" if d["pace"] else "")
                rows.append({
                    "date": d["date"], "target": pedia, "done": hecho,
                    "pct": d["pct"], "met": d["met"], "auto": False,
                })
            return rows[:limit]

        rows = []
        for s in self._sessions().order_by("-recorded_at")[:limit]:
            hecho = (
                f"{s.total_reps} reps" if s.total_reps
                else f"{s.session_duration_seconds}s"
            )
            rows.append({
                "date": s.recorded_at.date(),
                "target": s.target_label or "—",
                "done": hecho,
                "pct": s.achievement_pct,
                "auto": False,
            })
        return rows

    def sessions_to_goal(self, limit=200):
        """Cuántas sesiones cumplidas faltan para el destino, o None si
        el objetivo no tiene final definido."""
        for i in range(self.current_step(), limit):
            if self.target_for_step(i)["done"]:
                return max(0, (i - self.current_step()) * self.sessions_per_step)
        return None

    def own_progress_pct(self):
        """
        Cuánto lleva ESTE objetivo por su cuenta, del 0 al 100 (o None si
        no se puede medir — ver más abajo).

        Es la misma cuenta que antes solo se hacía para la medida
        principal del plan (Plan.progress_pct() llamaba a esto contra
        `headline` y ya está — el resto de objetivos, aunque llevaran su
        propio progreso por dentro, no contaban para nada a nivel de
        plan). Al añadir varios objetivos de golpe (alta rápida) eso
        empezó a notarse como una tontería: tener 8 ejercicios al fallo
        avanzando cada uno lo suyo y que el % del plan dependa solo de
        cuál se marcó como principal. Ahora Plan.progress_pct() promedia
        esto sobre TODOS los objetivos, no solo sobre uno.

        None cuando el objetivo no tiene destino definido (progresión
        sin `goal_*`, ej. "sube hasta un techo" sin techo puesto) — no
        hay con qué medir cuánto camino queda, así que no se puede
        convertir en un %. Plan.progress_pct() ignora los None al
        promediar en vez de tratarlos como 0.
        """
        if self.watch_keyword and not self.exercise_id:
            # Curso de Udemy: el progreso es lo que Udemy dice que llevas
            # (fracciones "x/x" de Contenido del curso, ver
            # record_course_progress), NO cuántas veces se "cumplió" la
            # tarea -- eso daba 100% con solo marcar el día como hecho.
            # Sin dato todavía -> None (queda fuera de la media del plan)
            # en vez de inventar un 0 o un 100.
            return self.current_course_progress_pct()

        if self.progression == self.PROG_COMPLETION:
            # Cumplimiento no tiene escalones que subir — se mide en
            # cuántas veces de las que tocaba se cumplió, usando el
            # mismo criterio que ya usa successes_and_streak() (que sí
            # sabe distinguir objetivo de TAREA, con Occurrence, de
            # objetivo de EJERCICIO, con WorkoutSession — usar
            # directamente _occurrences() aquí, como hacía el código
            # viejo, daba siempre 0 para un ejercicio de Deporte en
            # cumplimiento, porque _occurrences() solo mira series_id y
            # los ejercicios no tienen).
            total = (
                self._occurrences().count() if self.series_id
                else self.session_count()
            )
            if not total:
                return 0
            successes, _ = self.successes_and_streak()
            return min(100, round(100 * successes / total))

        remaining = self.sessions_to_goal()
        if remaining is None:
            return None
        successes, _ = self.successes_and_streak()
        total_sessions = self.current_step() * self.sessions_per_step + remaining
        if total_sessions <= 0:
            return 100
        return min(100, round(100 * successes / total_sessions))


class WorkoutSession(models.Model):
    """
    Estadísticas de una sesión de entreno. La mayoría se graban con la
    cámara (MediaPipe, en el navegador) — no se guarda ningún vídeo, solo
    los números que salen del conteo. Las de running (mode=distance) se
    escriben a mano (cinta, reloj, Samsung Health…): ahí total_reps se
    queda a 0 y lo que importa es distance_km / steps.
    """
    EXERCISE_PULLUP = "pullup"  # se usa como valor por defecto y de respaldo

    task = models.ForeignKey(
        Task, on_delete=models.SET_NULL, null=True, blank=True, related_name="workout_sessions"
    )
    routine = models.ForeignKey(
        Routine, on_delete=models.SET_NULL, null=True, blank=True, related_name="workout_sessions",
        help_text="Si esta sesión vino de un circuito (Routine), cuál. En blanco para ejercicios sueltos.",
    )
    plan = models.ForeignKey(
        Plan, on_delete=models.SET_NULL, null=True, blank=True, related_name="workout_sessions",
        help_text="Plan al que contaba esta sesión, si había uno activo.",
    )
    # Objetivo que estaba vigente en ESE momento. Se guarda en la sesión
    # en vez de recalcularlo después, porque el objetivo sube con las
    # sesiones: si se recalculara, el historial de hace un mes se
    # compararía con el objetivo de hoy y saldría un porcentaje falso.
    target_reps = models.PositiveIntegerField(null=True, blank=True)
    target_sets = models.PositiveIntegerField(null=True, blank=True)
    target_seconds = models.PositiveIntegerField(null=True, blank=True)
    target_distance_km = models.FloatField(null=True, blank=True)
    target_pace_seconds_per_km = models.PositiveIntegerField(null=True, blank=True)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="workout_sessions",
        help_text="Dueño de la sesión. Ver Task.user para el mismo criterio.",
    )
    series_id = models.UUIDField(null=True, blank=True)
    # Guarda el slug del Exercise (ej. "pullup", "squat"). Antes tenía
    # choices=EXERCISE_CHOICES, una lista aparte que había que mantener a
    # mano sincronizada con la tabla Exercise — si añadías un ejercicio
    # desde /admin, no aparecía aquí y el nombre salía en crudo (el slug).
    # Ahora el nombre se resuelve en caliente contra el catálogo, ver
    # exercise_name más abajo: un único sitio de verdad.
    exercise = models.CharField(max_length=32, default=EXERCISE_PULLUP)
    total_reps = models.PositiveIntegerField(default=0)
    total_sets = models.PositiveIntegerField(default=0)
    sets = models.JSONField(default=list, blank=True)  # [{"reps": 8, "durations": [1.1, ...]}, ...]
    session_duration_seconds = models.PositiveIntegerField(default=0)
    avg_rep_seconds = models.FloatField(null=True, blank=True)
    rest_alerts_triggered = models.PositiveIntegerField(default=0)
    rep_durations = models.JSONField(default=list, blank=True)  # [1.1, 1.3, ...] segundos por rep
    added_weight_kg = models.FloatField(
        null=True, blank=True,
        help_text="Peso extra usado (ej. chaleco lastrado en dominadas con peso). No lo mide la cámara, se anota a mano.",
    )
    distance_km = models.FloatField(null=True, blank=True, help_text="Solo running: km recorridos.")
    steps = models.PositiveIntegerField(null=True, blank=True, help_text="Solo running: pasos, si los tienes (cinta, reloj…).")

    # De dónde salió el dato. Importa para dos cosas: saber si el
    # número es de fiar (un reloj mide mejor que un dedo escribiendo), y
    # poder reimportar sin duplicar.
    SOURCE_MANUAL = "manual"
    SOURCE_HEALTH_CONNECT = "health_connect"
    SOURCE_OCR = "ocr"
    SOURCE_CHOICES = [
        (SOURCE_MANUAL, "A mano"),
        (SOURCE_HEALTH_CONNECT, "Health Connect"),
        (SOURCE_OCR, "Foto de la cinta"),
    ]
    source = models.CharField(max_length=20, choices=SOURCE_CHOICES, default=SOURCE_MANUAL)
    # Id que le da la fuente original a esa sesión (Health Connect da uno
    # por cada carrera). Con unique=True, reimportar el mismo periodo no
    # duplica nada — simplemente choca y se ignora.
    external_id = models.CharField(
        max_length=120, blank=True, default="",
        help_text="Id de la sesión en la app de origen, para no importarla dos veces.",
    )
    recorded_at = models.DateTimeField(auto_now_add=True)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-recorded_at"]

    @property
    def pace_seconds_per_km(self):
        """
        Ritmo en segundos por kilómetro, o None si no aplica.

        En segundos y no en "minutos decimales" a propósito: 5,5 min/km
        se lee mal (¿5:30 o 5:50?), mientras que 330 s/km es exacto y se
        formatea a 5:30 sin ambigüedad al enseñarlo.
        """
        if not self.distance_km or not self.session_duration_seconds:
            return None
        return self.session_duration_seconds / self.distance_km

    @property
    def pace_display(self):
        """El ritmo tal y como se dice en voz alta: 5:30/km."""
        pace = self.pace_seconds_per_km
        if pace is None:
            return ""
        minutes, seconds = divmod(int(round(pace)), 60)
        return f"{minutes}:{seconds:02d}/km"

    @property
    def achievement_pct(self):
        """
        Qué porcentaje del objetivo se cumplió, o None si no había.

        Se compara el TOTAL hecho contra el TOTAL pedido (series ×
        repeticiones), no serie por serie. Si el objetivo era 3×10 y
        hiciste 4×8, eso son 32 de 30 — lo hiciste, aunque repartido
        distinto. Contar serie a serie penalizaría una forma de entrenar
        que es igual de válida.
        """
        if self.target_sets and self.target_reps:
            objetivo = self.target_sets * self.target_reps
            hecho = self.total_reps
        elif self.target_sets and self.target_seconds:
            objetivo = self.target_sets * self.target_seconds
            hecho = self.session_duration_seconds
        elif self.target_sets and not self.target_reps and not self.target_seconds:
            # Al fallo: no hay reps/segundos que pedir, así que el % se
            # mide en series completadas, no en lo que salió en cada
            # una — ver PlanItem.PROG_FAILURE. total_reps se sigue
            # guardando (historial/PR) pero no entra aquí a propósito:
            # una última serie floja por fatiga no debe bajar el %.
            objetivo = self.target_sets
            hecho = self.total_sets
        elif self.target_distance_km and self.target_pace_seconds_per_km:
            # Aquí no vale un simple "hecho/pedido": hay dos condiciones
            # a la vez (distancia Y ritmo), igual que en la importación
            # de Health Connect — andar 5 km muy despacio no completa un
            # objetivo de "5 km a 6:00/km". Si no se cumplió el ritmo, 0
            # sin más, por mucha distancia que hubiera; si se cumplió,
            # el porcentaje es cuánta distancia sacaste de la pedida (con
            # bonus si fue más).
            pace = self.pace_seconds_per_km
            if self.distance_km is None or pace is None or pace > self.target_pace_seconds_per_km:
                return 0
            return min(200, round(100 * self.distance_km / self.target_distance_km))
        else:
            return None
        if not objetivo:
            return None
        return round(100 * hecho / objetivo)

    @property
    def target_met(self):
        """
        Si esta sesión, ELLA SOLA, llegó a su objetivo.

        True tanto si no había objetivo que exigir (entreno libre, sin
        plan) como si lo hubo y se alcanzó o se superó. Solo es False
        cuando había un número que cumplir y se quedó corto — que es el
        único caso en el que una tarea de un solo ejercicio no debe
        darse por completada sola.
        """
        pct = self.achievement_pct
        return pct is None or pct >= 100

    @property
    def target_label(self):
        """El objetivo en texto, para enseñarlo junto al resultado."""
        if self.target_sets and self.target_reps:
            return f"{self.target_sets} × {self.target_reps}"
        if self.target_sets and self.target_seconds:
            return f"{self.target_sets} × {self.target_seconds}s"
        if self.target_sets:
            return f"{self.target_sets} series al fallo"
        return ""

    @property
    def exercise_name(self):
        """Nombre legible del ejercicio, resuelto contra el catálogo
        Exercise. Si el slug no está en el catálogo (ej. se borró desde
        /admin después de guardar esta sesión), cae al slug en crudo en
        vez de romper."""
        ex = Exercise.objects.filter(slug=self.exercise).first()
        return ex.name if ex else self.exercise

    def __str__(self):
        if self.distance_km is not None:
            return f"{self.exercise_name} — {self.distance_km}km ({self.recorded_at:%Y-%m-%d %H:%M})"
        return f"{self.exercise_name} — {self.total_reps} reps ({self.recorded_at:%Y-%m-%d %H:%M})"


def last_set_reps(user, exercise_slug, plan=None):
    """
    Reps de cada serie la última vez que `user` hizo `exercise_slug`
    ([12, 10, 9]), o None si no hay ninguna sesión con las reps por serie
    guardadas. Alimenta el aviso "Serie 2: la última vez hiciste 10".

    Primero se mira dentro de `plan` (si se pasa): es la comparación más
    justa. Si el plan aún no tiene nada de ese ejercicio -- o es un
    entreno suelto, sin plan -- se usa la última vez que se hizo en
    cualquier sitio, salvo dentro de un circuito/calentamiento (routine),
    donde las reps son de rutina y no de entrenamiento de verdad.
    """
    if not user or not exercise_slug:
        return None

    def _first_with_reps(qs):
        # En Python (no con .exclude(sets=[])): comparar un JSONField con
        # una lista vacía no se comporta igual en todos los motores de BD;
        # con las últimas sesiones basta.
        for ws in qs.order_by("-recorded_at")[:10]:
            reps = [
                int(s["reps"]) for s in (ws.sets or [])
                if isinstance(s, dict) and isinstance(s.get("reps"), (int, float)) and s["reps"] > 0
            ]
            if reps:
                return reps
        return None

    base = WorkoutSession.objects.filter(
        exercise=exercise_slug, user=user, deleted_at__isnull=True,
    )
    if plan is not None:
        found = _first_with_reps(base.filter(plan=plan))
        if found:
            return found
    return _first_with_reps(base.filter(routine__isnull=True))



class TimerSession(models.Model):
    """
    Una sesión cronometrada de una tarea de Enfoque (category='work'):
    leer, estudiar, estirar… lo que sea que se apoye en un temporizador
    en vez de en la cámara o en repeticiones.

    Mismo patrón que WorkoutSession: el objetivo se guarda en la sesión
    en el momento de guardarla (target_minutes), no se recalcula después,
    para que el historial no cambie de significado si algún día editas
    el objetivo de la tarea.

    source distingue si los minutos vinieron de un cronómetro que
    controlaste a mano o del tiempo real que estuvo abierta una app
    externa (solo tiene sentido para subcategory='reading', y solo si
    hay plugin nativo instalado en la app — ver /mnt del proyecto móvil).
    """
    SOURCE_MANUAL = "manual"
    SOURCE_APP_USAGE = "app_usage"
    SOURCE_PC_USAGE = "pc_usage"
    SOURCE_CHOICES = [
        (SOURCE_MANUAL, "Cronómetro manual"),
        (SOURCE_APP_USAGE, "Tiempo en la app"),
        (SOURCE_PC_USAGE, "Tiempo en el PC"),
    ]

    task = models.ForeignKey(
        Task, on_delete=models.SET_NULL, null=True, blank=True, related_name="timer_sessions"
    )
    plan = models.ForeignKey(
        Plan, on_delete=models.SET_NULL, null=True, blank=True, related_name="timer_sessions",
        help_text="Para cuando esta tarea cuente para un objetivo del 12 Week Year. Sin usar todavía.",
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="timer_sessions",
    )
    series_id = models.UUIDField(null=True, blank=True)

    # Copia de task.subcategory en el momento de guardar — igual que el
    # objetivo, no se recalcula después contra la tarea actual.
    subcategory = models.CharField(max_length=16, blank=True)

    source = models.CharField(max_length=16, choices=SOURCE_CHOICES, default=SOURCE_MANUAL)
    app_package = models.CharField(
        max_length=120, blank=True,
        help_text="Paquete Android de la app leída (ej. com.adobe.reader) si source=app_usage, "
                   "o el dominio vigilado (ej. udemy.com) si source=pc_usage.",
    )

    minutes = models.PositiveIntegerField(default=0)
    target_minutes = models.PositiveIntegerField(null=True, blank=True)

    recorded_at = models.DateTimeField(auto_now_add=True)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-recorded_at"]

    @property
    def achievement_pct(self):
        """Porcentaje del objetivo cumplido, o None si la tarea no tenía uno (sesión libre)."""
        if not self.target_minutes:
            return None
        return round(100 * self.minutes / self.target_minutes)

    @property
    def target_met(self):
        """
        Igual que WorkoutSession.target_met: True si no había objetivo
        que exigir, o si lo hubo y se alcanzó. Solo False si había un
        número que cumplir y se quedó corto.
        """
        pct = self.achievement_pct
        return pct is None or pct >= 100

    @property
    def subcategory_label(self):
        return dict(Task.FOCUS_SUBCATEGORY_CHOICES).get(self.subcategory, "Lectura")

    def __str__(self):
        return f"{self.subcategory_label} — {self.minutes} min ({self.recorded_at:%Y-%m-%d %H:%M})"


class WarmupStatus(models.Model):
    """
    Cuándo calentó el usuario por última vez. Un solo registro por
    usuario (no un historial): antes de cualquier tarea de Deporte se
    pregunta si ya ha calentado (ver views.task_workout / .routine_play
    / .plan_session, a través de views._require_warmup) — RECOMENDADO,
    no obligatorio: el vídeo que se ofrece si dice que no es opcional y
    se puede saltar — salvo que ya se haya calentado (dicho que sí, o
    pasado por el vídeo) dentro de las últimas FRESH_WINDOW horas — así
    dos sesiones seguidas el mismo día (tren superior + tren inferior,
    por ejemplo) no preguntan dos veces.
    """
    FRESH_WINDOW = timedelta(hours=2)

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="warmup_status",
    )
    last_warmup_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Calentamiento de {self.user} — {self.last_warmup_at or 'nunca'}"

    @classmethod
    def is_fresh(cls, user):
        """True si no hace falta volver a calentar todavía."""
        status = cls.objects.filter(user=user).first()
        if not status or not status.last_warmup_at:
            return False
        return timezone.now() - status.last_warmup_at < cls.FRESH_WINDOW

    @classmethod
    def mark_done(cls, user):
        status, _ = cls.objects.get_or_create(user=user)
        status.last_warmup_at = timezone.now()
        status.save(update_fields=["last_warmup_at"])


class CoursePlaylist(models.Model):
    """
    Un curso de idioma verificado A MANO: una playlist real de YouTube
    que una persona ha comprobado que de verdad es del idioma y nivel
    que dice ser.

    Por qué existe esto en vez de buscar en caliente cada vez: la
    búsqueda automática (ver `youtube_search.search_playlists`, comando
    `search_courses`) demostró en la práctica que para niveles con poco
    contenido gratis (C1, C2 sobre todo) YouTube no dice "no hay nada"
    — devuelve lo más parecido por relevancia genérica, que suele ser
    el mismo curso de principiantes repetido bajo una etiqueta de nivel
    que no le corresponde. Confiar en eso automáticamente habría colado
    lecciones de A1 como si fueran de C2.

    La solución es la misma que ya usa la app para Deporte: un catálogo
    CURADO (`Exercise` es el equivalente ahí) del que la app asigna
    directamente, sin buscar ni inventar nada por su cuenta —
    `api._catalog_entries_for_language` elige, por idioma + nivel +
    idioma nativo, sin IA de por medio (ver docstring de
    `api.build_language_plan_draft`). `search_courses` sigue siendo
    útil, pero como herramienta de DESCUBRIMIENTO para encontrar
    candidatos que un humano revisa antes de añadirlos aquí — no como
    fuente de verdad automática. Ver el comando `add_course_playlist`,
    que enseña un preview real (títulos, duración, subtítulos) antes de
    guardar nada.
    """
    language = models.CharField(max_length=40, help_text="Ej. 'francés'. En minúscula, sin acentos raros.")
    level = models.CharField(
        max_length=2, choices=Plan.CEFR_LEVEL_CHOICES,
        help_text="Nivel más bajo que cubre esta playlist (si solo cubre uno, es el único).",
    )
    # La mayoría de playlists curadas cubren un único nivel MCER — pero
    # algunas (sobre todo canales grandes, tipo curso completo en una
    # sola lista) van seguidas de A1 a B2 o similar, sin cortes. En
    # blanco = cubre solo `level`, como antes de que existiera este
    # campo (compatible con todo el catálogo ya cargado). Puesto, dice
    # el nivel más alto que cubre — ver CoursePlaylist.levels_covered()
    # y api._catalog_entries_for_language, que ya no exige coincidencia
    # exacta de nivel: basta con que el rango [level, level_to] toque
    # alguno de los niveles pedidos.
    level_to = models.CharField(
        max_length=2, blank=True, choices=Plan.CEFR_LEVEL_CHOICES,
        help_text="Si esta playlist cubre VARIOS niveles seguidos sin cortes (ej. una sola "
                   "playlist de A1 a B2), el nivel más alto que cubre. En blanco = cubre solo "
                   "`level`, como hasta ahora.",
    )
    # En qué idioma están las explicaciones del curso — no el idioma que
    # se aprende (eso es `language`), sino el del hablante al que va
    # dirigido (ej. un curso de francés "para hispanohablantes" lleva
    # native_language="español"). En blanco = neutro/inmersión (vale
    # para cualquiera, ej. subtítulos en el propio idioma que se
    # aprende, sin explicaciones de por medio). Sirve para no recomendar
    # un curso pensado para hablantes de otro idioma distinto al nativo
    # del usuario — ver Plan.known_languages y
    # api._catalog_entries_for_language.
    native_language = models.CharField(
        max_length=40, blank=True,
        help_text="Idioma en el que se explica el curso (ej. 'español'). En blanco = neutro, "
                   "vale para cualquier hablante.",
    )
    youtube_playlist_id = models.CharField(max_length=64)
    title = models.CharField(max_length=300, blank=True)
    channel_title = models.CharField(max_length=200, blank=True)
    notes = models.TextField(
        blank=True, help_text="Por qué se eligió esta playlist, qué cubre, algo a vigilar...",
    )
    is_active = models.BooleanField(
        default=True, help_text="Desactivar en vez de borrar si deja de estar disponible o resulta floja.",
    )
    order = models.PositiveIntegerField(
        default=0,
        help_text="Orden dentro de su idioma+nivel+idioma nativo, si hay varias — la de menor "
                   "número es la que se asigna primero.",
    )
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["language", "level", "order"]

    def __str__(self):
        audience = f" · para {self.native_language}" if self.native_language else " · neutro"
        return f"{self.title or self.youtube_playlist_id} ({self.language} · {self.level_label}{audience})"

    @property
    def level_label(self):
        """'A1' si es de un solo nivel, 'A1 → B2' si cubre varios seguidos."""
        return self.level if not self.level_to or self.level_to == self.level else f"{self.level} → {self.level_to}"

    def levels_covered(self):
        """Todos los niveles MCER que cubre, de `level` a `level_to`
        (o solo `level` si `level_to` está en blanco) — ver CEFR_LEVELS
        al principio de este archivo."""
        start = CEFR_LEVELS.index(self.level) if self.level in CEFR_LEVELS else 0
        end = CEFR_LEVELS.index(self.level_to) if self.level_to in CEFR_LEVELS else start
        if end < start:
            start, end = end, start
        return CEFR_LEVELS[start:end + 1]


class CourseModule(models.Model):
    """
    Un vídeo concreto dentro del temario de un plan de Estudio · Idiomas
    (Plan.study_subtype='language').

    A diferencia del resto de Estudio (donde el objetivo es el mismo
    vídeo/playlist repetido cada sesión, ver PlanItem), un curso de
    idioma es una SECUENCIA: vídeos distintos, de nivel creciente, uno
    (o varios) por sesión — casi siempre de VARIAS playlists de YouTube
    encadenadas (pocas playlists gratis cubren de A1 a C2 seguido), pero
    una sola playlist puede aportar varios módulos seguidos si cubre
    más de un nivel (ver CoursePlaylist.level_to). Por eso el orden lo
    posee esta tabla, no una playlist de YouTube.

    Se rellena a partir de las `CoursePlaylist` ya verificadas para el
    idioma (y el idioma nativo) del plan — nunca de una búsqueda en
    caliente sin revisar. Ver `api._apply_language_plan_fields` /
    `api.build_language_plan_draft` / `api.expand_language_selection`
    para el flujo completo (asignación directa del catálogo →
    previsualizar → confirmar) — ya no pasa por IA, ver docstring de
    `build_language_plan_draft`.
    """
    plan = models.ForeignKey(Plan, on_delete=models.CASCADE, related_name="course_modules")
    order = models.PositiveIntegerField(default=0, help_text="Posición en el temario completo del curso.")
    scheduled_week = models.PositiveIntegerField(
        null=True, blank=True, help_text="En qué semana del plan toca ver este vídeo.",
    )
    level = models.CharField(max_length=2, blank=True, choices=Plan.CEFR_LEVEL_CHOICES)

    youtube_video_id = models.CharField(max_length=32)
    title = models.CharField(max_length=300, blank=True)
    channel_title = models.CharField(max_length=200, blank=True)
    duration_seconds = models.PositiveIntegerField(null=True, blank=True)
    has_captions = models.BooleanField(
        default=False,
        help_text="Si YouTube reporta subtítulos disponibles — no garantiza que se puedan "
                   "descargar (ver notas de tasks/youtube_search.py), pero ayuda a priorizar.",
    )
    source_playlist = models.ForeignKey(
        CoursePlaylist, on_delete=models.SET_NULL, null=True, blank=True,
        help_text="De qué playlist curada salió, para poder revisar la fuente.",
    )

    # Tema del bloque al que pertenece este vídeo (varios vídeos seguidos
    # suelen compartir tema, ej. "saludos y presentarse"). Hoy se deja
    # en blanco al crear el temario (nadie lo rellena todavía a mano) —
    # api.maybe_trigger_quiz() usa esto si está, y si no, cae en
    # `title` — ver CourseQuiz para el test que se genera con esto.
    topic = models.CharField(max_length=200, blank=True)

    # Cuándo se vio de verdad — esta es la fuente real del avance del
    # curso (ver Plan._language_completed_count), no un dato solo de
    # auditoría: lo pone Plan.mark_current_module_watched(), llamada
    # justo después de guardar la Occurrence del día (ver
    # views.task_video_save) con cuántos vídeos se completaron en esa
    # sesión — puede ser más de uno si se encadenaron varios vídeos
    # cortos seguidos para llenar el objetivo diario en minutos.
    watched_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return f"{self.title or self.youtube_video_id} ({self.level or 'sin nivel'})"


class CourseQuiz(models.Model):
    """
    Un test corto de opción múltiple, generado con IA a partir de los
    temas de los últimos `Plan.quiz_every_n_videos` vídeos vistos de un
    curso de idioma — ver `api.maybe_trigger_quiz` (se dispara solo,
    desde `views.task_video_save`, justo después de marcar el vídeo
    como visto).

    A propósito NO bloquea nada: el vídeo ya cuenta como hecho al
    verlo (Task.mark_done), pase lo que pase aquí — este test es un
    "aparte" con su propia racha (ver `Plan.quiz_streak_stats` /
    `streak_stats` de abajo), pensado para forzar que se preste
    atención de verdad sin arriesgar el progreso del curso en sí si un
    día sale mal.
    """
    plan = models.ForeignKey(Plan, on_delete=models.CASCADE, related_name="quizzes")
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

    # CourseModule.order del último vídeo cubierto por este test — solo
    # para trazabilidad y para no generar dos tests seguidos sobre
    # exactamente el mismo tramo (ver api.maybe_trigger_quiz).
    up_to_order = models.PositiveIntegerField(default=0)
    topics = models.JSONField(
        default=list, blank=True, help_text="Temas de los vídeos usados para generar este test.",
    )
    # [{"question": "...", "options": ["...", "...", "...", "..."], "correct_index": 0}, ...]
    questions = models.JSONField(default=list, blank=True)
    # Índices elegidos por el usuario, mismo orden que `questions`. En
    # blanco hasta que se responde.
    answers = models.JSONField(null=True, blank=True)
    score = models.PositiveIntegerField(null=True, blank=True)
    total = models.PositiveIntegerField(default=0)
    passed = models.BooleanField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    answered_at = models.DateTimeField(null=True, blank=True)

    # ≥70% de aciertos aprueba — ni "todo perfecto o nada" (desanima sin
    # motivo por un despiste) ni "con que respondas ya vale" (no fuerza
    # a prestar atención de verdad, que es todo el propósito de esto).
    PASS_THRESHOLD = 0.7

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        estado = "sin responder" if not self.answered_at else ("aprobado" if self.passed else "no aprobado")
        return f"Test de {self.plan.language_name} — {estado}"

    def answer(self, selected):
        """
        Corrige `selected` (lista de índices elegidos, mismo orden que
        `questions`) y guarda el resultado. Un índice que falta o no es
        válido cuenta como fallo, nunca como excepción — un test a
        medio responder simplemente saca peor nota, no rompe la página.
        """
        total = len(self.questions)
        score = 0
        for i, q in enumerate(self.questions):
            chosen = selected[i] if i < len(selected) else None
            if isinstance(chosen, int) and chosen == q.get("correct_index"):
                score += 1
        self.answers = list(selected)
        self.score = score
        self.total = total
        self.passed = total > 0 and (score / total) >= self.PASS_THRESHOLD
        self.answered_at = timezone.now()
        self.save(update_fields=["answers", "score", "total", "passed", "answered_at"])
        return self

    @classmethod
    def streak_stats(cls, plan_id):
        """Misma cuenta que Occurrence.streak_stats, pero sobre tests ya
        respondidos de este plan: se rompe en cuanto uno no se aprueba."""
        quizzes = list(
            cls.objects.filter(plan_id=plan_id, answered_at__isnull=False).order_by("-answered_at")
        )
        current = 0
        for q in quizzes:
            if q.passed:
                current += 1
            else:
                break
        max_s = 0
        running = 0
        for q in reversed(quizzes):
            if q.passed:
                running += 1
                max_s = max(max_s, running)
            else:
                running = 0
        return {"current_streak": current, "max_streak": max_s}


class SavedVideo(models.Model):
    """
    Vídeos de YouTube guardados para reutilizar sin tener que pegar el
    enlace cada vez que se entrena o se estudia.

    Se eligen en el momento de hacerlo, como alternativa al modo de
    siempre (circuito, cámara, temporizador) — no van atados a una
    tarea concreta, así una tarea que se repite puede usar un vídeo
    distinto cada día, o ninguno. `scope` es solo para filtrar la lista
    y no enseñar vídeos de estudio al entrenar tren inferior.
    """
    SCOPE_LOWER_BODY = "lower_body"
    SCOPE_UPPER_BODY = "upper_body"
    SCOPE_STUDY = "study_session"
    SCOPE_CHOICES = [
        (SCOPE_LOWER_BODY, "Tren inferior"),
        (SCOPE_UPPER_BODY, "Tren superior"),
        (SCOPE_STUDY, "Estudio"),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="saved_videos",
    )
    scope = models.CharField(max_length=16, choices=SCOPE_CHOICES)
    title = models.CharField(
        max_length=120, blank=True,
        help_text="Para reconocerlo en la lista. En blanco, se enseña el ID del vídeo.",
    )
    youtube_video_id = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def save(self, *args, **kwargs):
        raw = (self.youtube_video_id or "").strip()
        if raw:
            m = _YOUTUBE_ID_RE.search(raw)
            self.youtube_video_id = m.group(1) if m else raw
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title or self.youtube_video_id


class AIGenerationLog(models.Model):
    """
    Un registro por cada vez que se llama a la IA para generar un plan
    (con éxito o sin él — una llamada fallida a Gemini también gasta
    cuota gratis, así que también cuenta).

    Existe solo para poner un tope diario de generaciones y así proteger
    la cuota gratis de GEMINI_API_KEY, que hoy es una sola clave
    compartida por toda la app — si en el futuro hay más de una persona
    usándola, evita que alguien (a propósito o sin querer) se la deje a
    cero para todos los demás. En cuanto haya cuentas de usuario de
    verdad, este tope debería pasar a ser por persona en vez de global
    (ya lleva el campo `user` preparado para eso).
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="ai_generation_logs",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    @classmethod
    def count_today(cls, user=None):
        today = timezone.localtime(timezone.now()).date()
        qs = cls.objects.filter(created_at__date=today)
        if user is not None:
            qs = qs.filter(user=user)
        return qs.count()

    @classmethod
    def record(cls, user=None):
        cls.objects.create(user=user)


class Occurrence(models.Model):
    RESULT_DONE = "done"
    RESULT_NOT_DONE = "not_done"
    RESULT_CHOICES = [
        (RESULT_DONE, "Hecho"),
        (RESULT_NOT_DONE, "No hecho"),
    ]

    task = models.ForeignKey(
        Task, on_delete=models.SET_NULL, null=True, blank=True, related_name="occurrences"
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="occurrences",
        help_text="Dueño de la ocurrencia. Ver Task.user para el mismo criterio.",
    )
    series_id = models.UUIDField()
    title = models.CharField(max_length=255)
    result = models.CharField(max_length=10, choices=RESULT_CHOICES)
    due_date = models.DateField(null=True, blank=True)
    auto_expired = models.BooleanField(default=False)
    minutes_watched = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Solo en tareas de vídeo: minutos reales vistos en el navegador "
                   "(IFrame API de YouTube), no un dato introducido a mano.",
    )
    recorded_at = models.DateTimeField(auto_now_add=True)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-recorded_at"]
        constraints = [
            # Un único resultado por día y serie. Ver Task._record_occurrence:
            # el resultado de un día es un hecho corregible, no un log que se
            # apila. Solo aplica cuando hay due_date — las tareas sueltas sin
            # fecha no tienen "día" al que anclarse.
            models.UniqueConstraint(
                fields=["series_id", "due_date"],
                condition=models.Q(due_date__isnull=False),
                name="unique_occurrence_per_series_day",
            ),
        ]

    def __str__(self):
        return f"{self.title} — {self.get_result_display()} ({self.recorded_at:%Y-%m-%d})"

    @classmethod
    def streak_stats(cls, series_id):
        """
        Calcula racha actual y máxima histórica para una serie.
        La racha se rompe en cuanto aparece un not_done.
        """
        occs = list(cls.objects.filter(series_id=series_id).order_by("-recorded_at"))

        # Racha actual: contar done consecutivos desde el más reciente
        current = 0
        for occ in occs:
            if occ.result == cls.RESULT_DONE:
                current += 1
            else:
                break

        # Racha máxima: recorrer todo en orden cronológico
        max_s = 0
        running = 0
        for occ in reversed(occs):
            if occ.result == cls.RESULT_DONE:
                running += 1
                max_s = max(max_s, running)
            else:
                running = 0

        return {"current_streak": current, "max_streak": max_s}

    @classmethod
    def weekly_completion(cls, user, reference_date=None, series_id=None):
        """
        Porcentaje de ejecución de la semana actual (lunes a domingo).

        Primera pieza del 12 Week Year: una división simple sobre las
        ocurrencias que ya se guardan — sin modelo nuevo, sin campo
        nuevo. "Empieza por aquí" porque es barato y da una lectura
        inmediata de cómo va la semana cada vez que se abre la lista.

        Cada ocurrencia se cuenta en la semana de su due_date (el día al
        que pertenecía la tarea) si lo tiene, y si no en la semana en
        que se registró — mismo criterio que PlanItem.history() usa
        para las tareas sin due_date.

        Con `series_id` se filtra a una sola serie (ej. la tarea de un
        plan concreto) en vez del global — es lo que usa Plan.weekly_completion
        para la revisión semanal por objetivo, reutilizando exactamente
        el mismo cálculo.

        El total NO se queda solo en lo que ya existe como Task/Occurrence:
        una tarea repetida (diaria, cada 2 días, L-X-V...) solo genera la
        SIGUIENTE instancia cuando se resuelve la anterior (ver
        Task._spawn_next), así que el lunes por la mañana casi ninguna
        instancia del resto de la semana existe todavía — antes eso hacía
        que el total fuera subiendo día a día (10, luego 11, luego 13...)
        en vez de conocerse de entrada. Se completa con
        Task.project_pending_series (el mismo cálculo que ya usa "Por
        generar" en el filtro de "Esta semana"), que para cada tarea
        pendiente que se repite simula qué fechas más caerían dentro de
        la semana SIN crear ninguna Task real — así el total cuenta lo
        que toca por calendario desde el primer día, no lo que ya se ha
        materializado.
        """
        today = reference_date or timezone.localtime(timezone.now()).date()
        week_start = today - timedelta(days=today.weekday())  # lunes
        week_end = week_start + timedelta(days=6)             # domingo

        occs = cls.objects.filter(user=user, deleted_at__isnull=True)
        if series_id:
            occs = occs.filter(series_id=series_id)
        occs = occs.filter(
            models.Q(due_date__gte=week_start, due_date__lte=week_end)
            | models.Q(
                due_date__isnull=True,
                recorded_at__date__gte=week_start,
                recorded_at__date__lte=week_end,
            )
        )
        pending = Task.objects.filter(
            user=user, deleted_at__isnull=True, is_done=False,
        ).filter(models.Q(due_date__isnull=True) | models.Q(due_date__lte=week_end))
        if series_id:
            pending = pending.filter(series_id=series_id)
        done, total = cls._count_done_total(occs, pending)

        # Fechas de esta semana que aún no se han generado como Task real
        # para series que se repiten y siguen pendientes (ver docstring).
        projected = Task.project_pending_series(list(pending), Task.RANGE_WEEK, reference_date=today)
        total += sum(
            len(row["preview_dates"]) + row["extra_count"]
            for row in projected if not row["infinite"]
        )

        return {
            "week_start": week_start,
            "week_end": week_end,
            "done": done,
            "not_done": total - done,
            "total": total,
            "pct": round(100 * done / total) if total else None,
        }

    @classmethod
    def _count_done_total(cls, occs, pending):
        """
        (hechas, total) sumando lo ya resuelto (Occurrence) Y lo que
        sigue pendiente (Task con is_done=False).

        Antes el total solo eran las Occurrence, y una tarea sin resolver
        no tiene ninguna: con 4 tareas y 2 hechas salía "2 de 2" (100%).
        Las pendientes tienen que estar en el total.

        Una tarea pendiente NO se cuenta dos veces: "Desmarcar" la deja
        pendiente pero guarda una Occurrence de "no hecha" para ese día,
        y ya cuenta ahí.

        Con due_date, cada (series, día) ya es única por la restricción
        de la tabla (ver Occurrence.Meta) — imposible que se apilen filas
        de más ahí. SIN due_date (tareas sueltas), Task._record_occurrence
        SÍ crea una fila nueva cada vez que se marca/desmarca, a
        propósito (no hay día al que anclar un update_or_create) — pero
        eso significa que marcar, desmarcar y volver a marcar una tarea
        suelta en el mismo rango dejaba 2-3 filas contando por separado,
        inflando "hechas" y "total" del mismo tirón aunque la tarea siga
        siendo UNA sola. Aquí se dedupean por task_id quedándonos con el
        resultado más reciente, igual que ya pasa gratis con due_date.
        """
        occ_rows = list(
            occs.order_by("recorded_at")
            .values_list("series_id", "due_date", "result", "task_id")
        )
        dated_rows = [r for r in occ_rows if r[1] is not None]
        # Última fila de cada task_id sin due_date (occ_rows viene
        # ordenado por recorded_at, así que la última entrada gana).
        latest_loose = {}
        for series_id, due_date, result, task_id in occ_rows:
            if due_date is None:
                latest_loose[task_id] = result

        done = sum(1 for r in dated_rows if r[2] == cls.RESULT_DONE)
        done += sum(1 for result in latest_loose.values() if result == cls.RESULT_DONE)

        seen_slots = {(r[0], r[1]) for r in dated_rows}
        seen_tasks = {t_id for t_id, result in latest_loose.items() if result != cls.RESULT_DONE}

        extra = 0
        for t_id, t_series, t_due in pending.values_list("id", "series_id", "due_date"):
            if t_due is not None and (t_series, t_due) in seen_slots:
                continue
            if t_due is None and t_id in seen_tasks:
                continue
            extra += 1
        return done, len(dated_rows) + len(latest_loose) + extra

    @classmethod
    def daily_completion(cls, user, reference_date=None):
        """
        Progreso de HOY: tareas hechas / tareas del día. Mismo criterio de
        día que weekly_completion (due_date, o recorded_at si no tiene).
        """
        today = reference_date or timezone.localtime(timezone.now()).date()
        occs = cls.objects.filter(user=user, deleted_at__isnull=True).filter(
            models.Q(due_date=today)
            | models.Q(due_date__isnull=True, recorded_at__date=today)
        )
        pending = Task.objects.filter(
            user=user, deleted_at__isnull=True, is_done=False,
        ).filter(models.Q(due_date__isnull=True) | models.Q(due_date__lte=today))
        done, total = cls._count_done_total(occs, pending)
        return {
            "date": today,
            "done": done,
            "total": total,
            "pct": round(100 * done / total) if total else None,
        }


class DebugLog(models.Model):
    """
    Registro de depuración del contador de cámara (botón 📋, ver
    exportScissorLog en workout.js), mandado directo desde la app/web al
    servidor en vez de depender de compartir/copiar y reenviar a mano.

    No lleva `user`: es una herramienta de desarrollo de un solo uso
    (diagnosticar un contador que falla ahora mismo), no un dato de la
    app -- no hace falta filtrar por usuario para lo que sirve (ver
    api.debug_log_create/debug_log_latest, protegidos por un token propio
    en vez del candado de la app entera, ver todoapp/basic_auth.py).

    Sin límite de líneas propio aparte del que ya impone scissorLogMax en
    workout.js -- si esto crece demasiado con el tiempo, debug_log_create
    poda las entradas más viejas (ver MAX_ENTRIES).
    """
    PLATFORM_WEB = "web"
    PLATFORM_MOBILE = "mobile"
    PLATFORM_CHOICES = [(PLATFORM_WEB, "Web"), (PLATFORM_MOBILE, "Móvil")]

    MAX_ENTRIES = 5  # cuántas se conservan -- ver debug_log_create en api.py

    created_at = models.DateTimeField(auto_now_add=True)
    platform = models.CharField(max_length=10, choices=PLATFORM_CHOICES)
    counter_key = models.CharField(max_length=60, blank=True)
    build = models.CharField(max_length=60, blank=True)
    # Explicación en texto libre que se pide al pulsar 📋 ("me han fallado
    # X dominadas") -- opcional, para saber qué pasó sin tener que
    # adivinarlo solo a partir del registro (ver exportScissorLog).
    note = models.TextField(blank=True)
    content = models.TextField()

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.counter_key or '?'} ({self.platform}) — {self.created_at:%Y-%m-%d %H:%M}"

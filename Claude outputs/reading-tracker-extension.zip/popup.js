const statusEl = document.getElementById('status');
const warnEl = document.getElementById('permission-warning');
const totalsEl = document.getElementById('totals');

const MESSAGES = {
  reading: (r) => `Leyendo: ${r.title}`,
  idle: () => 'PDF en primer plano, pero pareces inactivo.',
  'not-pdf': () => 'La pestana activa no es un PDF.',
  'no-active-tab': () => 'No se ha detectado ninguna pestana activa.',
  'no-focus': () => 'Chrome no tiene el foco ahora mismo.',
  'no-url': () => 'Pestana de archivo local sin permiso concedido.',
};

function renderStatus(result) {
  if (!result) {
    statusEl.textContent = 'Sin datos todavia.';
    statusEl.className = 'status muted';
    warnEl.style.display = 'none';
    return;
  }

  warnEl.style.display = result.status === 'no-url' ? 'block' : 'none';
  const build = MESSAGES[result.status];
  statusEl.textContent = build ? build(result) : result.status;
  statusEl.className = 'status ' + (result.status === 'reading' ? 'ok' : 'muted');
}

function renderTotals(totals = {}) {
  totalsEl.innerHTML = '';
  Object.entries(totals).forEach(([url, ticks]) => {
    const li = document.createElement('li');
    li.textContent = `${ticks} min - ${decodeURIComponent(url.split('/').pop())}`;
    totalsEl.appendChild(li);
  });
}

async function refresh() {
  const data = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
  renderStatus(data?.lastResult);
  renderTotals(data?.totals);
}

document.getElementById('check-now').addEventListener('click', async () => {
  statusEl.textContent = 'Comprobando...';
  const { result } = await chrome.runtime.sendMessage({ type: 'CHECK_NOW' });
  renderStatus(result);
  refresh();
});

document.getElementById('open-settings').addEventListener('click', () => {
  chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` });
});

refresh();

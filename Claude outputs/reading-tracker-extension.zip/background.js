const ALARM_NAME = 'reading-tick';
const IDLE_THRESHOLD_SECONDS = 60;
const PDF_REGEX = /\.pdf($|\?)/i;

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) checkReading();
});

async function checkReading() {
  const result = await evaluateState();
  await recordResult(result);
  return result;
}

async function evaluateState() {
  const focusedWin = await chrome.windows.getLastFocused({ populate: true });
  if (!focusedWin || !focusedWin.focused) {
    return { status: 'no-focus' };
  }

  const activeTab = focusedWin.tabs?.find((t) => t.active);
  if (!activeTab) {
    return { status: 'no-active-tab' };
  }

  if (!activeTab.url) {
    // Suele ser una pestana file:// sin el permiso "acceso a URLs de archivo" concedido
    return { status: 'no-url', tabId: activeTab.id, title: activeTab.title || null };
  }

  const isFileUrl = activeTab.url.startsWith('file://');
  const isPdf = PDF_REGEX.test(activeTab.url);

  if (!isPdf) {
    return { status: 'not-pdf', url: activeTab.url };
  }

  const idleState = await chrome.idle.queryState(IDLE_THRESHOLD_SECONDS);
  if (idleState !== 'active') {
    return { status: 'idle', url: activeTab.url, idleState };
  }

  return {
    status: 'reading',
    url: activeTab.url,
    title: activeTab.title || activeTab.url,
    isFileUrl,
  };
}

async function recordResult(result) {
  const { log = [], totals = {} } = await chrome.storage.local.get(['log', 'totals']);

  log.push({ ts: Date.now(), ...result });
  if (log.length > 200) log.shift(); // no dejar crecer el log indefinidamente

  if (result.status === 'reading') {
    const key = result.url;
    totals[key] = (totals[key] || 0) + 1; // +1 tick (~1 minuto con el alarm por defecto)
  }

  await chrome.storage.local.set({ log, totals, lastResult: result });
}

// El popup usa esto para forzar una comprobacion o pedir el estado guardado
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'CHECK_NOW') {
    checkReading().then((result) => sendResponse({ result }));
    return true; // respuesta asincrona
  }
  if (msg?.type === 'GET_STATE') {
    chrome.storage.local.get(['log', 'totals', 'lastResult']).then((data) => sendResponse(data));
    return true;
  }
});

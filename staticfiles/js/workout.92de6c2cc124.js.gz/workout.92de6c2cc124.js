/* ============================================================
   Contador de dominadas con MediaPipe (100% en el navegador).
   No se sube ni se guarda ningún vídeo — solo los números que
   salen de aquí (reps, duración de cada rep, avisos de descanso).
   ============================================================ */

// De dónde sale MediaPipe (versión vendorizada + rutas a los ficheros
// locales en static/vendor/mediapipe/) se decide en UN ÚNICO fichero,
// static/js/mediapipe-vendor.js — nunca aquí. Así, si algún día hay
// que revendorizar una versión nueva o volver a un CDN externo, solo
// hace falta tocar ese fichero pequeño, no bucear por todo workout.js.
// Ver static/vendor/mediapipe/README.md para el paso a paso.
import { MEDIAPIPE_BUNDLE_URL, MEDIAPIPE_WASM_BASE_URL, MODEL_URL } from "./mediapipe-vendor.js";

// Etiqueta de versión de ESTE fichero, a mano, para poder comprobar en dos
// segundos si un registro exportado (ver exportScissorLog) viene de verdad
// del código que se acaba de entregar o de una copia vieja que el navegador
// (o una pestaña que llevaba rato abierta) seguía ejecutando por debajo.
// Se estampa como primera línea del registro exportado, tal cual está
// cargada en la pestaña que lo generó — así, si no coincide con la que se
// esperaba, la explicación ya no es una suposición: se ve. Cambiar este
// valor cada vez que se toque processDip (o cualquier otra parte que use
// logScissor) de verdad ayuda a diagnosticar.
const WORKOUT_JS_BUILD = "2026-09-09-voicestep-per-exercise+arm-cross-v8+voice5s+armcircles-v6+necklateral-v3+armscissors-v2+legrotation-v4+kneeraises-v1+heelkicks-v10+seatedhamstring-v4+hiplateral-v5+neckcircles-v1+neckhalfturn-v2+forearmrotation-v1+wristrotation-v2+standingquadstretch-v1+hipforwardback-v3+frontpos-v1+cindy-v2";

// Token del registro de depuración remoto (ver settings.DEBUG_LOG_TOKEN
// en el backend) -- exportScissorLog() lo manda junto al registro para
// que el endpoint sepa que es una petición legítima. No es la
// contraseña de la app (esto NO va detrás de BasicAuthMiddleware, ver
// todoapp/basic_auth.py) -- si algún día se rota, cambia también aquí,
// en mobile-app/www/js/workout.js y en el DEBUG_LOG_TOKEN del servidor (.env).
const DEBUG_LOG_TOKEN = "R4Xg0yUJWyZKObyTH4lhOlVkzJbpKvny";

/**
 * Manda un registro de depuración al servidor (mismo endpoint y token
 * que usa exportScissorLog() para los ejercicios de cámara) -- extraída
 * como función independiente para que también puedan usarla los modos
 * cronómetro / cronómetro+postura de circuitos y planes (session-runner.js
 * en móvil, circuit.js/plan-session.js en web), que no tienen ninguna
 * instancia de WorkoutController. Best-effort: nunca lanza, solo devuelve
 * si se pudo mandar o no -- igual que el bloque original.
 */
export async function sendDebugLogToServer({ counterKey, note = "", content, build = WORKOUT_JS_BUILD, platform = "web" }) {
  try {
    const resp = await fetch("/api/debug-log/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: DEBUG_LOG_TOKEN, platform, counter_key: counterKey, build, note, content }),
    });
    return resp.ok;
  } catch (e) {
    console.warn("No se pudo mandar el registro al servidor:", e);
    return false;
  }
}

/**
 * Comparte/copia/descarga (y, best-effort, manda al servidor vía
 * sendDebugLogToServer) un registro de depuración en texto plano.
 * Extraído de WorkoutController.exportScissorLog() para poder usarlo
 * también desde los ejercicios de cronómetro/postura de los circuitos y
 * planes (runTimer/runTimerWithPosture en session-runner.js,
 * circuit.js, plan-session.js), que no tienen una instancia de
 * WorkoutController -- ahí no hay this.scissorLog, así que quien llama
 * pasa sus propias líneas ya recogidas en "lines".
 */
export async function exportDebugLogText({ lines, counterKey, statusEl, build = WORKOUT_JS_BUILD, platform = "web" }) {
  if (!statusEl) return;
  if (!lines || !lines.length) {
    statusEl.textContent = "Todavía no hay datos registrados -- espera unos segundos y vuelve a intentarlo.";
    return;
  }
  const text = `=== workout.js build: ${build} ===\n` + lines.join("\n");
  const filename = `${counterKey}-debug.txt`;
  const n = lines.length;

  const note = (window.prompt("¿Qué ha pasado? (opcional -- se manda junto al registro)", "") || "").trim();
  const remoteSent = await sendDebugLogToServer({ counterKey, note, content: text, build, platform });

  try {
    const file = new File([text], filename, { type: "text/plain" });
    if (navigator.canShare?.({ files: [file] })) {
      await navigator.share({ files: [file], title: filename });
      statusEl.textContent =
        `${remoteSent ? "Enviado \u2713 y c" : "C"}ompartido (${n} líneas, build ${build}) — elige "Guardar en Archivos" o mándalo ` +
        "directo desde el panel de compartir.";
      return;
    }
  } catch (e) {
    if (e?.name === "AbortError") {
      statusEl.textContent = "Panel de compartir cerrado sin enviar nada.";
      return;
    }
    console.warn("navigator.share con archivo falló, se prueba portapapeles/descarga:", e);
  }

  let copied = false;
  try {
    await navigator.clipboard.writeText(text);
    copied = true;
  } catch (e) {
    console.warn("No se pudo copiar el registro al portapapeles:", e);
  }

  let downloaded = false;
  try {
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    downloaded = true;
  } catch (e2) {
    console.error("No se pudo descargar el registro como archivo:", e2);
  }

  const prefix = remoteSent ? "Enviado \u2713 y c" : "C";
  if (copied && downloaded) {
    statusEl.textContent = `${prefix}opiado al portapapeles y descargado como archivo (${n} líneas, build ${build}).`;
  } else if (copied) {
    statusEl.textContent = `${prefix}opiado al portapapeles (${n} líneas, build ${build}) — ya puedes pegarlo donde lo quieras mandar.`;
  } else if (downloaded) {
    statusEl.textContent = `${remoteSent ? "Enviado \u2713 y d" : "D"}escargado como archivo (${n} líneas, build ${build}).`;
  } else if (remoteSent) {
    statusEl.textContent = `Enviado \u2713 (${n} líneas, build ${build}) -- no se ha podido además copiar/descargar, pero esto sí ha llegado.`;
  } else {
    statusEl.textContent = "No se ha podido copiar, descargar ni enviar -- mira la consola del navegador (F12).";
  }
}

// Umbral de movimiento (proporcional al ancho de hombros) para
// considerar que hay un cambio de estado real y no ruido de la cámara.
const MOVE_FACTOR = 0.12;
const LIFTOFF_FACTOR = 0.04; // primer indicio de movimiento real (para medir bien la duracion)
const BAR_MARGIN_FACTOR = 0.25; // cuanto por debajo de la barra ya cuenta como "llegaste arriba"
const BAR_OFFSET_FACTOR = 0.05; // empuja la linea de la barra hacia arriba respecto a la muñeca (~2cm en un adulto medio, ver nota abajo)
const HANG_MARGIN_FACTOR = 0.08; // cuanto tienen que estar las munecas por encima de los hombros para considerar que estas colgado
// Umbral, bastante mas generoso que HANG_MARGIN_FACTOR, para decidir que
// de verdad te has SOLTADO de la barra a mitad de serie (no solo que
// hayas dejado de estar "colgado" segun el margen fino de arriba). En lo
// mas alto de una dominada los hombros suben tanto que casi tocan la
// altura de las munecas -siguen agarradas a la barra- asi que con el
// margen fino de HANG_MARGIN_FACTOR una dominada aguantada arriba se
// tomaba por "te has soltado" y cerraba la serie sola (reportado: "he
// aguantado un poco arriba y me ha contado como el principio de una
// serie nueva"). Aqui se exige que la muneca haya bajado CLARAMENTE por
// debajo del hombro -senal inequivoca de brazos ya extendidos hacia
// abajo- antes de dar la serie por terminada.
const RELEASE_MARGIN_FACTOR = 0.15;
const SCALE_TOLERANCE = 0.3; // cuanto puede variar el ancho de hombros (te acercas/alejas) antes de desconfiar del frame
const MIN_REP_SECONDS = 0.3; // por debajo de esto, se descarta como ruido
const PERF_LOG_EVERY_N_FRAMES = 90; // cada cuantos frames se vuelca al registro [perf] (ver loop()) un resumen de ms/frame real de detectForVideo -- ~3s a 30fps, ~1.5s a 60fps
// Prueba hecha 2026-09-15 en el Redmi A5 de Alex: "GPU" prom=114.8ms/9fps
// vs "CPU" prom=215.0ms/5fps (casi el doble de lento) — confirma que la
// GPU SÍ acelera de verdad en este dispositivo. ~9-11fps con GPU es el
// techo real del hardware para el modelo full, no un fallback oculto a
// CPU esperando a activarse. Dejar en "GPU" (mejor opción confirmada).
const POSE_DELEGATE = "GPU";
// La voz solo anuncia multiplos de N (N, 2N, 3N...) -- decirlas TODAS no
// daba tiempo a seguir el ritmo real de la serie en los ejercicios muy
// rapidos. Antes N=5 era fijo para todos los ejercicios; ahora es por
// ejercicio (Exercise.config.voice_step, ver voice_step en models.py),
// leido en el constructor como this.voiceStep desde data-voice-step. Por
// defecto (sin config, o ejercicio no encontrado) N=1: anuncia cada rep --
// pensado para ejercicios de fuerza a ritmo controlado (dominadas,
// fondos, flexiones, sentadillas...). Los pocos de cadencia muy rapida
// (jumping jacks, circulos de brazos, talones al gluteo, rodillas altas)
// llevan voice_step=5 puesto por la migracion 0050_set_voice_step_fast_exercises.
const DEFAULT_VOICE_STEP = 1;
const HANG_STABLE_MS = 500;   // cuanto tiempo seguido con los brazos en alto para empezar a calibrar
const ARMS_DOWN_STABLE_MS = 400; // cuanto tiempo seguido con los brazos abajo para dar la serie por terminada (evita falsos positivos por un frame ruidoso)
const CALIBRATION_MS = 1200;  // tiempo colgado quieto que se usa como referencia
const REST_ALERT_SECONDS = 90;
// Descanso obligatorio entre series: mientras no haya pasado esto desde
// que se cerró la serie anterior, countRep()/notePostureOk() no cuentan
// nada aunque vuelvas a colocarte y te muevas antes de tiempo — antes
// se contaban repeticiones calladas en pleno descanso si probabas a
// moverte (pedido explícitamente, ver announceRestBlocked). Mismo
// número que REST_ALERT_SECONDS a propósito: es el mismo "90 segundos"
// del que se avisa al usuario al cerrar la serie.
const MIN_REST_MS = REST_ALERT_SECONDS * 1000;
// Dominadas de arquero: mismo criterio de barra/subida-bajada que las
// dominadas normales (ver processArcherPullup), con un añadido — en el
// punto más alto de cada repetición, un brazo tiene que estar doblado
// (el que tira) y el otro estirado (el que se desliza por la barra).
// Igual de laxos que el resto de ángulos del fichero (ver
// PUSHUP_UP_ANGLE_DEG / PUSHUP_DOWN_ANGLE_DEG más abajo): no hace falta
// que sean exactos, solo que uno esté claramente doblado y el otro
// claramente recto.
const ARCHER_BENT_MAX_DEG = 115;     // codo del brazo que tira: como mucho esto para contar como "a 90° más o menos"
const ARCHER_STRAIGHT_MIN_DEG = 150; // codo del brazo que se desliza: al menos esto para contar como "estirado"
// Cuánto tiempo seguido sin detectarte NADA (o casi nada) en el encuadre
// para dar la serie en curso por terminada — sentadillas y los tres
// abdominales tumbado no tienen su propio "te has soltado" como
// dominadas o fondos, así que sin esto una serie se quedaba abierta para
// siempre en silencio si te ibas del encuadre. Salirse del encuadre a
// propósito sirve entonces de "siguiente serie" para quien no quiera
// levantarse del suelo entre series de abdominales (basta con salirse
// un momento y volver a entrar). Más largo que ARMS_DOWN_STABLE_MS a
// propósito: perder la detección un instante (oclusión, un giro brusco)
// es más común que soltarte de una barra, y no debería cerrar la serie
// por un despiste de la cámara.
const OUT_OF_FRAME_STABLE_MS = 1200;
// Ejercicios sin ningún cierre de serie propio (a diferencia de
// dominadas y fondos, que ya se cierran solos al soltarte) — a estos se
// les aplica el cierre por salir del encuadre de arriba, y también el
// cierre por ponerte de pie en el caso de los abdominales tumbado (ver
// ON_GROUND_STABLE_MS más abajo).
const GROUND_STYLE_COUNTERS = new Set(["lsit", "pushupfront", "squatfront", "squat", "splitsquat", "crunch", "legraise", "situp", "scissor", "doublecrunch", "pushup", "dip", "inclinepushup", "dumbbellcurl", "jumpingjack", "benchdip", "armcircles", "necklateral", "armscissors", "legrotation", "kneeraises", "heelkicks", "hiplateral", "neckcircles", "neckhalfturn", "neckturn", "forearmrotation", "wristrotation", "hipforwardback"]);
// Plancha / plancha lateral: a diferencia del resto de GROUND_STYLE_COUNTERS
// (que cuentan repeticiones), aquí se cuenta TIEMPO aguantando la postura
// — el cierre de serie no es "te has puesto de pie o has salido del
// encuadre" en sí (aunque las dos cosas también rompen la postura y acaban
// cerrando la serie de todas formas, ver notePostureBroken) sino "llevas
// PLANK_INVALID_STABLE_MS con la postura rota, sea cual sea el motivo" —
// levantar un brazo para el gesto del vaivén también rompe la postura
// ("apoya los dos brazos"), así que ni siquiera hace falta comprobar
// checkWaveGesture aparte: las mismas tres formas de terminar (ponerte de
// pie, salir del encuadre, agitar la mano) ya rompen la postura por sí
// solas. Por eso plank/sideplank no viven en GROUND_STYLE_COUNTERS ni
// comparten su lógica de cierre.
const CAMERA_POSTURE_COUNTERS = new Set(["lsithold", "plank", "sideplank", "wallsit", "kneeholdbar", "handstand", "armcrossstretch", "tricepsoverheadstretch", "seatedhamstringstretch", "standingquadstretch"]);
// Calentamientos y estiramientos (Exercise.body_area="warmup": jumping
// jacks, estiramiento cruzado de brazo…): pedido explicitamente no forzar
// el descanso obligatorio (MIN_REST_MS) entre series/lados aqui - no tiene
// sentido "descansar" entre un lado y el otro de un estiramiento, ni entre
// series de un calentamiento, que es precisamente para lo contrario
// (activarse antes de la sesion de verdad). Ver countRep()/notePostureOk().
const NO_REST_COUNTERS = new Set(["pushupfront", "squatfront", "jumpingjack", "armcrossstretch", "tricepsoverheadstretch", "armcircles", "necklateral", "armscissors", "legrotation", "kneeraises", "heelkicks", "seatedhamstringstretch", "hiplateral", "neckcircles", "neckhalfturn", "neckturn", "forearmrotation", "wristrotation", "standingquadstretch", "hipforwardback"]);

// --- Contadores DE FRENTE (Cindy workout) -- primera versión, sin probar en cámara real (2026-09-19) ---
// pushupfront: flexiones tumbado boca abajo MIRANDO a la cámara (móvil delante, a la altura del suelo o en
// un trípode alto). De frente el codo casi no se ve en 2D (se acorta), así que aquí SÍ se usan los world
// landmarks 3D de MediaPipe (result.worldLandmarks) para el ángulo del codo; si no vinieran, cae al 2D.
// squatfront: sentadillas de frente. La rodilla en 2D no sirve de frente, así que se mide cuánto baja la
// cadera respecto a los tobillos, en anchos de hombros (ratio que no depende de la distancia a la cámara),
// calibrado contra tu propia posición de pie al armar.
const FRONT_MIN_VISIBILITY = 0.4;
const PUSHUPFRONT_ARM_GATE_DEG = 140;      // brazos casi rectos para armar
const PUSHUPFRONT_DOWN_DEG = 110;          // codo doblado -> abajo
const PUSHUPFRONT_UP_DEG = 135;            // brazo otra vez casi recto -> rep completa
const PUSHUPFRONT_SMOOTH_ALPHA = 0.6;      // EMA del ángulo (1 = sin suavizar)
const PUSHUPFRONT_STANDING_TORSO_RATIO = 1.25; // hombro-cadera vertical / ancho de hombros por encima de esto = de pie (solo si se ven las caderas)
const PUSHUPFRONT_BREAK_STABLE_MS = 1000;
const SQUATFRONT_MIN_STAND_RATIO = 1.4;    // cadera-tobillo vertical / ancho de hombros mínimo para fiarse de "de pie"
const SQUATFRONT_ARM_STABLE_MS = 700;
const SQUATFRONT_ARM_MAX_JUMP = 0.15;      // salto máximo del ratio entre frames para considerarte quieto al armar
const SQUATFRONT_DOWN_FRACTION = 0.72;     // ratio <= 65% del de pie -> abajo
const SQUATFRONT_UP_FRACTION = 0.90;       // ratio >= 88% del de pie -> arriba (rep completa)
const SQUATFRONT_SMOOTH_ALPHA = 0.5;
const SQUATFRONT_MAX_W_CHANGE = 0.15;   // si el ancho de hombros cambia más de esto respecto a de pie, te estás acercando/alejando de la cámara: no es una sentadilla
const SQUATFRONT_REF_TRACK_BAND = 0.20; // mientras la bajada sea menor que esto, la referencia de pie sigue a tu altura
const SQUATFRONT_REF_ALPHA = 0.05;
const SQUATFRONT_MAX_REP_MS = 6000;     // más tiempo abajo que esto = no es una rep, se descarta
const SQUATFRONT_SHOULDER_DROP_DOWN = 0.40; // tronco baja >= 40% del ancho de hombros respecto a de pie -> abajo (sentadilla de verdad: ~0.7-1.0)
const SQUATFRONT_SHOULDER_DROP_UP = 0.18;   // vuelven a menos de 12% -> arriba (rep completa)
const SQUATFRONT_SHOULDER_ARM_MAX_JUMP = 0.10; // salto máximo de la altura de hombros entre frames (en anchos de hombros) para considerarte quieto al armar
const SQUATFRONT_ARM_SETTLE_MS = 600;
const SQUATFRONT_ARMS_UP_MS = 600;        // las dos muñecas por encima de la nariz seguido esto (de pie, arriba) = 'he terminado' (Cindy: pasar a la siguiente ronda sin tocar la pantalla)
// Para el aviso hablado corto de "ponte en posición" (ver
// notePostureBroken): estos tres se hacen de perfil (de lado a la
// cámara), así que ese aviso añade "de perfil" — el resto de
// CAMERA_POSTURE_COUNTERS (kneehold en barra, de frente; pino, sin
// restricción de orientación) usa el genérico a secas.
const PROFILE_POSTURE_COUNTERS = new Set(["lsithold", "plank", "sideplank", "wallsit", "seatedhamstringstretch"]);
// Vaivén de la mano para terminar una serie sin ponerte de pie ni salir
// del encuadre — ver checkWaveGesture. Solo para GROUND_STYLE_COUNTERS:
// ya se pueden cerrar poniéndote de pie o saliendo del encuadre, esto es
// una tercera forma para cuando ninguna de esas dos te venga bien en
// ese momento (p.ej. abdominales tumbado sin querer levantarte).
const WAVE_RAISE_MARGIN_FACTOR = 0.25; // SUBIDO de 0.05 a 0.25 (2026-09-17, ver el porqué junto a WAVE_MIN_AMPLITUDE_FACTOR más abajo): con las manos detrás de la nuca tumbado (postura normal de crunch/elevación de piernas), la muñeca ya superaba el margen mínimo anterior sin que hubiera ningún gesto deliberado -- ahora hace falta un brazo claramente levantado, no solo una mano junto a la cabeza
const WAVE_MIN_VISIBILITY = 0.4;
const WAVE_WINDOW_MS = 1800; // cuánto historial de la muñeca se guarda para ver el vaivén
const WAVE_MIN_AMPLITUDE_FACTOR = 0.25; // SUBIDO de 0.12 a 0.25 (2026-09-17): registro real -- llevar las manos a la nuca en crunch/elevación de piernas cerró la serie sola ("Serie de 3 terminada" justo tras el crunch 3, sin gesto real) porque el balanceo normal del torso al hacer la repetición ya movía la muñeca ese margen a los lados; ahora exige un vaivén de verdad amplio
const WAVE_MIN_DIRECTION_CHANGES = 3; // SUBIDO de 2 a 3 (2026-09-17), junto a los dos cambios de arriba, para que un saludo de verdad (izq-der-izq-der) siga detectándose pero un balanceo incidental del torso, con menos vaivenes limpios, ya no baste
// Sentadillas: alternativa a salir del encuadre para terminar la serie
// sin agitar la mano — ponerte de frente a la cámara (dejar de estar de
// perfil). Se detecta con la MISMA visibilidad que ya se calcula para
// elegir de qué lado medir el ángulo de rodilla: de perfil, un lado
// queda tapado por el cuerpo (visibilidades muy distintas); de frente,
// los dos lados se ven parecido.
const SQUAT_FRONTAL_VIS_DIFF_MAX = 0.12; // cuánto pueden diferir left/rightVis y aun así considerarse "de frente"
const SQUAT_FRONTAL_STABLE_MS = 700; // cuánto tiempo de frente y quieto para dar la serie por terminada
// Avisos hablados de estado (que no te ve bien, fin de serie…): el texto
// en pantalla se actualiza siempre, pero repetir el MISMO aviso por voz
// a menudo cansa rápido — así que un aviso idéntico al anterior no se
// repite antes de este tiempo. Subido a propósito: mejor que se sienta
// tranquilo que pesado.
const STATUS_VOICE_REPEAT_GAP_MS = 25000;
// Aun así, si el aviso es DISTINTO al anterior (p.ej. pasas de "no te
// veo bien" a "fin de serie"), se dice enseguida — no tiene sentido
// hacerte esperar. Este margen mínimo es solo para evitar una ráfaga si
// la detección parpadea entre dos estados en un par de frames seguidos.
const STATUS_VOICE_MIN_GAP_MS = 2000;
// No se aplica nada de esto al conteo de repeticiones (speakRep), que
// va aparte y siempre suena al momento.

// Fondos (2ª versión — ver git log para la anterior, basada en nariz
// vs. codos): ahora se cuentan por el ÁNGULO DEL CODO
// (hombro-codo-muñeca), igual que las flexiones, de perfil. La versión
// anterior evitaba el ángulo a propósito porque "solo se mide bien de
// perfil" — pero un ángulo no depende de la distancia a la cámara,
// mientras que nariz-vs-codos (normalizado por ancho de hombros) sí se
// degradaba a cierta distancia (mismo problema real que dominadas: el
// ruido de seguimiento se come el margen cuando el ancho de hombros en
// píxeles se hace pequeño). Y de perfil, además, entras en el encuadre
// mucho más estrecho que de frente (no hace falta encajar las dos
// paralelas a lo ancho), así que también arregla el fallo de "de cerca
// no me ve entera/o".
//
// El problema que resuelve todo lo de abajo: un ángulo de codo recto
// por sí solo NO distingue estar agarrado a las paralelas de estar
// simplemente de pie con los brazos colgando — el ángulo es ~180° en
// los dos casos. Hace falta algo que sea verdad SOLO cuando estás de
// verdad montado en las paralelas.
//
// Primer intento (ya retirado): usar la CADERA como referencia — cuánto
// sube respecto a tu altura de pie. Dos ajustes de umbral sobre ese
// enfoque no arreglaron el problema real, así que se le pidió a Alex un
// registro real de cámara (ver logScissor/exportScissorLog) — y ese
// registro demostró que la cadera es, en la práctica, el punto MENOS
// fiable de los que sigue MediaPipe con esta barra/encuadre: con Alex
// quieto y montado de verdad, "cadera subida" oscilaba de forma salvaje
// entre 0.7 y más de 13 (y llegó a salir negativa), y la recalibración
// automática (al volver a estado null tras bajarse) llegó a fijar la
// referencia de pie en un valor imposible (1.889) a partir de un único
// frame con la cadera mal vista — eso dejó el sistema incapaz de volver
// a armar una serie nueva después de la primera. La causa: el chequeo
// de visibilidad de más abajo promedia CUATRO puntos (hombro, codo,
// muñeca, cadera), así que una cadera apenas vista podía colar igual si
// los otros tres se veían bien.
//
// En ese mismo registro, en cambio, el ángulo de codo (hombro-codo-
// muñeca, que nunca toca la cadera) se movió siempre de forma suave y
// físicamente creíble durante toda la sesión. Así que el criterio de
// "¿sigues montada/o?" usa ahora el HOMBRO en su lugar, con dos
// salvaguardas que la cadera no tenía:
//
//  - El hombro solo actualiza la referencia de pie (dipGroundShoulderY)
//    en frames donde ÉL MISMO (no el promedio de los 4 puntos de más
//    abajo) se ve razonablemente bien (DIP_CALIBRATION_MIN_VISIBILITY)
//    — así un frame puntual con mala lectura no puede arruinar la
//    referencia para el resto de la sesión, que es justo lo que le pasó
//    a la cadera.
//
//  - En vez de un número fijo adivinado en abstracto (que fue el propio
//    problema con la cadera: los umbrales no se correspondían con nada
//    real en cámara), los umbrales de "sigues montada/o" y "te has
//    bajado de verdad" se calculan como una FRACCIÓN del pico de subida
//    de hombro que TÚ MISMA/O has enseñado en ESTA serie
//    (dipSetPeakShoulderRise, ver processDip) — se adaptan solos a tu
//    cuerpo y a tu barra concreta, en vez de una cifra fija que puede no
//    corresponder a nada en tu configuración real.
//
// Segundo bug real, visto en el mismo registro: Alex se subió, hizo
// unos fondos bien contados y, al levantar una mano para rascarse la
// nariz (sin bajarse de las paralelas), esa "repetición" también se
// contó. Causa: el ciclo arriba↔abajo solo miraba el ÁNGULO DEL CODO —
// doblar y estirar el brazo, aunque sea solo para rascarte o ajustarte
// algo, reproduce la misma secuencia de ángulos que un fondo real. La
// diferencia física real es que un fondo de verdad baja el CUERPO
// ENTERO (el hombro baja una cantidad apreciable), mientras que un
// gesto aislado del brazo casi no mueve el hombro. Arreglo: además del
// ciclo de ángulo, se exige que el hombro haya bajado un mínimo
// (DIP_MIN_SHOULDER_DROP_FACTOR) durante el tramo de abajada para que
// la repetición cuente de verdad — si no, se descarta sin cerrar la
// serie (ver countRep en processDip).
//
// Tercer bug real, visto en el PRIMER registro ya con el hombro (tras
// el cambio de arriba): el rediseño contaba bien y ya no colaba el
// gesto de rascarse, pero el cierre automático de serie (bajarte de
// las paralelas) falló al menos una vez y Alex tuvo que recurrir al
// gesto de la mano. El registro mostró la misma FAMILIA de problema que
// tenía la cadera, solo que más sutil: un salto de Y de un solo frame a
// otro (p.ej. 0.966→1.051 en un paso, algo que ningún cuerpo real hace
// en ese tiempo) que, según cuándo pasaba:
//  - si pasaba con this.state === null, arrastraba dipGroundShoulderY
//    (la referencia de pie) lejos de su valor real — se vio
//    0.914→1.064 en poco más de un segundo — dejando después varios
//    segundos sin poder volver a armar una serie nueva;
//  - si pasaba con this.state === "top", inflaba de golpe
//    dipSetPeakShoulderRise (se llegó a ver pico_serie=4.01 cuando el
//    valor real sostenido rondaba 1.4-2.0), lo que subía
//    mountedThreshold por encima de lo alcanzable de verdad y dejaba
//    "montada/o=no" fijo cerca de 22 segundos seguidos aun estando
//    montada/o de verdad.
// Arreglo: el mismo filtro de dos pasos que ya usan las tijeretas desde
// antes (recorte de salto bruto ANTES de suavizar, luego media móvil
// exponencial — ver SCISSOR_MAX_LIFT_JUMP/SCISSOR_SMOOTHING_ALPHA más
// abajo), aplicado a la Y del hombro (DIP_SHOULDER_MAX_Y_JUMP /
// DIP_SHOULDER_SMOOTHING_ALPHA, ver processDip) — así un solo frame con
// mala lectura ya no puede arrastrar ni la referencia de pie ni el pico
// de la serie. El ángulo del codo (elbowAngle) sigue usando el hombro
// BRUTO, sin este suavizado, para no restarle inmediatez a la detección
// de la propia repetición.
//
// Cuarto y quinto ajuste, del siguiente registro real (con el
// suavizado ya puesto): la cuenta de repeticiones y el armado inicial
// iban bien, pero el cierre automático de serie SEGUÍA yendo lento — el
// registro mostró casi 8 segundos de pie, ya claramente bajado de las
// paralelas, sin que se cerrara la serie sola, porque hombro_subido se
// quedaba pegado justo por encima del umbral de desmonte (p.ej. 0.41
// contra un umbral de 0.36) y tardaba en cruzarlo. La raíz: ese umbral
// se compara contra dipGroundShoulderY, una referencia de pie fijada al
// PRINCIPIO de toda la sesión — si te quedas de pie después en una
// postura o a una distancia ligeramente distinta a la de aquel momento,
// el margen entre "de pie de verdad" y el umbral puede ser tan pequeño
// que cualquier ruido tarda varios segundos en cruzarlo. Arreglo,
// idea de Alex: de perfil (como se hace el ejercicio) solo se ve bien
// UN hombro — el otro queda tapado por el propio cuerpo. En cuanto se
// ven los DOS hombros a la vez con buena confianza, es porque te has
// girado a mirar de frente a la cámara — algo que nunca pasa a media
// repetición — así que es una señal binaria, mucho más rápida y fiable
// que esperar a que un número cruce un umbral (ver DIP_FACE_CAMERA_
// VISIBILITY/DIP_FACE_CAMERA_STABLE_MS, processDip). Cerrar la serie así
// se suma a las otras dos formas que ya había (desmonte "de perfil" por
// umbral, y el gesto de la mano) — no las sustituye.
//
// ACTUALIZACIÓN (undécimo bug, ver el comentario largo junto a
// DIP_FACE_CAMERA_STABLE_MS en processDip): con datos reales de más de
// una cámara/postura de perfil, ambos hombros salen visibles ~0.95-1.00
// SIEMPRE, no solo al girarte de frente — así que esta idea, tal como
// estaba, no distinguía nada y quedó DESACTIVADA en processDip.
//
// De paso, otro bug real visto en el mismo tipo de sesiones: a veces no
// llegaba a armar al subirte a las paralelas. La visibilidad para armar
// promediaba CUATRO puntos (hombro+codo+muñeca+cadera), y la cadera no
// se usa para NADA más en esta función desde el rediseño (ver arriba) —
// era el mismo error que ya tuvo el chequeo de la cadera como
// referencia: un punto que ni hace falta puede arruinar la media si se
// ve mal (encuadre justo, cadera tapada por la propia barra, etc.).
// Arreglo: la visibilidad ahora promedia solo hombro+codo+muñeca, los
// tres puntos que de verdad se usan.
//
// Sexto bug real, el más grave con diferencia: tras los arreglos de
// arriba, un registro real mostró CERO fondos contados en toda la
// sesión (30 segundos, con bajadas y subidas claramente reales y
// profundas en el ángulo de codo: 9°, 24°, 47°...) porque el estado NUNCA
// llegaba a "bottom". Causa: hombro_subido (shoulderRise) se normalizaba
// dividiendo por upperArmLength, el largo hombro-codo medido en 2D FRAME
// A FRAME. Ese largo se ve bien de pie (brazo casi vertical, bien de
// perfil a la cámara), pero en el punto más bajo de un fondo real el
// brazo gira hacia atrás y se sale del plano de la cámara — su
// proyección en 2D se acorta mucho aunque el brazo en sí (en 3D) no
// cambie de largo. Un denominador que se encoge así infla artificialmente
// el cociente: el registro mostró hombro_subido cayendo hasta -2.94 en
// mitad de una bajada real, muy por debajo de mountedThreshold, así que
// stillMounted se volvía falso ANTES de que el ángulo de codo llegara a
// DIP_DOWN_ANGLE_DEG — la transición arriba→abajo nunca se cumplía y no
// se contaba ni una repetición. Arreglo: dejar de medir el largo de
// referencia frame a frame y, en su lugar, aprenderlo UNA VEZ, de pie
// (igual que dipGroundShoulderY), usando el largo hombro-CADERA (el
// tronco gira mucho menos que el brazo al bajar/subir) — ver
// dipTorsoLength, DIP_TORSO_LENGTH_MAX_JUMP, processDip. Esto reintroduce
// la cadera en la función, pero SOLO para esta calibración de pie — sigue
// sin formar parte del chequeo de visibilidad de "te veo" (ver el bug de
// arriba) ni de nada que se mida ya montada/o.
const DIP_UP_ANGLE_DEG = 155;   // codo casi recto -> arriba/armado (posición de partida / cuenta la repetición al volver aquí)
const DIP_DOWN_ANGLE_DEG = 90;  // codo doblado en ángulo recto o más -> abajo (mismo criterio "~90°" que ya se usaba antes)
const DIP_MIN_VISIBILITY = 0.4; // visibilidad MEDIA de hombro+codo+muñeca (los tres puntos que se usan de verdad — ya no la cadera, ver arriba), para saber que se te ve en absoluto
const DIP_CALIBRATION_MIN_VISIBILITY = 0.6; // visibilidad del HOMBRO EN SÍ (no la media de arriba) exigida para fiarse de él al (re)calibrar la referencia de pie — ver el bug real de la cadera corrupta, arriba
const DIP_ARM_STABLE_MS = 600;  // cuánto tiempo con el codo recto y quieto para armar el contador — ya NO exige nada de cadera/hombro para armar (ver más abajo, en processDip, por qué)
const DIP_BREAK_STABLE_MS = 1000; // cuánto tiempo seguido con la combinación de desmonte "de perfil" (hombro cerca de la referencia de pie) para dar la serie por terminada
const DIP_BREAK_INTERRUPT_GRACE_MS = 300; // octavo bug: un solo frame (o unos pocos) que deja de cumplir la forma de desmonte, por ruido de un landmark, NO reinicia la cuenta de arriba al momento — hace falta que la interrupción misma se sostenga esto para darla por real (ver processDip)
const DIP_SHOULDER_RISE_MOUNTED_RATIO = 0.5;  // fracción del pico de subida de hombro de ESTA serie por debajo de la cual el ciclo de repetición se congela (te estás bajando/subiendo, no haciendo un fondo)
const DIP_SHOULDER_RISE_DISMOUNT_RATIO = 0.25; // fracción, más estricta todavía, por debajo de la cual se considera que te has bajado de verdad "de perfil"
const DIP_MIN_SHOULDER_DROP_FACTOR = 0.30; // cuánto (en largo de tronco, hombro-cadera — ver el sexto bug, arriba) tiene que bajar el hombro en el tramo de abajada para que la repetición cuente — ver el bug de "rascarse la nariz", arriba
// DUODÉCIMO BUG REAL (2026-09-04, registro real desde el móvil, paralelas):
// el usuario reprodujo aposta el fallo original — de pie, SIN subirse a
// las paralelas, levantando las piernas a 90° y moviendo un poco los
// hombros arriba/abajo para imitar el gesto — y las 3 "repeticiones" de
// esa serie se contaron igual, confirmado por el usuario ("los 3 han
// sido los 3 fallos", "ni he puesto los brazos a 90° tampoco"). En el
// registro real, las 3 bajada_hombro fueron 0.16, 0.16 y 0.22 — las tres
// pasaban el mínimo de 0.15 por un margen mínimo (0.01–0.07), justo lo
// que se esperaría de un simple bamboleo de hombro sin fondo real. Se
// sube el mínimo a 0.30 (el doble) para exigir una bajada de verdad —
// con datos reales de picos de serie ya vistos (dipSetPeakShoulderRise
// llegando a 0.40 en fondos genuinos), 0.30 sigue dejando sitio a un
// fondo real sin exigir el pico entero. Si con este cambio deja de
// contar fondos de verdad (demasiado exigente) o sigue colándose algún
// bamboleo (demasiado laxo), hace falta un registro nuevo con el número
// real de bajada_hombro de ESE caso concreto para afinar otra vez — no
// adivinar sin datos (ver el historial de bugs de arriba, con más de un
// "arreglo" revertido por eso mismo).
const DIP_SHOULDER_SMOOTHING_ALPHA = 0.3; // media móvil exponencial sobre la Y del hombro (calibración/subida/pico/bajada — NO el ángulo del codo) — mismo valor que SCISSOR_SMOOTHING_ALPHA, ya probado
const DIP_SHOULDER_MAX_Y_JUMP = 0.04; // cuánto puede cambiar como mucho la Y bruta del hombro de un frame al siguiente antes de pasar por la media móvil — un salto mayor no es el cuerpo moviéndose, es un fallo puntual de tracking (ver el tercer bug, arriba, y SCISSOR_MAX_LIFT_JUMP)
const DIP_TORSO_LENGTH_MAX_JUMP = 0.05; // igual que DIP_SHOULDER_MAX_Y_JUMP pero para el largo hombro-cadera (dipTorsoLength) — ver el sexto bug, arriba
const DIP_FACE_CAMERA_VISIBILITY = 0.4; // visibilidad mínima exigida a AMBOS hombros a la vez para entender que te has girado de frente a la cámara (ver el cuarto ajuste, arriba). Bajado de 0.6 a 0.4 (el mismo umbral que DIP_MIN_VISIBILITY, ya probado) — con 0.6 hacía falta acercarse mucho a la cámara para que llegara a dispararse; de momento sin datos exactos de a qué visibilidad se queda un hombro tapado de perfil a distancia normal, así que se deja también sitio en el registro por frame (hombro_izq_vis/hombro_der_vis, más abajo en processDip) para afinar este número con datos reales si 0.4 se queda corto o se pasa
const DIP_FACE_CAMERA_STABLE_MS = 500; // cuánto tiempo seguido con los dos hombros visibles para dar la serie por terminada así — más corto que DIP_BREAK_STABLE_MS porque es una señal mucho más explícita e inequívoca

// Altura de las paralelas: BAJAS (te quedan las piernas dobladas, cerca
// de 90°, para no arrastrar los pies) o ALTAS (a la altura del pecho,
// piernas colgando estiradas, la cadera sube de verdad al montarte). Se
// detecta una vez por serie, nada más armar (dipBarType, ver processDip),
// para saber por CUÁL señal guiarse al detectar que te has bajado
// (desmonte): la cadera (paralelas altas, mismo concepto que ya se hacía
// con el hombro) o la rodilla (paralelas bajas). No hacen falta umbrales
// nuevos: los ángulos de rodilla reutilizan los MISMOS ya probados en
// sentadillas (SQUAT_UP_ANGLE_DEG/SQUAT_DOWN_ANGLE_DEG, más abajo en el
// archivo — misma idea de articulación doblada/estirada) y la subida de
// cadera reutiliza DIP_SHOULDER_RISE_MOUNTED_RATIO/DISMOUNT_RATIO, ya
// probados para el hombro. Esto NO toca cómo se cuentan las repeticiones
// (stillMounted, DIP_MIN_SHOULDER_DROP_FACTOR, dipRepShoulderTopY/MaxY,
// todo eso sigue igual) — solo cómo se decide que has terminado la serie.

// ── Flexiones (push-ups) ────────────────────────────────────────────
// Igual que los fondos, se detectan por un ÁNGULO, no por posición: no
// hay barra ni referencia que calibrar, y un ángulo no depende de lo
// cerca que estés de la cámara. Pero a diferencia de los fondos (que
// evitan a propósito el ángulo del codo porque "solo se mide bien de
// perfil" y el movimiento se ve igual de frente), aquí SÍ se usa el
// ángulo del codo (hombro-codo-muñeca): una flexión se hace boca abajo,
// con el cuerpo horizontal, así que el movimiento YA es de perfil por
// definición y el codo se ve doblarse perfectamente desde el lado.
//
// Justo por eso el aviso de colocación insiste en que LOS CODOS MIREN
// HACIA ATRÁS (pegados al cuerpo), no hacia los lados: un codo que se
// abre hacia fuera se mueve sobre todo en PROFUNDIDAD respecto a la
// cámara (hacia/desde el objetivo), y MediaPipe con una sola cámara no
// mide bien esa profundidad (angle() solo usa x/y, ver más abajo) — el
// ángulo saldría aplanado y las repeticiones no se contarían bien. Con
// el codo hacia atrás, el brazo se dobla en el mismo plano que ve la
// cámara de perfil, y el ángulo se mide de verdad.
//
// Antes de armar el contador hace falta confirmarte en la posición de
// ARRIBA: tumbado boca abajo de verdad (tiltFromHorizontal respecto al
// suelo, no un simple ángulo de línea — ver por qué en processPushup),
// cuerpo estirado (hombro-cadera-tobillo), brazos estirados y manos a
// la altura del pecho con los codos pegados al cuerpo, sostenido un
// rato (igual que crunch/situp con ON_GROUND_STABLE_MS) — así ponerte
// en posición no cuenta como nada. El chequeo de tilt (tumbado de
// verdad, no de pie) es lo que evita que estar de pie con los brazos
// rectos arme el contador por error, así que no hace falta exigir el
// codo doblado para eso.
const PUSHUP_UP_ANGLE_DEG = 160;   // brazo casi recto -> arriba (posición de partida / cuenta la repetición al volver aquí)
const PUSHUP_DOWN_ANGLE_DEG = 90;  // codo doblado en ángulo recto o más -> abajo (criterio real de "flexión completa")
const PUSHUP_MIN_VISIBILITY = 0.4;
const PUSHUP_LINE_MIN_DEG = 150;   // hombro-cadera-tobillo casi recto (cuerpo estirado, no encogido)
// Reportado 2026-09-14: haciendo flexiones rápido, el esqueleto no sigue el
// ritmo y se pierden repeticiones. En un móvil lento (o con el modelo MediaPipe
// "full") el frame exacto en el que el codo pasa por PUSHUP_DOWN_ANGLE_DEG o
// PUSHUP_UP_ANGLE_DEG puede "saltarse" entre dos capturas consecutivas
// (undersampling), así que la transición de estado nunca se dispara aunque la
// persona sí haya bajado/subido del todo. Se ensancha SOLO la zona de CONTEO
// (no el gate de armado inicial, que se queda estricto en PUSHUP_UP_ANGLE_DEG
// sostenido, sin este margen) el margen de abajo, así que un frame "cercano"
// ya vale como haber llegado, sin tener que tocar el ángulo exacto. Valor de
// partida sin calibrar en cámara real — pendiente de ajustar con el registro
// de depuración (📋) si se siguen perdiendo repeticiones, o si con esto
// empieza a contar de más (bajarlo).
const PUSHUP_FAST_REP_TOLERANCE_DEG = 10;
const PUSHUP_COUNT_DOWN_ANGLE_DEG = PUSHUP_DOWN_ANGLE_DEG + PUSHUP_FAST_REP_TOLERANCE_DEG; // 100° — dispara "abajo" con un poco más de margen
// Registro real (2026-09-15, Redmi A5, flexiones rápidas de verdad, log
// completo vía Compartir): con el umbral simétrico de 150° para "arriba",
// una tanda de ~3 flexiones físicas rápidas y seguidas quedó comprimida en
// UNA sola rep contada de 3.0s — el codo oscilaba entre ~66° y ~149° sin
// llegar nunca a 150°, así que el estado se quedaba en "bottom" todo el
// rato y no volvía a armarse entre repetición y repetición. No es
// undersampling (el ángulo sí se ve, solo que no llega al umbral) — es que
// al encadenar flexiones rápidas no se bloquea el codo del todo entre una
// y la siguiente, algo normal haciendo series rápidas de verdad.
// Solución: separar el umbral de "vuelta arriba para poder contar la
// siguiente" (rearm) del umbral de profundidad. La profundidad (abajo,
// PUSHUP_COUNT_DOWN_ANGLE_DEG=100°) NO se toca — ahí es donde se decide si
// la flexión fue completa de verdad. Para el rearm basta con alejarse lo
// bastante del fondo como para distinguir una repetición real de ruido de
// la cámara, sin exigir el bloqueo de codo completo: con los datos de
// arriba, 130° habría separado esa tanda en ~3 repeticiones distintas en
// vez de 1 (quedan margen de 30° tanto respecto al umbral de bajada como
// respecto a los picos reales registrados, 142-149°).
const PUSHUP_REARM_TOLERANCE_DEG = 30;
const PUSHUP_COUNT_UP_ANGLE_DEG = PUSHUP_UP_ANGLE_DEG - PUSHUP_REARM_TOLERANCE_DEG;         // 130° — solo rearma el conteo, no mide profundidad
// Mismo motivo que JUMPINGJACK_MIN_REP_SECONDS/KNEERAISE_MIN_REP_SECONDS:
// flexiones no tenía umbral propio y usaba el genérico MIN_REP_SECONDS (0.3s),
// que puede descartar como "ruido" una flexión rápida real.
const PUSHUP_MIN_REP_SECONDS = 0.15;
// Registro real (2026-09-15, mismo test que PUSHUP_REARM_TOLERANCE_DEG):
// el armado tardó 11+ de los 16s totales porque el intento de "postura
// confirmada" se reiniciaba una y otra vez — el codo, estando REALMENTE
// quieto en plancha, oscilaba entre lecturas de ~149-159° y de repente
// ~161-166°, y como armsStraight exigía elbowAngle >= PUSHUP_UP_ANGLE_DEG
// (160°) EN CADA FRAME, un solo frame a 157-158° (2-3° por debajo)
// reiniciaba groundStableSince a null y tiraba los ON_GROUND_STABLE_MS ya
// acumulados — pasó 3 veces seguidas antes de que un tramo de suerte se
// mantuviera 600ms sin bajar de 160. Esto es ruido normal de estimación
// de landmarks estando parado, no falta de postura real. El umbral de
// PROFUNDIDAD/calidad de la flexión en sí (PUSHUP_DOWN_ANGLE_DEG=90,
// PUSHUP_UP_ANGLE_DEG=160 como referencia de "recto de verdad") no se
// toca — esto solo afecta a si cuenta como "brazos estirados" para EMPEZAR
// a armar el contador, no a si una repetición cuenta como completa.
const PUSHUP_ARM_GATE_TOLERANCE_DEG = 15;
const PUSHUP_ARM_GATE_ANGLE_DEG = PUSHUP_UP_ANGLE_DEG - PUSHUP_ARM_GATE_TOLERANCE_DEG; // 145°
// Cierre de serie por romper la postura (te levantas): usa el mismo
// tilt que el gate de armado pero con MENOS sensibilidad a propósito —
// ver el fallo real que arregla en el docstring de processPushup: con
// el codo pegado al cuerpo (como se pide), el brazo tapa la cadera en
// la imagen justo al bajar, y eso ensuciaba la lectura del tilt lo
// bastante como para cerrar la serie sola a media flexión. Un umbral
// más laxo (60° en vez de los 40° de ON_GROUND_MAX_TILT_DEG) y más
// tiempo seguido (1000ms en vez de los 400ms de OFF_GROUND_STABLE_MS)
// dejan pasar ese ruido de seguimiento sin dejar de detectar que te has
// puesto de pie de verdad, que tarda mucho más que eso.
const PUSHUP_BROKEN_TILT_DEG = 60;
const PUSHUP_BREAK_STABLE_MS = 1000;

// ── Curl de bíceps con mancuernas ───────────────────────────────────────
// Se cuenta por el ÁNGULO DEL CODO (hombro-codo-muñeca), igual que
// flexiones/fondos/sentadillas — y, como esos tres, DE PERFIL, no de
// frente.
//
// SEGUNDA VERSIÓN: la primera (cámara de frente, como dominadas, para
// ver las dos mancuernas a la vez) no contaba NINGUNA repetición en
// cámara real — Alex lo probó y el contador se quedaba a cero. La causa
// física: un curl dobla el antebrazo en el plano SAGITAL del cuerpo (de
// delante hacia atrás, respecto a ti) — de frente a la cámara ese plano
// queda casi de canto, perpendicular a la imagen, así que el movimiento
// real apenas se ve en las coordenadas x/y de MediaPipe (que no da
// profundidad fiable con una sola cámara): el ángulo del codo proyectado
// se movía mucho menos que el ángulo real y nunca llegaba a cruzar
// CURL_FLEXED_ANGLE_DEG. De perfil, en cambio, ese plano sagital
// coincide con el plano de la imagen — el antebrazo sube dibujando un
// arco grande y bien visible, exactamente el mismo motivo por el que
// sentadillas/flexiones/fondos ya se miden de perfil (ver el bloque de
// comentarios de processDip más arriba). Por eso ahora, igual que esos
// tres, solo se trackea el lado (izq/der) que mejor se vea — el otro
// queda tapado por el propio cuerpo de perfil, así que no hace falta
// (ni se puede) ver los dos brazos a la vez.
//
// El problema real que pidió Alex resolver, en sus propias palabras: que
// no cuente una repetición falsa si "levanto las manos por error" o si
// "tengo el móvil agarrado [delante] de la cámara". Mirado SOLO por el
// ángulo del codo, esos dos gestos son indistinguibles de un curl de
// verdad (el codo también pasa de recto a doblado). MediaPipe Pose no da
// la forma de la mano (¿cerrada sujetando algo, o abierta?) ni reconoce
// objetos — solo hombro/codo/muñeca — así que "notar si hay algo
// agarrado" no se puede comprobar de forma literal. Lo que SÍ se puede
// comprobar, y sigue siendo válido de perfil, es la FORMA del
// movimiento:
//
//  - Un curl de verdad mantiene el CODO PEGADO AL COSTADO: solo gira el
//    antebrazo, el brazo (hombro-codo) apenas se mueve — de perfil, eso
//    quiere decir que el codo no se adelanta ni se atrasa respecto a la
//    cadera (ver curlElbowDrift en processDumbbellCurl). Levantar las
//    manos sin querer, rascarte o subir el móvil hacia la cara SIEMPRE
//    separa el codo del cuerpo o lo levanta hacia el hombro.
//  - Un curl de verdad NUNCA sube la muñeca por encima de la cara: el
//    punto más alto de un curl con mancuerna queda sobre el pecho/hombro.
//    Mirar el móvil, en cambio, sube la mano a la altura de los ojos.
//    Ver curlWristDrop en processDumbbellCurl.
//
// Estas comprobaciones (codo pegado, muñeca bajo la cara, cámara
// estable) se hacen en TODOS los frames mientras la serie está armada,
// no solo al principio — así un gesto suelto que rompa la forma real de
// un curl a medio ángulo nunca se cuenta como repetición, aunque el
// ángulo de codo por sí solo dibuje un ciclo estirado-doblado-estirado.
//
// Valores de partida, sin probar del todo en cámara real todavía — ver
// processDumbbellCurl si en el próximo test siguen sin cuadrar.
const CURL_EXTENDED_ANGLE_DEG = 155; // codo casi recto -> brazo colgando (posición de partida / cuenta la repetición al volver aquí)
const CURL_FLEXED_ANGLE_DEG = 70;    // codo doblado -> arriba del curl (mitad de la repetición)
const CURL_MIN_VISIBILITY = 0.4;
const CURL_ELBOW_DRIFT_MAX_FACTOR = 0.45; // cuánto puede alejarse el codo de la cadera EN HORIZONTAL, de perfil (proporción al tronco hombro-cadera) y seguir considerándose "pegado al costado"
const CURL_ELBOW_RISE_MAX_FACTOR = 0.25;  // cuánto puede subir el codo respecto a su altura AL ARMAR (proporción al tronco) antes de dejar de considerarse un curl — evita que levantar el BRAZO entero por el hombro (en vez de solo doblar el antebrazo) cuente como curl. Es relativo a la referencia guardada al armar (curlElbowBaselineY), NO a la cadera — ver processDumbbellCurl para el porqué del cambio.
const CURL_WRIST_FACE_MARGIN_FACTOR = 0.15; // margen (proporción al tronco) que la muñeca tiene que quedar POR DEBAJO de la nariz — mirar el móvil sube la mano a la cara, un curl real no pasa de pecho/hombro
const CURL_BROKEN_STABLE_MS = 400; // cuánto tiempo seguido con la forma rota (codo despegado, muñeca a la altura de la cara, o cámara temblando) para dar la serie por rota y cerrarla — corto a propósito: aquí importa más cortar un falso positivo que aguantar un parpadeo de la detección
const CURL_ARM_STABLE_MS = 500; // cuánto tiempo con el brazo estirado y en posición, seguido, para armar el contador
// Temporizador de "aguantando arriba" que pidió Alex: si te quedas con
// el brazo doblado (arriba del curl) sin volver a bajar, no es un curl
// — es una sujeción aguantada (una bolsa, el propio móvil...). No cuenta
// como repetición hasta que de verdad bajes y vuelvas a subir (eso ya lo
// garantiza el ciclo estirado→doblado→estirado de más abajo: aquí no
// hace falta ningún cambio para NO contarlo), pero además se avisa en
// pantalla de cuánto llevas así, para que quede claro que no se está
// contando nada mientras tanto — ver processDumbbellCurl.
const CURL_TOP_HOLD_WARN_MS = 1500;
// Detección de cámara inestable (el móvil sujeto en la mano en vez de
// apoyado en algún sitio fijo, otra forma de leer "tengo el móvil
// agarrado"): se mide cuánto se mueve el punto medio de los hombros de
// un frame al siguiente, en proporción al ancho de hombros — con el
// móvil apoyado ese punto apenas tiembla; sujeto en la mano tiembla de
// forma sostenida. Ver checkCameraShake.
const CURL_CAMERA_SHAKE_FACTOR = 0.03;
const CURL_CAMERA_SHAKE_STABLE_MS = 600;
// Cierre automático de serie por descanso, pedido por Alex: si te
// quedas con el brazo ESTIRADO DEL TODO y quieto (sin ni doblarlo ni
// moverte) más de CURL_REST_AUTO_CLOSE_MS, se interpreta como que has
// terminado la serie y quieres descansar — igual que agitar la mano o
// salirte del encuadre (ver closeActiveSet), pero sin tener que hacer
// ningún gesto: basta con pararse. La siguiente vez que vuelvas a
// armar (CURL_ARM_STABLE_MS con el brazo estirado) empieza una serie
// NUEVA sola, sin tocar nada. Solo se aplica si ya llevas alguna
// repetición contada en la serie (currentSetReps > 0): si todavía no
// has empezado a mover el brazo no hay nada que cerrar. El umbral es
// bastante más largo que una pausa normal entre repeticiones (la mayoría
// de la gente no aguanta 6s parada del todo entre una rep y la
// siguiente sin querer descansar) — vale también para un plan con
// objetivo de series/reps: cerrar la serie aquí solo empieza a contar
// una serie nueva, no fuerza a parar si quieres hacer más de lo que
// pide el objetivo.
const CURL_REST_AUTO_CLOSE_MS = 6000;
const CURL_REST_WARN_MS = 2000; // a partir de aquí se avisa en pantalla de la cuenta atrás, para que no pille por sorpresa



// ── Flexiones inclinadas (pies en alto) ─────────────────────────────
// A petición de Alex: mismo gesto de brazo que una flexión normal (mismo
// ángulo de codo cuenta la repetición, ver más arriba), pero con los pies
// apoyados en alto (una silla, un escalón, un sofá...) en vez de en el
// suelo.
//
// PRIMER intento (retirado tras probarlo en cámara real): usar
// tiltFromHorizontal(hombro, cadera) con un SUELO en vez de un techo —
// por debajo de un mínimo de inclinación, no cuenta como flexión
// inclinada. Falló de dos formas reales, las dos vistas por Alex en la
// primera prueba:
//  (1) una flexión NORMAL, plana, se contó igual — el ángulo hombro-
//      cadera puede salir mayor de lo esperado por el simple ángulo de
//      cámara/postura, sin que los pies estén elevados de verdad, así
//      que un suelo de inclinación por sí solo no distingue "pies en
//      alto" de "flexión plana vista con cierto ángulo";
//  (2) tras armar, cualquier ciclo de ángulo de codo contaba una
//      repetición SIN volver a comprobar nada — al coger el portátil y
//      recolocarlo delante, el gesto de doblar y estirar el brazo para
//      cogerlo se contó como una flexión, porque solo se miraba
//      elbowAngle una vez armado (mismo tipo de bug que "rascarse la
//      nariz" en fondos, ver processDip).
//
// Arreglo, en dos partes:
//
//  A) La señal de "pies en alto" ya NO es un ángulo indirecto
//     (hombro-cadera vs. horizontal), sino la comparación DIRECTA que
//     describe el propio ejercicio: la MUÑECA tiene que quedar
//     claramente por DEBAJO del TOBILLO en la imagen (Y crece hacia
//     abajo, así que tobillo.y < muñeca.y con margen — ver
//     INCLINE_PUSHUP_MIN_FOOT_RISE_FACTOR). Sin techo: por mucho que se
//     eleven los pies, la diferencia solo crece, así que sigue contando
//     igual ("da igual lo alto que pongas los pies"), pero SIN el falso
//     positivo de (1) — una flexión plana de verdad no cumple esto (los
//     pies y las manos quedan a una altura parecida en la imagen), y
//     estar de pie tampoco (de pie, la muñeca queda muy por ENCIMA del
//     tobillo, justo lo contrario).
//
//  B) La postura (pies en alto + cuerpo recto, ver bodyStraight) se
//     comprueba en TODOS los frames mientras la serie está armada, no
//     solo al empezar. En cuanto deja de cumplirse, el frame se
//     descarta sin mirar el ángulo de codo (así un gesto suelto de
//     brazo — coger el portátil, rascarte — nunca se puede convertir en
//     repetición aunque el ángulo por sí solo dibuje el ciclo
//     arriba-abajo-arriba) y, si se sostiene fuera de posición
//     (INCLINE_PUSHUP_BROKEN_STABLE_MS), se cierra la serie sola — el
//     equivalente de "te has puesto de pie" para esta variante, ahora sí
//     posible porque el criterio (B) no se confunde con estar de pie.
//
// El resto de condiciones (ángulo de codo para contar, visibilidad
// mínima) son las de processPushup — mismo gesto de brazo, mismas
// constantes (PUSHUP_UP_ANGLE_DEG, PUSHUP_DOWN_ANGLE_DEG,
// PUSHUP_MIN_VISIBILITY, PUSHUP_LINE_MIN_DEG, ON_GROUND_STABLE_MS).
const INCLINE_PUSHUP_MIN_FOOT_RISE_FACTOR = 0.12; // (muñeca.y - tobillo.y) en proporción al largo de tronco (hombro-cadera) — cuánto tiene que quedar el tobillo por ENCIMA de la muñeca en la imagen. Valor de partida, sin probar en cámara real: si cuesta armar con los pies solo un poco elevados, bajarlo; si sigue colándose una flexión plana, subirlo.
const INCLINE_PUSHUP_BROKEN_STABLE_MS = 400; // cuánto tiempo seguido fuera de posición (pies ya no en alto, o cuerpo encogido) para dar la serie por rota y cerrarla — más corto que PUSHUP_BREAK_STABLE_MS (1000ms) a propósito: aquí un falso positivo importa más que cortar por un parpadeo de la detección

// ── Fondos en banco (bench dip) ─────────────────────────────────────
// A petición de Alex: variante de fondos donde, en vez de paralelas,
// las manos se apoyan detrás del cuerpo en una superficie elevada (un
// banco, una silla, el borde de un sofá) y los pies se apoyan en el
// suelo por delante — el cuerpo entero forma una "L": el tronco
// prácticamente vertical y las piernas estiradas hacia delante,
// prácticamente horizontales, con la cadera en el vértice de la L.
//
// Mismo gesto de brazo que un fondo normal: el codo se dobla hasta
// ~90° y vuelve a estirarse para contar la repetición (se reutilizan
// DIP_UP_ANGLE_DEG/DIP_DOWN_ANGLE_DEG, arriba — misma familia "fondos",
// mismo criterio "~90°" pedido).
//
// A diferencia de processDip (paralelas, de pie, con toda su lógica de
// calibración de altura de hombro/cadera — ver el bloque DIP_* de más
// arriba y los muchos bugs reales que fue arreglando), aquí NO hace
// falta calibrar nada: la postura se puede comprobar en DIRECTO en cada
// frame con dos comparaciones de landmarks, sin aprender ninguna
// referencia de pie primero. Se sigue el mismo patrón que
// processInclinePushup (ver el bloque INCLINE_PUSHUP_* de más arriba)
// en vez del de processDip:
//
//  A) "Manos por encima de los pies" — a petición explícita de Alex
//     ("los brazos tienen que estar rectos y tienen que estar a un
//     nivel por encima de los pies"): la MUÑECA tiene que quedar
//     claramente por ENCIMA del TOBILLO en la imagen (Y crece hacia
//     abajo, así que muñeca.y < tobillo.y con margen — ver
//     BENCHDIP_HAND_RISE_MIN_FACTOR). Es la comparación CONTRARIA a la
//     de flexiones inclinadas (allí el tobillo tenía que estar por
//     encima de la muñeca — pies en alto, manos en el suelo; aquí es al
//     revés — manos en alto, pies en el suelo), normalizada igual, por
//     el largo de tronco (hombro-cadera) del frame actual.
//
//  B) "Cuerpo en forma de L" — el ángulo hombro-cadera-tobillo tiene que
//     quedar cerca de 90°, NO cerca de 180° como en una flexión o una
//     plancha (cuerpo estirado en línea recta): eso es precisamente lo
//     que distingue un fondo en banco de, por ejemplo, tumbarte con las
//     manos elevadas. Rango con margen (BENCHDIP_BODY_ANGLE_MIN_DEG /
//     BENCHDIP_BODY_ANGLE_MAX_DEG) en vez de exigir 90° exactos, porque
//     ni la cadera queda siempre a la misma altura entre gente distinta
//     ni la cámara mide el ángulo con precisión perfecta.
//
// Igual que en flexiones inclinadas, la postura se comprueba en TODOS
// los frames mientras la serie está armada, no solo al principio — así
// un gesto suelto de brazo nunca se puede colar como repetición, y
// salir de la postura cierra la serie sola (BENCHDIP_BROKEN_STABLE_MS).
// Ver la nota "ARREGLO tras la primera prueba real", justo debajo, para
// el porqué (B) ya no forma parte de ese gate — se quedó en (A) sola.
const BENCHDIP_HAND_RISE_MIN_FACTOR = 0.12; // (tobillo.y - muñeca.y) en proporción al largo de tronco (hombro-cadera) — cuánto tiene que quedar la muñeca por ENCIMA del tobillo en la imagen.
// ARREGLO tras la primera prueba real en cámara: feedback de Alex —
// pidió relajar el ángulo de cuerpo ("si no forma una L perfecta no
// pasa nada") y reportó que, con el cuerpo en una L correcta al bajar,
// en cuanto se contaba la primera repetición y volvía a subir (brazos
// rectos), la serie se cerraba sola justo después — mismo patrón que
// el "cuenta 1, 1, 1..." que ya tuvo processDip en su día (ver el
// bloque DIP_* de más arriba): al subir del todo la cadera se abre de
// forma natural y variable de una persona a otra, así que exigirla
// dentro de un rango estrecho para MANTENER la serie abierta cerraba
// series reales por algo que no tiene nada que ver con romper la
// postura de verdad. Arreglo: (B) deja de formar parte de inPosition
// (ver más abajo, en processBenchDip) — se sigue calculando y
// mostrando en el registro de depuración, por si hace falta revisar el
// dato más adelante, pero ya no arma ni cierra la serie por sí solo. El
// único gate real que queda es (A) — manos por encima de los pies —
// tal y como pidió Alex: soltar las manos hacia el suelo, ponerte de
// pie o salir del encuadre son ahora las formas de cerrar la serie.
const BENCHDIP_BODY_ANGLE_MIN_DEG = 60;  // solo informativo (ver ARREGLO arriba): ángulo hombro-cadera-tobillo por debajo del cual ya no se parece a una L
const BENCHDIP_BODY_ANGLE_MAX_DEG = 120; // solo informativo (ver ARREGLO arriba): ángulo hombro-cadera-tobillo por encima del cual ya es más un cuerpo estirado (flexión/plancha) que una L
const BENCHDIP_BROKEN_STABLE_MS = 400; // cuánto tiempo seguido fuera de posición (manos ya no en alto, o piernas ya no estiradas) para dar la serie por rota y cerrarla — mismo valor/criterio que INCLINE_PUSHUP_BROKEN_STABLE_MS: aquí un falso positivo importa más que cortar por un parpadeo de la detección
const BENCHDIP_KNEE_MIN_DEG = 150; // ángulo cadera-rodilla-tobillo mínimo para considerar las piernas "estiradas" — ver la nota "SEGUNDO ARREGLO" en processBenchDip, más abajo: doblar la rodilla (sentarte normal, o el primer gesto de levantarte) rompe la postura, igual que soltar las manos del apoyo.
const BENCHDIP_TORSO_VERTICAL_MIN_DEG = 50; // inclinación mínima (tiltFromHorizontal, hombro-cadera) respecto a la HORIZONTAL para considerar el tronco "en vertical" — ver la nota "TERCER ARREGLO" en processBenchDip, más abajo. Primer valor, sin probar a fondo en cámara real: si cuesta armar estando bien sentado, bajarlo; si se sigue colando algo con el tronco inclinado, subirlo.


// Sentadillas: se cuentan por el ÁNGULO DE LA RODILLA (cadera-rodilla-tobillo),
// no por la altura de la nariz como en fondos. Un ángulo no depende de lo
// cerca que estés de la cámara, así que tampoco hace falta calibrar nada.
// A diferencia de los fondos (donde se evitó a propósito el ángulo del
// codo porque "solo se mide bien de perfil" y de frente ya se ve la nariz
// bajar igual de bien), aquí SÍ interesa el ángulo — pero eso significa
// que la sentadilla solo se puede contar bien vista DE PERFIL: de frente,
// la cámara no puede distinguir cuánto se dobla la rodilla en profundidad.
// Por eso el aviso en pantalla pide colocarse de lado.
const SQUAT_UP_ANGLE_DEG = 160;   // pierna casi recta -> de pie ("arriba")
const SQUAT_DOWN_ANGLE_DEG = 100; // rodilla suficientemente doblada -> sentadilla ("abajo")
const SQUAT_MIN_VISIBILITY = 0.4;
// Cuánto tiempo seguido de pie (rodilla estirada) hace falta para armar
// el contador — evita armar con una sola lectura ruidosa mientras se
// coloca el móvil (un frame suelto puede dar un ángulo alto por pura
// casualidad durante ese rato). Mismo patrón que hangStableSince en
// dominadas (HANG_STABLE_MS) o groundStableSince en abdominales tumbado
// (ON_GROUND_STABLE_MS) — sentadillas no lo tenía porque "no hay nada
// que calibrar", pero armar el contador SÍ necesita esta estabilidad,
// sea cual sea el ejercicio.
const SQUAT_ARM_STABLE_MS = 500;
// Reportado en vivo (2026-09-18): "me ha contado 1 repeticion de mas al
// ponerme en posicion" en un plan al fallo, y la serie se cerro sola sin
// querer justo despues. Dos sintomas, mismo momento (justo tras armar):
// (1) justo tras armar (de pie quieto SQUAT_ARM_STABLE_MS) seguias
// acomodandote -- ajustar postura, peso entre pies -- y ese movimiento
// residual podia cruzar SQUAT_DOWN_ANGLE_DEG y volver a subir, contando
// como si fuera una sentadilla real (mismo mecanismo ya root-causeado y
// arreglado en crunch, ver CRUNCH_ARM_SETTLE_MS/crunchArmedAt: se ignora
// la primera bajada hasta pasado este margen desde que se armo, solo
// afecta al primer instante de la serie). (2) el propio aviso "Listo!"
// (hablado + en pantalla) que se dispara justo al terminar de armar
// invita a mirar un instante al movil para leerlo/confirmarlo -- eso se
// lee como "de frente" (ver isFrontal mas abajo) y los 700ms de
// SQUAT_FRONTAL_STABLE_MS no bastaban para que ese vistazo no acabara
// cerrando la serie. Ambos comparten la misma causa de fondo (nada daba
// un margen de asentamiento justo tras armar) asi que se arreglan con el
// mismo mecanismo: no dejar que ninguna de las dos cuente hasta pasado
// este margen desde que se armo.
const SQUAT_ARM_SETTLE_MS = 600; // primer valor, mismo orden de magnitud que CRUNCH_ARM_SETTLE_MS (500ms) -- pendiente de confirmar con un log real
// Margen aparte y mas generoso para el cierre por "de frente" (ver
// isFrontal): aqui el objetivo no es solo que la pierna deje de temblar
// sino dar tiempo real a leer/escuchar el aviso "Listo!" sin que ese
// vistazo cuente para cerrar la serie.
const SQUAT_FRONTAL_GRACE_MS = 1500; // primer valor, pendiente de confirmar con un log real

// Split squat / zancada estática: mismo ángulo cadera-rodilla-tobillo de
// perfil que la sentadilla (ver bloque SQUAT_* arriba), pero aquí las
// dos piernas quedan separadas delante/detrás en vez de una tapando a
// la otra -- processSplitSquat NO fija un lado de antemano como
// processSquat, usa la rodilla más doblada de las que se vean bien (ver
// esa función). Mismos umbrales de ángulo que sentadillas como primera
// aproximación -- pendiente de calibrar con cámara real, igual que el
// resto de la familia de ejercicios nuevos.
const SPLITSQUAT_UP_ANGLE_DEG = 160;
const SPLITSQUAT_DOWN_ANGLE_DEG = 100;
const SPLITSQUAT_MIN_VISIBILITY = 0.4;
const SPLITSQUAT_STABLE_MS = 500; // mismo criterio/valor que SQUAT_ARM_STABLE_MS
const SPLITSQUAT_ARM_GATE_TOLERANCE_DEG = 15; // AÑADIDO 2026-09-17 tras un registro real: de pie en la postura escalonada (una pierna delante, otra detrás), el ángulo mínimo entre las dos piernas rara vez sostenía los 160° seguidos (oscilaba 125-176°, natural en un split squat -- la pierna de atrás no queda tan recta como en una sentadilla normal); solo afecta al armado inicial, ver SPLITSQUAT_ARM_GATE_ANGLE_DEG
const SPLITSQUAT_ARM_GATE_ANGLE_DEG = SPLITSQUAT_UP_ANGLE_DEG - SPLITSQUAT_ARM_GATE_TOLERANCE_DEG;
// Cuarta forma de terminar la serie: quedarte quieto (parado, de pie o
// de frente a la cámara) sin avanzar en la repetición durante más de
// SPLITSQUAT_IDLE_CLOSE_MS. Se probaron dos versiones geométricas de
// "detectar que te has puesto de frente" (anchura de cadera, luego
// anchura de hombros) y ninguna de las dos dio resultados fiables con
// cámara real -- un aviso simple de inactividad es más simple y más
// robusto (pedido explícitamente por Alex).
const SPLITSQUAT_IDLE_CLOSE_MS = 5000;
// BUG REAL visto en el primer test (reportado por Alex): levantar un pie
// hacia atrás y doblar solo ESA rodilla (tipo curl femoral de pie, sin
// tocar la otra pierna) se contaba como repetición, porque kneeAngle
// (el mínimo de las dos piernas) bajaba de sobra del umbral aunque la
// pierna de apoyo siguiera con la rodilla recta. Un split squat de
// verdad dobla las DOS rodillas a la vez (la de delante y la de
// detrás), así que además de exigir que la más doblada baje de
// SPLITSQUAT_DOWN_ANGLE_DEG, se exige que la OTRA pierna (si también se
// ve) no esté recta del todo -- ver processSplitSquat. Primer valor,
// pendiente de calibrar con cámara real.
const SPLITSQUAT_SUPPORT_MAX_ANGLE_DEG = 150;

// -- Jumping jacks (calentamiento, subtipo de prueba) -------------------
// Ejercicio DE FRENTE a la camara (a diferencia de sentadillas/fondos,
// que van de perfil) y simetrico izquierda-derecha, asi que no hace
// falta elegir un lado como en processSquat. Se cuenta un ciclo cerrado
// (brazos pegados al cuerpo, pies juntos) -> abierto (brazos por encima
// de la cabeza, piernas separadas) -> cerrado, contando la repeticion al
// volver a cerrar (mismo patron que sentadillas: se cuenta al VOLVER a
// la posicion de partida, no al abrir). Referencia de escala: el ancho
// de hombros, igual que el resto del fichero (MOVE_FACTOR,
// HANG_MARGIN_FACTOR...) para que el umbral no dependa de la distancia
// a la camara.
const JUMPINGJACK_MIN_VISIBILITY = 0.3; // visibilidad media de hombros+caderas+munecas+tobillos exigida para fiarse del frame -- bajado de 0.4: saltando de verdad (movimiento rapido de todo el cuerpo) la confianza de MediaPipe en munecas y tobillos baja por el propio movimiento (motion blur), no porque hayas salido del encuadre; con 0.4 se perdian frames en pleno salto (ver JUMPINGJACK_OUT_OF_FRAME_MS para el otro lado de este mismo problema)
const JUMPINGJACK_ARMS_UP_MARGIN_FACTOR = 0.15;   // cuanto por encima del hombro tienen que estar las munecas para contar "brazos arriba" (proporcional al ancho de hombros)
const JUMPINGJACK_ARMS_DOWN_MARGIN_FACTOR = 0.1;  // cuanto como mucho por encima del hombro para contar "brazos abajo/pegados al cuerpo"
const JUMPINGJACK_LEGS_OPEN_RATIO = 1.6;  // los tobillos tienen que estar al menos esto de veces mas separados que la cadera para contar "piernas abiertas"
const JUMPINGJACK_LEGS_CLOSED_RATIO = 1.3; // como mucho esto de veces mas separados que la cadera para contar "piernas juntas" -- subido de 1.15: de pie de forma normal (sin pegar los pies a proposito) el ratio real ya anda cerca de 1.15-1.3, asi que exigir <1.15 en TODOS los frames de forma continua (sin margen de ruido, ver JUMPINGJACK_ARM_NOISE_TOLERANCE_MS) tardaba muchisimo en armar, o incluso no llegaba a armar
const JUMPINGJACK_ARM_STABLE_MS = 500; // tiempo quieto en posicion cerrada para armar el contador (mismo patron que SQUAT_ARM_STABLE_MS)
const JUMPINGJACK_STILL_MS = 2000; // sin abrir ni cerrar (ni un medio-ciclo) durante esto: se interpreta que has parado y se cierra la serie sola -- sustituye a checkWaveGesture aqui, ver la nota junto a processJumpingJack
const JUMPINGJACK_OPEN_STABLE_MS = 150; // "piernas abiertas" tiene que sostenerse esto seguido antes de contarlo como el inicio de un salto -- filtra un roce/ruido de un frame suelto (occlusion, un tropiezo) sin estar saltando; ver la nota junto a processJumpingJack sobre la serie fantasma reportada
const JUMPINGJACK_FIRST_JUMP_GRACE_MS = 6000; // margen (desde que se arma) antes de que el primer salto cuente como "te has quedado quieto" -- tiene que cubrir el tiempo que tarda en decirse el aviso hablado "Listo!..." (unos 2-3s) MAS el tiempo de reaccion para empezar a saltar; ver la nota junto al bloque de armado en processJumpingJack
const JUMPINGJACK_ARM_NOISE_TOLERANCE_MS = 200; // al armar (posicion cerrada quieta), un frame suelto que NO cumple armsDown/legsClosed (parpadeo del tracking, no un movimiento real) se tolera hasta esto sin reiniciar el cronometro de estabilidad -- de pie de forma normal el ratio de piernas ya baila por ruido de deteccion, y sin esta tolerancia cualquier parpadeo aislado reiniciaba jjArmStableSince entero y el armado no terminaba nunca de completarse
const JUMPINGJACK_OUT_OF_FRAME_MS = 3000; // cuanto tiempo sin verte bien (vis < JUMPINGJACK_MIN_VISIBILITY) hace falta para cerrar la serie por ausencia -- mas largo que el OUT_OF_FRAME_STABLE_MS generico (1200ms) porque saltando de verdad es normal encadenar varios frames de visibilidad baja seguidos por el propio movimiento; reportado: con el umbral generico la serie se cerraba sola (0 repeticiones, en silencio) a mitad de una tanda de saltos reales
const JUMPINGJACK_MIN_REP_SECONDS = 0.12; // sustituye al MIN_REP_SECONDS generico (0.3s) SOLO para jumping jacks -- repStartTime se marca ya DESPUES del debounce de apertura (JUMPINGJACK_OPEN_STABLE_MS, 150ms), que es el que de verdad filtra el ruido de un frame suelto; exigir encima 0.3s completos de duracion de "repeticion" descartaba saltos reales rapidos como si fueran ruido -- reportado explicitamente: a partir de cierto punto, yendo mas rapido, dejaban de contarse repeticiones sueltas (confirmado en el registro: aperturas reales de ~0.25-0.3s de duracion, sin ningun aviso de "Jumping jack N")

// Círculos de brazos — DE FRENTE a la cámara, calentamiento dinámico (no
// isométrico: a diferencia de armcrossstretch/tricepsoverheadstretch, que
// se aguantan, aquí se cuentan repeticiones — un círculo completo de los
// dos brazos a la vez = una repetición, igual de espíritu que jumping
// jack). Pedido por el usuario con un vídeo de referencia (WhatsApp,
// 2026-09-05): de pie, los dos brazos extendidos giran a la vez, primero
// hacia delante y luego, dentro de la MISMA serie, la cámara cambia sola
// el sentido esperado a "hacia atrás" (mismo espíritu que el cambio de
// lado en checkArmCrossStretch, pero aquí los dos brazos giran juntos en
// vez de alternar izq/der).
//
// Geometría: para cada brazo se calcula un ángulo LOCAL alrededor de su
// propio hombro (ver wrapAngleDelta/processArmCircles), con el eje X
// normalizado para que "hacia fuera" sea siempre positivo en los dos
// lados (el hombro/muñeca izquierdos del cuerpo -L_SHOULDER/L_WRIST-
// aparecen en la mitad DERECHA de la imagen sin espejar -ver la nota ya
// existente sobre PoseLandmarker.detectForVideo leyendo el frame sin
// espejar-, así que su "fuera" es +x; los del lado derecho del cuerpo
// aparecen en la mitad IZQUIERDA, así que su "fuera" es -x) y el eje Y
// invertido para que "arriba" sea positivo. Con este ángulo local, un
// giro real sincronizado de los dos brazos produce el MISMO signo de
// velocidad angular en ambos brazos, así que un simple promedio de los
// dos ya sirve de señal combinada sin tratar cada brazo por separado.
//
// Sentido: analizando el vídeo de referencia (brazos abajo -> suben
// cruzando por delante del cuerpo hasta juntarse arriba cerca de la cara
// -> bajan abriéndose por los lados, en cruz, hasta abajo otra vez), con
// esta convención de ángulo local el ángulo desciende de forma continua
// a lo largo de toda la vuelta — así que "hacia delante" se define como
// ángulo DECRECIENTE, y "hacia atrás" como creciente (el sentido
// contrario). Confirmado con cámara real (test 2026-09-05): el signo
// calculado coincide con este análisis del vídeo -- igual que
// armcrossstretch/tricepsoverheadstretch, lo que falló en el primer
// test no fue el signo sino los umbrales de tracking (ver
// ARMCIRCLES_MIN_REACH_FACTOR y ARMCIRCLES_MAX_SINGLE_ARM_DELTA).
const ARMCIRCLES_MIN_VISIBILITY = 0.4; // visibilidad media de hombros+muñecas exigida para fiarse del frame
const ARMCIRCLES_MIN_REACH_FACTOR = 0.45; // la muñeca tiene que estar al menos esto de veces el ancho de hombros lejos del hombro para considerar el brazo "extendido" (evita acumular ángulo con el brazo pegado al cuerpo, quieto) -- bajado de 0.6 (segundo test en cámara real, 2026-09-05): con 0.6 hacía falta el brazo prácticamente perfectamente recto para armar el contador, cualquier codo algo doblado se quedaba corto
const ARMCIRCLES_ARM_STABLE_MS = 400; // brazos extendidos sostenido esto antes de armar el contador (mismo espíritu que JUMPINGJACK_ARM_STABLE_MS, más corto porque aquí no hay piernas que comprobar)
const ARMCIRCLES_MIN_ANGULAR_DELTA = 0.02; // radianes por frame por debajo de esto se consideran ruido de tracking, no giro de verdad (ni cuenta como progreso para ARMCIRCLES_STILL_MS ni se acumula)
const ARMCIRCLES_STILL_MS = 2500; // sin progreso angular de verdad durante esto: se interpreta que te has parado -- si en esta serie aún no has hecho el otro sentido, se cambia de sentido solo, sin pedir bajar los brazos (ver processArmCircles); si ya lo habías hecho, se cierra la serie sola (mismo patrón que JUMPINGJACK_STILL_MS)
const ARMCIRCLES_OUT_OF_FRAME_MS = 3000; // mismo motivo que JUMPINGJACK_OUT_OF_FRAME_MS: girando de verdad los brazos también se pierde visibilidad por motion blur, no solo al salirte del encuadre
const ARMCIRCLES_MIN_REP_SECONDS = 0.5; // una vuelta completa por debajo de esto es un salto de ángulo mal calculado (ruido), no un círculo de verdad hecho a mano
const ARMCIRCLES_MAX_SINGLE_ARM_DELTA = 2.4; // radianes (~137°) por frame: por encima de esto, el ángulo de ESE brazo este frame se descarta como fallo puntual de tracking (típicamente cuando las muñecas se cruzan cerca de la cara, con el "radio" muy pequeño y el ángulo hipersensible a cualquier ruido) en vez de sumarse al acumulado — primer test en cámara real (2026-09-05) mostró saltos aislados de 30-57°/frame justo ahí, algunos con el signo cambiado, que descuadraban el conteo; subido de 1.0 a 1.6 (segundo test, girar rápido perdía reps) y luego a 2.4 (cuarto test, seguía perdiendo reps yendo rápido pese a v5 dejar de tirar el giro para siempre en el frame descartado -- 2.4 deja mucho más margen sin acercarse a pi, donde el propio signo del delta dejaría de ser fiable)

// NECKLATERAL_*: giros/inclinaciones laterales de cuello -- de frente a
// la cámara, de pie o sentada/o, la nariz se separa del centro (punto
// medio de los hombros) hacia un lado y vuelve al centro; un vaivén
// completo (centro -> lado -> centro) cuenta como una repetición (ver
// processNeckLateral). Pedido con un vídeo de referencia (WhatsApp,
// 2026-09-05): "que detecte cuando la nariz va a un lado sin que el
// cuello se mueva de sitio" -- por eso, aparte de contar el vaivén, se
// vigila el punto medio de los HOMBROS (no de la cara): la cabeza puede
// girar/inclinarse, pero el torso tiene que quedarse donde estaba (ver
// NECKLATERAL_DRIFT_TOLERANCE_FACTOR) -- primera versión, pendiente de
// calibrar con un test en cámara real, mismo patrón que
// armcrossstretch/tricepsoverheadstretch/armcircles en su día.
const NECKLATERAL_MIN_VISIBILITY = 0.4; // visibilidad media de nariz+hombros exigida para fiarse del frame
const NECKLATERAL_ENTER_FACTOR = 0.16; // la nariz tiene que separarse del punto medio de los hombros al menos esto de veces el ancho de hombros para contar "ha llegado a un lado"
const NECKLATERAL_MAX_VERTICAL_FACTOR = 0.12; // cuanto puede "caer" la nariz (respecto a los hombros, ya descontado tu propio centro) para que un desplazamiento siga contando como ir HACIA UN LADO -- reportado en la primera prueba real (2026-09-05): tirar la cabeza hacia delante/abajo (barbilla al pecho) se contaba como repetición, porque ese movimiento también corre algo la nariz en horizontal (ruido de tracking/perspectiva), aunque el movimiento real sea sobre todo vertical. Por debajo de este umbral el vaivén se acepta igual (una inclinación lateral real también baja algo la nariz hacia el hombro, no es un movimiento puramente horizontal); por encima, se descarta como "eso ha sido hacia abajo, no hacia un lado"
const NECKLATERAL_EXIT_FACTOR = 0.05; // tiene que volver a estar más cerca del centro que esto para cerrar el vaivén y contar la repetición (histéresis, evita contar temblores cerca del umbral de entrada como varias repeticiones)
const NECKLATERAL_CENTER_STABLE_MS = 500; // centrada/o y quieta/o sostenido esto antes de armar el contador -- fija tu propio "centro" real como baseline (mismo espíritu que ARMCIRCLES_ARM_STABLE_MS/JUMPINGJACK_ARM_STABLE_MS)
const NECKLATERAL_SIDE_STABLE_MS = 100; // el lado tiene que sostenerse esto seguido antes de confirmarse -- filtra un pico de un frame suelto (ruido de tracking), no un giro de verdad
const NECKLATERAL_MIN_REP_SECONDS = 0.15; // sustituye al MIN_REP_SECONDS generico (0.3s) SOLO para este ejercicio -- repStartTime se marca YA DESPUES del debounce de confirmacion (NECKLATERAL_SIDE_STABLE_MS), que es el que de verdad filtra el ruido de un pico de un frame suelto (mismo razonamiento que JUMPINGJACK_MIN_REP_SECONDS); exigir encima 0.3s completos desde ahi hasta volver al centro descartaba como "ruido" un vaiven real hecho con cierta soltura (visto en pruebas: 400ms de ida y vuelta, con 100ms ya consumidos por el debounce, se quedaba en ~300ms y caia justo en el borde)
const NECKLATERAL_STILL_MS = 4000; // sin completar ningún vaivén durante esto: se interpreta que has terminado y se cierra la serie sola (mismo patrón que JUMPINGJACK_STILL_MS/ARMCIRCLES_STILL_MS, con más margen porque este es un movimiento lento de cuello, no un salto o un giro de brazo entero)
const NECKLATERAL_DRIFT_TOLERANCE_FACTOR = 0.12; // cuánto puede desplazarse el punto medio de los hombros (respecto a donde estaba al salir del centro) antes de avisar de que el cuerpo se está inclinando en vez de solo girar/inclinar la cabeza -- se avisa, no se penaliza (misma filosofía que el sentido equivocado en círculos de brazos): la repetición se sigue contando igual

// NECKTURN_*: giro de cabeza a los lados -- DISTINTO de NECKLATERAL_*
// (que es una INCLINACIÓN, oreja hacia el hombro): aquí la cabeza GIRA
// sobre el eje vertical del cuello (como decir "no" con la cabeza), de
// frente a la cámara, de pie o sentada/o -- mira hacia un lado y vuelve
// a mirar al frente; un vaivén completo (centro -> lado -> centro)
// cuenta como una repetición (ver processNeckTurn). Pedido explícitamente
// como ejercicio nuevo y separado, con un vídeo de referencia (WhatsApp,
// grabado 2026-09-04, subido 2026-09-08): "que también cuenten según el
// movimiento de la nariz de un lado a otro" y "esperar mirando al frente
// para la siguiente serie" -- ambas cosas ya las resuelve, sin cambios,
// la misma mecánica de necklateral (armar el contador exige centrarte
// primero, y closeActiveSet() vuelve a pedir centro al cerrar la serie).
// Misma geometría de base que necklateral (desplazamiento horizontal de
// la nariz respecto al punto medio de los hombros, normalizado por el
// ancho de hombros) y mismos valores ya calibrados ahí -- reutilizados
// como punto de partida razonable bajo constantes propias e
// independientes (girar de verdad suele desplazar la nariz TANTO o más
// que inclinar la cabeza, así que debería ir bien igual) -- primera
// versión de este ejercicio, pendiente de confirmar con una prueba real
// en cámara.
const NECKTURN_MIN_VISIBILITY = 0.4; // visibilidad media de nariz+hombros exigida para fiarse del frame (mismo umbral que NECKLATERAL_MIN_VISIBILITY)
const NECKTURN_ENTER_FACTOR = 0.16; // la nariz tiene que separarse del punto medio de los hombros al menos esto de veces el ancho de hombros para contar "ha llegado a un lado" (mismo umbral que NECKLATERAL_ENTER_FACTOR)
const NECKTURN_MAX_VERTICAL_FACTOR = 0.12; // cuánto puede "caer" la nariz (respecto a los hombros, ya descontado tu propio centro) para que un desplazamiento siga contando como ir HACIA UN LADO y no hacia delante/abajo (barbilla al pecho) -- mismo umbral y mismo motivo que NECKLATERAL_MAX_VERTICAL_FACTOR
const NECKTURN_EXIT_FACTOR = 0.05; // tiene que volver a estar más cerca del centro que esto para cerrar el vaivén y contar la repetición (histéresis, mismo umbral que NECKLATERAL_EXIT_FACTOR)
const NECKTURN_CENTER_STABLE_MS = 500; // mirando al frente y quieta/o sostenido esto antes de armar el contador -- fija tu propio "centro" real como baseline (mismo valor que NECKLATERAL_CENTER_STABLE_MS)
const NECKTURN_SIDE_STABLE_MS = 100; // el lado tiene que sostenerse esto seguido antes de confirmarse -- filtra un pico de un frame suelto (ruido de tracking), no un giro de verdad (mismo valor que NECKLATERAL_SIDE_STABLE_MS)
const NECKTURN_MIN_REP_SECONDS = 0.15; // sustituye al MIN_REP_SECONDS genérico (0.3s) SOLO para este ejercicio, mismo motivo y mismo valor que NECKLATERAL_MIN_REP_SECONDS
const NECKTURN_STILL_MS = 4000; // sin completar ningún vaivén durante esto: se interpreta que has terminado y se cierra la serie sola (mismo valor que NECKLATERAL_STILL_MS)
const NECKTURN_DRIFT_TOLERANCE_FACTOR = 0.12; // cuánto puede desplazarse el punto medio de los hombros (respecto a donde estaba al salir del centro) antes de avisar de que el cuerpo entero se está girando/desplazando en vez de solo la cabeza -- se avisa, no se penaliza (mismo espíritu que NECKLATERAL_DRIFT_TOLERANCE_FACTOR)

// NECKCIRCLE_*: círculo completo de cuello -- de pie o sentada/o, de
// frente a la cámara: la cabeza dibuja un círculo completo (de frente,
// hacia un lado, barbilla al pecho, hacia el otro lado, y hacia atrás/
// arriba de vuelta al frente), en cualquier sentido (horario o
// antihorario) -- una vuelta completa cuenta como una repetición (ver
// processNeckCircles). Mismo principio de ángulo acumulado que
// ARMCIRCLES_* (wrapAngleDelta sobre el ángulo de un vector, sumando el
// delta de cada fotograma hasta llegar a ±2π), pero aquí el vector no es
// hombro->muñeca sino punto-medio-de-hombros->nariz, y a diferencia de
// círculos de brazos NO hay bloqueo de sentido (armCirclePhase): aquí
// cualquiera de los dos sentidos cuenta siempre, sin tener que completar
// antes el otro ni pararte para cambiar -- pedido explícitamente por el
// usuario ("que también cuenten si los hago en sentido contrario").
// Pedido con un vídeo de referencia (WhatsApp, 2026-09-04): de pie, de
// frente a la cámara, la cabeza da una vuelta completa alrededor del
// cuello. Primera versión, pendiente de calibrar con un test en cámara
// real, mismo patrón que el resto de la familia.
const NECKCIRCLE_MIN_VISIBILITY = 0.4; // visibilidad media de nariz+hombros exigida para fiarse del frame (mismo umbral que NECKLATERAL_MIN_VISIBILITY)
const NECKCIRCLE_CENTER_ENTER_FACTOR = 0.16; // para armar, la nariz tiene que estar dentro de esto (veces el ancho de hombros) del centro -- de frente y quieta/o, no a mitad de un giro (mismo umbral que NECKLATERAL_ENTER_FACTOR)
const NECKCIRCLE_CENTER_STABLE_MS = 500; // de frente y quieta/o sostenido esto antes de armar el contador (mismo valor que NECKLATERAL_CENTER_STABLE_MS)
const NECKCIRCLE_MIN_ANGULAR_DELTA = 0.02; // radianes por frame por debajo de esto se consideran ruido de tracking, no giro de verdad (mismo umbral que ARMCIRCLES_MIN_ANGULAR_DELTA/LEGROTATION_MIN_ANGULAR_DELTA)
const NECKCIRCLE_MAX_SINGLE_FRAME_DELTA = 1.2; // BAJADO de 2.4 (~137°, copiado sin más de ARMCIRCLES_MAX_SINGLE_ARM_DELTA/LEGROTATION_MAX_SINGLE_LEG_DELTA) a 1.2 (~69°) tras una prueba real (2026-09-17, Redmi A5, ~10-12fps): el registro mostró saltos puntuales de 56°, 81°, 99° e incluso 127° en un solo fotograma aceptados como giro real -- físicamente imposibles para un cuello (rango de movimiento mucho menor y más lento que un brazo o una pierna haciendo círculos anchos, que es para lo que se pensó el 2.4 original). Esos saltos, en ambos sentidos, se sumaban al acumulado y se cancelaban entre sí sin avance neto -- la vuelta completa de 360° nunca llegaba a cerrarse en toda la sesión. 1.2 rad deja margen de sobra (más del doble) sobre los saltos de giro real más rápidos vistos en ese mismo registro (~30-45°/frame) y rechaza los picos de ruido. Pendiente de confirmar con un test real nuevo.
const NECKCIRCLE_STILL_MS = 4000; // sin progreso angular de verdad durante esto: se interpreta que has terminado y se cierra la serie sola (mismo patrón que NECKLATERAL_STILL_MS, más margen que ARMCIRCLES_STILL_MS porque el cuello gira más despacio que un brazo)
const NECKCIRCLE_OUT_OF_FRAME_MS = 3000; // mismo motivo que ARMCIRCLES_OUT_OF_FRAME_MS: girando la cabeza de verdad también se pierde algo de confianza de tracking por el propio movimiento, no solo al salirte del encuadre
const NECKCIRCLE_MIN_REP_SECONDS = 1.0; // una vuelta completa por debajo de esto es un salto de ángulo mal calculado (ruido), no un círculo de cuello de verdad hecho a mano -- más alto que ARMCIRCLES_MIN_REP_SECONDS (0.5) porque un giro de cuello es forzosamente más lento que uno de brazo

// NECKHALFTURN_*: media vuelta de cuello -- de pie o sentada/o, de
// frente a la cámara: la cabeza va de un lado (oreja hacia el hombro) al
// otro pasando por el centro con la barbilla hacia el pecho, SIN seguir
// hasta completar el círculo entero (sin llegar a inclinar la cabeza
// hacia atrás) -- pedido explícitamente como "que pare a la mitad", con
// un segundo vídeo de referencia (WhatsApp, 2026-09-04) para
// diferenciarlo del círculo completo de arriba.
//
// v1 (mismo mecanismo que NECKCIRCLE_*, un umbral fijo de π acumulado en
// cualquier sentido) contaba una repetición de más al final de una serie
// real (2026-09-08): tras la última repetición de verdad, el usuario se
// quedó quieto/a cerca del extremo, y el ruido de tracking siguió
// arrastrando el ángulo acumulado lentamente en el MISMO sentido -- sin
// llegar a cambiar de sentido en ningún momento -- hasta cruzar π igual
// que si hubiera sido una repetición real. v2 cambia el criterio por
// completo: ya NO se cuenta al llegar a un ángulo acumulado fijo, sino
// cada vez que se CONFIRMA un cambio de sentido (parar e invertir el
// giro, pedido explícitamente por el usuario: "haz que cuente una rep
// cada vez que paro y cambio de direccion") -- así que seguir girando
// sin parar en el mismo sentido, por mucho que acumule, ya NUNCA cuenta
// de más. El cambio de sentido se confirma cuando el movimiento en el
// sentido contrario se sostiene NECKHALFTURN_REVERSE_STABLE_MS seguidos
// (filtra un simple temblor, no una inversión de verdad), y solo cuenta
// si el vaivén que se cierra giró al menos NECKHALFTURN_MIN_SWING_RAD
// (filtra una inversión real pero minúscula, no un vaivén completo).
// Sigue sin haber bloqueo de sentido: el primer movimiento de cada
// vaivén, en cualquier sentido, es válido -- pedido explícitamente por
// el usuario ("que también cuenten si los hago en sentido contrario").
const NECKHALFTURN_MIN_VISIBILITY = 0.4; // visibilidad media de nariz+hombros exigida para fiarse del frame (mismo umbral que NECKCIRCLE_MIN_VISIBILITY/NECKLATERAL_MIN_VISIBILITY)
const NECKHALFTURN_CENTER_ENTER_FACTOR = 0.16; // para armar, la nariz tiene que estar dentro de esto (veces el ancho de hombros) del centro (mismo umbral que NECKCIRCLE_CENTER_ENTER_FACTOR)
const NECKHALFTURN_CENTER_STABLE_MS = 500; // de frente y quieta/o sostenido esto antes de armar el contador (mismo valor que NECKCIRCLE_CENTER_STABLE_MS)
const NECKHALFTURN_MIN_ANGULAR_DELTA = 0.02; // radianes por frame por debajo de esto se consideran ruido de tracking, no giro de verdad ni posible cambio de sentido (mismo umbral que NECKCIRCLE_MIN_ANGULAR_DELTA)
const NECKHALFTURN_MAX_SINGLE_FRAME_DELTA = 1.2; // BAJADO de 2.4 a la vez que NECKCIRCLE_MAX_SINGLE_FRAME_DELTA (mismo registro real 2026-09-17, mismo motivo): un salto de ruido de ~130° en el sentido contrario, sostenido apenas NECKHALFTURN_REVERSE_STABLE_MS (150ms, 1-2 fotogramas a este fps), bastaba por sí solo para superar tanto ese umbral como NECKHALFTURN_MIN_SWING_RAD (60°) y contar una repetición falsa -- causa muy probable de contar 3 en vez de 1 en media vuelta reportado ese mismo día. Pendiente de confirmar con un test real nuevo.
const NECKHALFTURN_STILL_MS = 4000; // sin progreso angular de verdad durante esto: se interpreta que has terminado y se cierra la serie sola (mismo valor que NECKCIRCLE_STILL_MS/NECKLATERAL_STILL_MS)
const NECKHALFTURN_OUT_OF_FRAME_MS = 3000; // mismo motivo que NECKCIRCLE_OUT_OF_FRAME_MS
const NECKHALFTURN_MIN_REP_SECONDS = 0.5; // una media vuelta por debajo de esto es ruido, no un vaivén de verdad hecho a mano
const NECKHALFTURN_REVERSE_STABLE_MS = 150; // movimiento en el sentido contrario sostenido esto antes de confirmar un cambio de sentido de verdad -- filtra un temblor de un solo fotograma cerca del punto más girado (mismo espíritu que NECKLATERAL_SIDE_STABLE_MS/HIPLATERAL_SIDE_STABLE_MS, algo más largo porque aquí el movimiento es continuo y suave, no un gesto que se sostiene de golpe)
const NECKHALFTURN_MIN_SWING_RAD = Math.PI / 3; // ~60°: el vaivén que se cierra al confirmarse un cambio de sentido tiene que haber girado al menos esto para contar como repetición -- filtra una inversión real pero minúscula (un ligero rebote cerca del extremo) sin exigir llegar exactamente a los 180° del vídeo de referencia

// HIPLATERAL_*: balanceo lateral de cadera -- de frente a la cámara, de
// pie, con los pies bien separados (más que el ancho de cadera) y SIN
// moverlos del sitio: la cadera se desplaza de un lado a otro y vuelve
// al centro; un vaivén completo (centro -> lado -> centro) cuenta como
// una repetición (ver processHipLateral). Mismo espíritu de vaivén
// centro/lado que NECKLATERAL_*, pero aquí el punto que se mueve es la
// CADERA (no la nariz) y la referencia fija es el punto medio de los
// TOBILLOS (no los hombros) -- los pies tienen que quedarse plantados
// mientras la cadera va de un lado a otro, así que aquí es el
// desplazamiento de los TOBILLOS el que se vigila y se avisa si de más
// (ver HIPLATERAL_FEET_DRIFT_TOLERANCE_FACTOR), igual que NECKLATERAL
// vigila los hombros. Pedido por el usuario con un vídeo de referencia
// propio (subido 2026-09-07): pies en el suelo, con una distancia entre
// ellos más ancha que la cadera, sin moverse, la cadera va de un lado a
// otro.
//
// v2/v3 (mismo día, a partir de la primera prueba real en cámara):
// reportados dos problemas. (a) mover la cadera hacia delante y hacia
// atrás (sin ir a ningún lado) se contaba como repetición válida -- el
// umbral en X por sí solo no distingue un desplazamiento lateral de uno
// en profundidad; añadido un chequeo sobre la coordenada Z de MediaPipe
// (ver HIPLATERAL_MAX_DEPTH_FACTOR, primera vez que este proyecto usa
// profundidad, mismo espíritu que el chequeo vertical de
// NECKLATERAL_MAX_VERTICAL_FACTOR). (b) la primera "repetición" contada
// no era de verdad, porque salía de estar aún colocándote -- v2 había
// probado a sustituir el requisito de partida por manos en la cadera +
// pies a la distancia de los codos, pero se ha vuelto (v3) a la postura
// simple de siempre (pies más anchos que la cadera) a petición del
// usuario; en su lugar se ha alargado HIPLATERAL_CENTER_STABLE_MS
// (500ms -> 1500ms) para exigir más tiempo realmente quieto antes de
// armar el contador -- mismo mecanismo (una espera más larga antes de
// armar) que ya usa el resto de la familia para este mismo problema.
const HIPLATERAL_MIN_VISIBILITY = 0.4; // visibilidad media de cadera+tobillos exigida para fiarse del frame
const HIPLATERAL_MIN_STANCE_FACTOR = 1.15; // los tobillos tienen que estar separados al menos esto de veces el ancho de cadera para considerar la postura "pies bien separados" (más ancho que la cadera, pedido explícitamente) -- por debajo de esto se avisa de que hay que abrir más los pies, sin llegar a armar el contador
const HIPLATERAL_ENTER_FACTOR = 0.12; // la cadera tiene que separarse del punto medio de los tobillos al menos esto de veces el ancho de la base (tobillo a tobillo) para contar "ha llegado a un lado"
const HIPLATERAL_EXIT_FACTOR = 0.04; // tiene que volver a estar más cerca del centro que esto para cerrar el vaivén y contar la repetición (histéresis, mismo espíritu que NECKLATERAL_EXIT_FACTOR)
const HIPLATERAL_CENTER_STABLE_MS = 1500; // centrada/o y quieta/o sostenido esto antes de armar el contador -- fija tu propio "centro" real como baseline; subido de 500 a 1500 (v3) porque 500ms dejaba que la primera "repetición" saliera de estar aún colocándote/ajustando los pies, no de un balanceo de verdad (reportado en la primera prueba real, 2026-09-07)
const HIPLATERAL_SIDE_STABLE_MS = 100; // el lado tiene que sostenerse esto seguido antes de confirmarse -- filtra un pico de un frame suelto (ruido de tracking), no un balanceo de verdad (mismo espíritu que NECKLATERAL_SIDE_STABLE_MS)
const HIPLATERAL_MIN_REP_SECONDS = 0.2; // un vaivén completo por debajo de esto es ruido, no un balanceo de verdad
const HIPLATERAL_STILL_MS = 4000; // sin completar ningún vaivén durante esto: se interpreta que has terminado y se cierra la serie sola (mismo patrón que NECKLATERAL_STILL_MS)
const HIPLATERAL_FEET_DRIFT_TOLERANCE_FACTOR = 0.15; // cuánto puede desplazarse el punto medio de los tobillos (respecto a donde estaba al confirmarse el lado) antes de avisar de que los pies se están moviendo del sitio en vez de quedarse quietos mientras solo la cadera se balancea -- a diferencia de NECKLATERAL_DRIFT_TOLERANCE_FACTOR (que solo avisa sin bloquear), aquí superarlo también bloquea que el vaivén cuente como repetición al volver al centro: se detectó en una prueba real que, al terminar una serie y caminar hacia la cámara con las manos fuera de la cadera, ese desplazamiento de pies se contaba igualmente como repetición válida (2026-09-07)
const HIPLATERAL_MAX_DEPTH_FACTOR = 0.35; // cuánto puede alejarse/acercarse la cadera de la cámara (eje Z de MediaPipe, relativo a tu propia profundidad de referencia fijada al armar, normalizado por el ancho de la base) para que un desplazamiento en X siga contando como ir HACIA UN LADO -- reportado en la primera prueba real (2026-09-07): mover la cadera hacia delante y hacia atrás se contaba como repetición válida, porque ese movimiento también corre algo la cadera en horizontal (ruido/perspectiva de cámara), aunque el movimiento real sea sobre todo en profundidad. Por encima de este umbral el vaivén NO se confirma como lateral (mismo espíritu que NECKLATERAL_MAX_VERTICAL_FACTOR con la nariz cayendo hacia delante/abajo) -- primera vez que este proyecto usa la coordenada z, pendiente de calibrar con un test en cámara real
const HIPLATERAL_GEOMETRY_SMOOTHING_ALPHA = 0.3; // media móvil exponencial (mismo valor que SCISSOR_SMOOTHING_ALPHA/DIP_SHOULDER_SMOOTHING_ALPHA) aplicada a hipMidX/hipMidZ/hipWidth/ankleMidX/stanceWidth ANTES de comparar nada -- en la segunda prueba real (2026-09-07) hipWidth (cadera casi de frente, muy poca separación en x/y) llegó a saltar entre 0.008 y 0.09 de un fotograma a otro por puro ruido de tracking, y como la comprobación de "pies bien separados" se hacía cada fotograma sin ningún margen, un solo fotograma ruidoso bastaba para desarmar un vaivén que ya llevaba varios segundos armado (nunca llegaba a confirmarse un lado). Suavizar las cinco magnitudes de golpe, igual que se hace con la altura de tobillos en tijeretas, amortigua ese ruido sin esconder un cambio real y sostenido de postura.

// HIPFORWARDBACK_*: cadera adelante y atrás -- de pie, DE PERFIL a la
// cámara (a diferencia de HIPLATERAL_*, que pide de frente), pies
// quietos en el suelo: la cadera se lleva hacia delante y hacia atrás,
// volviendo cada vez al centro. Mismo mecanismo de vaivén con
// histéresis que HIPLATERAL_* (armar sobre un centro estable, entrar a
// un umbral, salir a uno más corto), pero rotado 90°: lo que en
// HIPLATERAL_* era el eje bueno para "a un lado" (X, de frente) y el
// eje ruidoso para "delante/atrás" (Z, de frente -- ver
// HIPLATERAL_MAX_DEPTH_FACTOR) se intercambian al ponerse de perfil, así
// que aquí "delante/atrás" se mide limpio en X sin tocar Z para nada.
// Normalizado por la longitud cadera-tobillo (no por el ancho de la
// base tobillo-tobillo, que de perfil se solapa casi a cero -- mismo
// motivo que HEELKICK_MAX_HIP_DRIFT_FACTOR). De perfil las dos
// caderas/tobillos casi se solapan en la imagen, así que solo se
// vigila un lado, elegido UNA vez al armar según cuál se vea mejor y
// fijo el resto de la serie (mismo criterio que "elegida UNA pierna"
// en talones al glúteo v10). Primera versión, umbrales sin probar en
// cámara real todavía -- pendientes de calibrar con un test real, mismo
// patrón que el resto de la familia.
const HIPFORWARDBACK_MIN_VISIBILITY = 0.4; // visibilidad media de cadera+tobillo (del lado vigilado) exigida para fiarse del frame (mismo umbral que el resto de la familia)
const HIPFORWARDBACK_CENTER_GATE_TOLERANCE_FACTOR = 0.20; // AÑADIDO en v3 tras una prueba real en móvil (2026-09-17, Redmi A5, ~10fps): el armado nunca llegó a completarse en TODA la sesión (37s) -- el registro mostró la desviación real oscilando de forma sostenida entre -0.36 y +0.28 incluso "quieto" intentando centrarse, muy por encima del umbral de 0.06 usado hasta ahora para el propio gate de armado (ese umbral se calibró para detectar el MOVIMIENTO real del ejercicio, no para tolerar el vaivén postural normal de estar de pie de perfil a ~10fps). Se separa un umbral propio, más ancho, solo para decidir si un fotograma mantiene vivo el cronómetro de estabilidad -- HIPFORWARDBACK_ENTER_FACTOR (abajo) se queda igual para todo lo demás (detección de dirección adelante/atrás una vez armado), que es donde sí importa que siga siendo sensible. Con este umbral el tramo de ~2.7s de sway real capturado en ese registro (13.9s-16.6s, siempre por debajo de 0.21) sí habría bastado para completar los 1500ms de HIPFORWARDBACK_CENTER_STABLE_MS. Pendiente de confirmar con un test real nuevo.
const HIPFORWARDBACK_ENTER_FACTOR = 0.06; // BAJADO de 0.12 (v1, copiado sin más de HIPLATERAL_ENTER_FACTOR) a 0.06 en v2 tras una prueba real (2026-09-08): con 0.12 nunca llegó a contar ni una repetición -- el registro en vivo mostró la desviación real, moviendo la cadera adelante/atrás a propósito, tocando techo entre 0.09 y 0.11 (nunca cruzando 0.12), mientras que de pie sin más (ruido/ajuste de postura) se quedaba entre 0.01 y 0.05. El hip hinge de este ejercicio mueve la cadera bastante menos, en proporción a la longitud de la pierna, que el balanceo lateral de cadera (para el que sí valía 0.12) -- normal, son amplitudes de movimiento distintas. 0.06 deja margen holgado a los dos lados de esa separación observada; pendiente de confirmar con otra prueba real.
const HIPFORWARDBACK_EXIT_FACTOR = 0.02; // BAJADO de 0.04 a la vez que HIPFORWARDBACK_ENTER_FACTOR (v2), manteniendo la misma proporción 1:3 entre umbral de salida y de entrada que HIPLATERAL_EXIT_FACTOR/HIPLATERAL_ENTER_FACTOR
const HIPFORWARDBACK_CENTER_STABLE_MS = 1500; // centrada/o y quieta/o sostenido esto antes de armar el contador -- fija tu propio "centro" real como baseline (mismo valor y motivo que HIPLATERAL_CENTER_STABLE_MS)
const HIPFORWARDBACK_DIRECTION_STABLE_MS = 100; // delante/atrás tiene que sostenerse esto seguido antes de confirmarse -- filtra un pico de un frame suelto, no un vaivén de verdad (mismo espíritu que HIPLATERAL_SIDE_STABLE_MS)
const HIPFORWARDBACK_MIN_REP_SECONDS = 0.2; // un vaivén completo por debajo de esto es ruido, no un vaivén de verdad (mismo valor que HIPLATERAL_MIN_REP_SECONDS)
const HIPFORWARDBACK_STILL_MS = 4000; // sin completar ningún vaivén durante esto: se interpreta que has terminado y se cierra la serie sola (mismo valor que HIPLATERAL_STILL_MS)
const HIPFORWARDBACK_FEET_DRIFT_TOLERANCE_FACTOR = 0.15; // cuánto puede desplazarse el tobillo vigilado (respecto a donde estaba al confirmarse delante/atrás), en fracción de la longitud de la pierna, antes de que el vaivén en curso no cuente como repetición al volver al centro -- mismo mecanismo y valor que HIPLATERAL_FEET_DRIFT_TOLERANCE_FACTOR
const HIPFORWARDBACK_GEOMETRY_SMOOTHING_ALPHA = 0.3; // media móvil exponencial aplicada a la posición X de cadera y tobillo y a la longitud de la pierna ANTES de comparar nada -- mismo valor y motivo que HIPLATERAL_GEOMETRY_SMOOTHING_ALPHA
const HIPFORWARDBACK_PROFILE_MAX_HIP_WIDTH_FACTOR = 0.35; // separación aparente cadera-cadera (Math.hypot, en X e Y), en fracción de la longitud de la pierna vigilada, por ENCIMA de la cual se considera que ya NO estás de perfil sino girándote hacia la cámara -- de perfil de verdad las dos caderas casi se solapan en la imagen (mismo razonamiento que ya usa esta familia para normalizar por longitud de pierna en vez de anchura de base). Pedido explícito del usuario tras una prueba real (2026-09-08): las últimas repeticiones de una serie se contaron mientras se acercaba caminando a la cámara (dejando de estar de perfil), y no quiere que eso cuente. Cifra de partida sin contrastar todavía con un giro real medido en cámara -- pendiente de calibrar.
const HIPFORWARDBACK_PROFILE_CONFIRM_MS = 250; // el giro hacia la cámara (por encima de HIPFORWARDBACK_PROFILE_MAX_HIP_WIDTH_FACTOR) tiene que sostenerse esto seguido antes de actuar -- filtra un pico de un fotograma suelto por ruido de tracking, no un giro de verdad (mismo espíritu que HIPFORWARDBACK_DIRECTION_STABLE_MS, algo más largo porque aquí conviene más margen antes de invalidar una repetición o desarmar)

// ARMSCISSORS_*: tijeras de brazos -- de pie, de frente a la cámara,
// calentamiento/estiramiento dinámico: los dos brazos se extienden en
// cruz (a los lados, como una T) y luego se cruzan por delante del
// pecho, volviendo después a extendidos; un vaivén completo (extendidos
// -> cruzados -> extendidos) cuenta como una repetición (ver
// processArmScissors). Mismo espíritu de vaivén centro/lado que
// NECKLATERAL_*, pero aquí el "centro" es brazos extendidos y el "lado"
// es brazos cruzados; el cruce se mide con la misma fracción relativa
// al ancho de hombros que checkArmCrossStretch (STRETCH_CROSS_MIN_FRACTION),
// por ser aspect-ratio-independiente. Pedido con un vídeo de referencia
// (WhatsApp, 2026-09-06). Primera versión, pendiente de calibrar con un
// test en cámara real, mismo patrón que el resto de la familia.
const ARMSCISSORS_MIN_VISIBILITY = 0.4; // visibilidad media de hombros+muñecas exigida para fiarse del frame
const ARMSCISSORS_MIN_REACH_FACTOR = 0.6; // muñeca a al menos esto de veces el ancho de hombros de su propio hombro para considerar el brazo "extendido" (estado centro) -- más exigente que ARMCIRCLES_MIN_REACH_FACTOR (0.45) porque aquí no hay giro continuo que perdone un brazo algo doblado, se compara solo en el instante de reposo
const ARMSCISSORS_CENTER_STABLE_MS = 400; // brazos extendidos sostenido esto antes de armar (mismo espíritu que ARMCIRCLES_ARM_STABLE_MS)
const ARMSCISSORS_CROSS_MIN_FRACTION = 0.4; // cada muñeca tiene que haber recorrido, en horizontal, al menos esta fracción de la distancia hasta el hombro contrario para considerar los brazos "cruzados" -- umbral más bajo que STRETCH_CROSS_MIN_FRACTION (0.5) porque aquí basta con cruzar el centro del pecho, no llegar hasta el hombro contrario como en el estiramiento sostenido
const ARMSCISSORS_CROSS_STABLE_MS = 100; // el cruce tiene que sostenerse esto seguido antes de confirmarse -- filtra un pico de un frame suelto, no un cruce de verdad (mismo espíritu que NECKLATERAL_SIDE_STABLE_MS)
const ARMSCISSORS_CROSS_EXIT_FRACTION = 0.15; // para cerrar el vaivén hace falta que la fracción de cruce de las dos muñecas baje de esto (histéresis) -- NO se mide con reach: primera prueba real (2026-09-06) mostró que reach apenas cambia entre brazos extendidos y cruzados a la altura del pecho, así que el cierre saltaba en el frame siguiente al cruce y la repetición nunca llegaba a MIN_REP_SECONDS
const ARMSCISSORS_MIN_REP_SECONDS = 0.15; // un vaivén completo por debajo de esto es ruido, no un cruce de verdad -- bajado de 0.25 (mismo valor que NECKLATERAL_MIN_REP_SECONDS), un cruce rápido real puede ser breve
const ARMSCISSORS_STILL_MS = 3000; // sin completar ningún vaivén durante esto: se interpreta que has terminado y se cierra la serie sola (mismo patrón que NECKLATERAL_STILL_MS/ARMCIRCLES_STILL_MS)
const ARMSCISSORS_OUT_OF_FRAME_MS = 3000; // igual que ARMCIRCLES_OUT_OF_FRAME_MS: cruzando los brazos rápido también baja la confianza de MediaPipe por motion blur, no solo al salirte del encuadre

// ---------------------------------------------------------------------
// Rotación de piernas — DE FRENTE a la cámara, de pie, en equilibrio
// sobre una pierna: la otra rodilla se levanta y traza un giro parcial
// alrededor de la cadera (de delante hacia el lado, o al revés), antes
// de volver a bajar el pie al suelo. Un giro cuenta como una
// repetición en cuanto la pierna levantada acumula suficiente rotación
// alrededor de su propia cadera (ver LEGROTATION_MIN_ROTATION_DEG) --
// SIN exigir una vuelta completa de 360° como en círculos de brazos
// (aquí es anatómicamente imposible, la cadera no gira tanto de pie) y
// sin importar el sentido del giro (pedido explícitamente: "no seas
// muy estricto con el umbral").
//
// Pedido por el usuario con dos vídeos de referencia (WhatsApp,
// 2026-09-06): de pie, brazos en cruz para el equilibrio, se levanta
// una rodilla y se rota la cadera (la rodilla dibuja un arco desde
// delante hacia el lado) antes de volver a apoyar el pie.
//
// Dos puntos pedidos explícitamente, y los dos son justo lo contrario
// del patrón habitual del resto de la familia (armcrossstretch et al,
// donde volver a la postura de reposo SÍ resetea/exige reconfirmar):
//   1. "si el usuario toca el suelo entre reps no pasa nada" -- aquí
//      apoyar el pie entre repeticiones NO es un fallo ni un reseteo a
//      "esperando postura", es justo el punto normal de cierre de cada
//      repetición (mismo espíritu que una sentadilla volviendo a estar
//      de pie entre reps): el momento en que la pierna vuelve a bajar
//      del todo es cuando se decide si lo girado cuenta como
//      repetición, y se vuelve a esperar la siguiente subida sin pedir
//      nada más.
//   2. "si pasa mas de 5 segundos entre reps sin hacer nada que cuente
//      como nueva serie" -- igual que ARMCIRCLES_STILL_MS/
//      NECKLATERAL_STILL_MS/ARMSCISSORS_STILL_MS, pero con el valor
//      concreto pedido (5000ms en vez de los 2500-4000ms del resto).
// ---------------------------------------------------------------------
const LEGROTATION_MIN_VISIBILITY = 0.4; // visibilidad media de caderas+rodillas+tobillos exigida para fiarse del frame (mismo umbral que el resto de la familia)
const LEGROTATION_STABLE_MS = 400; // de pie con las dos piernas apoyadas sostenido esto antes de armar el contador (mismo espíritu que ARMCIRCLES_ARM_STABLE_MS/ARMSCISSORS_CENTER_STABLE_MS)
const LEGROTATION_RAISE_ENTER_FRACTION = 0.6; // fracción cadera->rodilla (0 = rodilla a la altura de la cadera, 1 = pierna colgando recta) por debajo de la cual se considera que ESA pierna se ha levantado -- deliberadamente laxo ("no seas muy estricto con el umbral"), no hace falta levantar la rodilla hasta la cadera, solo despegarla claramente del reposo
const LEGROTATION_RAISE_EXIT_FRACTION = 0.85; // para dar la pierna por "vuelta a apoyar" hace falta que la fracción suba de esto -- histéresis por encima de LEGROTATION_RAISE_ENTER_FRACTION para que el ruido de tracking justo en el umbral no abra y cierre repeticiones fantasma
const LEGROTATION_REARM_STABLE_MS = 150; // Reportado en vivo (2026-09-18): en reps rapidas, al bajar el pie al suelo se contaban 2-3 repeticiones de mas -- log real confirmo que el rearme (mas abajo, raisedL/raisedR) no exigia ningun instante de apoyo de verdad: una lectura de tracking ruidosa que saltara directamente por debajo del umbral de subida, sin haber estado realmente apoyada, bastaba para rearmar y acumular un giro fantasma (visto en el log: "esperando subida" de un solo fotograma, ya con bajada_der negativa, justo tras cerrar la rep anterior). Se exige ahora este minimo con las dos piernas de verdad apoyadas (>= LEGROTATION_RAISE_EXIT_FRACTION, no solo por debajo del umbral de subida) antes de dejar rearmar -- deliberadamente corto para no bloquear reps rapidas reales, el pie siempre toca el suelo un instante por rapido que vayas.
const LEGROTATION_MIN_ROTATION_DEG = 40; // grados de rotación acumulada (en cualquier sentido) de la rodilla alrededor de su cadera, durante UNA subida, para que cuente como el "giro" pedido y no un simple levantar-y-bajar la pierna sin rotar -- laxo a propósito, pendiente de calibrar con un test en cámara real como el resto de la familia
const LEGROTATION_MIN_ANGULAR_DELTA = 0.02; // radianes por frame por debajo de esto se consideran ruido de tracking, no giro de verdad (mismo umbral que ARMCIRCLES_MIN_ANGULAR_DELTA)
const LEGROTATION_MAX_SINGLE_LEG_DELTA = 2.4; // radianes (~137°) por frame: un salto puntual mayor que esto se descarta como fallo de tracking, no rotación real (mismo valor y motivo que ARMCIRCLES_MAX_SINGLE_ARM_DELTA)
const LEGROTATION_MIN_REP_SECONDS = 0.3; // una subida+giro por debajo de esto es ruido, no una repetición de verdad
const LEGROTATION_STILL_MS = 5000; // sin empezar ninguna subida nueva ni completar ninguna repetición durante esto: se interpreta que has terminado y se cierra la serie sola (mismo patrón que ARMCIRCLES_STILL_MS/NECKLATERAL_STILL_MS/ARMSCISSORS_STILL_MS) -- valor pedido explícitamente por el usuario
const LEGROTATION_OUT_OF_FRAME_MS = 3000; // mismo motivo que ARMCIRCLES_OUT_OF_FRAME_MS: girando la pierna de verdad también baja la confianza de MediaPipe por motion blur, no solo al salirte del encuadre
const LEGROTATION_VISIBLE_CONFIRM_MS = 500; // reportado en vivo: el aviso de "a la vista" saltaba con un solo frame suelto que superaba LEGROTATION_MIN_VISIBILITY (p.ej. mientras el modelo aún calentaba justo tras cargar) y un instante después volvía "sin detección" del todo -- exige mantenerse por encima del umbral este rato seguido antes de anunciarlo, para no decir que se ve algo que en realidad no se ve
const LEGROTATION_MAX_HIP_DRIFT_FACTOR = 1.4; // reportado en vivo: "estaba yendo de camino a la silla y la ha contado" -- caminar también levanta la rodilla y puede acumular ángulo de sobra en el vector cadera->rodilla, así que la geometría del giro sola no basta para distinguirlo de una rotación de verdad en el sitio. Se compara el punto medio de las dos caderas al empezar la subida con el de al bajarla, normalizado por el ancho de cadera (para no depender de la distancia a la cámara) -- por encima de esta fracción se interpreta que el cuerpo entero se ha desplazado (caminando varios pasos), no que la pierna ha girado en el sitio, y la repetición NO cuenta aunque el giro acumulado supere LEGROTATION_MIN_ROTATION_DEG. SUBIDO de 0.4 a 1.4 tras reportarse en vivo que 0.4 rechazaba repeticiones genuinas -- el balanceo normal de equilibrio a la pata coja ya desplaza la cadera esa fracción por sí solo, así que hacía falta mucho más margen antes de asumir que el usuario caminó. Sigue siendo una cifra pendiente de calibrar con más pruebas en cámara real

// ---------------------------------------------------------------------
// Rodillas altas (marcha con rodillas altas) -- DE PERFIL a la cámara,
// de pie, marchando en el sitio: se alterna levantar una rodilla y
// volver a apoyar el pie, sin pausa entre piernas. Pedido por el
// usuario con un vídeo de referencia (WhatsApp, 2026-09-07).
//
// Cuatro puntos pedidos explícitamente:
//   1. De perfil, con la cadera, la rodilla y el tobillo bien visibles
//      (igual que sentadillas) -- no de frente, como rotación de
//      piernas.
//   2. Mensajes al mínimo -- un solo aviso hablado al empezar (igual
//      que sentadillas), no dos (visibilidad + armado por separado)
//      como rotación de piernas o jumping jacks.
//   3. Umbral de ángulo relajado, por si no se llega muy alto con la
//      rodilla -- KNEERAISE_RAISE_ENTER_FRACTION más laxo todavía que
//      LEGROTATION_RAISE_ENTER_FRACTION (0.75 vs 0.6: hace falta menos
//      recorrido de la rodilla para que cuente como "levantada").
//   4. Que el contador aguante el ritmo real (marcha rápida, casi sin
//      pausa entre piernas) sin saltarse ninguna repetición -- por eso
//      esta versión NO seguye ningún giro ni comprueba desplazamiento
//      de cadera como rotación de piernas (mismo tipo de geometría
//      cadera->rodilla, pero pensada para un movimiento lento y
//      controlado): cuanto menos cálculo haga falta por fotograma,
//      menos margen para que un fotograma real de la subida se quede
//      sin mirar. Y MIN_REP_SECONDS bajo (0.12s, igual que jumping
//      jacks) para no descartar como "ruido" una subida y bajada
//      rápidas de verdad -- ver la nota junto a
//      JUMPINGJACK_MIN_REP_SECONDS sobre el mismo problema, ya
//      reportado ahí con otro ejercicio rápido.
//
// Igual que rotación de piernas: apoyar el pie entre repeticiones NO es
// un fallo, es el cierre normal de cada subida (no hay postura de
// reposo que reconfirmar entre repeticiones).
// ---------------------------------------------------------------------
// 2026-09-19: rodillas altas pasa a hacerse DE FRENTE. Se compara la altura de cada rodilla+tobillo con la de la OTRA pierna
// (la que sube se ve por encima de la que se queda apoyada), normalizado por la longitud de pierna: sin calibrar
// distancias, una pierna cada vez, y vale a cualquier velocidad porque solo mira 'cual va mas alta'.
const KNEERAISE_LIFT_FULL = 0.45; // diferencia de altura (fraccion de longitud de pierna) que equivale a rodilla a la altura de la cadera -> bajada=0
const KNEERAISE_ARM_MAX_DIFF = 0.09; // al armar se aprende el desnivel de reposo (camara torcida) mientras la diferencia entre piernas sea menor que esto
const KNEERAISE_MIN_VISIBILITY = 0.4; // visibilidad media de caderas+rodillas+tobillos exigida para fiarse del frame (mismo umbral que el resto de la familia)
const KNEERAISE_STABLE_MS = 600; /* 2026-09-19 frontpos-v1: 400->600, ademas de la ventana FRONTPOS_SETTLED_MS */ // de pie con las dos piernas apoyadas sostenido esto antes de armar el contador, para no contar media repetición si entras en encuadre a media zancada (mismo espíritu que LEGROTATION_STABLE_MS)
const KNEERAISE_RAISE_ENTER_FRACTION = 0.75; // fracción cadera->rodilla (0 = rodilla a la altura de la cadera, 1 = pierna colgando recta) por debajo de la cual se considera que ESA pierna se ha levantado -- deliberadamente MÁS laxo que LEGROTATION_RAISE_ENTER_FRACTION (0.6): pedido explícitamente "que el umbral sea relajado en caso que no lleguen tan alto", así que basta con un recorrido de rodilla moderado, no hace falta acercarse a la horizontal
const KNEERAISE_RAISE_EXIT_FRACTION = 0.90; // para dar la pierna por "vuelta a apoyar" hace falta que la fracción suba de esto -- histéresis por encima de KNEERAISE_RAISE_ENTER_FRACTION para que el ruido de tracking justo en el umbral no abra y cierre repeticiones fantasma; hueco más corto que en rotación de piernas para confirmar la bajada antes y no retrasar la siguiente subida en un ritmo rápido
const KNEERAISE_REARM_EXIT_FRACTION = 0.80; // AÑADIDO 2026-09-17 tras un registro real: solo para cerrar una repetición ya armada (ritmo rápido en marcha), no para el armado inicial de pie -- ver el porqué junto a KNEERAISE_RAISE_EXIT_FRACTION
const KNEERAISE_MIN_REP_SECONDS = 0.12; // una subida+bajada por debajo de esto es ruido, no una repetición de verdad -- bajo a propósito (igual que JUMPINGJACK_MIN_REP_SECONDS) para no descartar reps reales rápidas en marcha a buen ritmo
const KNEERAISE_STILL_MS = 2000; // sin empezar ninguna subida nueva ni completar ninguna repetición durante esto: se interpreta que has terminado y se cierra la serie sola -- más corto que LEGROTATION_STILL_MS (5000ms, pensado para recuperar el equilibrio a la pata coja): este ejercicio es marcha continua rápida, no hace falta tanto margen para decidir que has parado
const KNEERAISE_OUT_OF_FRAME_MS = 3000; // mismo motivo que LEGROTATION_OUT_OF_FRAME_MS/JUMPINGJACK_OUT_OF_FRAME_MS: marchando de verdad la confianza de MediaPipe también baja por el propio movimiento (motion blur), no solo al salirte del encuadre
const KNEERAISE_VISIBLE_CONFIRM_MS = 500; // mismo motivo que LEGROTATION_VISIBLE_CONFIRM_MS: exige mantenerse por encima de KNEERAISE_MIN_VISIBILITY este rato seguido antes de anunciar "a la vista", para no decir que se ve algo que en realidad no se veía con un solo frame suelto

// ---------------------------------------------------------------------
// ---------------------------------------------------------------------
// Talones al gluteo (butt kicks) -- DE PERFIL a la camara, de pie,
// marchando en el sitio: se alterna llevar el talon hacia el gluteo
// (la rodilla se dobla mucho, el muslo se queda casi vertical) y volver
// a apoyar el pie, sin pausa entre piernas. Pedido por el usuario con
// un video de referencia (WhatsApp, subido 2026-09-07) para anadir al
// calentamiento.
//
// Cuatro puntos pedidos explicitamente (mismo formato que rodillas
// altas, el ejercicio hermano mas parecido de la familia):
//   1. De perfil, con la cadera, la rodilla y el tobillo bien visibles.
//   2. Mensajes al minimo -- un solo aviso hablado al empezar, igual
//      que rodillas altas/sentadillas, no separado en visibilidad +
//      armado.
//   3. Umbral relajado, por si no se llega muy alto con el talon -- ver
//      HEELKICK_KNEE_ANGLE_ENTER_DEG mas abajo.
//   4. Que el contador aguante el ritmo real (marcha rapida, casi sin
//      pausa entre piernas) sin saltarse ninguna repeticion -- mismo
//      motivo que rodillas altas: nada de rotacion, el minimo calculo
//      posible por fotograma, y MIN_REP_SECONDS bajo para no descartar
//      como "ruido" una subida y bajada rapidas de verdad.
//
// Geometria: angulo cadera-rodilla-tobillo, usando la funcion angle()
// ya existente en este archivo (la misma que usan las sentadillas,
// documentada alli como fiable de perfil porque solo usa x/y). Pierna
// estirada de pie ~= 180 grados; al doblar la rodilla y acercar el
// talon al gluteo el angulo baja. v1-v4 usaban en su lugar una fraccion
// de distancia cadera->tobillo (self-relativa, sin necesitar
// calibracion) que funcionaba para contar, pero su intento de v4 de
// distinguir "patear en el sitio" de "caminar" (comparando las DOS
// caderas, igual que legrotation) resulto ROTO en este ejercicio: de
// perfil, las dos caderas caen casi en el mismo punto de la pantalla,
// asi que esa comparacion se disparaba con cualquier ruido minimo y
// rechazaba casi todas las repeticiones reales (ver el historial en
// memoria). El angulo de una sola pierna evita ese problema de raiz
// (no compara las dos caderas entre si) y fue ademas sugerido
// directamente por el usuario tras el fallo.
// ---------------------------------------------------------------------
// 2026-09-19: talones al gluteo pasa a hacerse DE FRENTE. Las constantes HEELKICK_KNEE_ANGLE_* de arriba YA NO SE USAN
// (eran del angulo 2D de perfil). Ahora: el talon que sube se ve como el TOBILLO que sube respecto al otro tobillo
// (normalizado por la longitud de pierna, sin calibrar nada) O como el tobillo que DESAPARECE (visibilidad baja) al ir
// hacia atras, detras de la pierna. El debug del 📋 dice cual de las dos ha disparado.
const HEELKICK_LIFT_ENTER = 0.15; // tobillo vigilado al menos esta fraccion de la longitud de pierna POR ENCIMA del otro tobillo => talon arriba
const HEELKICK_LIFT_EXIT = 0.07; // por debajo de esto => vuelve a estar apoyado (histeresis)
const HEELKICK_ANKLE_SEEN_VIS = 0.6; // visibilidad a partir de la cual un tobillo/rodilla se considera bien visto
const HEELKICK_ANKLE_HIDDEN_VIS = 0.5; // por debajo de esto (con la rodilla bien vista y el tobillo visto hace poco) se considera que el pie ha desaparecido por detras
const HEELKICK_HIDDEN_MAX_MS = 1000; // el 'desaparecido' solo vale si el tobillo se vio bien en el ultimo segundo (si no, es que el pie esta fuera de encuadre, no que patee)
const HEELKICK_LIFT_HIDDEN_VALUE = 0.25; // valor de 'subida' que se asigna mientras el tobillo esta oculto
const HEELKICK_MIN_VISIBILITY = 0.4; // visibilidad media de caderas+rodillas+tobillos exigida para fiarse del frame (mismo umbral que el resto de la familia)
const HEELKICK_MAX_HIP_DRIFT_FACTOR = 0.4; // 2026-09-19: subido de 0.25 a 0.4 al pasar a vista de frente (el peso se balancea de lado a lado). Sin datos reales todavia. Texto original: // desplazamiento del punto medio de caderas durante una subida, respecto a la longitud de la pierna QUE SE QUEDA apoyada (no la que patea), por encima del cual la repeticion se descarta por "te has desplazado" (caminar) en vez de patear en el sitio. Bajado de 0.5 a 0.25 en v7 tras un registro en vivo: las 13 repeticiones limpias de una serie marchando en el sitio dieron deriva 0.02-0.15, mientras que las sospechosas de arrastrar caminar (justo tras reposicionarte, ver el hueco de deteccion antes de HEELKICK_VISIBLE_CONFIRM_MS mas abajo) dieron 0.32-1.71 -- separacion clara, 0.25 deja margen a ambos lados sin necesitar mas datos todavia.
const HEELKICK_KNEE_ANGLE_ENTER_DEG = 90; // angulo cadera-rodilla-tobillo por DEBAJO del cual se considera que ESA pierna ha llevado el talon hacia el gluteo -- pedido directamente por el usuario ("que sea minimo 90 grados") tras el fallo de la v4; deliberadamente relajado, en linea con "que el umbral sea relajado en caso que no lleguen tan alto": no hace falta doblar la rodilla del todo
const HEELKICK_KNEE_ANGLE_EXIT_DEG = 160; // para dar la pierna por "vuelta a apoyar" (estirada de nuevo) hace falta que el angulo suba de esto -- histeresis por encima de HEELKICK_KNEE_ANGLE_ENTER_DEG para que el ruido de tracking justo en el umbral no abra y cierre repeticiones fantasma; mismo valor que SQUAT_UP_ANGLE_DEG para "de pie"
const HEELKICK_MIN_REP_SECONDS = 0.12; // una subida+bajada por debajo de esto es ruido, no una repeticion de verdad -- bajo a proposito (igual que KNEERAISE_MIN_REP_SECONDS/JUMPINGJACK_MIN_REP_SECONDS) para no descartar reps reales rapidas en marcha a buen ritmo
const HEELKICK_STILL_MS = 2000; // sin empezar ninguna subida nueva ni completar ninguna repeticion durante esto: se interpreta que has terminado y se cierra la serie sola -- mismo valor que rodillas altas, marcha continua rapida, no hace falta mas margen
const HEELKICK_OUT_OF_FRAME_MS = 3000; // mismo motivo que KNEERAISE_OUT_OF_FRAME_MS: marchando de verdad la confianza de MediaPipe tambien baja por el propio movimiento (motion blur), no solo al salirte del encuadre
const HEELKICK_VISIBLE_CONFIRM_MS = 500; // mismo motivo que KNEERAISE_VISIBLE_CONFIRM_MS/LEGROTATION_VISIBLE_CONFIRM_MS: exige mantenerse por encima de HEELKICK_MIN_VISIBILITY este rato seguido antes de anunciar "a la vista", para no decir que se ve algo que en realidad no se veia con un solo frame suelto
const HEELKICK_MAX_ANGLE_DELTA = 90; // avance maximo (en grados del angulo cadera-rodilla-tobillo) permitido POR FOTOGRAMA -- ratchet, no filtro de "congelar": la referencia SIEMPRE avanza hacia el dato crudo, como maximo esta cantidad por fotograma, en vez de quedarse fija en el ultimo valor bueno (mismo mecanismo que HEELKICK_MAX_FRAME_DELTA usaba en v3 para la fraccion de distancia -- ver el historial en memoria sobre por que un filtro de "congelar" bloqueaba repeticiones reales y rapidas en este ejercicio explosivo). Cifra pendiente de calibrar con mas pruebas en camara real.
const HEELKICK_ANGLE_SMOOTHING_ALPHA = 0.5; // media movil exponencial aplicada DESPUES del ratchet de arriba, una pierna a la vez -- misma tecnica que SCISSOR_SMOOTHING_ALPHA en tijeretas, para la pierna que la camara ve peor. De perfil, la pierna MAS LEJANA a la camara queda parcialmente tapada por el torso durante todo el ejercicio (no solo a veces), asi que MediaPipe le da una confianza mas baja y su angulo tiembla bastante mas que el de la pierna cercana aunque el ratchet ya recorte los saltos imposibles -- eso es lo que produce repeticiones fantasma sin haber hecho el movimiento y la sensacion de que "solo cuenta la pierna que se ve mejor". Alpha mas alto que el 0.3 de tijeretas (que es un ejercicio mucho mas lento) para no introducir demasiado retraso en un ejercicio explosivo. Cifra de partida sin calibrar con datos reales todavia.

// 2026-09-19 (frontpos-v1) -- COMPUERTA DE POSICION comun a rodillas altas y talones al gluteo (los dos ahora DE FRENTE).
// Motivo (logs reales 2026-09-19): (a) al caminar hacia la camara / ir a pulsar el boton entraban repeticiones falsas
// (primera rep de la serie 1 y las 2 ultimas de cada serie, con desniveles de +-2.0 imposibles en las rodillas);
// (b) talones al gluteo daba por 'levantado' un tobillo 'oculto' (visibilidad baja) aunque solo se viera la cara.
// Ahora NADA se arma ni se cuenta si no se te ve el cuerpo entero (hombros, caderas, rodillas y pies) DENTRO del encuadre,
// erguido y de frente, y ademas EN TU SITIO (sin caminar ni acercarte/alejarte de la camara).
const FRONTPOS_MIN_VIS = 0.5; // visibilidad minima de CADA punto exigido (hombros, caderas, rodillas y pies)
const FRONTPOS_EDGE_MARGIN = 0.02; // un punto a menos de esta fraccion del borde del encuadre se considera cortado
const FRONTPOS_MIN_TORSO_H = 0.07; // altura hombros->caderas (fraccion del alto del encuadre) minima: por debajo estas demasiado lejos
const FRONTPOS_MIN_SHOULDER_W = 0.10; // ancho de hombros minimo (fraccion del ancho): por debajo estas de lado o demasiado lejos
const FRONTPOS_MIN_THIGH_H = 0.06; // altura caderas->rodillas minima: por debajo no estas erguido
const FRONTPOS_WINDOW_MS = 900; // ventana sobre la que se mide 'te estas moviendo de sitio'
const FRONTPOS_SETTLED_MS = 650; // la ventana debe cubrir al menos esto de datos limpios para fiarse (evita armar justo al aparecer en encuadre)
const FRONTPOS_MAX_SWAY_X = 0.45; // recorrido horizontal del punto medio de caderas en la ventana, en anchos de hombros (marchar en el sitio da ~0.1-0.2)
const FRONTPOS_MAX_SWAY_Y = 0.35; // idem vertical (acercarte/alejarte o agacharte)
const FRONTPOS_MAX_SCALE_CHANGE = 0.14; // cambio relativo del ancho de hombros en la ventana (acercarte/alejarte de la camara)
const FRONTPOS_LOST_MS = 350; // fuera de posicion seguido esto => se descarta la subida en curso y se avisa (un parpadeo de 1-2 frames no)
const KNEERAISE_MAX_UP_SECONDS = 2; // una rodilla 'levantada' mas de esto no es marchar (es un paso o un equilibrio): se descarta sin contar
const HEELKICK_ARM_STEADY_MS = 400; // en su sitio, entero y de frente, sostenido esto (ademas de la ventana de FRONTPOS_SETTLED_MS) antes de armar
const HEELKICK_ARM_MAX_DIFF = 0.09; // mientras no esta armado se aprende el desnivel de reposo de los tobillos (camara/suelo torcidos) si la diferencia es menor que esto
const HEELKICK_MAX_UP_SECONDS = 1.5; // un talon 'arriba' mas de esto no es un talon al gluteo de marcha (es un paso, o estirar el cuadriceps): se descarta
const HEELKICK_HIDDEN_ONLY_MIN_SECONDS = 0.2; // subida sostenida SOLO por 'tobillo oculto' (sin desnivel real) debe durar al menos esto para contar


// ---------------------------------------------------------------------
// Rotacion de brazo sujetando el codo -- de pie, de frente a la
// camara: una mano agarra el codo del otro brazo (por delante, cerca
// del cuerpo) y ese otro brazo empieza a girar en circulos alrededor
// del codo (el antebrazo traza la circunferencia, el codo se queda
// mas o menos fijo, sujeto por la otra mano). Pedido por el usuario
// con dos videos de referencia (WhatsApp, grabados 2026-09-04): uno
// ensena un brazo, el otro el contrario -- mismo ejercicio, mano
// espejada, asi que un solo contador vale para los dos brazos sin
// duplicar nada (pedido explicitamente: "que sirva para las dos
// manos asi nos ahorramos hacer 2 ejercicios").
//
// "Es muy facil" (palabras del usuario): sin postura de reposo previa
// que confirmar, sin angulo de codo que exigir -- basta con que la
// otra mano este agarrando el codo del brazo que gira. Se comprueban
// los dos lados posibles (izquierdo gira/derecho agarra, o al reves)
// y vale cualquiera de los dos, igual que checkArmCrossStretch en su
// dia; a diferencia de ese estiramiento (isometrico, un aguante
// cuenta como serie), aqui se cuenta por repeticiones -- cada vuelta
// completa (360 grados) del antebrazo alrededor del codo, en
// cualquier sentido, sin bloqueo de sentido (mismo mecanismo que
// circulos de cuello: wrapAngleDelta acumulado sobre el vector
// codo->muneca, ver processForearmRotation). Se puede cambiar de
// brazo en cualquier momento sin cerrar la serie (mismo espiritu que
// rotacion de piernas, avisando por voz solo cuando el lado cambia de
// verdad).
//
// Primera version, umbrales sin probar en camara real todavia --
// pendiente de calibrar con un test real, mismo patron que el resto
// de la familia.
// ---------------------------------------------------------------------
const FOREARMROTATION_MIN_VISIBILITY = 0.4; // visibilidad media de hombros+codos+munecas exigida para fiarse del frame (mismo umbral que el resto de la familia)
const FOREARMROTATION_GRAB_MAX_FACTOR = 1.6; // muneca de la mano que agarra, a lo sumo esto de veces el ancho de hombros de distancia del codo del brazo que gira -- umbral amplio, primer valor sin calibrar (a medio camino entre STRETCH_GRAB_MAX_FACTOR=2.4, pensado para codo-a-codo del estiramiento cruzado, y el umbral bastante mas estricto de isquiotibiales sentado=0.8, muneca-a-tobillo)
const FOREARMROTATION_MIN_REACH_FACTOR = 0.25; // la muneca del brazo que gira tiene que estar al menos esto de veces el ancho de hombros lejos de SU PROPIO codo para fiarse del angulo (evita acumular ruido con el antebrazo pegado al codo, radio casi cero) -- mas bajo que ARMCIRCLES_MIN_REACH_FACTOR (0.45) porque aqui el "radio" es el antebrazo, mas corto que el brazo entero extendido
const FOREARMROTATION_STABLE_MS = 400; // agarre sostenido esto antes de armar el contador (mismo espiritu que ARMCIRCLES_ARM_STABLE_MS/ARMSCISSORS_CENTER_STABLE_MS)
const FOREARMROTATION_GRAB_BREAK_MS = 800; // el agarre tiene que fallar seguido esto (no un solo fotograma suelto de ruido de tracking) antes de darlo por soltado de verdad -- mismo motivo que el resto de la familia con sus propios *_STABLE_MS de histeresis
const FOREARMROTATION_MIN_ANGULAR_DELTA = 0.02; // radianes por fotograma por debajo de esto se consideran ruido de tracking, no giro de verdad (mismo umbral que ARMCIRCLES_MIN_ANGULAR_DELTA/NECKCIRCLE_MIN_ANGULAR_DELTA)
const FOREARMROTATION_MAX_SINGLE_FRAME_DELTA = 2.4; // radianes (~137 grados) por fotograma: un salto puntual mayor que esto se descarta como fallo de tracking, no giro real (mismo valor que ARMCIRCLES_MAX_SINGLE_ARM_DELTA/LEGROTATION_MAX_SINGLE_LEG_DELTA/NECKCIRCLE_MAX_SINGLE_FRAME_DELTA)
const FOREARMROTATION_MIN_REP_SECONDS = 0.4; // una vuelta completa por debajo de esto es un salto de angulo mal calculado (ruido), no un circulo de verdad hecho a mano
const FOREARMROTATION_STILL_MS = 3000; // sin agarre valido en ningun brazo ni giro de verdad durante esto: se interpreta que has terminado y se cierra la serie sola (mismo patron que ARMSCISSORS_STILL_MS/ARMCIRCLES_STILL_MS)
const FOREARMROTATION_OUT_OF_FRAME_MS = 3000; // mismo motivo que ARMCIRCLES_OUT_OF_FRAME_MS: girando de verdad el antebrazo tambien baja la confianza de MediaPipe por motion blur, no solo al salirte del encuadre

// WRISTROTATION_*: rotación de muñecas con los dedos entrelazados -- de
// pie o sentada/o, de frente a la cámara: manos juntas, dedos
// entrelazados como al rezar, delante del pecho/barbilla, y las dos
// muñecas giran juntas dibujando un círculo (el conjunto de manos se
// desplaza en círculo -- eso es justo lo que se ve, y lo que se puede
// medir, con landmarks de pose; no hay landmarks de dedos individuales
// en este modelo). Pedido con un vídeo de referencia (WhatsApp, grabado
// 2026-09-04, subido 2026-09-08).
//
// Mismo mecanismo que círculos de cuello/brazos (wrapAngleDelta sobre
// el ángulo de un vector, acumulando el delta de cada fotograma hasta
// llegar a ±2π = una repetición), aquí sobre el vector
// punto-medio-de-hombros->punto-medio-de-muñecas, sin bloqueo de
// sentido (cualquiera de los dos sentidos cuenta, mismo espíritu que
// NECKCIRCLE_*/FOREARMROTATION_*). Esto es precisamente lo que
// distingue "dar vueltas" de "ir de un lado a otro" que pidió el
// usuario explícitamente: un vaivén de lado a lado nunca completa una
// vuelta entera -- el ángulo avanza y luego retrocede sobre el mismo
// arco, así que el acumulado con signo nunca llega a 2π y no cuenta
// nada, mientras que un círculo de verdad sí lo completa. No hace
// falta ninguna lógica aparte para diferenciarlos, es la misma
// protección ya probada en círculos de cuello/brazos/rotación de
// piernas.
//
// Manos juntas: al contrario que círculos de cuello (que no tiene nada
// que "agarrar"), aquí SÍ hay una postura que mantener durante todo el
// giro -- las dos muñecas cerca la una de la otra (proxy de dedos
// entrelazados, que un modelo de pose no ve). Se comprueba igual que
// el agarre de FOREARMROTATION_* (con su misma histéresis de soltado,
// WRISTROTATION_TOGETHER_BREAK_MS) en vez de exigirlo con un
// posturechecker aislado, porque aquí se cuenta por repeticiones
// (mode="pose"), no por aguante (mode="timed").
//
// Sobre landmarks 3D (world landmarks) de MediaPipe: el modelo de pose
// que usa este proyecto (PoseLandmarker, ver poseLandmarker.detectForVideo)
// sí los expone (result.worldLandmarks), pero NINGÚN ejercicio de esta
// familia los usa todavía -- todos calculan ángulos sobre los landmarks
// normalizados de imagen (x,y en 2D), incluida esta primera versión.
// En el vídeo de referencia (manos delante del pecho, giro casi de cara
// a la cámara) el círculo en 2D ya se ve completo y limpio, así que se
// empieza igual que el resto de la familia: primera versión sencilla en
// 2D, pendiente de calibrar con un test real. Si un test real muestra
// que el plano del círculo no es lo bastante frontal (el círculo se
// aplana en pantalla y se confunde con un vaivén), ahí sí merecería la
// pena pasar a world landmarks para un ángulo fiable pase lo que pase
// la orientación de la cámara -- de momento, sin probar en cámara real,
// sería una complicación sin base.
const WRISTROTATION_MIN_VISIBILITY = 0.4; // visibilidad media de hombros+muñecas exigida para fiarse del frame (mismo umbral que el resto de la familia)
const WRISTROTATION_TOGETHER_MAX_FACTOR = 0.35; // distancia muñeca-muñeca, a lo sumo esto de veces el ancho de hombros, para considerar las manos "juntas" -- primer valor sin calibrar, pendiente de test real
const WRISTROTATION_TOGETHER_STABLE_MS = 400; // manos juntas sostenido esto antes de armar el contador (mismo espíritu que ARMCIRCLES_ARM_STABLE_MS/FOREARMROTATION_STABLE_MS)
const WRISTROTATION_TOGETHER_BREAK_MS = 800; // las manos tienen que separarse seguido esto (no un solo fotograma suelto de ruido) antes de darlo por soltado de verdad (mismo valor y motivo que FOREARMROTATION_GRAB_BREAK_MS)
// v2 (primer test en cámara real, 2026-09-08): el ángulo acumulado NUNCA
// se acercaba a 360° pese a que el usuario giraba las manos de verdad sin
// parar -- se quedaba oscilando en una banda de ~30° (p.ej. 130°-160°) y
// terminaba cerrándose por WRISTROTATION_STILL_MS sin contar ni una sola
// repetición. Causa: a diferencia de círculos de cuello (donde la nariz SÍ
// gira alrededor del eje real cuello-hombro) o círculos de brazos (donde
// la muñeca SÍ gira alrededor del hombro real), aquí las manos juntas NO
// giran alrededor de ningún punto anatómico -- dibujan un círculo pequeño
// y propio delante del pecho, con centro en el aire. Anclar el ángulo al
// punto medio de hombros (muy alejado de ese círculo real) hace que el
// vector barra solo un arco estrecho en vez de una vuelta completa, por
// pura geometría (igual que un compás con el pie clavado lejos del centro
// del círculo que quieres medir). Arreglo: en vez de un ancla fija, se
// estima el CENTRO del propio círculo con una media móvil exponencial
// (EMA) muy lenta de la posición de las manos, y se mide el ángulo de
// (mano - centro) en vez de (mano - hombro). Con una rotación real
// sostenida esto converge matemáticamente a seguir barriendo la vuelta
// completa a la misma velocidad angular que el giro real (filtro paso-alto
// de primer orden sobre una señal periódica: conserva la frecuencia,
// solo cambia fase/amplitud) -- y de propina seguimos rechazando por
// construcción cualquier "ir de un lado a otro": ese movimiento tampoco
// completa una vuelta alrededor de SU propio centro estimado.
const WRISTROTATION_CENTER_EMA_ALPHA = 0.06; // SUBIDO de 0.02 tras una prueba real (2026-09-17, Redmi A5): el 0.02 se pensó "a ~30fps, constante de tiempo de más de 1s" (ver más abajo), pero el [perf] de ese mismo registro confirma que este modelo/dispositivo va a ~10fps real -- a un tercio del fps asumido, la MISMA alpha por fotograma tarda 3 veces más en converger en tiempo real (~5s en vez de ~1.7s). El registro mostró el acumulado congelado en seco varios segundos seguidos (p.ej. 7.9s-9.3s sin ningún delta) mientras, según la nota del usuario, seguía girando las manos de verdad -- consistente con un radio mano-centro cayendo por debajo del umbral mientras el centro EMA, todavía lejos de asentarse, no seguía el círculo real. 0.06 (~3x) apunta a restaurar la misma constante de tiempo real (~1.7s) que se pretendía originalmente a 30fps. Pendiente de confirmar con un test real nuevo -- si sigue perdiendo giro, revisar también si esto mismo (alpha pensada a 30fps) afecta a otros suavizados de esta familia en este dispositivo.
// Fracción hacia la posición actual de las manos que se mezcla en el centro estimado CADA FOTOGRAMA -- deliberadamente lento para que el centro no persiga la propia mano (eso colapsaría el radio a ~0 y el ángulo a ruido puro) sino que se asiente en el centro real del círculo que estás dibujando.
const WRISTROTATION_MIN_RADIUS_FACTOR = 0.02; // el radio actual (distancia mano-centro_estimado) tiene que ser al menos esto de veces el ancho de hombros para fiarse del ángulo -- umbral bajo a propósito porque justo al armar (y en cualquier cambio real de dirección) el radio puede ser legítimamente pequeño mientras el centro EMA todavía se está asentando
const WRISTROTATION_MIN_ANGULAR_DELTA = 0.02; // radianes por fotograma por debajo de esto se consideran ruido de tracking, no giro de verdad (mismo umbral que el resto de la familia)
const WRISTROTATION_MAX_SINGLE_FRAME_DELTA = 2.4; // radianes (~137°) por fotograma: un salto puntual mayor que esto se descarta como fallo de tracking, no giro real (mismo valor que el resto de la familia)
const WRISTROTATION_STILL_MS = 2500; // sin progreso angular de verdad durante esto: se interpreta que has terminado y se cierra la serie sola (mismo valor que ARMCIRCLES_STILL_MS -- un giro de muñecas es rápido, como un brazo, no lento como un cuello)
const WRISTROTATION_OUT_OF_FRAME_MS = 3000; // mismo motivo que el resto de la familia: girando de verdad las muñecas también baja la confianza de MediaPipe por motion blur, no solo al salirte del encuadre
const WRISTROTATION_MIN_REP_SECONDS = 0.4; // una vuelta completa por debajo de esto es un salto de ángulo mal calculado (ruido), no un círculo de verdad hecho a mano (mismo valor que FOREARMROTATION_MIN_REP_SECONDS)

// Ángulo2 - ángulo1 normalizado a (-π, π] — necesario porque un ángulo
// que pasa de 179° a -179° en un frame ha girado solo 2°, no casi 360°
// (ver processArmCircles).
function wrapAngleDelta(rawDelta) {
  let d = rawDelta;
  while (d > Math.PI) d -= 2 * Math.PI;
  while (d < -Math.PI) d += 2 * Math.PI;
  return d;
}
// NOTA sobre un intento anterior descartado: hubo una version que daba a
// "brazos arriba/abajo" y "piernas abiertas/juntas" una ventana de
// tiempo (creerselos "recientes" un rato) para tolerar que brazos y
// piernas no lleguen a su extremo en el mismo frame exacto durante un
// salto rapido. Se quito: esa ventana podia dejar "piernas abiertas" Y
// "piernas juntas" contados como ciertos A LA VEZ (uno de hace un
// instante, otro del frame actual) sin que en NINGUN instante real lo
// fueran las dos -- eso hacia que el estado oscilara solo entre
// open/closed varias veces por segundo, reiniciando repStartTime en
// cada oscilacion y descartando la repeticion real siguiente por
// "demasiado rapida" (MIN_REP_SECONDS). Visto en el registro: reportado
// como "de 15 saltos solo cuenta 12". El diseno de abajo (piernas
// como unica senal de abrir/cerrar, brazos solo como "algun frame
// arriba durante esta apertura") evita el problema de raiz sin
// necesitar ninguna ventana de tiempo.

// ── Abdominales tumbado (crunch, elevación de piernas, abdominal
// completo) ──────────────────────────────────────────────────────────
// Los tres se hacen BOCA ARRIBA con la cámara A UN LADO (de perfil), no
// de frente — así se ve bien cuánto se levantan los hombros o las
// piernas del suelo. El aviso de colocación sale al empezar cada serie
// (ver beginPrep). Los tres arrancan en reposo ("tumbado") y cuentan
// una repetición por cada ciclo completo tumbado→arriba→tumbado, igual
// que dominadas o fondos.
//
// Los tres necesitan saber que el usuario está DE VERDAD tumbado en el
// suelo antes de armar el contador — si no, levantarte de la silla o
// ponerte en posición ya contaba como una repetición completa por sí
// solo (visto en pruebas reales). Se mide con la INCLINACIÓN de la
// línea hombro-cadera respecto a la HORIZONTAL: tumbado, esa línea es
// casi horizontal; de pie o sentado, casi vertical — funciona pase lo
// que pase con la rodilla o el cuello, que no entran en esta cuenta.
// Y, como al colgarte de la barra en dominadas, hace falta verte
// tumbado y QUIETO un rato (ON_GROUND_STABLE_MS) antes de armar, no
// solo un frame — así ponerte en el suelo no cuenta como repetición.
const ON_GROUND_MAX_TILT_DEG = 40;  // por encima de esto, no se considera "tumbado"
// Umbral MÁS ESTRICTO, solo para ARMAR (no para cerrar la serie, donde
// sigue valiendo ON_GROUND_MAX_TILT_DEG tal cual): agacharte o inclinarte
// para colocar el móvil en el suelo (de perfil, a ras de suelo) puede dar
// una inclinación de torso de 25-40° sostenida varios segundos mientras
// ajustas el encuadre — eso ya bastaba para armar el contador (viendo
// "tumbado" donde en realidad solo estabas agachada/o) y que el resto de
// la colocación (levantarte, volver a tumbarte del todo) contara como una
// repetición completa. Tumbado de verdad boca arriba da una inclinación
// mucho más cercana a 0°, así que un umbral más ajustado para armar sigue
// dejando margen de sobra sin colar una simple postura de "agachado
// colocando la cámara".
const ON_GROUND_ARM_MAX_TILT_DEG = 20;
const ON_GROUND_STABLE_MS = 600;    // cuanto tiempo tumbado y quieto para armar el contador
const OFF_GROUND_STABLE_MS = 400;   // cuanto tiempo "de pie" seguido para dar la serie por terminada

// Crunch: solo se levantan cabeza y hombros, la cadera casi no se
// dobla — por eso NO se mide un ángulo de cadera (apenas cambiaría),
// sino cuánto sube el HOMBRO por encima de la CADERA (que se queda
// quieta y sirve de referencia). En proporción al muslo (cadera-
// rodilla, que no se mueve en este ejercicio) para no depender de lo
// cerca que estés de la cámara.
const CRUNCH_UP_FACTOR = 0.15;   // hombro claramente por encima de la cadera -> arriba
const CRUNCH_DOWN_FACTOR = 0.05; // hombro casi a la altura de la cadera -> tumbado
const CRUNCH_MIN_VISIBILITY = 0.4;
const CRUNCH_ARM_SETTLE_MS = 500; // Reportado en vivo (2026-09-18): "al ponerme en posición y estirarme" contaba una repetición que no era -- justo tras armar (tumbado quieto ON_GROUND_STABLE_MS) el usuario seguía acomodándose (estirarse, ajustar brazos/piernas) y ese movimiento residual podía cruzar CRUNCH_UP_FACTOR y volver a bajar, contando como si fuera una repetición real. Se ignora la primera subida hasta pasado este margen desde que se armó -- solo afecta al primer instante de la serie, no a las repeticiones siguientes.

// Elevación de piernas: aquí la cadera SÍ es el pivote (las piernas
// suben mientras el torso se queda en el suelo), así que se mide el
// ÁNGULO de cadera (hombro-cadera-tobillo) — mismo enfoque que la
// rodilla en sentadillas, y por el mismo motivo no hace falta calibrar
// nada ni depende de la distancia a la cámara. Además, las piernas
// tienen que estar ESTIRADAS para armar el contador (ángulo de rodilla
// cadera-rodilla-tobillo casi recto) — con las rodillas dobladas no es
// elevación de piernas.
const LEG_RAISE_DOWN_ANGLE_DEG = 165; // piernas estiradas en el suelo, en línea con el torso
const LEG_RAISE_UP_ANGLE_DEG = 100;   // piernas levantadas
const LEG_RAISE_STRAIGHT_MIN_DEG = 155; // rodilla casi recta -> pierna estirada, hace falta para armar
const LEG_RAISE_MIN_VISIBILITY = 0.4;
// Consejo de forma: los talones no deberían llegar a tocar el suelo al
// bajar (mejor mantener la tensión y parar justo antes) — a diferencia
// de LEG_RAISE_DOWN_ANGLE_DEG, que solo marca cuándo se da la rep por
// completada, este umbral está pegado a "piernas totalmente en el
// suelo" (~180°) y solo dispara un aviso hablado ocasional, sin afectar
// para nada al conteo de repeticiones.
const LEG_RAISE_TOUCHDOWN_ANGLE_DEG = 172;
// El cierre genérico "te has puesto de pie / fuera del suelo"
// (OFF_GROUND_STABLE_MS, 400ms) es demasiado agresivo aquí: tumbado
// boca arriba, el propio movimiento de subir/bajar las piernas entre
// repeticiones agita el ángulo hombro-cadera (tilt) lo bastante como
// para que el ruido de las landmarks cruce el umbral de "de pie" un
// instante — visto en un registro real donde, tras contar la primera
// repetición, la serie se cerraba sola nada más intentar la segunda,
// sin ningún otro cambio visible en cadera/rodilla justo antes del
// cierre (indicio de que era el tilt, no otra cosa, porque tilt no se
// registraba en el log -- ver también el aviso de depuración añadido
// más abajo). Se le da más margen que al resto de ejercicios tumbados
// que comparten OFF_GROUND_STABLE_MS (crunch, sit-up, tijeretas,
// doble-crunch), que no tienen evidencia de este problema -- no se
// toca el valor compartido para no afectarles sin datos.
const LEG_RAISE_OFF_GROUND_STABLE_MS = 900;

// Tijeretas: piernas ESTIRADAS, levantadas "a un palmo" del suelo (ni
// tocando el suelo, ni levantadas del todo como en elevación de
// piernas), alternando cuál pierna queda más alta. La cadera se queda
// apoyada en el suelo y sirve de referencia de altura "0" — se mide
// cuánto sube cada TOBILLO por encima de esa referencia, en proporción
// al muslo (igual que el resto de medidas de este bloque, para no
// depender de la distancia a la cámara). No hay un ciclo "abajo-arriba"
// como en el resto de abdominales tumbado: se cuenta cada vez que
// cambia cuál pierna está arriba, no un ciclo completo.
const SCISSOR_MIN_VISIBILITY = 0.4;
const SCISSOR_LIFT_MIN_FACTOR = 0.10; // tobillo por encima de la cadera, en proporción al muslo — mínimo para contar como "a un palmo"
const SCISSOR_LIFT_MAX_FACTOR = 0.6;  // por encima de esto ya no es "a un palmo" sino una elevación de piernas completa
// Subir solo el margen y el tiempo de confirmación (lo que se probó
// primero) resultó ser perseguirse la cola: subirlos evita los conteos
// de más por ruido, pero el mismo ruido en frames sueltos a veces
// también hacía que la lectura nunca llegara a mantenerse tan alta y
// tanto tiempo seguido, y entonces dejaba de contar repeticiones reales
// una temporada. La causa de fondo es que la altura de cada tobillo,
// frame a frame, viene con ruido — sobre todo justo cuando se cruzan y
// se tapan el uno al otro — así que además de un margen/tiempo
// razonables se suaviza la señal en sí con una media móvil (ver
// SCISSOR_SMOOTHING_ALPHA) antes de compararla.
//
// Un registro real (ver logScissor) enseñó además dos cosas que ni el
// margen ni la media móvil arreglaban por sí solas:
//   1) Con el cuerpo quieto, la diferencia "natural" entre tobillos ya
//      llega a 0.05-0.06 solo por la imprecisión normal de mantener las
//      dos piernas exactamente a la misma altura — un margen tan
//      pequeño contaba eso como un cambio de pierna real.
//   2) De un frame al siguiente aparecían saltos de altura enormes e
//      imposibles para una pierna real (de +0.5 a -2, en una fracción
//      de segundo) — eso no es la pierna moviéndose así de rápido, es
//      MediaPipe confundiendo el tobillo con otro punto durante un
//      frame suelto. Sin nada que lo filtre, ese pico entra tal cual en
//      la media móvil y dispara un cambio que no ha pasado de verdad.
// SCISSOR_MAX_LIFT_JUMP recorta esos saltos ANTES de suavizar (no se
// puede confiar en que la media los absorba sola, ver más abajo).
const SCISSOR_SWITCH_MARGIN_FACTOR = 0.20; // diferencia mínima entre los dos tobillos (ya suavizados) para dar una pierna por claramente "arriba" — bastante más que el "ruido de estar quieto" visto en el registro
const SCISSOR_SWITCH_STABLE_MS = 150; // cuánto tiempo seguido tiene que verse la otra pierna arriba para confirmar el cambio
const SCISSOR_SMOOTHING_ALPHA = 0.3; // media móvil exponencial sobre la altura de cada tobillo: cuánto pesa el frame actual frente al historial reciente. Un pico de un solo frame (típico al cruzarse los tobillos) apenas mueve la media, así que no hace falta un margen/tiempo grandes para ignorarlo
const SCISSOR_MAX_LIFT_JUMP = 0.15; // cuánto puede cambiar como mucho la altura de un tobillo (bruta) de un frame al siguiente. Un salto mayor no es la pierna moviéndose (ninguna pierna real cambia tanto en ~33ms) — es un fallo puntual de tracking, y se recorta a este máximo antes de que llegue a la media móvil

// Abdominal completo (situp): sube el torso ENTERO hasta sentarte — a
// diferencia del crunch, que solo levanta cabeza y hombros. Se mide
// igual que el gate de "tumbado" de arriba (inclinación hombro-cadera
// respecto a la horizontal), de tumbado (~0-30°) a sentado (~55-90°) —
// y no un ángulo de cadera con la rodilla, a propósito: así da igual
// que las rodillas estén dobladas (lo normal, con los pies apoyados) o
// que el cuello esté levantado — ninguno de los dos entra en la cuenta.
const SITUP_DOWN_TILT_DEG = 30; // torso casi horizontal -> tumbado
const SITUP_UP_TILT_DEG = 55;   // torso bien levantado -> sentado
const SITUP_MIN_VISIBILITY = 0.4;

// Doble crunch: a diferencia de crunch/elevación de piernas/abdominal
// completo, el torso se queda LEVANTADO todo el rato, en una posición
// intermedia (ni tumbado del todo ni sentado del todo) — mientras las
// piernas se doblan y estiran, llevando las rodillas al pecho y
// volviendo a estirar, una y otra vez. No hay fase "tumbado" en el
// ciclo, así que el gate de armado/cierre no es "¿estás tumbado?" (como
// en el resto) sino "¿tienes el torso dentro de la banda de inclinación
// de la postura?" — se sale de la serie tanto si te vuelves a tumbar del
// todo como si te llegas a sentar/poner de pie del todo.
//
// Los grados de más abajo son una traducción aproximada de cómo lo narró
// quien pidió esto ("el torso entre 100 y 150 grados") a la misma
// inclinación hombro-cadera respecto a la HORIZONTAL que ya usa
// tiltFromHorizontal() en el resto de este bloque (0°=tumbado,
// 90°=sentado del todo) — no es literalmente el mismo ángulo (el suyo
// suena a cadera-hombro-rodilla, que aquí se evita a propósito, ver
// DOUBLECRUNCH_TUCK_MAX_FACTOR más abajo) pero sí la misma idea: una
// postura reclinada, a medio camino entre tumbado y sentado.
const DOUBLECRUNCH_TILT_MIN_DEG = 30;
const DOUBLECRUNCH_TILT_MAX_DEG = 68;
const DOUBLECRUNCH_ACTIVE_MIN_TILT_DEG = 2; // CORREGIDO 2026-09-18: el valor anterior (12) seguía cerrando la serie justo en el caso que decía cubrir -- el mismo registro que lo motivó mostraba tilt=8° en pleno "tucked" real, y 8 < 12 también cierra. Bajado con margen por debajo de ese 8° observado; no se baja a 0 para conservar algo de margen frente al ruido de sensor y para que "tumbarse del todo" siga pudiendo cerrar la serie si tilt llega a rozar 0.
const DOUBLECRUNCH_MIN_VISIBILITY = 0.4;
// Las repeticiones se cuentan por la distancia RODILLA-HOMBRO, en
// proporción al torso (hombro-cadera, que no cambia mientras se
// mantiene la postura) — y NO por un ángulo de cadera-rodilla como en
// elevación de piernas: ese ángulo se vería contaminado por el propio
// movimiento de levantar el torso, que aquí se supone ya fijo.
const DOUBLECRUNCH_EXTEND_MIN_FACTOR = 1.1; // rodilla lejos del hombro -> piernas estiradas
const DOUBLECRUNCH_TUCK_MAX_FACTOR = 0.7;   // rodilla cerca del hombro -> rodillas al pecho

// Índices de landmarks de MediaPipe Pose que usamos
// Exportados (además de usarse aquí dentro): circuit.js los reutiliza
// para comprobar la postura de plancha/plancha lateral sin duplicar
// los índices de landmarks ni la función de ángulo.
export const NOSE = 0, L_SHOULDER = 11, R_SHOULDER = 12, L_ELBOW = 13, R_ELBOW = 14, L_WRIST = 15, R_WRIST = 16;
export const L_HIP = 23, R_HIP = 24, L_KNEE = 25, R_KNEE = 26, L_ANKLE = 27, R_ANKLE = 28;
export const L_FOOT_INDEX = 31, R_FOOT_INDEX = 32; // punta del pie -- usado solo por el estiramiento de isquiotibiales sentado, para medir "agarrar el pie" a lo largo del segmento tobillo-punta, no solo en el tobillo

/**
 * Ángulo (en grados) en el punto b, formado por los puntos a-b-c. Se usa
 * para medir cuánto se dobla la rodilla (cadera-rodilla-tobillo) en las
 * sentadillas. Solo usa x/y (2D) porque MediaPipe no da una profundidad
 * fiable con una sola cámara — de perfil, x/y ya capturan bien la flexión.
 */
export function angle(a, b, c) {
  const abx = a.x - b.x, aby = a.y - b.y;
  const cbx = c.x - b.x, cby = c.y - b.y;
  const magAB = Math.hypot(abx, aby);
  const magCB = Math.hypot(cbx, cby);
  if (!magAB || !magCB) return null;
  const cos = Math.min(1, Math.max(-1, (abx * cbx + aby * cby) / (magAB * magCB)));
  return (Math.acos(cos) * 180) / Math.PI;
}

/**
 * Inclinación (en grados, 0-90) de la línea a-b respecto a la HORIZONTAL.
 * 0° = línea horizontal (tumbado), 90° = línea vertical (de pie o
 * sentado erguido). Se usa para el gate de "¿está tumbado en el suelo?"
 * en crunch/elevación de piernas/abdominal completo — a diferencia de
 * angle() (el ángulo de una articulación entre tres puntos), esto da la
 * orientación de un solo segmento en la imagen, y a propósito no
 * depende de la rodilla ni del cuello para nada: da igual que las
 * rodillas estén dobladas o la cabeza levantada, la línea hombro-cadera
 * se mide igual.
 */
export function tiltFromHorizontal(a, b) {
  const dx = b.x - a.x, dy = b.y - a.y;
  if (!dx && !dy) return null;
  return (Math.atan2(Math.abs(dy), Math.abs(dx)) * 180) / Math.PI;
}

/**
 * Distancia mínima (2D) del punto p al SEGMENTO a-b (no a la recta
 * infinita) -- se usa para "agarrar el pie" como cualquier punto entre
 * el tobillo y la punta del pie (ver checkSeatedHamstringStretch), no
 * solo el tobillo en sí: agarrar más adelante, hacia los dedos, cuenta
 * igual. t se recorta a [0,1] para quedarse dentro del segmento -- una
 * mano por delante de la punta del pie da distancia a la punta (t=1),
 * una mano por detrás del tobillo (hacia la rodilla) da distancia al
 * tobillo (t=0), nunca "menos" por salirse del segmento.
 */
export function distanceToSegment(p, a, b) {
  const abx = b.x - a.x, aby = b.y - a.y;
  const lenSq = abx * abx + aby * aby;
  let t = lenSq ? ((p.x - a.x) * abx + (p.y - a.y) * aby) / lenSq : 0;
  t = Math.min(1, Math.max(0, t));
  const projX = a.x + t * abx, projY = a.y + t * aby;
  return Math.hypot(p.x - projX, p.y - projY);
}

// ── Plancha / plancha lateral: comprobación de postura ─────────────────
// Se usan tanto aquí (entreno suelto de una tarea) como en circuit.js /
// session-runner.js (dentro de un circuito) — de ahí que vivan en este
// archivo, exportadas, igual que angle()/tiltFromHorizontal() y los
// índices de landmarks: un solo sitio de verdad para la comprobación,
// en vez de mantenerla duplicada en cada reproductor.
//
// LIMITACIÓN CONOCIDA: MediaPipe Pose da la posición 2D de los
// landmarks, no hacia dónde mira la cara — "la nariz boca abajo" no se
// puede comprobar tal cual. Se aproxima con la nariz sin subir por
// encima de la línea de hombros (cabeza no levantada mirando al frente)
// + cuerpo en línea recta + los brazos apoyados. Es una aproximación
// razonable, no una detección exacta de hacia dónde miras.
const PLANK_LINE_MIN_DEG = 148;      // hombro-cadera-tobillo casi recto — algo de margen para cadera/hombros que no salen perfectos por el ruido de la cámara
// Cadera-rodilla-tobillo casi recto — la pierna no puede estar doblada.
// Distingue la plancha de verdad de estar sentada/o con la rodilla
// doblada hacia un lado (delante del portátil, por ejemplo), postura
// que sin este chequeo podía colarse como plancha válida — ver el
// porqué junto a checkPlankPosture.
const PLANK_KNEE_MIN_DEG = 150;
const PLANK_ARMS_DOWN_MARGIN = 0.05; // las muñecas deben quedar a la altura del hombro o por debajo
// Un codo doblado, apoyado en el suelo justo debajo del hombro, en vez
// de un brazo estirado — ver el porqué junto a checkPlankPosture.
const PLANK_ELBOW_BELOW_SHOULDER_MARGIN = 0.35;
// El cuerpo tiene que estar CLARAMENTE alzado del suelo — el hombro
// bastante más arriba en la imagen que el tobillo (los pies se quedan
// apoyados, pero el resto del cuerpo sube, apoyado solo en los
// antebrazos) — ver el porqué junto a checkPlankPosture.
const PLANK_MIN_INCLINE_FACTOR = 0.35;
const PLANK_MIN_VISIBILITY = 0.4;
// Orientación del cuerpo en la imagen (0°=horizontal, 90°=vertical). De
// pie y de perfil, hombro-cadera-tobillo también forma una línea recta,
// y hombro claramente por encima del tobillo (incline) y codo por
// debajo del hombro, así que pasaba TODAS las comprobaciones de plancha
// (reportado: "de pie de perfil me da correcto, debería estar
// estirado"). Una plancha real tiene la línea hombro-tobillo casi
// horizontal (~10-25°); de pie sale ~90°. Tope holgado para no romper
// planchas con cadera algo alta.
const PLANK_MAX_TILT_DEG = 40;

// La mano de arriba puede ir donde sea (cadera, estirada al techo, sobre
// la pierna...) — no se exige apoyarla en ningún sitio en concreto. Antes
// sí se comprobaba (SIDEPLANK_HIP_TOUCH_FACTOR, ya retirado): la idea era
// solo ayudar a MediaPipe a "leer" bien la postura, nunca una exigencia
// real del ejercicio, pero al ser un requisito bloqueante, un side plank
// hecho tal cual (de lado, apoyado en el codo y los pies, sin tocarse la
// cadera) nunca llegaba a darse por correcto — el aviso "Apoya la mano de
// arriba en la cadera" se repetía sin parar y el aguante no arrancaba
// nunca. Lo que de verdad identifica un side plank correcto es la línea
// del cuerpo, la cadera alzada y el codo de apoyo bien colocado (ver
// justo debajo); ninguno de los tres depende de la mano de arriba.
const SIDEPLANK_LINE_MIN_DEG = 145;      // algo más laxo que la plancha normal: la cadera sube un poco de forma natural
const SIDEPLANK_MIN_VISIBILITY = 0.4;
// La cadera tiene que quedar CLARAMENTE alzada respecto al codo de apoyo
// y el tobillo de abajo (los dos puntos que tocan el suelo) — igual que
// PLANK_MIN_INCLINE_FACTOR en la plancha normal, distingue una plancha
// lateral de verdad de estar simplemente tumbada/o de lado en el suelo,
// relajada/o (esa postura también da una línea recta hombro-cadera-
// tobillo, pero con la cadera a ras de suelo) — ver el porqué junto a
// checkSidePlankPosture. Se deja algo más laxo que en la plancha normal
// porque la elevación de la cadera de lado es, de por sí, más pequeña.
const SIDEPLANK_MIN_HIP_LIFT = 0.22;
// Tope de arriba para hipLift: solo hay mínimo, no máximo, así que nada
// impedía que una cadera disparatadamente alta (te has puesto de pie a
// medias, la cámara te capta a media incorporación) siguiera contando
// como "postura correcta" con tal de superar el mínimo. Según un registro
// real (aguantado subiendo de 6s a 25s mientras la persona ya se había
// puesto de pie y se movía por delante de la cámara), hipLift subía de
// forma continua y suave de ~0.5 (aguante real) a más de 2 según se
// incorporaba — nada ruidoso, un movimiento real de levantarse. Por
// encima de este tope ya no es una plancha lateral con la cadera bien
// alta, es que te has separado del suelo del todo.
const SIDEPLANK_MAX_HIP_LIFT = 1.2;
// SIDEPLANK_MAX_HIP_LIFT arregló levantarte DESPACIO, de forma continua,
// en medio de un aguante — pero según un registro real posterior, no
// cubre otro caso distinto: terminar la serie de verdad (la cadera ya
// vuelve a 0 — "confirmado=no" — y el tramo se cierra bien) y LUEGO
// alejarte de pie, caminando hacia la cámara/ordenador (hace falta,
// para caber en el encuadre). Caminando de pie, con los brazos a los
// lados, hombro-cadera-tobillo puede seguir saliendo casi recto
// (lineAngle 170-180°, como al tumbarte de lado) y hipLift se queda
// DENTRO del rango 0-0.9 (no llega a superar el tope de arriba) — así
// que sin más comprobación, unos segundos de caminar de pie se
// contaban como un aguante nuevo empezando de cero ("me lo ha contado
// como plank" al ir hacia el ordenador tras 41s de plancha lateral
// correctos). Lo que de verdad falta comprobar es la ORIENTACIÓN del
// cuerpo en la imagen: tumbada/o de lado, el tramo hombro-cadera tiene
// que salir prácticamente HORIZONTAL en la imagen (cerca de 0°); de
// pie, ese mismo tramo sale prácticamente VERTICAL (cerca de 90°) —
// algo que ni lineAngle (mide si el cuerpo está doblado, no su
// orientación) ni hipLift (una altura relativa, no un ángulo respecto
// a la imagen) llegan a distinguir. Se usa tiltFromHorizontal(), ya
// definida más arriba y usada en crunch/elevación de piernas/
// abdominal completo para el mismo tipo de comprobación.
const SIDEPLANK_MAX_TILT_DEG = 45;
// Codo de apoyo bien por debajo del hombro — apoyo real en el
// antebrazo (lo pedido: "el codo en el suelo"), no un brazo estirado
// apoyando solo la mano ni un brazo que no llega a apoyar peso.
const SIDEPLANK_ELBOW_BELOW_SHOULDER_MARGIN = 0.22;
// Margen (como fracción del ancho de hombros) que el hombro contrario
// tiene que bajar para que se cambie qué lado se considera "de abajo"
// — ver el porqué junto a checkSidePlankPosture: sin este margen, con
// los dos hombros casi a la misma altura, la decisión saltaba de un
// lado a otro cada frame y desbarataba todas las medidas.
const SIDEPLANK_DOWN_SWITCH_MARGIN_FACTOR = 0.15;

// Pedir la postura de plancha o plancha lateral (alzada, apoyada en el
// antebrazo) de entrada, nada más empezar la serie, es pedir demasiado
// de golpe — sobre todo porque el primer aviso que se puede oír, si algo
// del encuadre no está bien, es "no se te ve entera/o", que no explica
// qué hacer. Por eso las dos pasan primero por un paso más sencillo:
// tumbarte del todo, en CUALQUIER orientación (boca arriba vale igual
// que boca abajo — aquí solo se comprueba que se te ve entera/o y que el
// cuerpo está estirado, nada de brazos ni de si estás alzada/o), para
// confirmar que el encuadre está bien. Solo entonces se pide el paso 2:
// ponerte en la plancha (o plancha lateral) de verdad — ver
// postureGroundConfirmed en processPosture.
//
// La plancha lateral SÍ pasaba antes directa al paso 2, sin este primer
// paso (se asumía que, de lado con las piernas estiradas, ya era fácil
// de detectar a la primera) — pero según lo reportado, no lo era: nada
// más empezar la serie ya se pedía directamente la postura completa
// (incluida, en su momento, la mano de arriba apoyada en la cadera, ver
// más abajo por qué eso ya no se exige), sin ningún paso previo que
// guiara cómo colocarse. Ahora sigue el mismo patrón que la plancha
// normal.
const LYING_FLAT_MIN_DEG = 155;
const LYING_FLAT_MIN_VISIBILITY = 0.4;
// De perfil de verdad, el cuerpo entero (del hombro al tobillo) ocupa
// un buen tramo de la imagen — bastante más que el ancho de hombros.
// Si en vez de eso apuntas el cuerpo HACIA la cámara (los pies "mirando
// hacia abajo" en la imagen pero en realidad mirando al objetivo), la
// profundidad no se ve en una imagen 2D: el cuerpo se "encoge" en la
// imagen aunque el ángulo hombro-cadera-tobillo pueda seguir saliendo
// cerca de recto por casualidad — así que el ángulo solo no basta,
// hace falta comprobar también que el cuerpo se vea realmente
// extendido de lado. Se usa tanto para el paso 1 (tumbarte del todo)
// como para la plancha en sí (ver checkPlankPosture).
const MIN_BODY_LENGTH_FACTOR = 2.2; // tramo hombro-tobillo en la imagen, en proporción al ancho de hombros

export function checkLyingFlat(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lH = lm[L_HIP], rH = lm[R_HIP];
  const lA = lm[L_ANKLE], rA = lm[R_ANKLE];
  // Igual que en tijeretas: de perfil, el lado de detrás pierde
  // confianza aunque MediaPipe siga estimando su posición razonablemente
  // bien — exigir visibilidad alta en los DOS lados a la vez casi nunca
  // se cumplía y el gate de "te veo" fallaba casi todo el rato. Ahora
  // solo hace falta ver bien el lado más cercano a la cámara.
  const leftVis = ((lS.visibility ?? 1) + (lH.visibility ?? 1) + (lA.visibility ?? 1)) / 3;
  const rightVis = ((rS.visibility ?? 1) + (rH.visibility ?? 1) + (rA.visibility ?? 1)) / 3;
  const useLeft = leftVis >= rightVis;
  const sideVis = useLeft ? leftVis : rightVis;
  if (sideVis < LYING_FLAT_MIN_VISIBILITY) {
    return { ok: false, reason: "vis" };
  }
  const shoulder = useLeft ? lS : rS;
  const hip = useLeft ? lH : rH;
  const ankle = useLeft ? lA : rA;
  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y) || 1;
  const lineAngle = angle(shoulder, hip, ankle);
  const bodyLength = Math.hypot(shoulder.x - ankle.x, shoulder.y - ankle.y);
  const bodyLengthFactor = bodyLength / shoulderWidth;
  const angleOk = lineAngle !== null && lineAngle >= LYING_FLAT_MIN_DEG;
  const lengthOk = bodyLengthFactor >= MIN_BODY_LENGTH_FACTOR;
  return {
    ok: angleOk && lengthOk,
    reason: !angleOk ? "angle" : !lengthOk ? "length" : null,
    lineAngle: lineAngle === null ? null : lineAngle.toFixed(0),
    bodyLengthFactor: bodyLengthFactor.toFixed(2),
  };
}

export function checkPlankPosture(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lE = lm[L_ELBOW], rE = lm[R_ELBOW];
  const lH = lm[L_HIP], rH = lm[R_HIP];
  const lK = lm[L_KNEE], rK = lm[R_KNEE];
  const lA = lm[L_ANKLE], rA = lm[R_ANKLE];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];

  // Igual que en tijeretas: de perfil, el lado de detrás pierde
  // confianza aunque MediaPipe siga estimando su posición razonablemente
  // bien — exigir visibilidad alta en los DIEZ puntos (ambos lados) a
  // la vez casi nunca se cumplía y el gate de "te veo" fallaba casi
  // todo el rato aunque la postura fuera correcta (justo lo que
  // mostraba el registro de depuración: "No se te ve entera/o" sin
  // parar). Ahora solo hace falta ver bien el lado más cercano a la
  // cámara (hombro, codo, cadera, rodilla, tobillo y muñeca de ESE
  // lado); el otro lado se usa tal cual lo reporte MediaPipe, tenga la
  // confianza que tenga.
  const leftVis = ((lS.visibility ?? 1) + (lE.visibility ?? 1) + (lH.visibility ?? 1) + (lK.visibility ?? 1) + (lA.visibility ?? 1) + (lW.visibility ?? 1)) / 6;
  const rightVis = ((rS.visibility ?? 1) + (rE.visibility ?? 1) + (rH.visibility ?? 1) + (rK.visibility ?? 1) + (rA.visibility ?? 1) + (rW.visibility ?? 1)) / 6;
  const useLeft = leftVis >= rightVis;
  const sideVis = useLeft ? leftVis : rightVis;

  if (sideVis < PLANK_MIN_VISIBILITY) {
    return { ok: false, reason: "No se te ve entera/o. Ponte de perfil a la cámara, con todo el cuerpo en el encuadre.", debug: { fail: "vis" } };
  }

  const shoulder = useLeft ? lS : rS;
  const hip = useLeft ? lH : rH;
  const knee = useLeft ? lK : rK;
  const ankle = useLeft ? lA : rA;
  const elbow = useLeft ? lE : rE;
  const wrist = useLeft ? lW : rW;

  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y) || 1;
  const shoulderMidY = (lS.y + rS.y) / 2;
  // Antes se promediaba la altura de las DOS muñecas — pero si una
  // apenas se ve, su posición es ruido y desvía la media. Ahora se usa
  // solo la muñeca del lado mejor visto, igual que el resto de medidas.
  const wristMidY = wrist.y;

  // Se calculan TODAS las medidas de golpe, de una — incluso las que
  // ya han fallado un umbral anterior — para que el objeto `debug` de
  // cada return lleve siempre los números completos: así, si hace
  // falta reajustar algún umbral con un registro real (ver logScissor/
  // exportScissorLog, reutilizado aquí para la plancha), no hay que
  // adivinar qué valor tenía en el momento del fallo.
  const lineAngle = angle(shoulder, hip, ankle);
  // Cadera-rodilla-tobillo, aparte de hombro-cadera-tobillo: sentarte
  // con la rodilla doblada hacia un lado (por ejemplo delante del
  // portátil) puede, vista de perfil, dar un tramo hombro-cadera-tobillo
  // que sale casi recto por casualidad — pero la rodilla doblada lo
  // delata. Sin esta comprobación, esa postura sentada se contaba como
  // plancha (lo que se reportó tras ~7s aguantados sin estar haciendo
  // el ejercicio).
  const kneeAngle = angle(hip, knee, ankle);
  const bodyLength = Math.hypot(shoulder.x - ankle.x, shoulder.y - ankle.y);
  const bodyLengthFactor = bodyLength / shoulderWidth;
  const armsDown = (wristMidY - shoulderMidY) / shoulderWidth;
  const incline = (ankle.y - shoulder.y) / shoulderWidth;
  const elbowDrop = (elbow.y - shoulder.y) / shoulderWidth;
  const tilt = tiltFromHorizontal(shoulder, ankle);
  const debug = {
    tilt: tilt === null ? null : tilt.toFixed(0),
    lineAngle: lineAngle === null ? null : lineAngle.toFixed(0),
    kneeAngle: kneeAngle === null ? null : kneeAngle.toFixed(0),
    bodyLengthFactor: bodyLengthFactor.toFixed(2),
    armsDown: armsDown.toFixed(2),
    incline: incline.toFixed(2),
    elbowDrop: elbowDrop.toFixed(2),
  };

  if (lineAngle === null || lineAngle < PLANK_LINE_MIN_DEG) {
    return { ok: false, reason: "Cadera desalineada — mantén el cuerpo en línea recta, de los hombros a los tobillos.", debug };
  }
  if (kneeAngle === null || kneeAngle < PLANK_KNEE_MIN_DEG) {
    return { ok: false, reason: "Estira las piernas del todo — la rodilla no puede quedar doblada en la plancha.", debug };
  }
  if (tilt === null || tilt > PLANK_MAX_TILT_DEG) {
    return { ok: false, reason: "Postura rota — pareces estar de pie. Túmbate boca abajo, apoyada/o en los antebrazos y los pies, para la plancha.", debug };
  }
  // Si apuntas el cuerpo HACIA la cámara en vez de estar de perfil (los
  // pies "mirando hacia abajo" en la imagen pero en realidad mirando al
  // objetivo), el ángulo de arriba puede salir recto por casualidad
  // aunque no estés de perfil de verdad — ver la nota junto a
  // MIN_BODY_LENGTH_FACTOR, más arriba, para el porqué.
  if (bodyLengthFactor < MIN_BODY_LENGTH_FACTOR) {
    return { ok: false, reason: "Ponte de perfil de verdad (de lado a la cámara), no con los pies apuntando hacia ella.", debug };
  }
  // La cabeza (mirar al suelo o no) NO se comprueba a propósito: no
  // cambia la línea del cuerpo que de verdad importa (pies-cadera-
  // hombros-codos, ver más abajo), y moverla para respirar o mirar
  // alrededor no debería romper una plancha que por lo demás es
  // correcta — antes sí se comprobaba y cada movimiento de cabeza
  // partía el tramo aguantado en una serie nueva.
  if (armsDown < -PLANK_ARMS_DOWN_MARGIN) {
    return { ok: false, reason: "Apoya los dos brazos en el suelo.", debug };
  }
  // "Cuerpo en línea recta" (el check de arriba, hombro-cadera-tobillo)
  // lo cumple TANTO una plancha de verdad, alzada del suelo, COMO estar
  // simplemente tumbado del todo en el suelo, boca abajo — un cuerpo
  // estirado en el suelo también forma una línea recta, solo que a
  // ras de suelo en vez de alzada. MediaPipe no dice si estás tocando
  // el suelo o no (solo posiciones 2D en la imagen), así que sin más
  // comprobación el aviso de "postura correcta" podía dispararse
  // estando tumbado del todo, sin aguantar nada con los brazos — es
  // justo el fallo que describiste: codos en el suelo, cuerpo tumbado,
  // contando como plancha.
  //
  // Lo que de verdad distingue una plancha real: el cuerpo entero tiene
  // que quedar ALZADO del suelo, apoyado solo en los antebrazos y los
  // pies — así que, vista de perfil, la silueta tiene que ir de los
  // pies (abajo, tocando el suelo) subiendo en diagonal hasta los
  // hombros/codos (bastante más arriba en la imagen), en vez de ir
  // todo al mismo nivel. Se comprueba con dos medidas:
  //   1) el HOMBRO tiene que quedar bastante más arriba en la imagen
  //      que el TOBILLO (el cuerpo alzado, no a ras de suelo);
  //   2) el CODO tiene que quedar claramente por debajo del hombro que
  //      sostiene (brazo doblado apoyando peso, no estirado ni
  //      simplemente posado).
  if (incline < PLANK_MIN_INCLINE_FACTOR) {
    return { ok: false, reason: "Sube las caderas: el cuerpo entero tiene que quedar alzado del suelo, apoyado en los antebrazos y los pies, no tumbado.", debug };
  }
  if (elbowDrop < PLANK_ELBOW_BELOW_SHOULDER_MARGIN) {
    return { ok: false, reason: "Ponte boca abajo, apoyada/o en los antebrazos, con los codos doblados justo debajo de los hombros.", debug };
  }
  return { ok: true, debug };
}

/**
 * Bring Sally Up (reto de flexiones, ver static/js/challenges.js) —
 * aguante isométrico ARRIBA o ABAJO, no repeticiones. Reutiliza
 * EXACTAMENTE los mismos umbrales que el contador de flexiones normal
 * (PUSHUP_UP_ANGLE_DEG / PUSHUP_DOWN_ANGLE_DEG / PUSHUP_LINE_MIN_DEG /
 * PUSHUP_MIN_VISIBILITY / ON_GROUND_MAX_TILT_DEG, ver processPushup más
 * abajo) para que "postura correcta" signifique lo mismo en el reto que
 * en una flexión contada de verdad — la única diferencia es qué se
 * pide: aquí no hay repetición que contar, hay que MANTENER el ángulo
 * de codo pedido (recto o doblado) el tiempo que dure ese tramo del
 * guion, igual que checkPlankPosture/checkKneeHoldBarPosture con el
 * suyo. Copia exacta de la misma función en la app móvil (ver
 * mobile-app/www/js/workout.js) — mismo criterio en las dos partes.
 */
function checkPushupHoldPosture(lm, holdTop) {
  const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
  const lElbow = lm[L_ELBOW], rElbow = lm[R_ELBOW];
  const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];
  const lHip = lm[L_HIP], rHip = lm[R_HIP];
  const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

  const leftVis = (
    (lShoulder.visibility ?? 1) + (lElbow.visibility ?? 1) + (lWrist.visibility ?? 1) +
    (lHip.visibility ?? 1) + (lAnkle.visibility ?? 1)
  ) / 5;
  const rightVis = (
    (rShoulder.visibility ?? 1) + (rElbow.visibility ?? 1) + (rWrist.visibility ?? 1) +
    (rHip.visibility ?? 1) + (rAnkle.visibility ?? 1)
  ) / 5;
  const useLeft = leftVis >= rightVis;
  const vis = useLeft ? leftVis : rightVis;

  if (vis < PUSHUP_MIN_VISIBILITY) {
    return {
      ok: false,
      reason: "No se te ven bien el hombro, el codo, la muñeca, la cadera y el tobillo. Ponte de perfil a la cámara.",
      debug: { fail: "vis" },
    };
  }

  const shoulder = useLeft ? lShoulder : rShoulder;
  const elbow = useLeft ? lElbow : rElbow;
  const wrist = useLeft ? lWrist : rWrist;
  const hip = useLeft ? lHip : rHip;
  const ankle = useLeft ? lAnkle : rAnkle;

  const elbowAngle = angle(shoulder, elbow, wrist);
  const lineAngle = angle(shoulder, hip, ankle);
  const tilt = tiltFromHorizontal(shoulder, hip);
  if (elbowAngle === null || lineAngle === null || tilt === null) {
    return { ok: false, reason: "No se te ve bien de perfil.", debug: { fail: "angle" } };
  }

  const debug = { elbowAngle: elbowAngle.toFixed(0), lineAngle: lineAngle.toFixed(0), tilt: tilt.toFixed(0) };

  if (tilt > ON_GROUND_MAX_TILT_DEG) {
    return { ok: false, reason: "Túmbate boca abajo, de perfil a la cámara.", debug };
  }
  if (lineAngle < PUSHUP_LINE_MIN_DEG) {
    return { ok: false, reason: "Estira el cuerpo — de los hombros a los tobillos en línea recta, sin encoger la cadera.", debug };
  }
  if (holdTop) {
    if (elbowAngle < PUSHUP_UP_ANGLE_DEG) {
      return { ok: false, reason: "Estira los brazos del todo — posición de arriba.", debug };
    }
  } else if (elbowAngle > PUSHUP_DOWN_ANGLE_DEG) {
    return { ok: false, reason: "Dobla los codos hasta abajo — pecho cerca del suelo.", debug };
  }
  return { ok: true, debug };
}

/** Aguante arriba (brazos estirados) — fase "Sube y aguanta" del reto. */
export function checkPushupTopHoldPosture(lm) {
  return checkPushupHoldPosture(lm, true);
}

/** Aguante abajo (codos doblados) — fase "Baja y aguanta" del reto. */
export function checkPushupBottomHoldPosture(lm) {
  return checkPushupHoldPosture(lm, false);
}

export function checkSidePlankPosture(lm, downSideHint = null) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lE = lm[L_ELBOW], rE = lm[R_ELBOW];
  const lH = lm[L_HIP], rH = lm[R_HIP];
  const lA = lm[L_ANKLE], rA = lm[R_ANKLE];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];

  // Igual que en la plancha normal: de perfil, el lado que queda
  // "detrás" (más lejos de la cámara, a veces parcialmente tapado por
  // el propio cuerpo) pierde confianza aunque MediaPipe siga estimando
  // su posición razonablemente bien. Antes se exigía visibilidad mínima
  // en los DIEZ puntos (los dos lados) A LA VEZ, y bastaba con que uno
  // solo (típicamente la muñeca de apoyo, semitapada por la cadera) se
  // fuera un instante por debajo del umbral para que saltara "no se te
  // ve entera/o" sin parar — el mismo problema, ya visto y arreglado,
  // de la plancha normal. Ahora se exige una visibilidad MEDIA
  // razonable entre los diez puntos, no que cada uno por separado la
  // supere.
  const points = [lS, rS, lE, rE, lH, rH, lA, rA, lW, rW];
  const avgVis = points.reduce((sum, p) => sum + (p.visibility ?? 1), 0) / points.length;
  if (avgVis < SIDEPLANK_MIN_VISIBILITY) {
    return { ok: false, reason: "No se te ve entera/o. Ponte de perfil a la cámara, con todo el cuerpo en el encuadre.", debug: { fail: "vis" } };
  }

  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y) || 1;
  // Antes se decidía qué lado está "abajo" (el que apoya en el suelo)
  // mirando qué MUÑECA queda más baja en la imagen — pero la muñeca de
  // arriba suele acabar posada sobre la cadera, medio tapada, que es
  // justo de las partes que peor detecta MediaPipe en esta postura. Los
  // HOMBROS, en cambio, se ven bien de perfil en la plancha lateral
  // (quedan uno claramente encima del otro, sin taparse) — así que
  // ahora se usan ellos para decidir qué lado es el de apoyo: más
  // fiable, como pediste.
  // Antes esto se decidía frame a frame, sin más: en cuanto un hombro
  // quedaba un pelín más bajo que el otro, ESE pasaba a ser "abajo". Con
  // los dos hombros casi a la misma altura (que es lo normal aquí, de
  // perfil) el más mínimo ruido de un frame a otro hacía que la
  // decisión saltara de un lado a otro sin parar — y como TODAS las
  // medidas (línea, altura de cadera, mano-cadera…) dependen de qué
  // lado es "abajo", cada salto mezclaba puntos de un lado con puntos
  // del otro y disparaba lecturas absurdas (p.ej. hipLift saltando de
  // -0.2 a 0.9 en un par de frames) — justo lo que se ve en el registro
  // que mandaste, y por lo que nunca llegaba a confirmarse la postura.
  // Ahora, una vez decidido un lado, hace falta que el OTRO lado quede
  // claramente más bajo (más de SIDEPLANK_DOWN_SWITCH_MARGIN_FACTOR de
  // margen) para cambiar de idea — así un empate o un frame ruidoso no
  // cambia nada.
  const shoulderGap = lS.y - rS.y; // positivo = hombro izquierdo más abajo
  const switchMargin = SIDEPLANK_DOWN_SWITCH_MARGIN_FACTOR * shoulderWidth;
  let leftIsDown;
  if (downSideHint === "left") {
    leftIsDown = shoulderGap > -switchMargin;
  } else if (downSideHint === "right") {
    leftIsDown = shoulderGap > switchMargin;
  } else {
    leftIsDown = shoulderGap > 0;
  }
  const downSide = leftIsDown ? "left" : "right";
  const downShoulder = leftIsDown ? lS : rS;
  const downElbow = leftIsDown ? lE : rE;
  const downWrist = leftIsDown ? lW : rW;
  const downHip = leftIsDown ? lH : rH;
  const downAnkle = leftIsDown ? lA : rA;

  const lineAngle = angle(downShoulder, downHip, downAnkle);
  const armDown = (downWrist.y - downShoulder.y) / shoulderWidth;
  // Codo de apoyo bien por debajo del hombro — ver SIDEPLANK_ELBOW_BELOW_SHOULDER_MARGIN.
  const elbowDrop = (downElbow.y - downShoulder.y) / shoulderWidth;
  // Cadera alzada respecto a los dos puntos que de verdad tocan el
  // suelo (el codo de apoyo y el tobillo de abajo) — ver el porqué
  // junto a SIDEPLANK_MIN_HIP_LIFT: sin esto, tumbarte de lado en el
  // suelo, relajada/o, también pasaría el chequeo de "línea recta" de
  // arriba.
  const groundY = (downElbow.y + downAnkle.y) / 2;
  const hipLift = (groundY - downHip.y) / shoulderWidth;
  // Orientación del cuerpo en la imagen (0°=horizontal/tumbado de lado,
  // 90°=vertical/de pie) — ver SIDEPLANK_MAX_TILT_DEG para el porqué.
  const tilt = tiltFromHorizontal(downShoulder, downHip);

  const debug = {
    lado: downSide === "left" ? "izq. abajo" : "der. abajo",
    lineAngle: lineAngle === null ? null : lineAngle.toFixed(0),
    hipLift: hipLift.toFixed(2),
    elbowDrop: elbowDrop.toFixed(2),
    armDown: armDown.toFixed(2),
    tilt: tilt === null ? null : tilt.toFixed(0),
  };

  if (lineAngle === null || lineAngle < SIDEPLANK_LINE_MIN_DEG) {
    return { ok: false, reason: "Cadera desalineada — mantén el cuerpo en línea recta, de los hombros a los tobillos.", debug, downSide };
  }
  if (tilt === null || tilt > SIDEPLANK_MAX_TILT_DEG) {
    return { ok: false, reason: "Postura rota — pareces estar de pie. Vuelve a tumbarte de lado para la plancha lateral.", debug, downSide };
  }
  if (hipLift < SIDEPLANK_MIN_HIP_LIFT) {
    return { ok: false, reason: "Sube la cadera: el cuerpo entero tiene que quedar alzado del suelo, apoyado en el antebrazo y el lateral de los pies, no tumbada/o de lado.", debug, downSide };
  }
  if (hipLift > SIDEPLANK_MAX_HIP_LIFT) {
    return { ok: false, reason: "Postura rota — parece que te has levantado. Vuelve a la plancha lateral.", debug, downSide };
  }
  if (elbowDrop < SIDEPLANK_ELBOW_BELOW_SHOULDER_MARGIN) {
    return { ok: false, reason: "Apoya el codo en el suelo, justo debajo del hombro — no el brazo estirado.", debug, downSide };
  }
  if (armDown < PLANK_ARMS_DOWN_MARGIN) {
    return { ok: false, reason: "Apoya el antebrazo de abajo en el suelo.", debug, downSide };
  }
  return { ok: true, debug, downSide };
}

// ── Silla en pared (wall sit): comprobación de postura ─────────────────
// La cámara se coloca A UN LADO (de perfil) y algo alejada, para que
// quepa la pierna entera en el encuadre — mismo motivo que en
// sentadillas (ver SQUAT_UP_ANGLE_DEG más arriba): de frente no se
// puede medir cuánto se dobla la rodilla en profundidad.
//
// A diferencia de la sentadilla (que cuenta repeticiones subiendo y
// bajando), aquí se AGUANTA la postura con la espalda apoyada — mismo
// patrón que la plancha (checkPlankPosture): se comprueba la postura
// frame a frame y se cuenta el TIEMPO aguantado, no repeticiones.
// Reutiliza el mismo mecanismo de aguante (CAMERA_POSTURE_COUNTERS,
// _flushPostureHold, notePostureOk/Broken, PLANK_INVALID_STABLE_MS,
// PLANK_MIN_HOLD_TO_COUNT_SECONDS…) que la plancha y la plancha
// lateral, así que no hace falta duplicar esas constantes de tiempo
// aquí.
//
// SÍ hay un primer paso (a diferencia de lo que decía este comentario
// antes): confirmar que te ve DE PIE, antes de aceptar la postura
// doblada de la silla — ver checkStanding()/postureGroundConfirmed en
// processPosture, mismo patrón que plancha/kneehold en barra. Se
// reportó que, colocando la cámara mientras ya estabas sentada/o en una
// silla de verdad, rodilla y cadera ya rondaban los 90° por sí solos —
// eso pasaba checkWallSitPosture a la primera sin haber hecho el
// ejercicio, contando el rato sentada/o como si fuera aguante de
// verdad. Pedir primero el cuerpo estirado del todo hace falta el
// movimiento real (de pie → silla) para empezar a contar.
//
// NO hace falta que el apoyo sea una pared: la cámara no ve lo que hay
// detrás, solo el ángulo del cuerpo — así que apoyarse en una barra,
// un poste o cualquier otra cosa vale igual, mientras la espalda quede
// recta y las piernas dobladas (pedido explícitamente: antes el aviso
// hablaba de "pared" como si fuera obligatoria, cuando nunca lo fue de
// verdad para la detección).
//
// Dos ángulos, de perfil, definen la postura:
//   - RODILLA (cadera-rodilla-tobillo) cerca de 90° — el muslo queda
//     paralelo al suelo, como sentada/o en una silla invisible.
//   - CADERA (hombro-cadera-rodilla) cerca de 90° — el torso, apoyado,
//     queda perpendicular al muslo.
// Y una comprobación de inclinación del torso respecto a la VERTICAL
// (no a la horizontal, al revés que en checkLyingFlat) para asegurar
// que la espalda está recta y apoyada, en vez de inclinada hacia
// delante como en una sentadilla libre sin apoyo.
//
// Márgenes ampliados (se reportó que la detección iba mal, saltando a
// "postura rota" con demasiada facilidad): la rodilla y la cadera
// admiten ahora ±25° alrededor de 90° (antes ±10-15°), y el torso
// admite algo más de inclinación hacia delante (antes exigía casi
// vertical del todo, que encajaba con una pared plana pero no tanto
// con apoyarse en una barra o un poste, donde el ángulo real varía más
// de una persona a otra).
const WALLSIT_KNEE_MIN_DEG = 65;  // rodilla más doblada que 90° todavía vale
const WALLSIT_KNEE_MAX_DEG = 115; // por encima de esto, las piernas no están lo bastante dobladas
const WALLSIT_HIP_MIN_DEG = 60;
// 120->135: al apoyar la cabeza en la pared el torso se echa algo hacia atras y el angulo hombro-cadera-rodilla se abre por encima de 120 (reportado: dejaba de contar con la cabeza en la pared y volvia al inclinar el cuello). Primera correccion, sin log real: si sigue fallando, pedir el 📋.
const WALLSIT_HIP_MAX_DEG = 135;
// Cuánto puede inclinarse el torso hacia delante y aun así contar como
// "espalda recta y apoyada". tiltFromHorizontal() da 90° con el torso
// en vertical del todo; bajado de 65° a 50° para dar más margen al
// apoyarse en una barra o un poste (no siempre queda tan a plomo como
// contra una pared plana) sin dejar de distinguirlo de una sentadilla
// libre inclinada hacia delante.
const WALLSIT_TORSO_MIN_TILT_DEG = 50;
const WALLSIT_MIN_VISIBILITY = 0.4;

export function checkWallSitPosture(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lH = lm[L_HIP], rH = lm[R_HIP];
  const lK = lm[L_KNEE], rK = lm[R_KNEE];
  const lA = lm[L_ANKLE], rA = lm[R_ANKLE];

  // Igual que en sentadillas/plancha: de perfil, solo hace falta ver
  // bien el lado más cercano a la cámara — exigir buena visibilidad en
  // los dos lados a la vez casi nunca se cumple de perfil.
  const leftVis = ((lS.visibility ?? 1) + (lH.visibility ?? 1) + (lK.visibility ?? 1) + (lA.visibility ?? 1)) / 4;
  const rightVis = ((rS.visibility ?? 1) + (rH.visibility ?? 1) + (rK.visibility ?? 1) + (rA.visibility ?? 1)) / 4;
  const useLeft = leftVis >= rightVis;
  const sideVis = useLeft ? leftVis : rightVis;

  if (sideVis < WALLSIT_MIN_VISIBILITY) {
    return {
      ok: false,
      reason: "No se te ve entera/o. Ponte de perfil a la cámara, algo alejada/o, con la pierna entera (de la cadera al tobillo) en el encuadre.",
      debug: { fail: "vis" },
    };
  }

  const shoulder = useLeft ? lS : rS;
  const hip = useLeft ? lH : rH;
  const knee = useLeft ? lK : rK;
  const ankle = useLeft ? lA : rA;

  const kneeAngle = angle(hip, knee, ankle);
  const hipAngle = angle(shoulder, hip, knee);
  // 0°=torso horizontal (tumbado), 90°=torso en vertical del todo —
  // aquí interesa que sea ALTO (torso recto y apoyado — pared, barra,
  // poste...).
  const tilt = tiltFromHorizontal(shoulder, hip);

  const debug = {
    kneeAngle: kneeAngle === null ? null : kneeAngle.toFixed(0),
    hipAngle: hipAngle === null ? null : hipAngle.toFixed(0),
    tilt: tilt === null ? null : tilt.toFixed(0),
  };

  if (tilt === null || tilt < WALLSIT_TORSO_MIN_TILT_DEG) {
    return { ok: false, reason: "Espalda desalineada — mantenla recta y apoyada (pared, barra o poste), sin inclinarte hacia delante.", debug };
  }
  if (kneeAngle === null || kneeAngle < WALLSIT_KNEE_MIN_DEG) {
    return { ok: false, reason: "Te has agachado de más — sube un poco, hasta que la rodilla ronde los 90°.", debug };
  }
  if (kneeAngle > WALLSIT_KNEE_MAX_DEG) {
    return { ok: false, reason: "Baja un poco más, deslizando la espalda por el apoyo, hasta que el muslo quede paralelo al suelo.", debug };
  }
  if (hipAngle === null || hipAngle < WALLSIT_HIP_MIN_DEG || hipAngle > WALLSIT_HIP_MAX_DEG) {
    return { ok: false, reason: "Ajusta la altura: la cadera tiene que quedar más o menos a 90°, como sentada/o en una silla.", debug };
  }
  return { ok: true, debug };
}

// Paso 1 de silla en pared (ver postureGroundConfirmed en
// processPosture): confirmar que te ve DE PIE, con la pierna estirada
// del todo, antes de aceptar la postura doblada — mismo criterio de
// "pierna recta" que SQUAT_UP_ANGLE_DEG (160°) para "de pie" en
// sentadillas, aplicado también a la cadera para que sentarte en una
// silla normal (rodilla Y cadera ya dobladas desde el principio) no
// cumpla nunca este paso 1 y por tanto nunca llegue a checkWallSitPosture.
const WALLSIT_STANDING_MIN_VISIBILITY = 0.4;
const WALLSIT_STANDING_KNEE_MIN_DEG = 160;
const WALLSIT_STANDING_HIP_MIN_DEG = 160;
const WALLSIT_STANDING_STABLE_MS = 600; // mismo margen que ON_GROUND_STABLE_MS

function checkStanding(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lH = lm[L_HIP], rH = lm[R_HIP];
  const lK = lm[L_KNEE], rK = lm[R_KNEE];
  const lA = lm[L_ANKLE], rA = lm[R_ANKLE];

  const leftVis = ((lS.visibility ?? 1) + (lH.visibility ?? 1) + (lK.visibility ?? 1) + (lA.visibility ?? 1)) / 4;
  const rightVis = ((rS.visibility ?? 1) + (rH.visibility ?? 1) + (rK.visibility ?? 1) + (rA.visibility ?? 1)) / 4;
  const useLeft = leftVis >= rightVis;
  const sideVis = useLeft ? leftVis : rightVis;

  if (sideVis < WALLSIT_STANDING_MIN_VISIBILITY) {
    return { ok: false, visible: false, kneeAngle: null, hipAngle: null };
  }

  const shoulder = useLeft ? lS : rS;
  const hip = useLeft ? lH : rH;
  const knee = useLeft ? lK : rK;
  const ankle = useLeft ? lA : rA;

  const kneeAngle = angle(hip, knee, ankle);
  const hipAngle = angle(shoulder, hip, knee);
  const ok =
    kneeAngle !== null && kneeAngle >= WALLSIT_STANDING_KNEE_MIN_DEG &&
    hipAngle !== null && hipAngle >= WALLSIT_STANDING_HIP_MIN_DEG;

  return {
    ok,
    visible: true,
    kneeAngle: kneeAngle === null ? null : kneeAngle.toFixed(0),
    hipAngle: hipAngle === null ? null : hipAngle.toFixed(0),
  };
}

// A diferencia de plancha/plancha lateral/silla en pared, aquí SÍ hace
// falta comprobar que sigues colgada/o de la barra (brazos estirados,
// agarre activo) — no solo la postura de las piernas. Se reutiliza el
// mismo margen que ya usan las dominadas (HANG_MARGIN_FACTOR): cuánto
// tienen que estar las muñecas por encima de los hombros para contar
// como "colgado".
//
// De frente a la cámara (no de perfil, como plancha/silla en pared): al
// colgarte de una barra ya te pones mirando hacia ella, así que pedir
// perfil sería forzar una postura rara. De frente también se ven bien
// los dos lados a la vez (hombros, cadera, rodillas, muñecas), así que
// aquí se promedian izquierda y derecha en vez de elegir "el lado mejor
// visto" como en los ejercicios de perfil.
const KNEEHOLDBAR_MIN_VISIBILITY = 0.4;
// Se probaron dos versiones anteriores antes de esta: un ángulo en
// cadera+rodilla (con un punto ciego de frente a la cámara, ver commits
// previos), y luego la distancia cadera-tobillo (normalizada por el ancho
// de hombros) — que sobre el papel tenía sentido (colgada/o con la pierna
// estirada el tobillo queda lejos de la cadera; al "encoger" se acerca),
// pero en la práctica NUNCA llegaba a marcar bien, según lo reportado y
// confirmado con el registro de depuración real: raiseRatio se quedaba
// entre 1.2 y 4 sin bajar de 1.0 por mucho que se subieran las rodillas a
// la altura de la cadera de verdad.
//
// El fallo: "subir las rodillas a la altura de la cadera" no significa
// que el TOBILLO se acerque a la cadera — con la rodilla doblada en
// ángulo (la espinilla colgando hacia abajo desde la rodilla, no pegada
// al muslo, que es justo la postura pedida — ver KNEEHOLDBAR_TIPS/
// notePostureOk), el tobillo se queda por debajo de la rodilla y por
// tanto lejos de la cadera, aunque el MUSLO (y la rodilla) ya estén
// perfectamente a la altura de la cadera. Medir tobillo-cadera es medir
// lo que sube el tobillo, no lo que sube la rodilla — y son cosas
// distintas en cuanto la rodilla se dobla.
//
// Ahora se mide directamente lo que se pide: la altura (posición Y en la
// imagen) de la rodilla respecto a la cadera, nada de distancias con el
// tobillo ni el propio tobillo como punto necesario — con la cámara de
// frente (confirmado: así se usa este ejercicio), subir el muslo hasta
// la cadera se ve directamente como que la rodilla sube en la imagen
// hasta quedar a la altura de la cadera o más arriba. Se normaliza por
// el ancho de hombros (no por el torso cadera-hombro: colgada/o con los
// brazos estirados por encima de la cabeza el torso se estira hacia
// arriba, así que usarlo de referencia encogía el margen también con las
// piernas quietas).
const KNEEHOLDBAR_KNEE_HIP_MAX_GAP_FACTOR = 0.4;

export function checkKneeHoldBarPosture(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lH = lm[L_HIP], rH = lm[R_HIP];
  const lK = lm[L_KNEE], rK = lm[R_KNEE];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];

  // Ya no hace falta el tobillo (ver más arriba el porqué) — con eso
  // fuera, la rodilla es el punto más "exigente" y de frente, encogida o
  // no, suele verse bien.
  if ([lS, rS, lH, rH, lK, rK, lW, rW].some((p) => (p.visibility ?? 1) < KNEEHOLDBAR_MIN_VISIBILITY)) {
    return {
      ok: false,
      reason: "No se te ve entera/o. Ponte de frente a la cámara, algo alejada/o, para que se vea todo el cuerpo colgado, de las manos a las rodillas.",
      debug: { fail: "vis" },
    };
  }

  const shoulderMid = { x: (lS.x + rS.x) / 2, y: (lS.y + rS.y) / 2 };
  const hipMidY = (lH.y + rH.y) / 2;
  const kneeMidY = (lK.y + rK.y) / 2;
  const wristMidY = (lW.y + rW.y) / 2;
  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y);

  const debug = {
    hanging: shoulderWidth ? (wristMidY < shoulderMid.y - HANG_MARGIN_FACTOR * shoulderWidth ? "sí" : "no") : null,
  };

  if (!shoulderWidth || wristMidY >= shoulderMid.y - HANG_MARGIN_FACTOR * shoulderWidth) {
    return { ok: false, reason: "No pareces estar colgada/o de la barra — agárrate con los brazos estirados.", debug };
  }

  // Y crece hacia abajo en la imagen: positivo = la rodilla queda por
  // debajo de la cadera (sin subir todavía), negativo o cero = la
  // rodilla ya está a la altura de la cadera o por encima.
  const kneeHipGap = (kneeMidY - hipMidY) / shoulderWidth;
  debug.kneeHipGap = kneeHipGap.toFixed(2);

  if (kneeHipGap > KNEEHOLDBAR_KNEE_HIP_MAX_GAP_FACTOR) {
    return { ok: false, reason: "Dobla más las rodillas, subiéndolas hasta dejarlas más o menos a la altura de la cadera.", debug };
  }
  return { ok: true, debug };
}

// Paso 1 de kneehold en barra (ver postureGroundConfirmed en processPosture,
// mismo patrón de dos pasos que plancha/plancha lateral): antes de pedir
// que subas las rodillas hace falta confirmar que ya te has agarrado a la
// barra — solo mira hombros y muñecas (ni cadera ni tobillo), así que
// vale aunque todavía no se te vea entero/a en el encuadre (por ejemplo,
// mientras te estás colocando). Con esto, el aviso de "no se te ve" que
// antes salía sin más mientras te acercabas a la barra pasa a ser un
// "ve y agárrate a la barra" bien concreto — ver postureWaitingMessage.
//
// Devuelve también "visible" (hombros y muñecas detectados, da igual si
// ya estás colgada/o o no) por separado de "ok" (además colgada/o de
// verdad) — así, en processPosture, se puede avisar por voz nada más
// verte aparecer en la cámara ("Te veo. ¡Listo! Cuélgate…"), igual que
// hace dominadas con startupVoiceGiven, sin esperar a que ya estés
// colgada/o para decir nada.
function checkKneeHoldBarHanging(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];

  const visible = ![lS, rS, lW, rW].some((p) => (p.visibility ?? 1) < KNEEHOLDBAR_MIN_VISIBILITY);
  if (!visible) {
    return { ok: false, visible: false };
  }

  const shoulderMidY = (lS.y + rS.y) / 2;
  const wristMidY = (lW.y + rW.y) / 2;
  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y);
  if (!shoulderWidth || wristMidY >= shoulderMidY - HANG_MARGIN_FACTOR * shoulderWidth) {
    return { ok: false, visible: true };
  }
  return { ok: true, visible: true };
}

// Pino (handstand): a diferencia de dead hang (ver historial de este
// archivo más abajo — un caso especialmente difícil, con varios intentos
// descartados, porque "colgarte" y "estar de pie estirando los brazos"
// se ven casi igual para MediaPipe), un pino no tiene ese problema de
// raíz: el cuerpo entero queda INVERTIDO, con la cadera por encima de
// los hombros en la imagen — algo que ninguna postura normal (de pie,
// agachada/o, o incluso tocándose los pies) puede producir. Esa única
// señal ya distingue un pino de cualquier otra cosa sin ambigüedad, así
// que no hace falta ningún truco de suavizado ni de referencia personal
// como los que sí hicieron falta en dead hang.
//
// Solo dos condiciones, tal y como se pidió: la cadera por encima de
// los hombros (cuerpo invertido) y los codos/muñecas por debajo de la
// cadera (los brazos aguantando el peso cerca del suelo, no estirados
// hacia arriba). No se exige nada de las piernas — ni que estén rectas
// ni que se vean siquiera — porque en un pino real los pies suelen
// salirse del encuadre (sobre todo con apoyo en la pared, muy cerca de
// esta), y exigir visibilidad ahí solo generaría fallos falsos por
// encuadre, no por mala postura.
//
// Sin paso 1 de confirmación (a diferencia de plancha/kneehold/dead
// hang): con una señal tan clara no hace falta pedir una postura
// intermedia antes de la de verdad — mismo criterio que silla en pared
// (ver checkWallSitPosture y postureWaitingMessage/processPosture, más
// abajo, donde "handstand" tampoco entra en el paso 1).
//
// Vale igual con o sin apoyo (pared, compañera/o…): la cámara no ve la
// pared, así que la postura del cuerpo que se mide es la misma se apoye
// o no — no hace falta ninguna lógica aparte para cada caso.
const HANDSTAND_MIN_VISIBILITY = 0.35; // algo más laxo que el resto: bocabajo, MediaPipe pierde algo de confianza y no debe tumbar la cuenta por eso
// Margen relativo al ancho de hombros, igual que HANG_MARGIN_FACTOR en
// dead hang/kneehold — pequeño a propósito, para que baste con estar
// claramente invertida/o o con los brazos claramente abajo, sin exigir
// una separación exagerada que sea fácil de perder por el balanceo
// normal de un pino.
const HANDSTAND_MARGIN_FACTOR = 0.08;

export function checkHandstandPosture(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lE = lm[L_ELBOW], rE = lm[R_ELBOW];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];
  const lH = lm[L_HIP], rH = lm[R_HIP];

  if ([lS, rS, lE, rE, lW, rW, lH, rH].some((p) => (p.visibility ?? 1) < HANDSTAND_MIN_VISIBILITY)) {
    return {
      ok: false,
      reason: "No se te ve entera/o. Ponte de forma que se vean las manos, los brazos y la cadera en el encuadre.",
      debug: { fail: "vis" },
    };
  }

  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y);
  if (!shoulderWidth) {
    return { ok: false, reason: "No se te ve bien. Aléjate un poco de la cámara.", debug: { fail: "vis" } };
  }
  const margin = HANDSTAND_MARGIN_FACTOR * shoulderWidth;

  const shoulderMidY = (lS.y + rS.y) / 2;
  const elbowMidY = (lE.y + rE.y) / 2;
  const wristMidY = (lW.y + rW.y) / 2;
  const hipMidY = (lH.y + rH.y) / 2;

  const debug = {
    invertido: hipMidY < shoulderMidY - margin ? "sí" : "no",
  };

  // Y crece hacia abajo en la imagen: la cadera tiene que quedar POR
  // ENCIMA de los hombros (Y menor) para que el cuerpo esté invertido.
  if (hipMidY >= shoulderMidY - margin) {
    return { ok: false, reason: "Todavía no pareces estar en el pino — sube la cadera por encima de los hombros.", debug };
  }

  // Brazos por debajo de la cintura: codos y muñecas por debajo de la
  // cadera en la imagen (Y mayor), como pide el ejercicio — manos en el
  // suelo aguantando el peso, no estiradas hacia arriba.
  if (elbowMidY <= hipMidY + margin || wristMidY <= hipMidY + margin) {
    return { ok: false, reason: "Lleva los brazos hacia el suelo, por debajo de la cadera.", debug };
  }

  return { ok: true, debug };
}

// Estiramiento cruzado de brazo (cross-body / posterior deltoid
// stretch): primero de una futura familia de estiramientos con cámara,
// pensados para "Deporte -> Estiramientos y calentamientos"
// (Task.SUBCATEGORY_WARMUP, ver tasks/models.py). Sigue el mismo patrón
// de dos pasos que silla en pared/kneehold en barra (ver
// postureGroundConfirmed en processPosture): paso 1 confirma la postura
// "standby" (de pie, relajada/o, con los brazos sueltos a los lados -
// checkStandbyPosture, pensada para reutilizarse tal cual en futuros
// estiramientos) y paso 2 pide la postura del estiramiento en sí
// (checkArmCrossStretch).
//
// No hace falta decir qué brazo toca primero: se comprueban los dos
// lados (izquierdo estirado/derecho agarra, o al revés) y vale
// cualquiera de los dos - así, sin lógica aparte, se puede hacer un
// lado, volver a standby (closeActivePostureSet pide reconfirmar el
// paso 1 para este ejercicio en concreto, a diferencia del resto de
// CAMERA_POSTURE_COUNTERS - ver closeActivePostureSet), y hacer el
// otro; cada aguante cuenta como una serie aparte, igual que cualquier
// otro ejercicio isométrico (ver _flushPostureHold).
//
// La cuenta atrás/adelante hablada hacia el objetivo (30s por defecto,
// ver DEFAULT_STRETCH_TARGET_SECONDS) reutiliza tal cual el mismo
// mecanismo que ya tienen plancha/silla en pared/etc. (ver
// notePostureOk): cuenta atrás mientras falta, y en cuanto se llega,
// pasa a contar hacia ADELANTE los segundos de propina.
//
// Umbrales de partida, sin probar en cámara real todavía (mismo caso
// que tuvieron en su día flexión inclinada o fondos en banco al
// añadirse) - pendientes de ajustar según lo que se reporte
// probándolos de verdad delante de la cámara.
const STRETCH_MIN_VISIBILITY = 0.4;
const STRETCH_STANDBY_ELBOW_MIN_DEG = 150; // brazo casi recto, colgando -> standby
const STRETCH_STANDBY_WRIST_BELOW_SHOULDER_FACTOR = 0.15; // cuánto por debajo del hombro tiene que quedar la muñeca (proporción al ancho de hombros)
const STRETCH_STANDBY_STABLE_MS = 500;
const STRETCH_ARM_CROSS_MIN_ELBOW_DEG = 90; // brazo que se estira: bastante recto, no doblado del todo (más margen: en la práctica, sujetando/tirando del brazo, el ángulo baja de vez en cuando incluso en repeticiones que sí valen - ver notas 2026-09-05)
const STRETCH_CROSS_MIN_FRACTION = 0.5; // la muñeca del brazo estirado tiene que haber recorrido, en horizontal, al menos esta fracción de la distancia hasta el hombro contrario (0 = no se ha movido de su propio hombro, 1 = ha llegado exactamente al hombro contrario) - esto es lo que de verdad distingue "brazo cruzado" de "brazo colgando en standby", sea cual sea el ancho de hombros o el encuadre de la cámara
const STRETCH_WRIST_HEIGHT_MAX_FACTOR = 3.2; // muñeca del brazo estirado, a una altura parecida a la del hombro (ni muy arriba ni muy abajo) - umbral amplio, ver notas de calibración 2026-09-05
const STRETCH_GRAB_MAX_FACTOR = 2.4; // muñeca del brazo que agarra, cerca del codo del brazo estirado - umbral amplio, ver notas de calibración 2026-09-05
// Antes en 600ms, igual que PLANK_INVALID_STABLE_MS - tenía sentido para
// plancha (si ya estás en posición, 600ms seguidos "mal" es que de
// verdad la has roto), pero aquí paso 2 empieza en standby y hay que
// MOVER un brazo entero, cruzarlo y agarrarlo - un gesto deliberado que
// lleva bastante más de 600ms. Con un registro real (build v6, ver
// notas 2026-09-05) se ve clarísimo: en CADA intento fallido, pasan
// entre 600 y 700ms de "postura incorrecta" y entonces salta de vuelta
// a pedir standby desde cero - incluso en un intento (21.2-21.5s del
// registro) donde el brazo derecho SÍ llegaba a cruzar del todo
// (cruce=1.06, codo=99°, igual de bien que cuando el izquierdo sí
// cuenta), el reinicio a standby llegaba antes de que esos ~200ms de
// postura correcta pudieran acumular los STRETCH_FLICKER_STABLE_MS
// necesarios para confirmarse - o sea, el problema no era la geometría
// ni los umbrales (que ya estaban bien), era que el temporizador de
// "date por vencido, vuelve a standby" no daba tiempo ni de terminar el
// gesto. Subido a un margen mucho más generoso para dar tiempo real a
// cruzar el brazo y agarrarlo sin que la propia comprobación te corte
// a medias.
const STRETCH_INVALID_STABLE_MS = 3000;
const STRETCH_FLICKER_STABLE_MS = 300;
const DEFAULT_STRETCH_TARGET_SECONDS = 30;
// Contadores de estiramiento que, sin objetivo propio (fuera de un plan
// o circuito), arrancan igualmente con una cuenta atrás por defecto en
// vez de contar libremente desde 0 - ver el constructor de
// WorkoutSession, más abajo.
const STRETCH_HOLD_COUNTERS = new Set(["armcrossstretch", "tricepsoverheadstretch", "seatedhamstringstretch", "standingquadstretch"]);

/**
 * Paso 1 de cualquier estiramiento: posición "standby" - de pie,
 * relajada/o, con los brazos sueltos a los lados. Pensada para
 * reutilizarse tal cual en futuros estiramientos (no solo el cruzado de
 * brazo), igual que checkStanding ya se reutiliza para silla en pared.
 */
function checkStandbyPosture(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lE = lm[L_ELBOW], rE = lm[R_ELBOW];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];

  const visible = ![lS, rS, lE, rE, lW, rW].some((p) => (p.visibility ?? 1) < STRETCH_MIN_VISIBILITY);
  if (!visible) return { ok: false, visible: false };

  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y);
  if (!shoulderWidth) return { ok: false, visible: true };
  const shoulderMidY = (lS.y + rS.y) / 2;

  const lElbowAngle = angle(lS, lE, lW);
  const rElbowAngle = angle(rS, rE, rW);
  const armsStraight =
    lElbowAngle !== null && lElbowAngle >= STRETCH_STANDBY_ELBOW_MIN_DEG &&
    rElbowAngle !== null && rElbowAngle >= STRETCH_STANDBY_ELBOW_MIN_DEG;
  const wristsDown =
    lW.y > shoulderMidY + STRETCH_STANDBY_WRIST_BELOW_SHOULDER_FACTOR * shoulderWidth &&
    rW.y > shoulderMidY + STRETCH_STANDBY_WRIST_BELOW_SHOULDER_FACTOR * shoulderWidth;

  return { ok: Boolean(armsStraight && wristsDown), visible: true };
}

/**
 * Paso 2: estiramiento cruzado de brazo - un brazo se estira hacia el
 * lado contrario, más o menos a la altura del hombro y bastante recto,
 * y el otro lo agarra por el codo (o cerca), tirando de él hacia el
 * pecho. Se comprueban los dos lados posibles (izquierdo estirado o
 * derecho estirado) y se devuelve el primero que encaje - ver el
 * comentario junto a STRETCH_HOLD_COUNTERS para el porqué de no exigir
 * un lado concreto.
 */
export function checkArmCrossStretch(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lE = lm[L_ELBOW], rE = lm[R_ELBOW];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];

  if ([lS, rS, lE, rE, lW, rW].some((p) => (p.visibility ?? 1) < STRETCH_MIN_VISIBILITY)) {
    // Antes esto solo decía "fail: vis" sin más - no había forma de saber,
    // mirando el registro, si lo que perdía visibilidad era justo el lado
    // que se estaba intentando estirar (indicio de un problema de encuadre
    // u oclusión en ESE lado en concreto) o cualquier otra cosa. Con los
    // números de visibilidad de cada articulación se puede distinguir -
    // ver notas de calibración 2026-09-05 (el brazo derecho seguía sin
    // contar incluso con la fracción de cruce ya corregida).
    return {
      ok: false,
      reason: "No se te ve entera/o. Ponte de frente a la cámara, algo alejada/o, para que se vean los dos brazos enteros.",
      debug: {
        fail: "vis",
        "vis-izq-hombro": (lS.visibility ?? 1).toFixed(2),
        "vis-izq-codo": (lE.visibility ?? 1).toFixed(2),
        "vis-izq-muneca": (lW.visibility ?? 1).toFixed(2),
        "vis-der-hombro": (rS.visibility ?? 1).toFixed(2),
        "vis-der-codo": (rE.visibility ?? 1).toFixed(2),
        "vis-der-muneca": (rW.visibility ?? 1).toFixed(2),
      },
    };
  }

  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y);
  if (!shoulderWidth) {
    return { ok: false, reason: "No se te ve entera/o. Ponte de frente a la cámara.", debug: { fail: "vis" } };
  }
  const shoulderMidY = (lS.y + rS.y) / 2;

  function evalSide(extShoulder, extElbow, extWrist, otherShoulder, otherWrist) {
    const extElbowAngle = angle(extShoulder, extElbow, extWrist);
    // Cuánto ha cruzado la muñeca hacia el hombro contrario, en horizontal,
    // como fracción de la distancia entre los dos hombros - en vez de una
    // distancia absoluta (que depende del ancho de hombros Y de la relación
    // de aspecto de la cámara, muy poco fiable, ver notas 2026-09-05). Signo
    // relativo a la propia postura, así que no depende de si la imagen viene
    // reflejada o no.
    const acrossDir = otherShoulder.x - extShoulder.x;
    const wristAcross = extWrist.x - extShoulder.x;
    const crossFraction = acrossDir === 0 ? 0 : wristAcross / acrossDir;
    const crossedEnough = crossFraction >= STRETCH_CROSS_MIN_FRACTION;
    const wristHeightOffset = Math.abs(extWrist.y - shoulderMidY) / shoulderWidth;
    const grabDist = Math.hypot(otherWrist.x - extElbow.x, otherWrist.y - extElbow.y) / shoulderWidth;
    const ok =
      extElbowAngle !== null && extElbowAngle >= STRETCH_ARM_CROSS_MIN_ELBOW_DEG &&
      crossedEnough &&
      wristHeightOffset <= STRETCH_WRIST_HEIGHT_MAX_FACTOR &&
      grabDist <= STRETCH_GRAB_MAX_FACTOR;
    return {
      ok,
      debug: {
        codo: extElbowAngle === null ? null : extElbowAngle.toFixed(0),
        cruce: crossFraction.toFixed(2),
        alturaMuneca: wristHeightOffset.toFixed(2),
        agarre: grabDist.toFixed(2),
      },
    };
  }

  const leftExtends = evalSide(lS, lE, lW, rS, rW);  // brazo izquierdo se estira, el derecho agarra
  const rightExtends = evalSide(rS, rE, rW, lS, lW); // brazo derecho se estira, el izquierdo agarra

  if (leftExtends.ok) return { ok: true, side: "left", debug: leftExtends.debug };
  if (rightExtends.ok) return { ok: true, side: "right", debug: rightExtends.debug };

  // Antes, aquí se devolvía siempre leftExtends.debug sin más - así que en
  // cualquier fallo con el brazo DERECHO estirado, el registro de
  // depuración mostraba los números de la hipótesis "brazo izquierdo
  // estirado" (que no tiene nada que ver con lo que la persona está
  // haciendo), dando datos sin sentido para calibrar ese lado - ver notas
  // de calibración 2026-09-05. Ahora se devuelven los dos lados por
  // separado, con prefijo, para poder ver de verdad cuál de los dos
  // estaba más cerca de valer y por qué.
  return {
    ok: false,
    reason: "Estira un brazo hacia el lado contrario, más o menos a la altura del hombro, y agárralo con el otro brazo por el codo, tirando de él hacia el pecho.",
    debug: {
      "izq-codo": leftExtends.debug.codo,
      "izq-cruce": leftExtends.debug.cruce,
      "izq-altura": leftExtends.debug.alturaMuneca,
      "izq-agarre": leftExtends.debug.agarre,
      "der-codo": rightExtends.debug.codo,
      "der-cruce": rightExtends.debug.cruce,
      "der-altura": rightExtends.debug.alturaMuneca,
      "der-agarre": rightExtends.debug.agarre,
    },
  };
}

// Estiramiento de tríceps por encima de la cabeza (overhead triceps
// stretch): segundo de la familia de estiramientos con cámara (ver el
// comentario junto a checkArmCrossStretch para el porqué de la familia
// y el patrón de dos pasos). Reutiliza tal cual checkStandbyPosture
// como paso 1.
//
// A diferencia del cruzado de brazo (brazo estirado, cruzando el
// pecho en horizontal), aquí el brazo que se estira va DOBLADO por el
// codo y ARRIBA, con la mano cayendo por detrás de la nuca/omóplato
// contrario, y el otro brazo sube para agarrar el codo (no la mano) y
// tirar de él hacia el centro/abajo. Pedido explícitamente de frente a
// la cámara (igual que el cruzado) — no hace falta perfil, y así se ven
// los dos brazos y la cabeza a la vez para las tres comprobaciones de
// abajo.
//
// Se comprueban los dos lados posibles (izquierdo doblado/derecho
// agarra, o al revés) igual que en checkArmCrossStretch, sin exigir un
// lado concreto — misma razón: alternar brazos sin lógica aparte,
// contando cada aguante como una serie aparte (STRETCH_HOLD_COUNTERS).
//
// Umbrales ajustados a partir de un registro real de cámara (primera
// prueba en vivo): con los valores iniciales el check nunca llegaba a
// confirmarse - "ok" parpadeaba frame a frame porque el ángulo de codo
// rondaba/superaba el límite y sobre todo porque "muñecaCabeza" y
// "agarre" oscilaban muchísimo entre frames consecutivos del mismo
// intento (p.ej. muñecaCabeza saltando de ~0.4 a ~4.0), por el ruido de
// tracking al estar esa muñeca semioculta detrás de la cabeza.
// alturaCodo se deja igual porque en el registro nunca fue el cuello
// de botella (en standby/de pie daba valores muy negativos, con mucho
// margen respecto al umbral).
const STRETCH_TRICEPS_ELBOW_MAX_DEG = 130; // ampliado de 100: en aguantes válidos del registro real el ángulo rondaba/superaba 100°
const STRETCH_TRICEPS_ELBOW_HIGH_FACTOR = 0.25; // sin cambios: nunca fue el cuello de botella en el registro real
const STRETCH_TRICEPS_WRIST_NEAR_HEAD_MAX_FACTOR = 2.2; // ampliado de 1.1: muy ruidoso por la oclusión parcial de la muñeca detrás de la cabeza
const STRETCH_TRICEPS_GRAB_MAX_FACTOR = 2.4; // ampliado de 1.3, igualado al umbral ya probado en producción para el cruzado de brazo (STRETCH_GRAB_MAX_FACTOR)

// La muñeca del brazo que se dobla queda parcialmente tapada por la
// cabeza al meterse detrás de la nuca (vista de frente) - MediaPipe
// refleja eso con visibility baja para ESA muñeca en concreto (se vio
// hasta 0.09 en el registro real, con la postura por lo demás
// correcta), aunque el resto del cuerpo se vea perfectamente. Exigirle
// el mismo umbral que a hombros/codos/muñeca que agarra (que sí deben
// verse enteros) forzaba "no se te ve" de forma constante y sumaba al
// parpadeo. Se usa un umbral mucho más permisivo solo para esa muñeca.
const STRETCH_TRICEPS_BENT_WRIST_MIN_VISIBILITY = 0.05; // bajado de 0.12: en el registro real la muneca doblada bajaba a 0.13 en aguantes validos
const STRETCH_TRICEPS_GRAB_WRIST_MIN_VISIBILITY = 0.25; // dedicado (antes reusaba STRETCH_MIN_VISIBILITY=0.4): la muneca que agarra tambien se vio bajar a ~0.41 en aguantes validos, justo en el borde del umbral estricto

/**
 * Paso 2 del estiramiento de tríceps: un brazo se dobla por el codo,
 * levantado, con la mano cayendo por detrás de la nuca, y el otro
 * brazo sube y agarra ese codo (no la mano) tirando de él hacia el
 * centro. Se comprueban los dos lados posibles y se devuelve el
 * primero que encaje - ver el comentario junto a esta función para el
 * porqué de no exigir un lado concreto.
 */
export function checkTricepsOverheadStretch(lm) {
  const nose = lm[NOSE];
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lE = lm[L_ELBOW], rE = lm[R_ELBOW];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];

  // Solo hombros/codos exigen visibilidad estricta aquí: son los puntos
  // que hacen falta para la geometría de los dos lados. La visibilidad
  // de cada muñeca se comprueba dentro de evalSide(), con un umbral
  // distinto según el papel (la que se dobla puede quedar tapada por
  // la cabeza; la que agarra no debería).
  if ([nose, lS, rS, lE, rE].some((p) => (p.visibility ?? 1) < STRETCH_MIN_VISIBILITY)) {
    return {
      ok: false,
      reason: "No se te ve entera/o. Ponte de frente a la cámara, algo alejada/o, para que se vean los dos brazos y la cabeza enteros.",
      debug: {
        fail: "vis",
        "vis-izq-hombro": (lS.visibility ?? 1).toFixed(2),
        "vis-izq-codo": (lE.visibility ?? 1).toFixed(2),
        "vis-der-hombro": (rS.visibility ?? 1).toFixed(2),
        "vis-der-codo": (rE.visibility ?? 1).toFixed(2),
      },
    };
  }

  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y);
  if (!shoulderWidth) {
    return { ok: false, reason: "No se te ve entera/o. Ponte de frente a la cámara.", debug: { fail: "vis" } };
  }
  const shoulderMidY = (lS.y + rS.y) / 2;

  function evalSide(bentShoulder, bentElbow, bentWrist, grabWrist) {
    // La muñeca que se dobla puede estar parcialmente tapada por la
    // cabeza (umbral permisivo); la que agarra tiene que verse normal.
    const bentWristVisible = (bentWrist.visibility ?? 1) >= STRETCH_TRICEPS_BENT_WRIST_MIN_VISIBILITY;
    const grabWristVisible = (grabWrist.visibility ?? 1) >= STRETCH_TRICEPS_GRAB_WRIST_MIN_VISIBILITY;
    const bentElbowAngle = angle(bentShoulder, bentElbow, bentWrist);
    // Y crece hacia abajo en la imagen: el codo tiene que quedar POR
    // ENCIMA de los hombros (Y menor), cerca de la cabeza.
    const elbowHeightOffset = (shoulderMidY - bentElbow.y) / shoulderWidth;
    const elbowHigh = elbowHeightOffset >= STRETCH_TRICEPS_ELBOW_HIGH_FACTOR;
    const wristNearHead = Math.hypot(bentWrist.x - nose.x, bentWrist.y - nose.y) / shoulderWidth;
    const grabDist = Math.hypot(grabWrist.x - bentElbow.x, grabWrist.y - bentElbow.y) / shoulderWidth;
    const ok =
      bentWristVisible && grabWristVisible &&
      bentElbowAngle !== null && bentElbowAngle <= STRETCH_TRICEPS_ELBOW_MAX_DEG &&
      elbowHigh &&
      wristNearHead <= STRETCH_TRICEPS_WRIST_NEAR_HEAD_MAX_FACTOR &&
      grabDist <= STRETCH_TRICEPS_GRAB_MAX_FACTOR;
    return {
      ok,
      debug: {
        codo: bentElbowAngle === null ? null : bentElbowAngle.toFixed(0),
        alturaCodo: elbowHeightOffset.toFixed(2),
        munecaCabeza: wristNearHead.toFixed(2),
        agarre: grabDist.toFixed(2),
        visMunecaDoblada: (bentWrist.visibility ?? 1).toFixed(2),
        visMunecaAgarre: (grabWrist.visibility ?? 1).toFixed(2),
      },
    };
  }

  const leftBends = evalSide(lS, lE, lW, rW);  // brazo izquierdo se dobla, el derecho agarra el codo
  const rightBends = evalSide(rS, rE, rW, lW); // brazo derecho se dobla, el izquierdo agarra el codo

  if (leftBends.ok) return { ok: true, side: "left", debug: leftBends.debug };
  if (rightBends.ok) return { ok: true, side: "right", debug: rightBends.debug };

  return {
    ok: false,
    reason: "Dobla un brazo por el codo, llevando la mano por detrás de la nuca, y con el otro brazo agarra ese codo (no la mano) tirando de él hacia el centro.",
    debug: {
      "izq-codo": leftBends.debug.codo,
      "izq-alturaCodo": leftBends.debug.alturaCodo,
      "izq-munecaCabeza": leftBends.debug.munecaCabeza,
      "izq-agarre": leftBends.debug.agarre,
      "der-codo": rightBends.debug.codo,
      "der-alturaCodo": rightBends.debug.alturaCodo,
      "der-munecaCabeza": rightBends.debug.munecaCabeza,
      "der-agarre": rightBends.debug.agarre,
    },
  };
}

// Estiramiento de isquiotibiales sentado: tercero de la familia de
// estiramientos ISOMÉTRICOS con cámara (ver el comentario junto a
// checkArmCrossStretch para el porqué de la familia y el patrón de dos
// pasos). Reutiliza tal cual checkStandbyPosture como paso 1 — de pie,
// relajada/o, exactamente igual que los dos anteriores; solo cambia el
// paso 2, que aquí se hace SENTADO EN EL SUELO (transición de pie a
// sentado entre paso 1 y paso 2, mismo espíritu que plancha, que pasa
// de tumbado boca arriba a boca abajo).
//
// A DIFERENCIA del cruzado de brazo/tríceps (de frente, para ver los
// dos brazos a la vez), este se pide DE PERFIL a la cámara: hace falta
// medir el ángulo cadera-rodilla-tobillo de la pierna que se estira
// (ver angle(), pensada para verse bien "de perfil" — de frente, una
// pierna apuntando hacia la cámara sale escorzada y el ángulo es puro
// ruido), igual que sentadillas/silla en pared/rodillas altas/talones
// al glúteo.
//
// Se comprueban las dos piernas posibles (izquierda estirada/derecha
// estirada) y se devuelve la primera que encaje — igual razón que en
// checkArmCrossStretch: alternar pierna sin lógica aparte, cada aguante
// cuenta como una serie aparte (STRETCH_HOLD_COUNTERS).
//
// Geometría: la pierna que se estira tiene que quedar (1) casi recta
// (ángulo cadera-rodilla-tobillo alto) y (2) a la altura del suelo — la
// cadera casi a la misma altura en la imagen que el tobillo de esa
// pierna, para distinguir "sentada/o en el suelo con la pierna
// estirada" de, por ejemplo, quedarte de pie e inclinarte a tocarte la
// punta del pie (que también deja la rodilla recta y la mano cerca del
// tobillo, pero con la cadera bien por encima) — y (3) alguna de las
// dos muñecas cerca del tobillo de esa pierna, agarrando el pie/tobillo
// para forzar el estiramiento (no importa cuál de las dos manos, igual
// que checkArmCrossStretch no exige un brazo concreto).
//
// Umbrales de partida, sin probar en cámara real todavía (mismo caso
// que tuvieron cruzado de brazo/tríceps al añadirse) — pendientes de
// ajustar según lo que se reporte probándolos de verdad delante de la
// cámara.
const STRETCH_HAMSTRING_MIN_VISIBILITY = 0.3; // algo más permisivo que STRETCH_MIN_VISIBILITY (0.4): de perfil, la pierna/mano del lado más lejano a la cámara queda parcialmente tapada por el propio cuerpo
const STRETCH_HAMSTRING_KNEE_MIN_DEG = 120; // v2: bajado de 150 (primer registro real, 2026-09-06) — igual que STRETCH_ARM_CROSS_MIN_ELBOW_DEG (90, mismo motivo: tirar del pie con la mano dobla la pierna algo más de lo esperado incluso en aguantes que sí valen), aguantes con buena pinta en el registro real oscilaban 120-180° frame a frame, así que 150 cortaba de forma intermitente ("a veces cuenta a veces no") exactamente lo que se buscaba contar
const STRETCH_HAMSTRING_HIP_ANKLE_MAX_FACTOR = 1.8; // v2: subido de 1.1 (primer registro real, 2026-09-06) — sentada/o de perfil e inclinándote hacia delante para agarrar el pie, la cadera se separa del suelo/tobillo más de lo previsto; sigue muy por debajo de las "varias veces el ancho de hombros" que da estar de pie, así que no debería colar standing como si fuera el estiramiento
const STRETCH_HAMSTRING_GRAB_MAX_FACTOR = 0.8; // v3: bajado de 2.4 (prueba real 2026-09-07: con la mano entre la rodilla y la cadera -- muy lejos del pie -- seguía dando ok). El v2 igualaba este umbral al de cruzado de brazo/tríceps, pero ahí la distancia es muñeca-codo (antebrazo); aquí es muñeca-tobillo a lo largo de TODA la pierna, una escala mucho mayor, así que el mismo factor no significa lo mismo -- necesita su propio umbral, mucho más ajustado (mano de verdad cerca del pie/tobillo). v4: pedido explícito del usuario -- "que sea a partir del tobillo, no el tobillo en concreto": la distancia ya no se mide al tobillo como PUNTO, sino al SEGMENTO tobillo-punta del pie (ver distanceToSegment/L_FOOT_INDEX/R_FOOT_INDEX), así que agarrar más adelante hacia los dedos también cuenta, no solo justo el tobillo

export function checkSeatedHamstringStretch(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lH = lm[L_HIP], rH = lm[R_HIP];
  const lK = lm[L_KNEE], rK = lm[R_KNEE];
  const lA = lm[L_ANKLE], rA = lm[R_ANKLE];
  const lF = lm[L_FOOT_INDEX], rF = lm[R_FOOT_INDEX];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];

  if ([lS, rS, lH, rH, lK, rK, lA, rA].some((p) => (p.visibility ?? 1) < STRETCH_HAMSTRING_MIN_VISIBILITY)) {
    return {
      ok: false,
      reason: "No se te ve entera/o. Siéntate de perfil a la cámara, algo alejada/o, para que se vean la cadera, las rodillas y los tobillos de las dos piernas.",
      debug: { fail: "vis" },
    };
  }

  const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y);
  if (!shoulderWidth) {
    return { ok: false, reason: "No se te ve entera/o. Ponte de perfil a la cámara.", debug: { fail: "vis" } };
  }

  // Segmento tobillo->punta del pie para medir "agarre": si la punta del
  // pie no se ve bien (oclusión de perfil, calzado que MediaPipe no capta
  // tan fiable como el tobillo), el segmento colapsa al propio tobillo
  // (mismo comportamiento que antes) en vez de fallar por un landmark
  // nuevo que no formaba parte de la comprobación de visibilidad general.
  function footSegmentEnd(ankle, footIndex) {
    return (footIndex.visibility ?? 1) >= STRETCH_HAMSTRING_MIN_VISIBILITY ? footIndex : ankle;
  }

  function evalSide(hip, knee, ankle, footIndex) {
    const kneeAngle = angle(hip, knee, ankle);
    const hipAnkleOffset = Math.abs(hip.y - ankle.y) / shoulderWidth;
    const footEnd = footSegmentEnd(ankle, footIndex);
    const grabDistL = (lW.visibility ?? 1) >= STRETCH_HAMSTRING_MIN_VISIBILITY
      ? distanceToSegment(lW, ankle, footEnd) / shoulderWidth
      : null;
    const grabDistR = (rW.visibility ?? 1) >= STRETCH_HAMSTRING_MIN_VISIBILITY
      ? distanceToSegment(rW, ankle, footEnd) / shoulderWidth
      : null;
    const grabDist = [grabDistL, grabDistR].filter((d) => d !== null).sort((a, b) => a - b)[0] ?? null;
    const ok =
      kneeAngle !== null && kneeAngle >= STRETCH_HAMSTRING_KNEE_MIN_DEG &&
      hipAnkleOffset <= STRETCH_HAMSTRING_HIP_ANKLE_MAX_FACTOR &&
      grabDist !== null && grabDist <= STRETCH_HAMSTRING_GRAB_MAX_FACTOR;
    return {
      ok,
      debug: {
        rodilla: kneeAngle === null ? null : kneeAngle.toFixed(0),
        caderaSuelo: hipAnkleOffset.toFixed(2),
        agarre: grabDist === null ? null : grabDist.toFixed(2),
      },
    };
  }

  const leftExtends = evalSide(lH, lK, lA, lF);  // pierna izquierda estirada
  const rightExtends = evalSide(rH, rK, rA, rF); // pierna derecha estirada

  if (leftExtends.ok) return { ok: true, side: "left", debug: leftExtends.debug };
  if (rightExtends.ok) return { ok: true, side: "right", debug: rightExtends.debug };

  return {
    ok: false,
    reason: "Siéntate en el suelo con una pierna estirada del todo y la otra doblada, e inclínate hacia delante para agarrarte el pie o el tobillo de la pierna estirada con la mano.",
    debug: {
      "izq-rodilla": leftExtends.debug.rodilla,
      "izq-caderaSuelo": leftExtends.debug.caderaSuelo,
      "izq-agarre": leftExtends.debug.agarre,
      "der-rodilla": rightExtends.debug.rodilla,
      "der-caderaSuelo": rightExtends.debug.caderaSuelo,
      "der-agarre": rightExtends.debug.agarre,
    },
  };
}

// Cuádriceps de pie (standing quad stretch): cuarto de la familia de
// estiramientos ISOMÉTRICOS con cámara (ver el comentario junto a
// checkArmCrossStretch para el porqué de la familia y el patrón de dos
// pasos). Reutiliza tal cual checkStandbyPosture como paso 1 — de pie,
// relajada/o, igual que los tres anteriores.
//
// A DIFERENCIA de los tres anteriores, aquí NO se mide ningún ángulo ni
// distancia de la pierna que se dobla ni del brazo que agarra por
// detrás — pedido explícitamente DE FRENTE a la cámara (a diferencia del
// isquiotibiales sentado, que pide perfil), y de frente, tanto el tramo
// rodilla-tobillo de la pierna doblada hacia atrás como el antebrazo que
// la sujeta por detrás de la espalda quedan tapados por el propio
// cuerpo, así que MediaPipe no puede darles una posición fiable. En vez
// de pelear contra eso con geometría poco fiable, se usa la propia caída
// de confianza (landmark.visibility) como LA señal: si la rodilla de una
// pierna se sigue viendo pero su tobillo "desaparece" (visibilidad muy
// baja) mientras la pierna de apoyo se queda recta y alguna muñeca
// también "desaparece" (el brazo que agarra por detrás), es que estás en
// el estiramiento.
//
// Se comprueban las dos piernas posibles (izquierda doblada/derecha
// doblada) y se devuelve la primera que encaje — misma razón que el
// resto de la familia: alternar pierna sin lógica aparte, cada aguante
// cuenta como una serie aparte (STRETCH_HOLD_COUNTERS). No se exige que
// la mano que agarra sea del mismo lado que la pierna doblada ni la
// contraria — vale cualquiera de las dos, igual que checkArmCrossStretch
// no exige un brazo concreto.
//
// Umbrales de partida, sin probar en cámara real todavía (mismo caso que
// tuvo el resto de la familia al añadirse) — pendientes de ajustar según
// lo que se reporte probándolos de verdad delante de la cámara.
const STRETCH_QUAD_MIN_VISIBILITY = 0.4; // hombros y caderas: exigidos visibles con normalidad, para confirmar que se te ve de frente antes de mirar nada más
const STRETCH_QUAD_STANDING_KNEE_MIN_DEG = 150; // pierna de APOYO (la que no se dobla): ángulo cadera-rodilla-tobillo, casi recta, de pie
const STRETCH_QUAD_FOLDED_KNEE_MIN_VISIBILITY = 0.4; // rodilla de la pierna que se dobla hacia atrás: tiene que SEGUIR viéndose (solo desaparece de ahí para abajo, no la pierna entera)
const STRETCH_QUAD_ANKLE_MAX_VISIBILITY = 0.3; // tobillo de esa misma pierna: tiene que "desaparecer" -- visibilidad claramente por debajo de la de la rodilla, oculto detrás del propio cuerpo
const STRETCH_QUAD_WRIST_MAX_VISIBILITY = 0.3; // la muñeca que sujeta el pie por detrás de la espalda también se oculta -- no importa cuál de las dos manos, igual que el agarre en el resto de la familia

/**
 * Paso 2 del cuádriceps de pie: una pierna se dobla por la rodilla hacia
 * atrás, llevando el talón hacia el glúteo, agarrada por detrás de la
 * espalda con una mano, mientras la otra pierna aguanta de pie, recta.
 * De frente a la cámara — ver el comentario junto a esta función para el
 * porqué de usar visibilidad en vez de geometría aquí.
 */
export function checkStandingQuadStretch(lm) {
  const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
  const lH = lm[L_HIP], rH = lm[R_HIP];
  const lK = lm[L_KNEE], rK = lm[R_KNEE];
  const lA = lm[L_ANKLE], rA = lm[R_ANKLE];
  const lW = lm[L_WRIST], rW = lm[R_WRIST];

  if ([lS, rS, lH, rH].some((p) => (p.visibility ?? 1) < STRETCH_QUAD_MIN_VISIBILITY)) {
    return {
      ok: false,
      reason: "No se te ve entera/o. Ponte de frente a la cámara, algo alejada/o, para que se vean los hombros y las caderas enteros.",
      debug: { fail: "vis" },
    };
  }

  const grabWristVanished = (lW.visibility ?? 1) <= STRETCH_QUAD_WRIST_MAX_VISIBILITY || (rW.visibility ?? 1) <= STRETCH_QUAD_WRIST_MAX_VISIBILITY;

  function evalSide(standHip, standKnee, standAnkle, foldKnee, foldAnkle) {
    const standLegVisible =
      (standKnee.visibility ?? 1) >= STRETCH_QUAD_MIN_VISIBILITY &&
      (standAnkle.visibility ?? 1) >= STRETCH_QUAD_MIN_VISIBILITY;
    const standKneeAngle = standLegVisible ? angle(standHip, standKnee, standAnkle) : null;
    const standingStraight = standKneeAngle !== null && standKneeAngle >= STRETCH_QUAD_STANDING_KNEE_MIN_DEG;
    const foldedKneeVisible = (foldKnee.visibility ?? 1) >= STRETCH_QUAD_FOLDED_KNEE_MIN_VISIBILITY;
    const ankleVanished = (foldAnkle.visibility ?? 1) <= STRETCH_QUAD_ANKLE_MAX_VISIBILITY;
    const ok = standingStraight && foldedKneeVisible && ankleVanished && grabWristVanished;
    return {
      ok,
      debug: {
        piernaApoyo: standKneeAngle === null ? null : standKneeAngle.toFixed(0),
        rodillaDoblada: (foldKnee.visibility ?? 1).toFixed(2),
        tobilloDoblado: (foldAnkle.visibility ?? 1).toFixed(2),
      },
    };
  }

  const leftFolds = evalSide(rH, rK, rA, lK, lA);  // pierna izquierda doblada hacia atrás, apoyada en la derecha
  const rightFolds = evalSide(lH, lK, lA, rK, rA); // pierna derecha doblada hacia atrás, apoyada en la izquierda

  if (leftFolds.ok) return { ok: true, side: "left", debug: leftFolds.debug };
  if (rightFolds.ok) return { ok: true, side: "right", debug: rightFolds.debug };

  return {
    ok: false,
    reason: "De pie y de frente a la cámara, dobla una rodilla llevando el talón hacia el glúteo por detrás, y agárrate el pie con la mano por detrás de la espalda, aguantando el equilibrio con la pierna contraria.",
    debug: {
      "izq-apoyo": leftFolds.debug.piernaApoyo,
      "izq-rodilla": leftFolds.debug.rodillaDoblada,
      "izq-tobillo": leftFolds.debug.tobilloDoblado,
      "der-apoyo": rightFolds.debug.piernaApoyo,
      "der-rodilla": rightFolds.debug.rodillaDoblada,
      "der-tobillo": rightFolds.debug.tobilloDoblado,
      munecaIzq: (lW.visibility ?? 1).toFixed(2),
      munecaDer: (rW.visibility ?? 1).toFixed(2),
    },
  };
}

// Cuánto tiempo seguido con la postura rota (por el motivo que sea: te
// has puesto de pie, has salido del encuadre, has levantado un brazo…)
// antes de dar la serie (el tramo aguantado) por terminada — igual que
// ARMS_DOWN_STABLE_MS en dominadas, para no cortar la serie por un
// parpadeo de la cámara o un ajuste rápido de postura.
//
// Este valor estaba en 2000ms, y con eso "seguía contando" bastante
// después de dejar la postura de verdad — según lo reportado y un
// registro real: al levantarte, notePostureOk() pone postureInvalidSince
// a null en CUANTO hay un frame confirmado como correcto (aunque sea un
// parpadeo de apenas 350ms en medio del ruido de la cámara mientras te
// levantas), así que el reloj de "llevas tanto tiempo mal" se reiniciaba
// una y otra vez sin llegar nunca a acumular 2 segundos SEGUIDOS de
// postura rota — y la serie no se cerraba en 15+ segundos de estar ya
// de pie. Bajado a un valor bastante más corto: sigue siendo más del
// doble de POSTURE_FLICKER_STABLE_MS (así que un parpadeo real de la
// cámara no corta nada), pero ya no da tanto margen a que una postura
// realmente rota, con solo algún frame ruidoso "de vuelta a correcto"
// de por medio, seguido contando como si nada.
const PLANK_INVALID_STABLE_MS = 800;
// Un tramo aguantado tan corto (medio segundo, un frame ruidoso que por
// casualidad cruzó el umbral) no es una serie de verdad — contarlo como
// tal (y sumar 1 al número de serie en pantalla) es justo el "me ha
// contado 4 series de 0 segundos" que se reportó: cada parpadeo breve
// de "postura correcta" en medio del ruido, seguido de
// PLANK_INVALID_STABLE_MS roto, cerraba una "serie" vacía. Por debajo de
// este mínimo, el tramo se descarta en silencio (ver _flushPostureHold)
// en vez de contarse. Subido de 1.5s a 2s: con PLANK_INVALID_STABLE_MS
// más corto (arriba), un tramo aún colándose por ruido durante la
// colocación tiene menos margen para llegar a 1.5s seguidos — 2s da un
// poco más de aire de sobra sin afectar a ningún aguante real (que dura
// muchos segundos de largo).
const PLANK_MIN_HOLD_TO_COUNT_SECONDS = 2;
// Un par de frames sueltos con una lectura ruidosa (justo en el borde
// de un umbral) no deberían hacer parpadear el aviso en pantalla y por
// voz entre "aguantando" y "no se te ve/postura incorrecta" todo el
// rato — eso es justo lo que se reportó como estresante. Por eso, antes
// de reflejar un cambio de correcto↔incorrecto en pantalla, hace falta
// que se mantenga así un ratito seguido — el mismo patrón de
// "candidato + tiempo seguido" que se usa en el resto del fichero (ver
// SCISSOR_SWITCH_STABLE_MS) aplicado aquí a si la postura es válida o
// no, en vez de a qué pierna está arriba. Nótese que esto es aparte de
// PLANK_INVALID_STABLE_MS (arriba): ese decide cuándo CERRAR la serie;
// esto decide cuándo cambiar lo que se ve/oye en pantalla.
const POSTURE_FLICKER_STABLE_MS = 350;
// Kneehold en barra a veces necesita más margen que el resto de
// CAMERA_POSTURE_COUNTERS: con la rodilla ya muy flexionada (subida de
// verdad hasta la cadera o más arriba), de frente a la cámara, la propia
// rodilla puede quedar parcialmente tapada por el muslo o el tronco —
// justo cuando MÁS arriba está, no cuando menos — y eso hace que
// MediaPipe se equivoque de vez en cuando durante un segundo largo, no
// solo un frame suelto. Según lo reportado: subir aún más las rodillas
// en mitad de un aguante que iba bien hacía que dejara de contar, y el
// registro real muestra kneeHipGap saltando a valores altos (como si la
// rodilla hubiera bajado mucho) varios frames seguidos mientras
// hanging=sí — un fallo de seguimiento, no un cambio real de postura.
// Plancha/plancha lateral no tienen este problema (de perfil, con las
// piernas quietas, no hay flexión extrema ni autoclusión), así que se
// deja su margen tal cual y solo se amplía para kneeholdbar.
const KNEEHOLDBAR_FLICKER_STABLE_MS = 700;
const KNEEHOLDBAR_INVALID_STABLE_MS = 1800;
// Pino: igual que kneehold en barra, se usa un margen más largo que
// plancha — bocabajo y en equilibrio, es normal que MediaPipe tenga
// alguna racha de seguimiento ruidoso mientras te balanceas un poco
// (algo inevitable en un pino de verdad), y eso no debería bastar para
// dar la postura por rota ni hacer parpadear el aviso en pantalla.
const HANDSTAND_FLICKER_STABLE_MS = 700;
const HANDSTAND_INVALID_STABLE_MS = 1800;
// Consejos rotativos mientras se aguanta: el primero no sale hasta pasado
// un rato (deja asentar la postura, no interrumpas nada más empezar), y
// van rotando cada PLANK_TIP_INTERVAL_MS mientras dure el aguante — se
// hablan directamente con speak(), no con announceStatus(), para no
// pisar el texto en pantalla del cronómetro de aguante (ver notePostureOk).
// Cada consejo se dice UNA sola vez por serie (sin dar la vuelta a la
// lista): en un aguante largo, antes se repetían en bucle cada 20s todo
// el rato, lo cual, sumado a los avisos de postura, se sentía como que
// "no se callaba" — ahora, tras los 3 consejos, se queda callado el
// resto de la serie.
const PLANK_TIP_FIRST_AT_SECONDS = 8;
const PLANK_TIP_INTERVAL_MS = 25000;
const PLANK_TIPS = [
  "Consejo: aprieta el abdomen y los glúteos, como si te fueran a dar un golpe en la tripa — no dejes que la cadera caiga.",
  "Consejo: no subas la cadera en forma de tejado. Mantén el cuerpo en línea recta, de los hombros a los tobillos.",
  "Consejo: respira con normalidad, no aguantes el aire — se aguanta más tiempo respirando bien.",
];
const SIDEPLANK_TIPS = [
  "Consejo: empuja la cadera hacia arriba, no dejes que caiga hacia el suelo.",
  "Consejo: apila los pies uno sobre otro y mantén el cuerpo en línea recta, sin doblarte por la cintura.",
  "Consejo: si te cuesta aguantar, apoya la rodilla de abajo en el suelo para quitar carga, sin perder la línea del cuerpo.",
];
const WALLSIT_TIPS = [
  "Consejo: reparte el peso entre los dos pies y no dejes que las rodillas se junten hacia dentro.",
  "Consejo: mantén toda la espalda pegada al apoyo (pared, barra o poste), sin arquear la zona baja.",
  "Consejo: respira con normalidad, no aguantes el aire — se aguanta más tiempo respirando bien.",
];
const KNEEHOLDBAR_TIPS = [
  "Consejo: no balancees el cuerpo para ayudarte a subir las rodillas — el impulso hace trampa, controla el movimiento.",
  "Consejo: aprieta el abdomen mientras aguantas, como en un crunch, en vez de dejar que cuelguen solo del agarre.",
  "Consejo: respira con normalidad, no aguantes el aire — se aguanta más tiempo respirando bien.",
];
const HANDSTAND_TIPS = [
  "Consejo: reparte el peso entre los dedos y la base de la mano, no solo la palma — así controlas mejor el equilibrio.",
  "Consejo: aprieta el abdomen y los glúteos para mantener el cuerpo recto, como en la plancha.",
  "Consejo: mira a un punto fijo entre las manos, en vez de al frente — ayuda a mantener el equilibrio.",
];

/** Segundos aguantados -> texto para el contador grande ("14s"). */
function formatHoldSeconds(totalSeconds) {
  return `${Math.max(0, Math.round(totalSeconds))}s`;
}

// Números en palabras para la voz (1–99). No basta con pasarle el
// dígito tal cual a SpeechSynthesisUtterance: según el motor de TTS
// del navegador, un número compuesto como "23" a veces se lee dígito a
// dígito ("dos, tres") en vez de "veintitrés". Escribiéndolo en
// palabras se elimina esa ambigüedad. Cubre de sobra hasta el 50 (lo
// pedido), y no hay techo duro: si algún día alguien encadena más de
// 99 reps en una sola serie, se lee el número tal cual como último
// recurso, pero eso ya no es un caso realista.
const UNIDADES_ES = ["cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve"];
const ESPECIALES_ES = {
  10: "diez", 11: "once", 12: "doce", 13: "trece", 14: "catorce", 15: "quince",
  16: "dieciséis", 17: "diecisiete", 18: "dieciocho", 19: "diecinueve",
  20: "veinte", 21: "veintiuno", 22: "veintidós", 23: "veintitrés",
  24: "veinticuatro", 25: "veinticinco", 26: "veintiséis", 27: "veintisiete",
  28: "veintiocho", 29: "veintinueve",
};
const DECENAS_ES = { 30: "treinta", 40: "cuarenta", 50: "cincuenta", 60: "sesenta", 70: "setenta", 80: "ochenta", 90: "noventa" };

export function numeroEnPalabras(n) {
  if (n < 10) return UNIDADES_ES[n];
  if (n < 30) return ESPECIALES_ES[n];
  if (n < 100) {
    const decena = Math.floor(n / 10) * 10;
    const resto = n % 10;
    return resto === 0 ? DECENAS_ES[decena] : `${DECENAS_ES[decena]} y ${UNIDADES_ES[resto]}`;
  }
  return String(n);
}

// Si la voz de conteo está activada — mismo ajuste que WorkoutSession usa
// (ver voiceEnabled en el constructor), expuesto suelto para que
// circuit.js/plan-session.js puedan respetarlo también en la cuenta
// atrás/adelante de plancha/plancha lateral/etc. dentro de un circuito o
// una sesión de plan, donde no hay ninguna instancia de WorkoutSession.
export function isVoiceEnabled() {
  return localStorage.getItem("libreta.voiceReps") !== "0";
}

/**
 * Habla un texto en voz alta con la Web Speech API — extraído de
 * WorkoutSession.speak() (que ahora es un envoltorio fino de esto, ver
 * más abajo) para que circuit.js/plan-session.js puedan usarlo también,
 * sin duplicar aquí la misma llamada a speechSynthesis.
 */
// Modo silencioso (reto Cindy, contrarreloj): speakOut() no dice nada salvo lo que se pase con
// force:true (las órdenes cortas del reto y el número de cada rep). Lo activa/desactiva
// challenges.js con setQuietVoice().
let _quietVoice = false;
export function setQuietVoice(on) {
  _quietVoice = !!on;
}

// Reto Cindy: la calibración de la barra (dominadas) se guarda entre rondas para no perder las
// primeras reps de cada ronda calibrando de nuevo (log real: 5 dominadas hechas, 1 contada).
let _pullupCalibCache = null;
export function clearPullupCalibCache() {
  _pullupCalibCache = null;
}

export function speakOut(texto, { flush = true, rate = 1, force = false } = {}) {
  if (_quietVoice && !force) return;
  if (typeof speechSynthesis === "undefined") return;
  try {
    if (flush) speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(texto);
    u.lang = "es-ES";
    u.volume = 1;
    u.rate = rate;
    u.pitch = 1;
    speechSynthesis.speak(u);
  } catch (e) {
    console.error("speechSynthesis", e);
  }
}

/**
 * Corta cualquier voz en curso YA, sin decir nada nuevo detrás — para
 * cuando sales de la pantalla de la cámara (stopCamera) y no tiene
 * sentido que la voz te siga hablando de un ejercicio que ya no estás
 * viendo. Mismo cambio que en la app móvil (ver mobile-app/www/js/
 * workout.js) — misma regla en las dos partes, aunque aquí no hay voz
 * nativa que parar aparte, solo la Web Speech API del navegador.
 */
export function stopSpeaking() {
  if (typeof speechSynthesis !== "undefined") {
    try {
      speechSynthesis.cancel();
    } catch (e) {
      console.error("speechSynthesis.cancel", e);
    }
  }
}

function el(id) { return document.getElementById(id); }

function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 880;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.3, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.55);
    // segundo pitido, un poco más agudo, medio segundo después
    setTimeout(() => {
      const ctx2 = new (window.AudioContext || window.webkitAudioContext)();
      const osc2 = ctx2.createOscillator();
      const gain2 = ctx2.createGain();
      osc2.type = "sine";
      osc2.frequency.value = 1046.5;
      gain2.gain.setValueAtTime(0.0001, ctx2.currentTime);
      gain2.gain.exponentialRampToValueAtTime(0.3, ctx2.currentTime + 0.02);
      gain2.gain.exponentialRampToValueAtTime(0.0001, ctx2.currentTime + 0.5);
      osc2.connect(gain2).connect(ctx2.destination);
      osc2.start();
      osc2.stop(ctx2.currentTime + 0.55);
    }, 550);
  } catch (e) {
    console.warn("No se pudo reproducir el aviso sonoro:", e);
  }
}

function getCookie(name) {
  const match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
  return match ? decodeURIComponent(match[2]) : null;
}


// ─────────────────────────────────────────────────────────────────────
// L-sit en paralelas (2026-09-20) -- "lsit" (repeticiones) y "lsithold" (aguante)
// ─────────────────────────────────────────────────────────────────────
// PRIMERA VERSIÓN, sin probar en cámara real: todos los umbrales son valores de partida por
// geometría, pendientes de ajustar con un log 📋 real.
//
// Cámara de PERFIL, cuerpo entero (hombro, cadera, rodilla y tobillo del lado que mira).
//
// 1) ARMAR = SUBIRTE A LAS PARALELAS. Mientras estás de pie junto a las paralelas (tronco vertical,
//    rodilla estirada) se aprende la altura del "centro del tronco" (media de la Y del hombro y de la
//    cadera) y el largo del tronco. Estás "montado" cuando ese centro sube LSIT_MOUNT_RISE_FACTOR
//    largos de tronco por encima de esa referencia, con el tronco recto y el brazo estirado, de forma
//    sostenida (LSIT_MOUNT_STABLE_MS). La referencia se queda CONGELADA mientras subes/estás montado y
//    sigue tu altura de pie el resto del tiempo (así, tras bajarte, se reajusta sola). Te has bajado
//    cuando la subida cae por debajo de ~40% de la máxima de esta subida (LSIT_DISMOUNT_FRACTION).
//    No sirve para paralelas tan bajas que la cadera no quede más alta que de pie (parallettes).
//
// 2) PIERNAS: rodilla y tobillo respecto a la cadera, en proporción al largo de la propia pierna:
//      kneeRel  = (rodilla.y - cadera.y) / muslo
//      ankleRel = (tobillo.y - cadera.y) / (muslo + pantorrilla)
//    0 = a la altura de la cadera (horizontal), 1 = colgando en vertical, negativo = por encima.
//    "L" (arriba) = los dos por debajo de su umbral Y rodilla estirada. "Abajo" = los dos por encima
//    del suyo (piernas claramente colgando).
//
// lsit: una repetición = L y de vuelta abajo. lsithold: mismo chequeo de "L", pero aguantado -- va por
// el mecanismo de aguante de plancha/silla en pared (processPosture) con createLSitHoldChecker().
const LSIT_MIN_VISIBILITY = 0.4;             // media hombro+cadera+rodilla+tobillo del lado elegido
const LSIT_STAND_MIN_TILT_DEG = 65;          // tronco (hombro-cadera) casi vertical para aprender la altura de pie
const LSIT_STAND_KNEE_MIN_DEG = 150;         // rodilla casi estirada para aprender la altura de pie (agacharte no cuenta)
const LSIT_MOUNT_RISE_FACTOR = 0.05;         // cuánto tiene que subir el centro del tronco (en largos de tronco) para considerarte montado. BAJADO de 0.15 a 0.05 (2026-09-20, primera prueba real): agarrarte y levantarte un par de centímetros (~0.05 de un tronco de ~50cm) ya cuenta como subido, no hace falta saltar a las paralelas. Si no arma, bajar; si arma de pie o al balancearte, subir. La subida en vivo sale en el estado en pantalla y en el log 📋 (campo subida).
const LSIT_RISE_FREEZE_FRACTION = 0.5;       // por encima de esta fracción de LSIT_MOUNT_RISE_FACTOR la referencia de pie deja de seguirte (estás subiendo)
const LSIT_MOUNT_STABLE_MS = 400;            // subida sostenida para armar (un salto suelto dura menos)
const LSIT_MOUNT_TORSO_MIN_TILT_DEG = 55;    // tronco erguido para contar como montado
const LSIT_MOUNT_ARM_MIN_DEG = 165;          // codo (si se ve) casi del todo estirado para armar: brazos en apoyo agarrado a las paralelas, no flexión de fondos (subido de 140)
// Señal del BRAZO (pedida por Alex): al agarrarte las paralelas el codo está algo doblado y al subirte se estira -- se sube unos
// centímetros. Con esa señal basta una subida pequeña (LSIT_MOUNT_RISE_FACTOR); sin ella (codo no visible, o ya estaba estirado)
// hace falta una subida mayor (LSIT_MOUNT_RISE_NO_ARM_FACTOR) para no armar por ruido estando de pie.
const LSIT_ARM_STRAIGHT_DEG = 168;           // codo COMPLETAMENTE estirado = al menos esto ahora
// SECUENCIA DE AGARRE (Alex, 2026-09-20): al CAMINAR los brazos ya van rectos, así que "brazos rectos" solo no dice nada. Lo que
// distingue subirte a las paralelas es: 1) un momento con los brazos algo doblados y las manos QUIETAS (agarrar las paralelas),
// 2) luego los brazos rectos del todo y el cuerpo sube un poco. Sin ese agarre previo no se arma (con el codo visible).
const LSIT_GRIP_MAX_DEG = 162;               // codo "algo doblado": como mucho esto (en los logs reales el agarre midió 117-161°)
const LSIT_GRIP_MIN_DEG = 90;                // ...y al menos esto (más doblado ya no es agarrar para subir)
const LSIT_GRIP_MIN_MS = 250;                // tiempo seguido con el codo doblado y la muñeca quieta para dar el agarre por hecho
const LSIT_GRIP_VALID_MS = 5000;             // cuánto tiempo vale ese agarre para armar después (agarras, y hasta 5 s después estiras y subes)
const LSIT_GRIP_WRIST_MAX_MOVE = 0.15;       // cuánto se puede mover la muñeca durante el agarre (en largos de tronco) para contar como quieta -- caminando o moviendo los brazos se mueve mucho más
const LSIT_MOUNT_RISE_NO_ARM_FACTOR = 0.15;  // subida exigida SOLO si no se ve el codo (no se puede comprobar el agarre)
// Anti falsos positivos (2026-09-20, logs reales 18/19: armó "Listo" estando de pie junto a las paralelas). Armar exige además haber
// estado de pie QUIETO LSIT_CALIB_MS aprendiendo la altura (antes de eso ni se mira la subida) y que el largo del tronco no cambie (si te
// acercas/alejas de la cámara, la referencia se re-aprende). NO se exige que los pies se levanten del suelo: una persona alta puede llegar
// a las paralelas sin despegarlos.
const LSIT_CALIB_MS = 1500;                  // de pie, recto y con la rodilla estirada, seguido, para dar la referencia por aprendida
const LSIT_SCALE_CHANGE_MAX = 0.10;          // cambio máximo (fracción) del largo de tronco respecto a la referencia sin re-aprender
const LSIT_REF_ALPHA = 0.15;                 // EMA de la referencia de pie
const LSIT_CY_SMOOTH_ALPHA = 0.4;            // EMA de la altura del centro del tronco
const LSIT_CY_MAX_JUMP = 0.04;               // salto máximo por frame de esa altura (fallo puntual de tracking) -- mismo criterio que DIP_SHOULDER_MAX_Y_JUMP
const LSIT_DISMOUNT_FRACTION = 0.4;          // te bajaste si la subida cae por debajo de esta fracción de la máxima de la subida
const LSIT_DISMOUNT_MIN_RISE = 0.02;         // ...y nunca por encima de este suelo mínimo (en largos de tronco)
const LSIT_DISMOUNT_STABLE_MS = 700;         // bajada sostenida para dar por terminada la serie
const LSIT_LEG_SMOOTH_ALPHA = 0.5;           // EMA de kneeRel/ankleRel (~10fps: mitad de respuesta inmediata)
const LSIT_UP_ANKLE_REL = 0.55;  // MODO RELAJADO (2026-09-20). Tobillo hasta ~33° por debajo de la horizontal de la cadera cuenta como L. Modo estricto futuro: 0.30
const LSIT_UP_KNEE_REL = 0.50;  // RELAJADO: rodilla hasta ~30° por debajo de la horizontal. Estricto futuro: 0.25
const LSIT_KNEE_STRAIGHT_MIN_DEG = 100;  // RELAJADO: casi no se exige rodilla estirada (solo descarta rodillas al pecho, <100°). Estricto futuro: 140
const LSIT_DOWN_ANKLE_REL = 0.70;  // RELAJADO: piernas abajo = tobillo >= ~44° por debajo de la horizontal. Estricto futuro: 0.65 (más colgando del todo)
const LSIT_DOWN_KNEE_REL = 0.55;  // RELAJADO: rodilla >= ~33° por debajo de la horizontal (siempre por encima del umbral de subida 0.50, para que 'arriba' y 'abajo' no se solapen)
const LSIT_UP_STABLE_MS = 40;  // debounce de "L" (repeticiones)
const LSIT_DOWN_STABLE_MS = 60;  // RELAJADO: debounce de "abajo" (antes 100)
const LSIT_MIN_REP_SECONDS = 0.15;  // RELAJADO: L -> abajo por debajo de esto es ruido (antes 0.25)
// Aguante: una vez confirmada la L, se tolera un poco más de caída (temblor) antes de romperla.
const LSIT_HOLD_LOOSE_ANKLE_REL = 0.66;  // hold: tolerancia mientras ya aguantabas (RELAJADO)
const LSIT_HOLD_LOOSE_KNEE_REL = 0.55;  // hold: tolerancia mientras ya aguantabas (RELAJADO)
const LSIT_HOLD_LOOSE_KNEE_MIN_DEG = 90;  // hold: tolerancia mientras ya aguantabas (RELAJADO)
const LSITHOLD_INVALID_STABLE_MS = 1500;     // cuánto tiempo seguido sin L para dar el tramo por terminado (más margen que la plancha: las piernas tiemblan y caen un poco)
const LSIT_LOG_INTERVAL_MS = 150;            // el log 📋 de L-sit escribe como mucho una línea de estado cada esto (el servidor recorta a 200.000 caracteres: a cada frame no cabían ni 25 s)
const LSIT_NOT_VISIBLE_MSG = "No se te ven bien el hombro, la cadera, la rodilla y el tobillo. Ponte de perfil a la cámara, con el cuerpo entero en el encuadre.";

export class LSitTracker {
  constructor() { this.reset(); }

  reset() {
    this.refY = null;          // altura (Y, 0-1) del centro del tronco de pie
    this.refLen = null;        // largo hombro-cadera de pie
    this.cySmooth = null;
    this.cyRawPrev = null;
    this.mounted = false;
    this.mountSince = null;
    this.dismountSince = null;
    this.peakRise = 0;
    this.wristHist = [];
    this.gripSince = null;
    this.gripAt = null;
    this.calibSince = null;
    this.calibrated = false;
    this.kneeRelS = null;
    this.ankleRelS = null;
  }

  update(lm, now) {
    const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER], lE = lm[L_ELBOW], rE = lm[R_ELBOW];
    const lW = lm[L_WRIST], rW = lm[R_WRIST], lH = lm[L_HIP], rH = lm[R_HIP];
    const lK = lm[L_KNEE], rK = lm[R_KNEE], lA = lm[L_ANKLE], rA = lm[R_ANKLE];
    const vis4 = (s, h, k, a) => ((s.visibility ?? 1) + (h.visibility ?? 1) + (k.visibility ?? 1) + (a.visibility ?? 1)) / 4;
    const leftVis = vis4(lS, lH, lK, lA), rightVis = vis4(rS, rH, rK, rA);
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;
    if (vis < LSIT_MIN_VISIBILITY) return { visible: false, vis, mounted: this.mounted };

    const s = useLeft ? lS : rS, e = useLeft ? lE : rE, w = useLeft ? lW : rW;
    const h = useLeft ? lH : rH, k = useLeft ? lK : rK, a = useLeft ? lA : rA;
    const torsoLen = Math.hypot(s.x - h.x, s.y - h.y);
    const thigh = Math.hypot(k.x - h.x, k.y - h.y);
    const shin = Math.hypot(a.x - k.x, a.y - k.y);
    const tilt = tiltFromHorizontal(s, h);
    const kneeAngle = angle(h, k, a);
    if (tilt === null || kneeAngle === null || torsoLen < 0.02 || thigh < 0.02 || thigh + shin < 0.05) {
      return { visible: false, vis, mounted: this.mounted };
    }
    const armVis = ((e.visibility ?? 1) + (w.visibility ?? 1)) / 2;
    const elbowAngle = armVis >= LSIT_MIN_VISIBILITY ? angle(s, e, w) : null;

    // Agarre: codo algo doblado con la muñeca QUIETA durante LSIT_GRIP_MIN_MS (manos en las paralelas). Solo cuenta antes de
    // montar y con la referencia de pie ya aprendida. gripAt = último instante en que se cumplía.
    this.wristHist.push({ t: now, x: w.x, y: w.y });
    while (this.wristHist.length && now - this.wristHist[0].t > LSIT_GRIP_MIN_MS) this.wristHist.shift();
    let gripNow = false;
    if (elbowAngle !== null && !this.mounted && this.calibrated && elbowAngle <= LSIT_GRIP_MAX_DEG && elbowAngle >= LSIT_GRIP_MIN_DEG) {
      let minX = w.x, maxX = w.x, minY = w.y, maxY = w.y;
      for (const p of this.wristHist) {
        if (p.x < minX) minX = p.x; if (p.x > maxX) maxX = p.x;
        if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y;
      }
      const still = Math.max(maxX - minX, maxY - minY) <= LSIT_GRIP_WRIST_MAX_MOVE * torsoLen;
      if (still) {
        if (this.gripSince === null) this.gripSince = now;
        if (now - this.gripSince >= LSIT_GRIP_MIN_MS) { gripNow = true; this.gripAt = now; }
      } else {
        this.gripSince = null;
      }
    } else {
      this.gripSince = null;
    }
    const gripRecent = this.gripAt !== null && now - this.gripAt <= LSIT_GRIP_VALID_MS;

    // Altura del centro del tronco: recorte de salto + media móvil (mismo patrón que processDip).
    let rawCy = (s.y + h.y) / 2;
    if (this.cyRawPrev !== null) {
      const d = rawCy - this.cyRawPrev;
      if (Math.abs(d) > LSIT_CY_MAX_JUMP) rawCy = this.cyRawPrev + Math.sign(d) * LSIT_CY_MAX_JUMP;
    }
    this.cyRawPrev = rawCy;
    this.cySmooth = this.cySmooth === null ? rawCy : this.cySmooth + LSIT_CY_SMOOTH_ALPHA * (rawCy - this.cySmooth);
    const cy = this.cySmooth;

    // Referencia de pie: se aprende la primera vez que estás recto, y luego SOLO sigue tu altura
    // mientras no estés subiendo/montado y estés recto con la rodilla estirada. Hasta que estés
    // LSIT_CALIB_MS de pie y quieto (this.calibrated) la referencia te sigue siempre y NO se detecta
    // ninguna subida; si cambia el largo del tronco (te acercas/alejas) se vuelve a aprender.
    const upright = tilt >= LSIT_STAND_MIN_TILT_DEG;
    const kneesStraight = kneeAngle >= LSIT_STAND_KNEE_MIN_DEG;
    const standing = upright && kneesStraight && !this.mounted;
    if (this.refY === null && upright && !this.mounted) {
      this.refY = cy;
      this.refLen = torsoLen;
    }
    let rise = null;
    if (this.refY !== null) {
      if (!this.mounted && Math.abs(torsoLen / this.refLen - 1) > LSIT_SCALE_CHANGE_MAX) {
        this.refY = cy; this.refLen = torsoLen;
        this.calibSince = null; this.calibrated = false;
      }
      rise = (this.refY - cy) / this.refLen;
      const rising = rise >= LSIT_MOUNT_RISE_FACTOR * LSIT_RISE_FREEZE_FRACTION;
      if (standing && (!this.calibrated || !rising)) {
        this.refY += LSIT_REF_ALPHA * (cy - this.refY);
        this.refLen += LSIT_REF_ALPHA * (torsoLen - this.refLen);
        rise = (this.refY - cy) / this.refLen;
      }
      if (!this.calibrated) {
        if (standing) {
          if (this.calibSince === null) this.calibSince = now;
          if (now - this.calibSince >= LSIT_CALIB_MS) this.calibrated = true;
        } else {
          this.calibSince = null;
        }
      }
    }

    // Montado / desmontado, con histéresis.
    const torsoOk = tilt >= LSIT_MOUNT_TORSO_MIN_TILT_DEG;
    const armsOk = elbowAngle === null || elbowAngle >= LSIT_MOUNT_ARM_MIN_DEG;
    if (rise !== null) {
      if (!this.mounted) {
        const riseOk = elbowAngle === null
          ? rise >= LSIT_MOUNT_RISE_NO_ARM_FACTOR
          : gripRecent && elbowAngle >= LSIT_ARM_STRAIGHT_DEG && rise >= LSIT_MOUNT_RISE_FACTOR;
        if (this.calibrated && riseOk && torsoOk && armsOk) {
          if (this.mountSince === null) this.mountSince = now;
          if (now - this.mountSince >= LSIT_MOUNT_STABLE_MS) {
            this.mounted = true;
            this.peakRise = Math.min(rise, 1);
            this.dismountSince = null;
            this.gripAt = null;
            this.gripSince = null;
          }
        } else {
          this.mountSince = null;
        }
      } else {
        this.peakRise = Math.max(this.peakRise, Math.min(rise, 1));
        const dismountBelow = Math.max(LSIT_DISMOUNT_MIN_RISE, LSIT_DISMOUNT_FRACTION * this.peakRise);
        if (rise < dismountBelow) {
          if (this.dismountSince === null) this.dismountSince = now;
          if (now - this.dismountSince >= LSIT_DISMOUNT_STABLE_MS) {
            this.mounted = false;
            this.mountSince = null;
            this.dismountSince = null;
          }
        } else {
          this.dismountSince = null;
        }
      }
    }

    // Piernas.
    const kneeRel = (k.y - h.y) / thigh;
    const ankleRel = (a.y - h.y) / (thigh + shin);
    this.kneeRelS = this.kneeRelS === null ? kneeRel : this.kneeRelS + LSIT_LEG_SMOOTH_ALPHA * (kneeRel - this.kneeRelS);
    this.ankleRelS = this.ankleRelS === null ? ankleRel : this.ankleRelS + LSIT_LEG_SMOOTH_ALPHA * (ankleRel - this.ankleRelS);
    const kr = this.kneeRelS, ar = this.ankleRelS;
    const straight = kneeAngle >= LSIT_KNEE_STRAIGHT_MIN_DEG;
    const legsUp = ar <= LSIT_UP_ANKLE_REL && kr <= LSIT_UP_KNEE_REL && straight;
    const legsUpLoose = ar <= LSIT_HOLD_LOOSE_ANKLE_REL && kr <= LSIT_HOLD_LOOSE_KNEE_REL && kneeAngle >= LSIT_HOLD_LOOSE_KNEE_MIN_DEG;
    const legsDown = ar >= LSIT_DOWN_ANKLE_REL && kr >= LSIT_DOWN_KNEE_REL;

    const mountReason = !this.calibrated
      ? "Ponte de pie, quieto, de perfil, con el cuerpo entero en el encuadre, un par de segundos (aprendiendo tu altura de pie)."
      : !gripRecent && elbowAngle !== null
      ? "Agárrate a las paralelas (brazos algo doblados, manos quietas) y luego estira los brazos del todo levantándote un poco."
      : "Estira los brazos del todo y levántate un poco sobre las paralelas, con el torso recto, y aguanta un momento.";
    const legsReason = !straight
      ? "Estira las rodillas: las piernas van rectas, juntas, a la altura de la cadera (forma de L)."
      : "Sube las piernas rectas hasta la altura de la cadera (forma de L).";
    const f = (v, d = 2) => (v === null || v === undefined ? null : v.toFixed(d));
    return {
      visible: true, side: useLeft ? "left" : "right", vis,
      mounted: this.mounted, rise, mountReason,
      kneeRel: kr, ankleRel: ar, kneeAngle, elbowAngle, tilt,
      legsUp, legsUpLoose, legsDown, legsReason,
      debug: {
        subida: f(rise), montado: this.mounted ? "sí" : "no", agarre: gripRecent ? "sí" : "no", calib: this.calibrated ? "sí" : "no",
        rodilla_rel: f(kr), tobillo_rel: f(ar),
        ang_rodilla: f(kneeAngle, 0), ang_codo: f(elbowAngle, 0), tronco: f(tilt, 0),
      },
    };
  }
}

/**
 * Comprobador de postura para el L-sit aguantado (lsithold), con el mismo formato que
 * checkPlankPosture y compañía ({ ok, reason, debug, side }), pero con estado propio (aprende tu
 * altura de pie y si estás montado, ver LSitTracker) -- por eso es una fábrica: cada sitio que lo
 * use (WorkoutSession, session-runner.js, circuit.js, plan-session.js) crea el suyo. El objeto
 * devuelto tiene .reset(). Ok = montado en las paralelas Y piernas en L (con más tolerancia
 * mientras ya estabas aguantando).
 */
export function createLSitHoldChecker() {
  const tracker = new LSitTracker();
  let lastOk = false;
  let lOnlySince = null;   // desde cuándo llevas la L "de libro" con torso y brazos como en las paralelas, sin haber pasado por calibración/agarre
  const check = (lm) => {
    const nowMs = performance.now();
    const info = tracker.update(lm, nowMs);
    if (!info.visible) {
      lastOk = false;
      return { ok: false, reason: LSIT_NOT_VISIBLE_MSG, debug: { visibilidad: info.vis.toFixed(2) } };
    }
    // Atajo propio del hold (2026-09-20): estar ya en la L (piernas rectas a la altura de la cadera,
    // torso vertical, brazos estirados) es la mejor prueba de que estás en las paralelas -- de pie
    // en el suelo no se hace. Así no hace falta haber pasado por calibración + agarre + subida si
    // te subes directamente o la calibración no llegó a completarse. Se pide sostenido 500 ms.
    let viaL = false;
    if (!info.mounted) {
      const armOk = info.elbowAngle === null || info.elbowAngle >= LSIT_MOUNT_ARM_MIN_DEG;
      if (info.legsUp && armOk && info.tilt !== null && info.tilt >= LSIT_MOUNT_TORSO_MIN_TILT_DEG) {
        if (lOnlySince === null) lOnlySince = nowMs;
        viaL = nowMs - lOnlySince >= 500;
      } else {
        lOnlySince = null;
      }
      if (!viaL && !lastOk) {
        return { ok: false, reason: info.mountReason, side: info.side, debug: info.debug };
      }
      if (!viaL && lastOk) {
        // ya estabas aguantando y el tracker dice "no montado" (p. ej. se soltó la referencia): no cortes por eso si la L sigue
        if (!info.legsUpLoose) { lastOk = false; return { ok: false, reason: info.legsReason, side: info.side, debug: info.debug }; }
      }
    } else {
      lOnlySince = null;
    }
    const up = lastOk ? info.legsUpLoose : info.legsUp;
    if (!up) {
      lastOk = false;
      return { ok: false, reason: info.legsReason, side: info.side, debug: info.debug };
    }
    lastOk = true;
    return { ok: true, side: info.side, debug: info.debug };
  };
  check.reset = () => { tracker.reset(); lastOk = false; lOnlySince = null; };
  return check;
}

class WorkoutSession {
  constructor(root) {
    this.root = root;
    this.saveUrl = root.dataset.saveUrl;
    // Objetivo del ejercicio (si viene de un plan o de un circuito con
    // meta fija) — solo para avisar al llegar, NO para parar el conteo.
    // Sin esto (o si no viene ninguno) simplemente no hay aviso.
    this.targetSets = root.dataset.targetSets ? parseInt(root.dataset.targetSets, 10) : null;
    this.targetReps = root.dataset.targetReps ? parseInt(root.dataset.targetReps, 10) : null;
    // Reps EXACTAS (reto Cindy): ni una más ni una menos por serie.
    this.exactReps = root.dataset.exactReps ? parseInt(root.dataset.exactReps, 10) : null;
    // Contrarreloj (Cindy): armado y calibración más cortos, para no perder reps al empezar.
    this.hangStableMs = this.exactReps ? 250 : HANG_STABLE_MS;
    this.calibrationMs = this.exactReps ? 600 : CALIBRATION_MS;
    this.groundStableMs = this.exactReps ? 250 : ON_GROUND_STABLE_MS;
    this.targetAnnounced = false;
    // Indice de serie (this.sets.length en el momento de avisar) en el
    // que ya se ha dado el aviso de "objetivo cumplido" (de serie o de
    // sesion, ver countRep) -- evita repetirlo en cada repeticion extra
    // dentro de la MISMA serie sin tener que resetear un flag en cada uno
    // de los sitios donde currentSetReps vuelve a 0 para abrir la
    // siguiente (closeActiveSet, beginPrep, el cambio de sentido de
    // armcircles, finish...): this.sets.length cambia solo cuando una
    // serie se cierra de verdad, en todos esos sitios por igual.
    this.setGoalAnnouncedAtSetIndex = -1;
    // Objetivo de plancha/plancha lateral/etc. (segundos a aguantar) — ver
    // notePostureOk para la cuenta atrás/adelante hablada que usa esto.
    this.targetSeconds = root.dataset.targetSeconds ? parseInt(root.dataset.targetSeconds, 10) : null;
    // Estiramientos (ver STRETCH_HOLD_COUNTERS): sin objetivo propio
    // (freestyle, sin plan/circuito detrás), arrancan igual con una
    // cuenta atrás por defecto en vez de contar libremente desde 0 -
    // pedido explícitamente para el estiramiento cruzado de brazo (30s,
    // y si sigues, sigue sumando por encima, igual que cualquier otro
    // objetivo de este mecanismo - ver notePostureOk). this.counterKey
    // todavía no está asignado en este punto del constructor, así que
    // se mira directamente root.dataset.counterKey.
    if (!this.targetSeconds && STRETCH_HOLD_COUNTERS.has(root.dataset.counterKey || "")) {
      this.targetSeconds = DEFAULT_STRETCH_TARGET_SECONDS;
    }
    this.postureCountdownLastSecond = null;   // último entero (cuenta atrás o adelante) ya dicho en el tramo de aguante actual
    this.postureGoalAnnouncedThisHold = false; // si ya se ha avisado "objetivo cumplido" en el tramo actual
    // Voz que cuenta las reps en alto ("¡uno! ¡dos! ¡tres!") — Web Speech
    // API, la trae el propio navegador. Activada por defecto; se puede
    // desactivar poniendo localStorage["libreta.voiceReps"] = "0" (misma
    // clave que usa la app móvil, por si algún día hay un ajuste aquí
    // también). Ver speakRep() más abajo.
    this.voiceEnabled = localStorage.getItem("libreta.voiceReps") !== "0";
    // Qué contador usar. Lo decide el ejercicio (counter_key en el
    // catálogo), no la pantalla.
    this.counterKey = root.dataset.counterKey || "pullup";
    // Cada cuantas reps habla la voz para ESTE ejercicio (ver
    // DEFAULT_VOICE_STEP y speakRep mas abajo) -- viene del catalogo
    // (Exercise.voice_step) via data-voice-step; si no llega nada (NaN,
    // vacio, challenges.js que no lo manda) cae al valor por defecto.
    this.voiceStep = parseInt(root.dataset.voiceStep, 10) || DEFAULT_VOICE_STEP;
    this.video = el("workout-video");
    this.canvas = el("workout-canvas");
    this.ctx = this.canvas.getContext("2d");

    // this.statusEl Y this.debugEl van los dos al mismo sitio: ningún
    // aviso, ni texto, ni "movimiento" bajo la cámara — pedido
    // explícito, ni siquiera un aviso fijo tipo "Preparando cámara…",
    // porque estorba al probar la app "in real life". En vez de
    // elementos reales del DOM, son objetos con un setter de
    // "textContent" que redirige TODO (avisos de estado normales,
    // avisos de fin de serie, descanso obligatorio, calibración, y
    // el texto de depuración de cada ejercicio) al registro exportable
    // (this.scissorLog, ver logScissor / exportScissorLog) en vez de a
    // la pantalla. Los ~40 sitios que hacen "this.statusEl.textContent
    // = ..." (directamente o vía setStatus/announceStatus/
    // announceSetComplete/announceRestBlocked) y los ~60 que hacen
    // "this.debugEl.textContent = ..." siguen funcionando tal cual, sin
    // tocar ni un sitio más. La VOZ no se toca — sigue hablando igual
    // que antes (speak()/speakOut no dependen de statusEl ni debugEl) —
    // solo se quita el texto visual bajo la cámara.
    // Cuando la app esté validada del todo y ya no haga falta
    // depurarla, quitar este shim (y el botón/registro entero) deja el
    // código donde estaba antes, sin más cambios que deshacer.
    const self = this;
    this.statusEl = {
      set textContent(text) {
        self.logScissor(`[status] ${text}`);
      },
    };
    this.goalBannerEl = el("workout-goal-banner");
    this.repsEl = el("workout-reps");
    this.setsEl = el("workout-sets");
    this.timerEl = el("workout-timer");
    this.restEl = el("workout-rest");
    this.finishBtn = el("workout-finish");
    this.cancelBtn = el("workout-cancel");
    this.debugEl = {
      set textContent(text) {
        self.logScissor(text);
      },
    };
    this.debugExportBtn = el("workout-debug-export");
    this.debugExportStatusEl = el("workout-debug-export-status");

    this.poseLandmarker = null;
    this.stream = null;
    this.running = false;

    this.calibrating = false;
    this.prepping = false;
    this.prepStartTs = null;
    this.hangStableSince = null;
    this.armsDownSince = null; // desde cuándo llevas los brazos abajo seguido, de verdad soltado (ver RELEASE_MARGIN_FACTOR) — para no cerrar la serie por un frame ruidoso
    this.groundStableSince = null; // crunch/legraise/situp: desde cuándo llevas tumbado y quieto seguido (para armar el contador, como hangStableSince en dominadas)
    this.offGroundSince = null;    // crunch/legraise/situp: desde cuándo llevas "de pie" seguido (para cerrar la serie, como armsDownSince en fondos)
    this.outOfFrameSince = null;   // sentadillas y abdominales tumbado: desde cuándo no se te detecta en el encuadre (para cerrar la serie, ver noteAbsence)
    this.waveSamples = [];         // sentadillas y abdominales tumbado: historial reciente de la muñeca levantada, para detectar el vaivén de "quiero terminar" (ver checkWaveGesture)
    this.frontalStableSince = null; // sentadillas: desde cuándo llevas de frente a la cámara (en vez de perfil) seguido, otra forma de terminar la serie
    this.torsoBandStableSince = null; // doble crunch: desde cuándo llevas el torso dentro de la banda de inclinación de la postura seguido (para armar el contador)
    this.torsoOutOfBandSince = null;  // doble crunch: desde cuándo llevas el torso FUERA de esa banda seguido (para cerrar la serie)
    this.scissorSide = null;          // tijeretas: qué pierna está más alta, YA CONFIRMADO (para detectar el cambio)
    this.scissorCandidateSide = null; // tijeretas: qué pierna parece estar poniéndose arriba, aún sin confirmar (ver SCISSOR_SWITCH_STABLE_MS)
    this.scissorCandidateSince = null; // tijeretas: desde cuándo lleva esa pierna candidata arriba seguido
    this.scissorSmoothA = null;       // tijeretas: altura ya suavizada de la pierna rastreada "1" (ver SCISSOR_SMOOTHING_ALPHA)
    this.scissorSmoothB = null;       // tijeretas: lo mismo para la pierna rastreada "2"
    this.scissorRawPrevA = null;      // tijeretas: altura BRUTA de la pierna "1" en el frame anterior, para recortar saltos imposibles (ver SCISSOR_MAX_LIFT_JUMP)
    this.scissorRawPrevB = null;      // tijeretas: lo mismo para la pierna "2"
    this.scissorTrackA = null;        // tijeretas: última posición (x,y) conocida de la pierna rastreada "1", para reconocerla por cercanía frame a frame (no por la etiqueta izq/dcha de MediaPipe, que se confunde de perfil)
    this.scissorTrackB = null;        // tijeretas: lo mismo para la pierna rastreada "2"
    this.scissorSwitchCount = 0;      // tijeretas: cambios de pierna confirmados desde que se armó — una repetición es un vaivén COMPLETO, así que solo se cuenta cada dos cambios
    this.scissorLog = [];             // tijeretas: registro de depuración en memoria (ver logScissor/exportScissorLog)
    // Instrumentación de rendimiento (2026-09-15): reportado que tras un
    // cambio que NO toca loop()/drawOverlay()/el modelo, el punto de la
    // nariz se ve con menos fps. Se mide el tiempo real de cada
    // detectForVideo() (ver loop()) y se vuelca un resumen cada
    // PERF_LOG_EVERY_N_FRAMES frames al mismo registro que exporta el
    // botón 📋, para tener un número real (ms/frame) en vez de
    // depender de la sensación al usarlo. "GPU" en baseOptions.delegate
    // es solo lo que se PIDE al crear el PoseLandmarker — la librería
    // puede caer a CPU sin avisar si el dispositivo/WebView no soporta
    // bien la aceleración; un ms/frame alto es la señal indirecta de que
    // eso ha pasado (o de que el móvil está limitado por otro motivo:
    // térmico, ahorro de batería, otra app en segundo plano).
    this.perfFrameTimes = [];
    this.perfLoggedOnce = false;
    // DECIMOCUARTO BUG REAL (2026-09-04): este tope se puso en 900
    // pensando en "de sobra para unos 30s a 30fps" — es decir, 1 línea
    // por frame. Pero processDip (y el resto de ejercicios) escriben DOS
    // líneas por frame: this.debugEl.textContent pasa por un shim que ya
    // llama a logScissor() (ver el shim de debugEl, arriba, donde se
    // define this.debugEl), Y ADEMÁS hay una llamada explícita a
    // logScissor() justo después con el registro detallado del mismo
    // frame. Con 2 líneas/frame la ventana real era la mitad (o menos,
    // si además hay avisos de estado de por medio) de los 30s pensados.
    // El usuario reprodujo el fallo de "cuenta una rep al montarse en las
    // paralelas sin hacer un fondo de verdad" en el build con el arreglo
    // de DIP_MIN_SHOULDER_DROP_FACTOR ya puesto, pulsó "copiar registro"
    // nada más terminar y pegó el registro completo (confirmado por él:
    // "no esta cortado, lo copio y pego directo") — y aun así el registro
    // exportado empezaba de golpe a los 9.9s, sin ni un [ARMADO] ni
    // [REP CONTADA] ni [rep descartada], todo en estado "top" quieto. No
    // es que faltara texto al pegarlo: el propio FIFO ya se había comido
    // esos frames antes de llegar a pulsar el botón, porque la ventana
    // real (con 2 líneas/frame) era bastante más corta de lo que este
    // comentario decía. Se sube el tope a 3600 (el cuádruple) para tener
    // margen real de sobra incluso contando las 2 líneas/frame — así la
    // próxima vez que reproduzca el fallo, el registro exportado sí debe
    // llegar hasta el momento exacto de la repetición en cuestión.
    this.scissorLogMax = 3600;
    this.scissorLogStart = performance.now(); // tijeretas: instante de referencia para los timestamps del registro
    // Plancha / plancha lateral: aquí no se cuentan repeticiones, se
    // cuenta TIEMPO aguantando la postura — ver processPosture,
    // notePostureOk/notePostureBroken y closeActivePostureSet.
    this.postureValidSince = null;   // desde cuándo llevas la postura correcta seguida en el tramo actual
    this.postureInvalidSince = null; // desde cuándo llevas la postura rota seguida (para cerrar la serie, PLANK_INVALID_STABLE_MS)
    this.lastPostureTickTs = null;   // último frame contado hacia currentHoldSeconds, para medir el hueco entre frames
    this.currentHoldSeconds = 0;     // segundos aguantados en el tramo en curso (aún sin cerrar como serie)
    this.totalHeldSeconds = 0;       // suma de todos los tramos aguantados de la sesión — esto es lo que se manda como session_duration_seconds al guardar (ver finish())
    this.tipIndex = 0;               // qué consejo rotativo toca decir a continuación
    this.lastTipAt = null;           // performance.now() del último consejo hablado
    this.sidePlankDownSide = null;   // plancha lateral: "left"/"right" — qué lado se consideró "de abajo" el frame anterior, para no dejar que la decisión salte cada frame (ver checkSidePlankPosture)
    this.stretchLastSide = null;     // estiramiento cruzado de brazo: "left"/"right" — qué brazo se acaba de estirar, para sugerir el lado contrario al volver a standby (ver closeActivePostureSet)
    this.postureGroundConfirmed = false; // plancha/plancha lateral: ya se ha confirmado que te ha visto tumbado del todo en el suelo (paso 1) antes de pedir la postura en sí (paso 2) — ver processPosture
    this.postureGroundSince = null;      // plancha/plancha lateral: desde cuándo llevas tumbado del todo, seguido, para confirmar el paso 1
    this.postureLastOk = null;         // plancha/plancha lateral: último estado (correcto/incorrecto) ya CONFIRMADO y reflejado en pantalla — ver POSTURE_FLICKER_STABLE_MS
    this.postureCandidateOk = null;    // plancha/plancha lateral: estado que parece estarse dando, aún sin confirmar
    this.postureCandidateSince = null; // plancha/plancha lateral: desde cuándo lleva ese estado candidato seguido
    this.calibrationSamples = [];
    this.calibrationStartTs = null;
    this.shoulderWidth = null;

    this.state = "down"; // "down" | "up"
    this.reps = 0;
    this.repDurations = [];
    this.sets = [];              // series ya cerradas: [{reps, durations}, ...]
    this.currentSetReps = 0;     // reps de la serie en curso
    this.currentSetDurations = [];
    this.localBottomY = null;  // y (0-1) del punto mas bajo visto en la fase actual
    this.localTopY = null;     // y (0-1) del punto mas alto visto en la fase actual
    this.barY = null;          // y (0-1) de la barra, medida por la altura de tus muñecas
    this.repStartTime = null;
    this.liftoffTime = null;   // instante en que detectamos que empezaste a moverte de verdad
    this.dipGroundShoulderY = null; // y (0-1) de tu hombro de pie, junto a las paralelas — referencia para saber si estás montado (ver processDip)
    this.dipArmedSince = null;  // desde cuándo llevas seguido con el codo recto, armando el contador
    this.dipBreakSince = null;  // desde cuándo llevas seguido con la combinación de desmonte (hombro abajo + codo recto), ya armado
    this.dipBreakInterruptSince = null; // desde cuándo el frame actual YA NO cumple la forma de desmonte, mientras dipBreakSince sigue vivo — un solo frame de ruido (ver DIP_BREAK_INTERRUPT_GRACE_MS/processDip) no debe tirar la cuenta de desmonte a la basura
    this.dipSetPeakShoulderRise = null; // pico de "hombro subido" visto en la serie en curso — de aquí salen los umbrales de montada/o y desmonte, adaptados a tu cuerpo (ver processDip)
    this.dipRepShoulderTopY = null; // y (0-1) del hombro justo al empezar a bajar en la repetición en curso
    this.dipRepShoulderMaxY = null; // y (0-1) más baja (más abajo en la imagen) que ha alcanzado el hombro en la repetición en curso
    this.dipTopShoulderY = null; // y (0-1) MÁS ALTA (Y más pequeña) vista mientras estás de verdad arriba (state==="top", brazos estirados) DESDE que se armó esta serie — décimo bug real, ver processDip: dipRepShoulderTopY se copiaba de un solo frame suelto (el del cruce de ángulo) en vez de esto. Se reinicia al armar cada serie (no solo al Recalibrar) para no arrastrar una lectura vieja de una serie anterior — ver el comentario junto a la reasignación, en processDip
    // (dipTopShoulderY: se probó aquí, y en la asignación de
    // dipRepShoulderTopY más abajo en processDip, una referencia de
    // "arriba" acumulada durante todo el tramo en top en vez del frame
    // suelto del cruce de ángulo. REVERTIDO por completo: el usuario
    // confirmó una repetición contada por accidente solo al colocar el
    // portátil/ponerte en posición, antes de hacer fondos de verdad — y
    // que la versión de antes, la de aquí debajo, SÍ contaba los fondos
    // bien, con la cámara de perfil confirmada.)
    this.dipShoulderSmoothY = null; // y (0-1) del hombro YA suavizada (recorte de saltos + media móvil) — se usa para todo excepto elbowAngle (ver DIP_SHOULDER_SMOOTHING_ALPHA/DIP_SHOULDER_MAX_Y_JUMP, processDip)
    this.dipShoulderRawPrevY = null; // y (0-1) bruta del hombro en el frame anterior, para recortar saltos imposibles antes de suavizar (mismo patrón que scissorRawPrevA)
    this.dipTorsoLength = null; // largo hombro-cadera aprendido UNA VEZ de pie y congelado para toda la serie — reemplaza al largo de brazo (hombro-codo) como referencia para normalizar hombro_subido, ver el sexto bug arriba y processDip
    this.dipTorsoLengthRawPrev = null; // largo hombro-cadera bruto del frame anterior, para recortar saltos imposibles antes de suavizar (mismo patrón que dipShoulderRawPrevY)
    this.dipFaceCameraSince = null; // desde cuándo llevas seguido con los DOS hombros visibles (te has girado de frente a la cámara) — otra forma de dar la serie por terminada, ver DIP_FACE_CAMERA_VISIBILITY/STABLE_MS
    this.dipGroundHipY = null; // y (0-1) de tu cadera de pie — mismo concepto que dipGroundShoulderY, para el caso de paralelas ALTAS (ver dipBarType, processDip)
    this.dipHipSmoothY = null; // y (0-1) de la cadera YA suavizada — mismo filtro que dipShoulderSmoothY
    this.dipHipRawPrevY = null; // y (0-1) bruta de la cadera del frame anterior, para el mismo recorte de salto que dipShoulderRawPrevY
    this.dipSetPeakHipRise = null; // pico de "cadera subida" visto en la serie en curso — mismo concepto que dipSetPeakShoulderRise, para paralelas ALTAS
    this.dipBarType = null; // "alta" | "baja" | null (aún sin determinar esta serie) — de qué altura son las paralelas, decidido una vez por serie nada más armar (ver processDip)
    this.squatSide = null;     // "left" | "right" — qué lado del cuerpo se ve mejor este frame (de perfil solo se ve bien uno)
    this.squatKneeAngle = null; // último ángulo de rodilla medido, solo para overlay/debug
    this.squatArmStableSince = null; // desde cuándo llevas de pie (rodilla estirada) seguido, sin armar aún el contador — ver SQUAT_ARM_STABLE_MS
    this.squatArmedAt = null; // performance.now() de cuándo se armó el contador (transición null -> "top") — ver SQUAT_ARM_SETTLE_MS/SQUAT_FRONTAL_GRACE_MS
    this.splitSquatKneeAngle = null; // último ángulo de rodilla (el mínimo de las dos piernas visibles), solo para overlay/debug
    this.splitSquatStableSince = null; // desde cuándo llevas de pie (las dos rodillas casi rectas) seguido, sin armar aún el contador — ver SPLITSQUAT_STABLE_MS
    this.splitSquatStateEnteredAt = null; // performance.now() de cuándo entraste en el estado actual (top/bottom) — para cerrar la serie si pasas SPLITSQUAT_IDLE_CLOSE_MS sin avanzar, ver processSplitSquat
    this.curlSide = null;            // curl: "left" | "right" — qué lado del cuerpo se ve mejor este frame (de perfil solo se ve bien uno), mismo concepto que squatSide/pushupSide
    this.curlElbowAngle = null;      // curl: último ángulo de codo medido, solo para overlay/debug
    this.curlTopHoldSince = null;    // curl: performance.now() de cuándo se llegó arriba (codo doblado) en la repetición en curso — para el aviso de "llevas aguantando, esto no cuenta todavía" (ver CURL_TOP_HOLD_WARN_MS/processDumbbellCurl)
    this.curlShoulderMidPrev = null; // curl: {x,y} del punto medio de hombros del frame anterior, para medir cuánto tiembla la cámara (ver checkCameraShake)
    this.curlCameraShakeSince = null; // curl: desde cuándo lleva la cámara temblando por encima del umbral, seguido (ver checkCameraShake)
    this.curlElbowBaselineY = null;  // curl: altura (y) del codo en el momento de armar — referencia para medir si el codo SUBE durante la serie (ver processDumbbellCurl, CURL_ELBOW_RISE_MAX_FACTOR)
    this.curlRestSince = null;       // curl: desde cuándo lleva el brazo estirado y quieto, seguido, en el estado "bottom" — para el cierre automático de serie por descanso (ver CURL_REST_AUTO_CLOSE_MS)
    this.legRaiseSide = null;  // mismo concepto que squatSide, para elevación de piernas
    this.lsitTracker = new LSitTracker(); // L-sit en paralelas (reps): altura de pie, montado/desmontado y piernas -- ver el bloque LSIT_*
    this.lsitHoldChecker = createLSitHoldChecker(); // L-sit en paralelas (aguante): comprobador de postura con estado propio
    this.lsitDownConfirmed = false; // lsit: ya se han visto las piernas abajo desde que se armó -- sin esto, armar ya con las piernas en L contaría una repetición sin haber visto la subida
    this.lsitUpSince = null;   // lsit: desde cuándo cumples la L seguido (debounce)
    this.lsitDownSince = null; // lsit: desde cuándo tienes las piernas abajo seguido (debounce)
    this.lsitLastLogAt = null; // lsit: último instante en que se escribió una línea de estado en el log (ver LSIT_LOG_INTERVAL_MS)
    this.pushupSide = null;    // mismo concepto que squatSide, para flexiones
    this.archerPeakLeftAngle = null;  // dominadas de arquero: ángulo de codo izquierdo en el punto más alto visto de la subida en curso
    this.archerPeakRightAngle = null; // idem, codo derecho
    this.archerLastSide = null;       // dominadas de arquero: "left" | "right" — lado detectado en la última repetición contada (para avisar si repites)
    this.archerLiveLeftAngle = null;  // dominadas de arquero: ángulo de codo izquierdo de ESTE frame, solo para overlay/debug
    this.archerLiveRightAngle = null; // idem, codo derecho
    this.armCirclePrevAngleL = null;    // círculos de brazos: último ángulo local (radianes) del brazo izquierdo, para calcular el delta del frame (ver ARMCIRCLES_* y processArmCircles)
    this.armCirclePrevAngleR = null;    // círculos de brazos: idem, brazo derecho
    this.armCircleAccum = 0;            // círculos de brazos: ángulo acumulado (con signo) desde la última vuelta completa contada — al llegar a ±2π se cuenta una repetición
    this.armCirclePhase = null;    // círculos de brazos: null (sentido aún no detectado) | "forward" | "backward" — se fija solo con la primera vuelta completa que hagas, y luego cambia sola en cuanto te paras un momento (ver ARMCIRCLES_STILL_MS/armCircleDidPhaseSwitch), no por llegar a un número de reps concreto
    this.armCirclePhaseReps = 0;        // círculos de brazos: repeticiones contadas en el sentido actual, para saber cuándo toca el cambio de fase
    this.armCircleArmStableSince = null; // círculos de brazos: desde cuándo llevas los dos brazos extendidos seguido, sin armar aún (ver ARMCIRCLES_ARM_STABLE_MS)
    this.armCircleLastProgressAt = null; // círculos de brazos: performance.now() del último frame con giro de verdad (por encima de ARMCIRCLES_MIN_ANGULAR_DELTA) — para cerrar la serie sola si te paras (ver ARMCIRCLES_STILL_MS)
    this.armCircleRepStartTime = null;   // círculos de brazos: performance.now() de cuándo empezó la vuelta en curso, para el filtro de ruido ARMCIRCLES_MIN_REP_SECONDS
    this.armCircleDidPhaseSwitch = false; // círculos de brazos: si ya se ha cambiado de sentido en la serie en curso -- al pararte la primera vez (ARMCIRCLES_STILL_MS) se cambia de sentido solo y se sigue la serie; al pararte la segunda vez (con los dos sentidos ya hechos) se cierra la serie (ver processArmCircles)
    this.neckLateralStableSince = null;      // giros de cuello: desde cuándo llevas la nariz centrada seguido, sin armar aún (ver NECKLATERAL_CENTER_STABLE_MS)
    this.neckLateralBaselineOffset = 0;      // giros de cuello: desviación nariz/hombros que se considera "centro" -- se fija al armar (ver processNeckLateral), para no exigir que la nariz esté perfectamente centrada de fábrica
    this.neckLateralBaselineVerticalOffset = 0; // giros de cuello: lo mismo que neckLateralBaselineOffset pero en vertical -- referencia de "qué tan abajo cae tu nariz de fábrica" respecto a tus hombros, para poder medir cuánto CAE DE MÁS durante el vaivén (ver NECKLATERAL_MAX_VERTICAL_FACTOR)
    this.neckLateralSide = null;             // giros de cuello: "left" | "right" mientras se confirma un lado (antes de que se sostenga NECKLATERAL_SIDE_STABLE_MS), null en el centro
    this.neckLateralSideSince = null;        // giros de cuello: desde cuándo llevas el lado actual sostenido, sin confirmar aún (ver NECKLATERAL_SIDE_STABLE_MS)
    this.neckLateralAnchorX = null;          // giros de cuello: punto medio de hombros (x) al confirmarse el lado, para medir cuánto se desplaza el torso durante el vaivén (ver NECKLATERAL_DRIFT_TOLERANCE_FACTOR)
    this.neckLateralDrifted = false;         // giros de cuello: si el torso se ha desplazado más de la cuenta durante el vaivén en curso (se avisa, no se penaliza -- ver processNeckLateral)
    this.neckLateralLastTransitionAt = null; // giros de cuello: performance.now() del último vaivén completado (o del armado), para cerrar la serie sola si te paras (ver NECKLATERAL_STILL_MS)
    this.neckTurnStableSince = null;      // giro de cabeza a los lados: desde cuándo llevas la nariz centrada seguido, sin armar aún (ver NECKTURN_CENTER_STABLE_MS)
    this.neckTurnBaselineOffset = 0;      // giro de cabeza a los lados: desviación nariz/hombros que se considera "centro" -- se fija al armar (ver processNeckTurn), mismo concepto que neckLateralBaselineOffset
    this.neckTurnBaselineVerticalOffset = 0; // giro de cabeza a los lados: idem que neckTurnBaselineOffset pero en vertical (ver NECKTURN_MAX_VERTICAL_FACTOR)
    this.neckTurnSide = null;             // giro de cabeza a los lados: "left" | "right" mientras se confirma un lado (antes de que se sostenga NECKTURN_SIDE_STABLE_MS), null en el centro
    this.neckTurnSideSince = null;        // giro de cabeza a los lados: desde cuándo llevas el lado actual sostenido, sin confirmar aún (ver NECKTURN_SIDE_STABLE_MS)
    this.neckTurnAnchorX = null;          // giro de cabeza a los lados: punto medio de hombros (x) al confirmarse el lado, para medir cuánto se desplaza el torso durante el vaivén (ver NECKTURN_DRIFT_TOLERANCE_FACTOR)
    this.neckTurnDrifted = false;         // giro de cabeza a los lados: si el torso se ha desplazado más de la cuenta durante el vaivén en curso (se avisa, no se penaliza -- ver processNeckTurn)
    this.neckTurnLastTransitionAt = null; // giro de cabeza a los lados: performance.now() del último vaivén completado (o del armado), para cerrar la serie sola si te paras (ver NECKTURN_STILL_MS)
    this.neckCirclePrevAngle = null;      // círculos de cuello: último ángulo (radianes) del vector hombros->nariz, para calcular el delta del frame (ver NECKCIRCLE_* y processNeckCircles)
    this.neckCircleAccum = 0;             // círculos de cuello: ángulo acumulado (con signo) desde la última vuelta contada -- al llegar a ±2π se cuenta una repetición, en cualquier sentido (sin bloqueo de sentido, a diferencia de círculos de brazos)
    this.neckCircleCenterStableSince = null; // círculos de cuello: desde cuándo llevas la cabeza centrada y quieta seguido, sin armar aún (ver NECKCIRCLE_CENTER_STABLE_MS)
    this.neckCircleLastProgressAt = null; // círculos de cuello: performance.now() del último frame con giro de verdad (por encima de NECKCIRCLE_MIN_ANGULAR_DELTA) -- para cerrar la serie sola si te paras (ver NECKCIRCLE_STILL_MS)
    this.neckCircleRepStartTime = null;   // círculos de cuello: performance.now() de cuándo empezó la vuelta en curso, para el filtro de ruido NECKCIRCLE_MIN_REP_SECONDS
    this.neckHalfTurnPrevAngle = null;      // media vuelta de cuello: idem que neckCirclePrevAngle, para processNeckHalfTurn
    this.neckHalfTurnAccum = 0;             // media vuelta de cuello: ángulo acumulado (con signo) del vaivén EN CURSO (desde el último cambio de sentido confirmado, o desde que se armó) -- se compara con NECKHALFTURN_MIN_SWING_RAD al confirmarse el siguiente cambio de sentido (ver v2 en el comentario de NECKHALFTURN_*)
    this.neckHalfTurnDirection = null;      // media vuelta de cuello: 1 | -1 | null -- sentido CONFIRMADO del vaivén en curso; null hasta el primer movimiento de verdad de la serie
    this.neckHalfTurnReverseSince = null;   // media vuelta de cuello: performance.now() desde cuándo llevas moviéndote en el sentido contrario al confirmado, sin confirmar aún el cambio (ver NECKHALFTURN_REVERSE_STABLE_MS) -- null mientras sigues en el mismo sentido
    this.neckHalfTurnCenterStableSince = null; // media vuelta de cuello: desde cuándo llevas la cabeza centrada y quieta seguido, sin armar aún (ver NECKHALFTURN_CENTER_STABLE_MS)
    this.neckHalfTurnLastProgressAt = null; // media vuelta de cuello: performance.now() del último frame con giro de verdad -- para cerrar la serie sola si te paras (ver NECKHALFTURN_STILL_MS)
    this.neckHalfTurnRepStartTime = null;   // media vuelta de cuello: performance.now() de cuándo empezó el vaivén en curso, para el filtro de ruido NECKHALFTURN_MIN_REP_SECONDS
    this.armScissorsCenterStableSince = null; // tijeras de brazos: desde cuándo llevas los dos brazos extendidos seguido, sin armar aún (ver ARMSCISSORS_CENTER_STABLE_MS)
    this.armScissorsCrossSince = null;        // tijeras de brazos: desde cuándo llevas los brazos cruzados seguido, sin confirmar aún (ver ARMSCISSORS_CROSS_STABLE_MS)
    this.armScissorsLastTransitionAt = null;  // tijeras de brazos: performance.now() del último vaivén completado (o del armado), para cerrar la serie sola si te paras (ver ARMSCISSORS_STILL_MS)
    this.legRotationStableSince = null;    // rotación de piernas: desde cuándo llevas las dos piernas apoyadas seguido, sin armar aún (ver LEGROTATION_STABLE_MS)
    this.legRotationGroundedSince = null;  // rotación de piernas: desde cuándo llevas las DOS piernas apoyadas de verdad (bajada >= LEGROTATION_RAISE_EXIT_FRACTION) seguido, para exigir LEGROTATION_REARM_STABLE_MS antes de rearmar una subida nueva -- ver processLegRotation
    this.legRotationActiveSide = null;     // rotación de piernas: "left" | "right" mientras una pierna está levantada y se le sigue el ángulo, null si las dos están apoyadas (esperando la siguiente subida)
    this.legRotationPrevAngle = null;      // rotación de piernas: último ángulo local (radianes) cadera->rodilla de la pierna activa, para calcular el delta del frame (ver LEGROTATION_* y processLegRotation)
    this.legRotationAccum = 0;             // rotación de piernas: rotación acumulada (valor absoluto) de la subida en curso -- se compara con LEGROTATION_MIN_ROTATION_DEG al bajar la pierna
    this.legRotationRepStartTime = null;   // rotación de piernas: performance.now() de cuándo empezó la subida en curso, para el filtro de ruido LEGROTATION_MIN_REP_SECONDS
    this.legRotationLastActivityAt = null; // rotación de piernas: performance.now() de la última subida empezada o repetición contada -- para cerrar la serie sola si pasan LEGROTATION_STILL_MS sin nada (ver processLegRotation)
    this.legRotationLastCountedSide = null; // rotación de piernas: "left" | "right" -- lado de la ÚLTIMA repetición contada, para saber si el lado actual es un cambio real y avisar por voz ("pierna izquierda"/"pierna derecha"); se resetea a null en cada serie nueva (ver processLegRotation) -- pedido explícitamente: que funcione para las dos piernas y sea capaz de diferenciarlas
    this.legRotationVisibleSince = null; // rotación de piernas: performance.now() desde cuándo la visibilidad lleva seguido por encima de LEGROTATION_MIN_VISIBILITY, sin cortes -- para no anunciar "a la vista" con un solo frame suelto (ver LEGROTATION_VISIBLE_CONFIRM_MS)
    this.legRotationExcursionHipMidX = null; // rotación de piernas: punto medio (x) de las dos caderas al EMPEZAR la subida en curso -- referencia para detectar si el cuerpo se ha desplazado de sitio (caminando) en vez de girar la pierna en el sitio (ver LEGROTATION_MAX_HIP_DRIFT_FACTOR)
    this.legRotationExcursionHipMidY = null; // rotación de piernas: idem, punto medio (y)
    this.legRotationExcursionHipWidth = null; // rotación de piernas: ancho de cadera al EMPEZAR la subida en curso, para normalizar el desplazamiento medido al cerrarla (ver LEGROTATION_MAX_HIP_DRIFT_FACTOR)
    this.kneeRaiseStableSince = null;      // rodillas altas: desde cuándo llevas las dos piernas apoyadas seguido, sin armar aún (ver KNEERAISE_STABLE_MS)
    this.kneeRaiseActiveSide = null;       // rodillas altas: "left" | "right" mientras una pierna está levantada, null si las dos están apoyadas (esperando la siguiente subida) -- sin lado "pegajoso", no se diferencian left/right entre repeticiones
    this.kneeRaiseRepStartTime = null;     // rodillas altas: performance.now() de cuándo empezó la subida en curso, para el filtro de ruido KNEERAISE_MIN_REP_SECONDS
    this.kneeRaiseLastActivityAt = null;   // rodillas altas: performance.now() de la última subida empezada o repetición contada -- para cerrar la serie sola si pasan KNEERAISE_STILL_MS sin nada
    this.kneeRaiseVisibleSince = null;     // rodillas altas: performance.now() desde cuándo la visibilidad lleva seguido por encima de KNEERAISE_MIN_VISIBILITY, sin cortes -- para no anunciar "a la vista" con un solo frame suelto (ver KNEERAISE_VISIBLE_CONFIRM_MS)
    this.heelKickTrackedSide = null;      // talones al gluteo: "left" | "right" -- que pierna se vigila esta serie, elegida UNA VEZ al armar segun cual se ve mejor (ver el porque junto a "this.state = active" en processHeelKicks); la otra no se procesa en absoluto
    this.heelKickUp = false;              // talones al gluteo: true mientras la pierna vigilada tiene el talon arriba
    this.heelKickRepStart = null;         // talones al gluteo: performance.now() de cuando empezo la subida en curso, para el filtro de ruido HEELKICK_MIN_REP_SECONDS
    this.heelKickExcursionHipMidX = null; // talones al gluteo: punto medio x de las caderas al empezar la subida en curso, para detectar "caminar" (ver HEELKICK_MAX_HIP_DRIFT_FACTOR)
    this.heelKickExcursionHipMidY = null; // talones al gluteo: punto medio y de las caderas al empezar la subida en curso
    this.heelKickExcursionLegScale = null; // talones al gluteo: longitud (cadera-tobillo) de la pierna que se queda apoyada al empezar la subida -- escala para normalizar el desplazamiento anterior
    this.heelKickLastActivityAt = null;   // talones al gluteo: performance.now() de la ultima subida empezada o repeticion contada -- para cerrar la serie sola si pasan HEELKICK_STILL_MS sin nada
    this.heelKickVisibleSince = null;     // talones al gluteo: performance.now() desde cuando la visibilidad lleva seguido por encima de HEELKICK_MIN_VISIBILITY, sin cortes -- para no anunciar "a la vista" con un solo frame suelto (ver HEELKICK_VISIBLE_CONFIRM_MS)
    this.heelKickPrevAngleL = null;      // talones al gluteo: angulo cadera-rodilla-tobillo (grados, pierna izquierda) del ultimo fotograma aceptado -- para descartar saltos imposibles de un fotograma al siguiente (ver HEELKICK_MAX_ANGLE_DELTA)
    this.heelKickPrevAngleR = null;      // talones al gluteo: idem, pierna derecha
    this.heelKickSmoothAngleL = null;    // talones al gluteo: angulo (grados, pierna izquierda) YA suavizado con media movil exponencial, tras el ratchet -- para amortiguar el temblor de la pierna que la camara ve peor (ver HEELKICK_ANGLE_SMOOTHING_ALPHA)
    this.heelKickSmoothAngleR = null;    // talones al gluteo: idem, pierna derecha
    this.hipLateralStableSince = null;      // balanceo lateral de cadera: desde cuándo llevas la cadera centrada (y los pies bien separados) seguido, sin armar aún (ver HIPLATERAL_CENTER_STABLE_MS)
    this.hipLateralBaselineOffset = 0;      // balanceo lateral de cadera: desviación cadera/tobillos que se considera "centro" -- se fija al armar (ver processHipLateral), para no exigir que la cadera esté perfectamente centrada de fábrica
    this.hipLateralBaselineDepth = 0;       // balanceo lateral de cadera: profundidad (z) de la cadera que se considera "centro" -- se fija al armar, para detectar si te alejas/acercas de la cámara en vez de ir a un lado (ver HIPLATERAL_MAX_DEPTH_FACTOR)
    this.hipLateralSide = null;             // balanceo lateral de cadera: "left" | "right" mientras se confirma un lado (antes de que se sostenga HIPLATERAL_SIDE_STABLE_MS), null en el centro
    this.hipLateralSideSince = null;        // balanceo lateral de cadera: desde cuándo llevas el lado actual sostenido, sin confirmar aún (ver HIPLATERAL_SIDE_STABLE_MS)
    this.hipLateralAnkleAnchorX = null;     // balanceo lateral de cadera: punto medio de tobillos (x) al confirmarse el lado, para medir cuánto se desplazan los pies durante el vaivén (ver HIPLATERAL_FEET_DRIFT_TOLERANCE_FACTOR)
    this.hipLateralFeetDrifted = false;     // balanceo lateral de cadera: si los pies se han desplazado más de la cuenta durante el vaivén en curso (se avisa, no se penaliza -- ver processHipLateral)
    this.hipLateralLastTransitionAt = null; // balanceo lateral de cadera: performance.now() del último vaivén completado (o del armado), para cerrar la serie sola si te paras (ver HIPLATERAL_STILL_MS)
    this.hipLateralSmoothHipMidX = null;    // balanceo lateral de cadera: hipMidX YA suavizado con media móvil exponencial (ver HIPLATERAL_GEOMETRY_SMOOTHING_ALPHA) -- amortigua el temblor de un solo fotograma para no desarmar el vaivén por ruido
    this.hipLateralSmoothHipMidZ = null;    // balanceo lateral de cadera: idem, hipMidZ
    this.hipLateralSmoothHipWidth = null;   // balanceo lateral de cadera: idem, hipWidth (la magnitud más pequeña y más ruidosa de las cinco -- la que más lo necesita)
    this.hipLateralSmoothAnkleMidX = null;  // balanceo lateral de cadera: idem, ankleMidX
    this.hipLateralSmoothStanceWidth = null; // balanceo lateral de cadera: idem, stanceWidth
    this.hipForwardBackTrackedSide = null;  // cadera adelante/atrás: "left" | "right" -- qué lado (cadera+tobillo) se vigila, elegido UNA VEZ al armar según cuál se ve mejor (mismo criterio que heelKickTrackedSide)
    this.hipForwardBackStableSince = null;  // cadera adelante/atrás: desde cuándo llevas la cadera centrada seguido, sin armar aún (ver HIPFORWARDBACK_CENTER_STABLE_MS)
    this.hipForwardBackBaselineOffset = 0;  // cadera adelante/atrás: desviación cadera/tobillo que se considera "centro" -- se fija al armar
    this.hipForwardBackFacingSign = 1;      // cadera adelante/atrás: +1 | -1, fijado al armar (nariz respecto al punto medio de hombros), para etiquetar "adelante"/"atrás" con sentido anatómico real y no solo izquierda/derecha de pantalla -- heurística de primera versión
    this.hipForwardBackDirection = null;    // cadera adelante/atrás: "front" | "back" mientras se confirma, null en el centro
    this.hipForwardBackDirectionSince = null; // cadera adelante/atrás: desde cuándo llevas la dirección actual sostenida, sin confirmar aún (ver HIPFORWARDBACK_DIRECTION_STABLE_MS)
    this.hipForwardBackAnkleAnchorX = null; // cadera adelante/atrás: X del tobillo vigilado al confirmarse delante/atrás, para medir cuánto se desplazan los pies durante el vaivén (ver HIPFORWARDBACK_FEET_DRIFT_TOLERANCE_FACTOR)
    this.hipForwardBackFeetDrifted = false; // cadera adelante/atrás: si los pies se han desplazado más de la cuenta durante el vaivén en curso (se avisa, no se penaliza -- ver processHipForwardBack)
    this.hipForwardBackLastTransitionAt = null; // cadera adelante/atrás: performance.now() del último vaivén completado (o del armado), para cerrar la serie sola si te paras (ver HIPFORWARDBACK_STILL_MS)
    this.hipForwardBackSmoothHipX = null;   // cadera adelante/atrás: X de la cadera vigilada YA suavizada con media móvil exponencial (ver HIPFORWARDBACK_GEOMETRY_SMOOTHING_ALPHA)
    this.hipForwardBackSmoothAnkleX = null; // cadera adelante/atrás: idem, X del tobillo vigilado
    this.hipForwardBackSmoothLegLength = null; // cadera adelante/atrás: idem, longitud cadera-tobillo (normalizador -- ver HIPFORWARDBACK_ENTER_FACTOR)
    this.hipForwardBackSmoothHipWidth = null; // cadera adelante/atrás: separación cadera-cadera (Math.hypot XY) YA suavizada con media móvil exponencial -- señal de "¿sigo de perfil?" (ver HIPFORWARDBACK_PROFILE_MAX_HIP_WIDTH_FACTOR)
    this.hipForwardBackNotProfileSince = null; // cadera adelante/atrás: desde cuándo llevas la separación cadera-cadera por encima del umbral de perfil seguido, sin confirmar aún (ver HIPFORWARDBACK_PROFILE_CONFIRM_MS)
    this.hipForwardBackTurnedAway = false; // cadera adelante/atrás: si te has girado hacia la cámara (perdiendo la posición de perfil) durante el vaivén en curso -- igual que hipForwardBackFeetDrifted, invalida la repetición al volver al centro en vez de contarla (ver processHipForwardBack)
    this.forearmRotationStableSince = null;      // rotacion de brazo (codo sujeto): desde cuando llevas un agarre valido seguido, sin armar aun (ver FOREARMROTATION_STABLE_MS)
    this.forearmRotationActiveSide = null;        // rotacion de brazo (codo sujeto): "left" | "right" -- que brazo gira ahora mismo, null mientras no esta armado
    this.forearmRotationGrabBrokenSince = null;   // rotacion de brazo (codo sujeto): performance.now() desde cuando el agarre del brazo activo lleva fallando seguido, sin darlo aun por soltado de verdad (ver FOREARMROTATION_GRAB_BREAK_MS)
    this.forearmRotationPrevAngle = null;         // rotacion de brazo (codo sujeto): ultimo angulo local (radianes) del vector codo->muneca del brazo activo, para calcular el delta del frame (ver FOREARMROTATION_* y processForearmRotation)
    this.forearmRotationAccum = 0;                // rotacion de brazo (codo sujeto): angulo acumulado (con signo) desde la ultima vuelta completa contada -- al llegar a +-2*PI se cuenta una repeticion, en cualquier sentido (sin bloqueo de sentido, igual que circulos de cuello)
    this.forearmRotationLastActivityAt = null;    // rotacion de brazo (codo sujeto): performance.now() del ultimo agarre armado/repeticion contada/cambio de brazo -- para cerrar la serie sola si pasan FOREARMROTATION_STILL_MS sin nada
    this.forearmRotationRepStartTime = null;      // rotacion de brazo (codo sujeto): performance.now() de cuando empezo la vuelta en curso, para el filtro de ruido FOREARMROTATION_MIN_REP_SECONDS
    this.forearmRotationLastCountedSide = null;   // rotacion de brazo (codo sujeto): "left" | "right" -- lado de la ULTIMA repeticion contada, para avisar por voz solo cuando el brazo activo cambia de verdad (mismo mecanismo que legRotationLastCountedSide); se resetea a null en cada serie nueva
    this.wristRotationTogetherStableSince = null; // rotación de muñecas: desde cuándo llevas las manos juntas seguido, sin armar aún (ver WRISTROTATION_TOGETHER_STABLE_MS)
    this.wristRotationBrokenSince = null;          // rotación de muñecas: performance.now() desde cuándo las manos llevan separadas seguido, sin darlo aún por roto de verdad (ver WRISTROTATION_TOGETHER_BREAK_MS)
    this.wristRotationPrevAngle = null;            // rotación de muñecas: último ángulo local (radianes) del vector punto-medio-de-hombros->punto-medio-de-muñecas, para calcular el delta del frame (ver WRISTROTATION_* y processWristRotation)
    this.wristRotationAccum = 0;                   // rotación de muñecas: ángulo acumulado (con signo) desde la última vuelta completa contada -- al llegar a ±2π se cuenta una repetición, en cualquier sentido (sin bloqueo de sentido, igual que círculos de cuello)
    this.wristRotationLastActivityAt = null;       // rotación de muñecas: performance.now() del último frame con manos juntas armadas/giro de verdad/repetición contada -- para cerrar la serie sola si pasan WRISTROTATION_STILL_MS sin nada
    this.wristRotationRepStartTime = null;         // rotación de muñecas: performance.now() de cuándo empezó la vuelta en curso, para el filtro de ruido WRISTROTATION_MIN_REP_SECONDS
    this.wristRotationCenterX = null;               // rotación de muñecas (v2): centro estimado (EMA lenta, ver WRISTROTATION_CENTER_EMA_ALPHA) del círculo que dibujan las manos juntas -- null hasta que se arma, momento en que se siembra con la posición inicial de las manos
    this.wristRotationCenterY = null;               // rotación de muñecas (v2): idem, coordenada Y

    this.sessionStart = null;
    this.lastRepTime = null;
    this.setClosedAt = null; // performance.now() de cuándo se cerró la última serie (con reps o con tiempo aguantado) — para el descanso obligatorio (ver MIN_REST_MS, countRep, notePostureOk, announceRestBlocked)
    // Si ya se ha avisado por voz de "todavía en descanso" EN ESTE descanso —
    // se resetea cada vez que se cierra una serie nueva (ver setClosedAt más
    // arriba, mismos 3 sitios). Antes este aviso se repetía cada 25s
    // (STATUS_VOICE_REPEAT_GAP_MS) mientras insistieras en moverte o te
    // quedaras ya colocada/o esperando — con una postura mantenida (plancha,
    // silla en pared…) eso significa "quedan 88s… quedan 63s… quedan 38s…"
    // sin parar durante todo el descanso, justo la chapa que se reportó.
    // Ahora se dice UNA vez por descanso y ya está — se entendió a la primera.
    this.restBlockedVoiceGiven = false;
    this.restAlerted = false;
    // Cierto solo entre el cierre de una serie de dominadas (normales o
    // de arquero) y el aviso de "descanso acabado" (ver tickRestTimer):
    // recuerda que hay que decir "cuélgate de la barra para empezar la
    // siguiente serie" en ESE momento, no nada más cerrar la serie — decirlo
    // antes no tiene sentido, porque todavía quedan los 90s de descanso
    // obligatorio por delante (ver MIN_REST_MS) y colgarse ahí sería
    // justo lo contrario de descansar.
    this.pendingHangReminder = false;
    // Silencia CUALQUIER voz (avisos, consejos, "te veo"/"no te veo",
    // "¡listo!"...) desde que termina una serie hasta que el reloj de
    // descanso llega a REST_ALERT_SECONDS (1:30). Se pone a true justo
    // al cerrar una serie (con reps o con tiempo aguantado), y se quita
    // en dos sitios: cuando de verdad arranca la siguiente serie
    // (countRep, o al entrar en postura válida en notePostureOk) o
    // cuando el aviso automático de "descanso acabado" salta a los 90s
    // (tickRestTimer). Mientras esté a true, el texto en pantalla se
    // sigue actualizando como siempre — solo la voz se calla.
    this.restVoiceQuiet = false;
    this.restAlertsTriggered = 0;
    this.lastSpokenStatusAt = null; // performance.now() del último aviso de estado hablado, sea cual sea el tipo (ver announceStatus)
    // Antes había un único "lastSpokenStatusKey" compartido por TODOS los
    // tipos de aviso: en cuanto sonaba un aviso de un tipo distinto (p.ej.
    // "Serie de 41s terminada…" al cerrar la plancha), se perdía el
    // recuerdo de cuándo había sonado por última vez "cadera desalineada",
    // así que el siguiente aviso de postura rota volvía a hablar casi al
    // momento (solo 2s después) en vez de esperar los 25s previstos — el
    // "no se calla" que se reportó. Ahora cada tipo de aviso (cada key)
    // lleva su propio cronómetro de 25s, independiente de los demás.
    this.lastSpokenAtByKey = new Map(); // key del aviso -> performance.now() de la última vez que SE DIJO (no solo se intentó) ese tipo
    // Aviso de "ya te veo bien, puedes empezar" — solo una vez en toda la
    // sesión (primera serie), no hace falta repetirlo entre series: para
    // la segunda serie ya sabes cómo colocarte.
    this.startupVoiceGiven = false;
    // Cuántas veces se ha anunciado por voz un "serie terminada" en esta
    // sesión — ver announceSetComplete(). La PRIMERA vez se dice la chapa
    // completa (cómo colocarte para la siguiente serie); a partir de la
    // segunda ya la sabes, así que solo se dice "Serie de N terminada." a
    // secas, sin repetir la misma explicación en cada serie.
    this.setsCompletedVoiceCount = 0;

    this.finishBtn.addEventListener("click", () => this.finish());
    this.cancelBtn.addEventListener("click", () => {
      this.stopCamera();
      window.location.href = root.dataset.cancelUrl;
    });
    this.recalBtn = el("workout-recalibrate");
    if (this.recalBtn) {
      this.recalBtn.addEventListener("click", () => this.beginPrep());
    }
    if (this.debugExportBtn) {
      this.debugExportBtn.addEventListener("click", () => this.exportScissorLog());
    }
  }

  /**
   * Botón #workout-debug-export -- ver exportDebugLogText() arriba
   * para el flujo completo (servidor / compartir / portapapeles /
   * descarga). A pesar del nombre de this.scissorLog (nació con las
   * tijeretas), cubre TODOS los ejercicios de cámara por igual.
   */
  async exportScissorLog() {
    await exportDebugLogText({
      lines: this.scissorLog,
      counterKey: this.counterKey,
      statusEl: this.debugExportStatusEl,
      platform: "web",
    });
  }

  setStatus(text) {
    this.statusEl.textContent = text;
  }

  /**
   * Habla un texto suelto (no un número de repetición — para eso está
   * speakRep). flush:true corta lo que se esté diciendo para decir esto
   * ya (para avisos urgentes); flush:false lo encola detrás sin cortar
   * nada, para no tragarse a media palabra el "¡tres!" de una repetición
   * que acabas de contar.
   */
  speak(text, { flush = true, force = false } = {}) {
    if (!this.voiceEnabled) return;
    // Todavía en el tramo silencioso del descanso (ver restVoiceQuiet):
    // ni avisos, ni consejos, ni "te veo"/"no te veo" — nada de voz. El
    // descanso es de verdad de los 90s (REST_ALERT_SECONDS), cámara
    // colocada una vez al principio de la sesión incluido — así que
    // esto no necesita excepciones.
    if (this.restVoiceQuiet && !force) return;
    // El motor de verdad (Web Speech API) vive en speakOut(), suelto más
    // arriba en este mismo fichero — así circuit.js/plan-session.js
    // también pueden hablar (la cuenta atrás de plancha/plancha
    // lateral/etc. dentro de un circuito o una sesión de plan) sin
    // duplicar aquí esa misma llamada.
    speakOut(text, { flush, force });
  }

  /**
   * Como setStatus(), pero además lo dice en voz alta — para los avisos
   * importantes (que no te ve bien, fin de serie…) que antes solo salían
   * como texto bajo la cámara, donde no los ves si estás en mitad del
   * ejercicio y no mirando la pantalla.
   *
   * El texto en pantalla se actualiza siempre, pero la voz es más
   * selectiva: si el aviso es del MISMO tipo que el anterior, no se
   * repite antes de STATUS_VOICE_REPEAT_GAP_MS — si no, sería un
   * "no te veo bien… no te veo bien… no te veo bien…" sin parar. Si es
   * de un tipo DISTINTO, se dice casi al momento (STATUS_VOICE_MIN_GAP_MS,
   * solo de sobra para no pillar un parpadeo de un par de frames entre
   * dos estados).
   *
   * `speechText` (opcional) es lo que se DICE si es distinto de lo que
   * se ve en pantalla (`text`) — para avisos donde el texto completo es
   * útil leído pero pesado hablado (ver notePostureBroken: "no te veo,
   * ponte en posición" en vez del texto largo de encuadre).
   *
   * `key` identifica el TIPO de aviso para esta comparación — por
   * defecto es el propio texto, pero hace falta pasarlo aparte cuando el
   * texto cambia cada vez aunque sea "la misma" repetición (p.ej. una
   * cuenta atrás con los segundos dentro del texto: sin esto, cada
   * segundo se trataría como un aviso "nuevo" y se leería sin parar).
   *
   * El cronómetro de los 25s es POR KEY (ver lastSpokenAtByKey): que
   * suene un aviso de un tipo distinto no reinicia la espera de este
   * tipo. Aparte, hay un margen corto (STATUS_VOICE_MIN_GAP_MS) frente a
   * CUALQUIER aviso hablado, sea del tipo que sea, solo para no
   * solapar dos avisos casi en el mismo instante.
   */
  announceStatus(text, key = text, speechText = text, force = false) {
    this.setStatus(text);
    if (!this.voiceEnabled) return;
    const now = performance.now();
    const lastForKey = this.lastSpokenAtByKey.get(key) ?? null;
    const keyGap = lastForKey === null ? Infinity : now - lastForKey;
    if (keyGap < STATUS_VOICE_REPEAT_GAP_MS) return;
    const anyGap = this.lastSpokenStatusAt === null ? Infinity : now - this.lastSpokenStatusAt;
    if (anyGap < STATUS_VOICE_MIN_GAP_MS) return;
    this.lastSpokenStatusAt = now;
    this.lastSpokenAtByKey.set(key, now);
    this.speak(speechText, { flush: false, force });
  }

  /**
   * Anuncia el cierre de una serie ("Serie de N terminada. <cómo
   * colocarte para la siguiente>"). En pantalla se ve siempre el aviso
   * completo, pero por VOZ la explicación de "cómo volver a colocarte"
   * solo se dice la primera vez de toda la sesión — a partir de la
   * segunda serie ya sabes cómo empezar, y repetirla en cada serie es
   * justo el "dar la tabarra" que hace tediosa la app. Así que a partir
   * de ahí solo se dice "Serie de N terminada.", corto y al grano.
   */
  announceSetComplete(prefix, waitingMessage) {
    // Descanso obligatorio: la explicación completa ("mínimo N segundos")
    // se decía SIEMPRE, en cada serie — pero es la misma tabarra que el
    // resto de este aviso (cómo colocarte), así que sigue la misma regla:
    // la chapa completa solo la PRIMERA vez de la sesión; a partir de la
    // segunda serie ya sabes que hay descanso obligatorio y cuánto dura,
    // así que por voz basta con "Descanso.", a secas. La regla de "no
    // cuento nada hasta que no pasen los 90s" en sí no cambia (ver
    // MIN_REST_MS, countRep, notePostureOk) — si intentas algo antes de
    // tiempo, announceRestBlocked() sí te lo explica con detalle cada vez,
    // porque ahí hace falta.
    //
    // Calentamientos/estiramientos (NO_REST_COUNTERS): aquí no HAY
    // descanso obligatorio de verdad (ver countRep()/notePostureOk()),
    // así que mencionarlo en la voz era mentira - se reportó que seguía
    // oyéndose "descanso obligatorio de 90s" en el estiramiento cruzado
    // de brazo pese a que ya no se aplicaba. Para estos, el aviso se
    // queda solo en "Serie de N terminada. <cómo seguir>", sin nada de
    // descanso.
    const skipsRest = NO_REST_COUNTERS.has(this.counterKey);
    const restNoteFull = skipsRest ? "" : `Descanso obligatorio: mínimo ${Math.round(MIN_REST_MS / 1000)} segundos. `;
    const restNoteShort = skipsRest ? "" : `Descanso. Quedan ${Math.round(MIN_REST_MS / 1000)} segundos. `;
    const fullText = `${prefix} terminada. ${restNoteFull}${waitingMessage}`;
    this.setStatus(fullText);
    // Con descanso obligatorio de por medio, "cómo colocarte para la
    // siguiente" (waitingMessage) se guarda para decírtelo POR VOZ
    // cuando el descanso termine de verdad (ver maybeAnnounceRestEnd(),
    // llamado cada frame desde processResult) -- decírtelo ya, aquí,
    // junto con "descansa 90 segundos", pedía colocarte antes de que
    // pudieras siquiera empezar el descanso, y así lo describió un
    // usuario real. En pantalla se sigue viendo todo junto de inmediato
    // (fullText, arriba) porque leer con calma no tiene el mismo
    // problema que oírlo una vez y ya.
    this.pendingRestEndMessage = skipsRest ? null : waitingMessage;
    if (!this.voiceEnabled) return;
    const isFirst = this.setsCompletedVoiceCount === 0;
    this.setsCompletedVoiceCount += 1;
    const now = performance.now();
    const anyGap = this.lastSpokenStatusAt === null ? Infinity : now - this.lastSpokenStatusAt;
    if (anyGap < STATUS_VOICE_MIN_GAP_MS) return;
    this.lastSpokenStatusAt = now;
    const immediateVoiceText = skipsRest
      ? fullText
      : `${prefix} terminada. ${isFirst ? restNoteFull : restNoteShort}`;
    this.speak(immediateVoiceText, { flush: false });
  }

  /**
   * Contrapartida de announceSetComplete(): cuando hay descanso
   * obligatorio de por medio, "cómo colocarte para la siguiente" se
   * queda pendiente en pendingRestEndMessage hasta que el descanso
   * (MIN_REST_MS desde setClosedAt) termina de verdad -- aquí se dice
   * por fin, por voz, una sola vez. Se llama en cada frame desde
   * processResult(), así que vale para cualquier ejercicio sin tener
   * que tocar cada uno por separado.
   */
  maybeAnnounceRestEnd(now) {
    if (!this.pendingRestEndMessage || this.setClosedAt === null) return;
    if (now - this.setClosedAt < MIN_REST_MS) return;
    const text = this.pendingRestEndMessage;
    this.pendingRestEndMessage = null;
    if (!this.voiceEnabled) return;
    const anyGap = this.lastSpokenStatusAt === null ? Infinity : now - this.lastSpokenStatusAt;
    if (anyGap < STATUS_VOICE_MIN_GAP_MS) return;
    this.lastSpokenStatusAt = now;
    this.speak(text, { flush: false });
  }

  /**
   * Has intentado contar algo (una repetición, o arrancar un tramo de
   * postura) mientras todavía dura el descanso obligatorio (MIN_REST_MS
   * desde que se cerró la serie anterior) — no se cuenta, pero SÍ hay
   * que decírtelo: a diferencia de announceStatus()/speak(), pasa por
   * alto restVoiceQuiet a propósito (igual que speakRep(), ver su
   * comentario) porque si esto se llama es justo porque has intentado
   * hacer algo en pleno descanso — quedarte callado ahí sería confuso,
   * parecería que la app no funciona o que no te ha visto.
   */
  announceRestBlocked(now) {
    const remaining = Math.max(0, Math.ceil((MIN_REST_MS - (now - this.setClosedAt)) / 1000));
    const text = `Todavía en descanso obligatorio — quedan ${remaining} segundos. No se cuenta nada hasta entonces.`;
    this.setStatus(text);
    if (!this.voiceEnabled) return;
    // Una sola vez POR DESCANSO (ver restBlockedVoiceGiven, reseteado
    // cada vez que se cierra una serie nueva) — no cada
    // STATUS_VOICE_REPEAT_GAP_MS. Con una postura mantenida (plancha,
    // silla en pared…) esto se llama en CADA frame mientras insistes o
    // simplemente te quedas ya colocada/o esperando a que pase el
    // descanso, así que repetirlo cada 25s se oía como "quedan 88s…
    // quedan 63s… quedan 38s…" sin parar — una vez ya sabes cuánto
    // queda y que no se está contando nada, no hace falta que insista.
    if (this.restBlockedVoiceGiven) return;
    const anyGap = this.lastSpokenStatusAt === null ? Infinity : now - this.lastSpokenStatusAt;
    if (anyGap < STATUS_VOICE_MIN_GAP_MS) return;
    this.restBlockedVoiceGiven = true;
    this.lastSpokenStatusAt = now;
    speakOut(text, { flush: false });
  }

  async start() {
    // "Pidiendo acceso a la cámara…" / "Cargando el modelo…" son ruido
    // técnico y mecánico, no guía útil — y ahora, con this.statusEl
    // convertido en shim (ver constructor), da igual usar setStatus()
    // o logScissor() directamente: los dos acaban en el mismo sitio,
    // el registro de depuración, sin pintar nada en pantalla.
    this.logScissor("Pidiendo acceso a la cámara…");
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        // 1280x720, no 640x480: con poca resolución, a cierta distancia
        // de la cámara el cuerpo ocupa muy pocos píxeles y el seguimiento
        // de MediaPipe se vuelve inestable (afecta sobre todo a
        // dominadas, calibradas por posición y no por ángulo). Son
        // valores "ideales" (sin exact/min), así que si la cámara no da
        // para tanto, el navegador se queda con la resolución más
        // cercana que sí soporte — no falla, degrada.
        video: { facingMode: "user", width: 1280, height: 720 },
        audio: false,
      });
    } catch (err) {
      this.announceStatus(
        "No se pudo acceder a la cámara. Revisa los permisos del navegador y recarga la página."
      );
      console.error(err);
      return;
    }

    this.video.srcObject = this.stream;
    await this.video.play();
    this.canvas.width = this.video.videoWidth || 640;
    this.canvas.height = this.video.videoHeight || 480;

    this.logScissor("Cargando el modelo de seguimiento…");
    try {
      const { FilesetResolver, PoseLandmarker } = await import(MEDIAPIPE_BUNDLE_URL);
      const vision = await FilesetResolver.forVisionTasks(MEDIAPIPE_WASM_BASE_URL);
      this.poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
        baseOptions: { modelAssetPath: MODEL_URL, delegate: POSE_DELEGATE },
        runningMode: "VIDEO",
        numPoses: 1,
      });
      this.logScissor(
        `[perf] PoseLandmarker creado pidiendo delegate=${POSE_DELEGATE} (con "GPU" la librería no ` +
        "confirma si de verdad lo consigue usar o cae a CPU en silencio — comparar el resumen [perf] " +
        "de más abajo entre una prueba con cada valor es la forma indirecta de saberlo)."
      );
    } catch (err) {
      this.announceStatus("No se pudo cargar el modelo de seguimiento. Comprueba tu conexión y recarga.");
      console.error(err);
      return;
    }

    this.running = true;
    this.sessionStart = performance.now();
    this.beginPrep();
    if (this.exactReps && this.counterKey === "pullup" && _pullupCalibCache) {
      // Ronda 2 en adelante: se reutiliza la calibración de la barra, sin esperar a colgarte ni calibrar.
      this.prepping = false;
      this.calibrating = false;
      this.shoulderWidth = _pullupCalibCache.shoulderWidth;
      this.barY = _pullupCalibCache.barY;
      this.localBottomY = _pullupCalibCache.localBottomY;
      this.localTopY = this.localBottomY;
      this.state = "down";
      this.repStartTime = performance.now();
      this.lastRepTime = this.repStartTime;
      this.logScissor("[calibración reutilizada de la ronda anterior]");
    }

    this.restIntervalId = setInterval(() => this.tickRestTimer(), 500);
    this.loop();
  }

  beginPrep() {
    // Cuenta atrás para darte tiempo a llegar a la barra y colgarte
    // ANTES de que se tome ninguna medida (esto es lo que fallaba:
    // calibrar de golpe al abrir la cámara, con nadie aún en la barra).

    // Cada (re)calibración marca el final de la serie en curso (si
    // tenía alguna repetición) y el principio de la siguiente.
    if (this.currentSetReps > 0) {
      this.sets.push({ reps: this.currentSetReps, durations: [...this.currentSetDurations] });
      this.currentSetReps = 0;
      this.currentSetDurations = [];
      this.updateSetDisplay();
      this.setClosedAt = performance.now();
      this.restBlockedVoiceGiven = false;
    }
    // Plancha / plancha lateral: el equivalente de lo de arriba pero para
    // un tramo de tiempo aguantado en vez de repeticiones (ver
    // _flushPostureHold) — así pulsar Recalibrar a media plancha también
    // guarda lo aguantado hasta ese momento como una serie, en vez de
    // perderlo.
    if (CAMERA_POSTURE_COUNTERS.has(this.counterKey)) {
      this._flushPostureHold();
    }
    // El contador grande siempre arranca en 0 al empezar una serie nueva.
    if (this.repsEl) this.repsEl.textContent = "0";

    this.prepping = true;
    this.calibrating = false;
    this.prepStartTs = performance.now();
    this.hangStableSince = null;
    this.armsDownSince = null;
    this.groundStableSince = null;
    this.offGroundSince = null;
    this.outOfFrameSince = null;
    this.waveSamples = [];
    this.frontalStableSince = null;
    this.torsoBandStableSince = null;
    this.torsoOutOfBandSince = null;
    this.postureValidSince = null;
    this.postureInvalidSince = null;
    this.lastPostureTickTs = null;
    this.tipIndex = 0;
    this.lastTipAt = null;
    this.calibrationSamples = [];
    this.localBottomY = null;
    this.localTopY = null;
    this.barY = null;
    this.archerPeakLeftAngle = null;
    this.archerPeakRightAngle = null;
    this.archerLastSide = null;
    this.archerLiveLeftAngle = null;
    this.archerLiveRightAngle = null;

    // Los fondos no se calibran ni se cuelgan de ninguna barra: el
    // estado arranca vacío y se fija solo cuando te pones arriba.
    // setStatus, no announceStatus: el aviso hablado de "ya puedes
    // empezar" lo da processDip/processSquat la primera vez que te ve
    // bien en toda la sesión — no hace falta repetirlo en cada serie.
    //
    // dipGroundShoulderY SÍ se reinicia aquí (a diferencia de entre
    // series, ver closeActiveSet): esto es "principio de sesión, o has
    // pulsado Recalibrar" — la cámara puede haberse movido, así que toca
    // volver a aprender tu altura de pie desde cero. Entre series NO se
    // toca, para que no haga falta bajarse y volver a subir para que la
    // referencia sea válida otra vez.
    if (this.counterKey === "dip") {
      this.prepping = false;
      this.state = null;
      this.dipGroundShoulderY = null;
      this.dipArmedSince = null;
      this.dipBreakSince = null;
      this.dipBreakInterruptSince = null;
      this.dipSetPeakShoulderRise = null;
      this.dipShoulderSmoothY = null;
      this.dipShoulderRawPrevY = null;
      this.dipTorsoLength = null;
      this.dipTorsoLengthRawPrev = null;
      this.dipFaceCameraSince = null;
      this.dipGroundHipY = null;
      this.dipHipSmoothY = null;
      this.dipHipRawPrevY = null;
      this.dipSetPeakHipRise = null;
      this.dipBarType = null;
      this.dipTopShoulderY = null;
      this.setStatus("Ponte de pie junto a las paralelas, de perfil a la cámara, un momento — así aprendo tu altura de referencia.");
    } else if (this.counterKey === "pushup") {
      // Tampoco hay nada que calibrar: el ángulo del codo no depende de
      // la distancia a la cámara. Solo hace falta confirmarte tumbado
      // boca abajo, en la posición de arriba (brazos estirados, manos a
      // la altura del pecho, codos pegados al cuerpo), antes de empezar
      // a contar (ver processPushup).
      this.prepping = false;
      this.state = null;
      this.pushupSide = null;
      this.groundStableSince = null;
      this.setStatus(
        "Túmbate boca abajo, de perfil a la cámara, con los brazos estirados, las manos a la altura del " +
        "pecho y los codos pegados al cuerpo (mirando hacia atrás), para empezar."
      );
    } else if (this.counterKey === "benchdip") {
      // Tampoco hay nada que calibrar: ni el ángulo de codo ni las
      // comprobaciones de postura (manos sobre pies, ángulo de cuerpo
      // en L) dependen de la distancia a la cámara. Solo hace falta
      // confirmarte en la posición INICIAL (brazos rectos, cuerpo en
      // L, manos por encima de los pies) antes de empezar a contar —
      // ver processBenchDip. A propósito this.state = null (no
      // "down"): no se cuenta ninguna repetición hasta que no te vea
      // de verdad en esa posición inicial primero.
      this.prepping = false;
      this.state = null;
      this.pushupSide = null;
      this.groundStableSince = null;
      this.offGroundSince = null;
      this.setStatus(
        "Siéntate en el borde de un banco o silla, apoya las manos a los lados con los brazos rectos y " +
        "los codos pegados al cuerpo (mirando hacia atrás). Estira las piernas hacia delante con los " +
        "pies en el suelo, y baja la cadera hasta formar una L con el cuerpo, de perfil a la cámara, " +
        "para empezar."
      );
    } else if (this.counterKey === "pushupfront" || this.counterKey === "squatfront") {
      // De frente: sin barra que calibrar; se arma al verte en postura (ver processPushupFront/processSquatFront).
      this.prepping = false;
      this.state = null;
      this.frontSmooth = null;
      this.frontRef = null;
      this.frontArmSince = null;
      this.groundStableSince = null;
      this.offGroundSince = null;
      this.squatArmedAt = null;
      this.frontW = null;
      this.setStatus(this.groundWaitingMessage());
    } else if (this.counterKey === "squat") {
      // Tampoco hay barra que calibrar aquí: el ángulo de rodilla no
      // depende de la distancia a la cámara. Solo hace falta esperar a
      // verte de pie para no contar media repetición al entrar.
      this.prepping = false;
      this.state = null;
      this.squatSide = null;
      this.squatKneeAngle = null;
      this.squatArmStableSince = null;
      this.squatArmedAt = null;
      this.setStatus("Ponte de perfil a la cámara, de pie, para empezar.");
    } else if (this.counterKey === "splitsquat") {
      // Igual que sentadillas: sin barra que calibrar, el ángulo de
      // rodilla no depende de la distancia a la cámara -- solo hace
      // falta esperar a verte de pie y en zancada para no contar media
      // repetición al entrar en encuadre a media bajada.
      this.prepping = false;
      this.state = null;
      this.splitSquatKneeAngle = null;
      this.splitSquatStableSince = null;
      this.splitSquatStateEnteredAt = null;
      this.setStatus("Ponte en posición para empezar.");
    } else if (this.counterKey === "jumpingjack") {
      // Tampoco hay nada que calibrar: los umbrales son proporcionales
      // al ancho de hombros/cadera, no dependen de la distancia a la
      // cámara. Solo hace falta esperar a verte de pie con los brazos
      // pegados al cuerpo y los pies juntos, para no contar media
      // repetición al entrar.
      this.prepping = false;
      this.state = null;
      this.jjArmStableSince = null;
      this.jjArmBadSince = null;
      this.jjLastTransitionAt = null;
      this.jjArmsUpSeenThisRep = false;
      this.jjLegsOpenSince = null;
      this.setStatus("Ponte de pie, de frente a la cámara, con los brazos pegados al cuerpo y los pies juntos, para empezar.");
    } else if (this.counterKey === "armcircles") {
      // Tampoco hay nada que calibrar: el ángulo es relativo a tu propio
      // hombro, no depende de la distancia a la cámara. Solo hace falta
      // esperar a verte con los dos brazos extendidos, para no arrancar
      // a mitad de un círculo.
      this.prepping = false;
      this.state = null;
      this.armCirclePrevAngleL = null;
      this.armCirclePrevAngleR = null;
      this.armCircleAccum = 0;
      this.armCirclePhase = null;
      this.armCirclePhaseReps = 0;
      this.armCircleArmStableSince = null;
      this.armCircleLastProgressAt = null;
      this.armCircleRepStartTime = null;
      this.armCircleDidPhaseSwitch = false;
      // Total contado en cada sentido a lo largo de TODA la sesión de
      // cámara (no se resetea al cambiar de sentido ni al cerrar una
      // serie -- solo aquí, una vez, al empezar) -- para exigir el
      // objetivo por separado en cada sentido (ver countRep más abajo:
      // pedido explícito "30 hacia delante y 30 hacia atrás", no 30
      // combinadas entre los dos como estaba antes).
      this.armCircleForwardTotal = 0;
      this.armCircleBackwardTotal = 0;
      this.setStatus("Ponte de pie, de frente a la cámara, con los brazos extendidos, para empezar.");
    } else if (this.counterKey === "necklateral") {
      // Tampoco hay nada que calibrar de una barra o de tu altura: el
      // umbral es proporcional al ancho de hombros, no depende de la
      // distancia a la cámara. Solo hace falta esperar a verte
      // centrada/o y quieta/o, para fijar tu propio "centro" real
      // (baseline) antes de empezar a contar vaivenes.
      this.prepping = false;
      this.state = null;
      this.neckLateralStableSince = null;
      this.neckLateralBaselineOffset = 0;
      this.neckLateralBaselineVerticalOffset = 0;
      this.neckLateralSide = null;
      this.neckLateralSideSince = null;
      this.neckLateralAnchorX = null;
      this.neckLateralDrifted = false;
      this.neckLateralLastTransitionAt = null;
      this.setStatus("Ponte de frente a la cámara, mirando al frente, para empezar.");
    } else if (this.counterKey === "neckturn") {
      // Igual que necklateral: nada que calibrar de una barra o de tu
      // altura, el umbral es proporcional al ancho de hombros. Solo
      // hace falta esperar a verte mirando al frente y quieta/o, para
      // fijar tu propio "centro" real (baseline) antes de empezar a
      // contar vaivenes.
      this.prepping = false;
      this.state = null;
      this.neckTurnStableSince = null;
      this.neckTurnBaselineOffset = 0;
      this.neckTurnBaselineVerticalOffset = 0;
      this.neckTurnSide = null;
      this.neckTurnSideSince = null;
      this.neckTurnAnchorX = null;
      this.neckTurnDrifted = false;
      this.neckTurnLastTransitionAt = null;
      this.setStatus("Ponte de frente a la cámara, mirando al frente, para empezar.");
    } else if (this.counterKey === "neckcircles") {
      // Tampoco hay nada que calibrar: el ángulo es relativo a tus
      // propios hombros, no depende de la distancia a la cámara. Solo
      // hace falta esperar a verte de frente y con la cabeza centrada,
      // para no arrancar a mitad de un círculo.
      this.prepping = false;
      this.state = null;
      this.neckCirclePrevAngle = null;
      this.neckCircleAccum = 0;
      this.neckCircleCenterStableSince = null;
      this.neckCircleLastProgressAt = null;
      this.neckCircleRepStartTime = null;
      this.setStatus("Ponte de frente a la cámara, mirando al frente, para empezar.");
    } else if (this.counterKey === "neckhalfturn") {
      // Igual que círculos de cuello: nada que calibrar, solo esperar a
      // verte de frente y con la cabeza centrada.
      this.prepping = false;
      this.state = null;
      this.neckHalfTurnPrevAngle = null;
      this.neckHalfTurnAccum = 0;
      this.neckHalfTurnDirection = null;
      this.neckHalfTurnReverseSince = null;
      this.neckHalfTurnCenterStableSince = null;
      this.neckHalfTurnLastProgressAt = null;
      this.neckHalfTurnRepStartTime = null;
      this.setStatus("Ponte de frente a la cámara, mirando al frente, para empezar.");
    } else if (this.counterKey === "hiplateral") {
      // Tampoco hay nada que calibrar de la distancia a la cámara: los
      // umbrales son proporcionales al ancho de la base de apoyo
      // (tobillo a tobillo), no a lo lejos que estés de la cámara. Solo
      // hace falta esperar a verte de pie, con los pies bien separados
      // y la cadera centrada y quieta, para fijar tu propio "centro"
      // real (baseline) antes de empezar a contar vaivenes.
      this.prepping = false;
      this.state = null;
      this.hipLateralStableSince = null;
      this.hipLateralBaselineOffset = 0;
      this.hipLateralBaselineDepth = 0;
      this.hipLateralSide = null;
      this.hipLateralSideSince = null;
      this.hipLateralAnkleAnchorX = null;
      this.hipLateralFeetDrifted = false;
      this.hipLateralLastTransitionAt = null;
      this.hipLateralSmoothHipMidX = null;
      this.hipLateralSmoothHipMidZ = null;
      this.hipLateralSmoothHipWidth = null;
      this.hipLateralSmoothAnkleMidX = null;
      this.hipLateralSmoothStanceWidth = null;
      this.setStatus("Ponte de frente a la cámara, con los pies bien separados, para empezar.");
    } else if (this.counterKey === "armscissors") {
      // Tampoco hay nada que calibrar: los umbrales son proporcionales
      // al ancho de hombros, no a la distancia a la cámara. Solo hace
      // falta esperar a verte con los dos brazos extendidos en cruz,
      // para no arrancar a mitad de un cruce.
      this.prepping = false;
      this.state = null;
      this.armScissorsCenterStableSince = null;
      this.armScissorsCrossSince = null;
      this.armScissorsLastTransitionAt = null;
      this.setStatus("Ponte de pie, de frente a la cámara, con los brazos extendidos en cruz, para empezar.");
    } else if (this.counterKey === "legrotation") {
      // Tampoco hay nada que calibrar: los umbrales son proporcionales a
      // tu propio muslo (distancia cadera-rodilla), no a la distancia a
      // la cámara. Solo hace falta esperar a verte de pie con las dos
      // piernas apoyadas, para no arrancar a mitad de una subida.
      this.prepping = false;
      this.state = null;
      this.legRotationStableSince = null;
      this.legRotationGroundedSince = null;
      this.legRotationActiveSide = null;
      this.legRotationPrevAngle = null;
      this.legRotationAccum = 0;
      this.legRotationRepStartTime = null;
      this.legRotationLastActivityAt = null;
      this.legRotationLastCountedSide = null;
      this.legRotationVisibleSince = null;
      this.legRotationExcursionHipMidX = null;
      this.legRotationExcursionHipMidY = null;
      this.legRotationExcursionHipWidth = null;
      // Total contado en cada pierna a lo largo de TODA la sesión de
      // cámara (no se resetea al cerrar una serie -- solo aquí, una vez,
      // al empezar) -- para exigir el objetivo por separado en cada
      // pierna (ver countRep más abajo: pedido explícito "30 una pierna y
      // 30 otra", mismo criterio que círculos de brazos).
      this.legRotationLeftTotal = 0;
      this.legRotationRightTotal = 0;
      this.setStatus("Ponte de pie, de frente a la cámara, con las dos piernas apoyadas, para empezar.");
    } else if (this.counterKey === "kneeraises") {
      // Tampoco hay nada que calibrar: los umbrales son proporcionales a
      // tu propio muslo (distancia cadera-rodilla), no a la distancia a
      // la cámara. Solo hace falta esperar a verte de pie con las dos
      // piernas apoyadas, para no arrancar a media zancada.
      this.prepping = false;
      this.state = null;
      this.kneeRaiseStableSince = null;
      this.kneeRaiseActiveSide = null;
      this.kneeRaiseRepStartTime = null;
      this.kneeRaiseLastActivityAt = null;
      this.kneeRaiseVisibleSince = null;
      this.kneeRaiseBias = null;
      this.kneeRaiseRepTainted = false;
      this.frontPosBadSince = null;
      this.frontPosSamples = [];
      this.setStatus("Ponte de pie, de frente a la cámara, con las dos piernas apoyadas, para empezar.");
    } else if (this.counterKey === "heelkicks") {
      // Tampoco hay nada que calibrar: los umbrales son proporcionales a
      // tu propia pierna (cadera-tobillo respecto a muslo+espinilla), no
      // a la distancia a la camara. Solo hace falta esperar a verte de
      // pie con las dos piernas apoyadas, para no arrancar a media
      // zancada.
      this.prepping = false;
      this.state = null;
      this.heelKickTrackedSide = null;
      this.heelKickUp = false;
      this.heelKickRepStart = null;
      this.heelKickExcursionHipMidX = null;
      this.heelKickExcursionHipMidY = null;
      this.heelKickExcursionLegScale = null;
      this.heelKickLastActivityAt = null;
      this.heelKickVisibleSince = null;
      this.heelKickPrevAngleL = null;
      this.heelKickSmoothAngleL = null;
      this.heelKickSmoothAngleR = null;
      this.heelKickPrevAngleR = null;
      this.heelKickAnkleSeenAtL = null;
      this.heelKickAnkleSeenAtR = null;
      this.heelKickSteadySince = null;
      this.heelKickActiveSide = null;
      this.heelKickRepTainted = false;
      this.heelKickRepMaxRaw = 0;
      this.heelKickBias = null;
      this.frontPosBadSince = null;
      this.frontPosSamples = [];
      this.setStatus("Ponte de pie, de frente a la cámara, con las dos piernas apoyadas, para empezar.");
    } else if (this.counterKey === "forearmrotation") {
      // Tampoco hay nada que calibrar: los umbrales son proporcionales
      // al ancho de hombros, no a la distancia a la cámara. Solo hace
      // falta esperar a ver un agarre válido en cualquiera de los dos
      // brazos, para no arrancar a mitad de un giro.
      this.prepping = false;
      this.state = null;
      this.forearmRotationStableSince = null;
      this.forearmRotationActiveSide = null;
      this.forearmRotationGrabBrokenSince = null;
      this.forearmRotationPrevAngle = null;
      this.forearmRotationAccum = 0;
      this.forearmRotationLastActivityAt = null;
      this.forearmRotationRepStartTime = null;
      this.forearmRotationLastCountedSide = null;
      this.setStatus("Agarra el codo de un brazo con la otra mano, cerca del cuerpo, para empezar.");
    } else if (this.counterKey === "wristrotation") {
      // Tampoco hay nada que calibrar: los umbrales son proporcionales
      // al ancho de hombros, no a la distancia a la cámara. Solo hace
      // falta esperar a verte con las manos juntas, para no arrancar a
      // mitad de un giro.
      this.prepping = false;
      this.state = null;
      this.wristRotationTogetherStableSince = null;
      this.wristRotationBrokenSince = null;
      this.wristRotationPrevAngle = null;
      this.wristRotationAccum = 0;
      this.wristRotationLastActivityAt = null;
      this.wristRotationRepStartTime = null;
      this.wristRotationCenterX = null;
      this.wristRotationCenterY = null;
      this.setStatus("Junta las manos con los dedos entrelazados, delante del pecho, para empezar.");
    } else if (this.counterKey === "hipforwardback") {
      // Tampoco hay nada que calibrar de la distancia a la cámara: los
      // umbrales son proporcionales a la longitud de la pierna del lado
      // vigilado, no a lo lejos que estés de la cámara. Solo hace falta
      // esperar a verte de pie, de perfil, con la cadera centrada y
      // quieta, para fijar tu propio "centro" real (baseline) antes de
      // empezar a contar vaivenes -- mismo mecanismo que hiplateral,
      // rotado a de perfil (ver HIPFORWARDBACK_* más arriba).
      this.prepping = false;
      this.state = null;
      this.hipForwardBackTrackedSide = null;
      this.hipForwardBackStableSince = null;
      this.hipForwardBackBaselineOffset = 0;
      this.hipForwardBackFacingSign = 1;
      this.hipForwardBackDirection = null;
      this.hipForwardBackDirectionSince = null;
      this.hipForwardBackAnkleAnchorX = null;
      this.hipForwardBackFeetDrifted = false;
      this.hipForwardBackLastTransitionAt = null;
      this.hipForwardBackSmoothHipX = null;
      this.hipForwardBackSmoothAnkleX = null;
      this.hipForwardBackSmoothLegLength = null;
      this.hipForwardBackSmoothHipWidth = null;
      this.hipForwardBackNotProfileSince = null;
      this.hipForwardBackTurnedAway = false;
      this.setStatus("Ponte de perfil a la cámara, de pie, con la cadera centrada, para empezar.");
    } else if (this.counterKey === "crunch") {
      // Tampoco hay nada que calibrar: se mide el hombro frente a la
      // cadera, en proporción al muslo — ningún valor depende de la
      // distancia a la cámara.
      this.prepping = false;
      this.state = null;
      this.setStatus("Túmbate boca arriba, con la cámara a un lado (de perfil), y encuadra el hombro, la cadera y la rodilla.");
    } else if (this.counterKey === "legraise") {
      this.prepping = false;
      this.state = null;
      this.legRaiseSide = null;
      this.setStatus("Túmbate boca arriba, con la cámara a un lado (de perfil), y encuadra el cuerpo entero, de los hombros a los tobillos.");
    } else if (this.counterKey === "lsit") {
      // Recalibrar/empezar: olvida la altura de pie aprendida y el estado montado -- hay que
      // volver a ponerse de pie junto a las paralelas un momento y subir (ver LSitTracker).
      this.prepping = false;
      this.state = null;
      this.lsitTracker.reset();
      this.lsitDownConfirmed = false;
      this.lsitUpSince = null;
      this.lsitDownSince = null;
      this.setStatus("Ponte de perfil a la cámara, de pie junto a las paralelas, con el cuerpo entero en el encuadre; luego súbete con los brazos estirados.");
    } else if (this.counterKey === "situp") {
      this.prepping = false;
      this.state = null;
      this.setStatus("Túmbate boca arriba con las rodillas dobladas, con la cámara a un lado (de perfil).");
    } else if (this.counterKey === "scissor") {
      this.prepping = false;
      this.state = null;
      this.scissorSide = null;
      this.scissorCandidateSide = null;
      this.scissorCandidateSince = null;
      this.scissorSmoothA = null;
      this.scissorSmoothB = null;
      this.scissorRawPrevA = null;
      this.scissorRawPrevB = null;
      this.scissorTrackA = null;
      this.scissorTrackB = null;
      this.scissorSwitchCount = 0;
      this.setStatus("Túmbate boca arriba, con la cámara a un lado (de perfil), y levanta los pies a un palmo del suelo.");
    } else if (this.counterKey === "doublecrunch") {
      this.prepping = false;
      this.state = null;
      this.setStatus("Túmbate boca arriba, con la cámara a un lado (de perfil), y levanta el torso hasta una posición intermedia.");
    } else if (this.counterKey === "dumbbellcurl") {
      // Tampoco hay nada que calibrar: el ángulo de codo no depende de
      // la distancia a la cámara. Solo hace falta confirmarte DE PERFIL
      // (no de frente — ver el bloque CURL_* más arriba para el
      // porqué), de pie, con el brazo colgando estirado, antes de
      // empezar a contar (ver processDumbbellCurl).
      this.prepping = false;
      this.state = null;
      this.curlSide = null;
      this.curlTopHoldSince = null;
      this.curlShoulderMidPrev = null;
      this.curlCameraShakeSince = null;
      this.curlElbowBaselineY = null;
      this.curlRestSince = null;
      this.setStatus(
        "Ponte de perfil a la cámara, de pie, con la mancuerna colgando, el brazo estirado y el codo pegado " +
        "al cuerpo, para empezar."
      );
    } else if (CAMERA_POSTURE_COUNTERS.has(this.counterKey)) {
      // Plancha / plancha lateral: no hay ni calibración ni ciclo de
      // reps que armar — solo empezar a contar en cuanto la postura sea
      // correcta (ver processPosture/notePostureOk). Antes de pedir la
      // postura en sí (plancha o plancha lateral) se pide un primer paso
      // más fácil (tumbarse del todo, en cualquier orientación) — ver
      // postureGroundConfirmed en processPosture.
      this.prepping = false;
      this.state = null;
      this.currentHoldSeconds = 0;
      if (this.counterKey === "lsithold") this.lsitHoldChecker.reset();
      this.postureGroundConfirmed = false;
      this.postureGroundSince = null;
      this.postureLastOk = null;
      this.postureCandidateOk = null;
      this.postureCandidateSince = null;
      this.postureCountdownLastSecond = null;
      this.postureGoalAnnouncedThisHold = false;
      if (this.repsEl) this.repsEl.textContent = formatHoldSeconds(0);
      this.setStatus(this.postureWaitingMessage());
    } else {
      this.state = "down";
    }
  }

  /**
   * Flexiones DE FRENTE (tumbado boca abajo, mirando a la cámara). Ver el bloque
   * PUSHUPFRONT_* de arriba. Sin gesto de agitar la mano (los brazos trabajan cerca
   * de la cabeza y darían falsos positivos): la serie se cierra saliendo del encuadre,
   * levantándote, o con el botón del reto.
   */
  processPushupFront(lm, now) {
    const w = this.worldLm;
    const sides = [
      { s: L_SHOULDER, e: L_ELBOW, r: L_WRIST },
      { s: R_SHOULDER, e: R_ELBOW, r: R_WRIST },
    ];
    const ang3 = (a, b, c) => {
      const abx = a.x - b.x, aby = a.y - b.y, abz = (a.z || 0) - (b.z || 0);
      const cbx = c.x - b.x, cby = c.y - b.y, cbz = (c.z || 0) - (b.z || 0);
      const mA = Math.hypot(abx, aby, abz), mC = Math.hypot(cbx, cby, cbz);
      if (!mA || !mC) return null;
      const cos = Math.min(1, Math.max(-1, (abx * cbx + aby * cby + abz * cbz) / (mA * mC)));
      return (Math.acos(cos) * 180) / Math.PI;
    };
    const angles = [];
    let angles2d = [];
    for (const sd of sides) {
      const vis = ((lm[sd.s].visibility ?? 1) + (lm[sd.e].visibility ?? 1) + (lm[sd.r].visibility ?? 1)) / 3;
      if (vis < FRONT_MIN_VISIBILITY) continue;
      const a2 = angle(lm[sd.s], lm[sd.e], lm[sd.r]);
      if (a2 !== null) angles2d.push(a2);
      const a3 = w ? ang3(w[sd.s], w[sd.e], w[sd.r]) : null;
      angles.push(a3 !== null ? a3 : a2);
    }
    const usable = angles.filter((a) => a !== null);
    if (!usable.length) {
      this.announceStatus(
        "No se te ven bien los hombros, los codos y las muñecas. Colócate boca abajo, mirando a la cámara, con los brazos en el encuadre.",
        "pushupfront_novis"
      );
      if (this.debugEl) this.debugEl.textContent = "buscando hombros, codos y muñecas de frente…";
      this.frontSmooth = null;
      this.groundStableSince = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;
    const raw = usable.reduce((a, b) => a + b, 0) / usable.length;
    this.frontSmooth = this.frontSmooth == null ? raw : PUSHUPFRONT_SMOOTH_ALPHA * raw + (1 - PUSHUPFRONT_SMOOTH_ALPHA) * this.frontSmooth;
    const elbowAngle = this.frontSmooth;

    // "¿De pie?": solo se puede saber si se ven las caderas -- de frente y tumbado el torso se
    // ve acortado en la imagen, de pie se ve largo. Mejor esfuerzo; sin caderas, se asume tumbado.
    const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER], lH = lm[L_HIP], rH = lm[R_HIP];
    const shoulderW = Math.abs(lS.x - rS.x);
    let torsoRatio = null;
    if (shoulderW > 0.02 && (lH.visibility ?? 1) >= 0.5 && (rH.visibility ?? 1) >= 0.5) {
      torsoRatio = (((lH.y + rH.y) / 2) - ((lS.y + rS.y) / 2)) / shoulderW;
    }
    const standingLike = torsoRatio !== null && torsoRatio > PUSHUPFRONT_STANDING_TORSO_RATIO;

    if (this.state !== null) {
      if (standingLike) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= PUSHUPFRONT_BREAK_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
      } else {
        this.offGroundSince = null;
      }
    }

    if (this.state === null) {
      if (this.exactReps && !standingLike && elbowAngle <= PUSHUPFRONT_DOWN_DEG) {
        // Contrarreloj: has empezado ya abajo (o bajando) sin pasar por la posición de brazos estirados:
        // se arma directamente en "abajo" para que la primera rep cuente al subir.
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= this.groundStableMs) {
          this.state = "bottom";
          this.repStartTime = now;
          this.groundStableSince = null;
          this.offGroundSince = null;
        }
      } else if (!standingLike && elbowAngle >= PUSHUPFRONT_ARM_GATE_DEG) {
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= this.groundStableMs) {
          this.state = "top";
          this.groundStableSince = null;
          this.offGroundSince = null;
          this.announceStatus("Te veo. ¡Listo! Puedes empezar las flexiones.", "ready_to_go");
        } else {
          this.setStatus("Postura vista… confirmando (no te muevas).");
        }
      } else {
        this.groundStableSince = null;
        this.setStatus(this.groundWaitingMessage());
      }
    } else if (this.state === "top") {
      if (elbowAngle <= PUSHUPFRONT_DOWN_DEG) {
        this.state = "bottom";
        this.repStartTime = now;
      }
    } else if (elbowAngle >= PUSHUPFRONT_UP_DEG) {
      this.countRep((now - this.repStartTime) / 1000, now, "Flexión", PUSHUP_MIN_REP_SECONDS);
      this.state = "top";
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `[de frente] codo ${w ? "3D" : "2D"}: ${elbowAngle.toFixed(0)}° (bruto ${raw.toFixed(0)}°, 2D ${angles2d.length ? (angles2d.reduce((a, b) => a + b, 0) / angles2d.length).toFixed(0) : "-"}°) | ` +
        `torso/hombros: ${torsoRatio === null ? "sin caderas" : torsoRatio.toFixed(2)}${standingLike ? " (de pie)" : ""} | estado: ${this.state ?? "esperando"} ` +
        `(abajo ≤${PUSHUPFRONT_DOWN_DEG}°, arriba ≥${PUSHUPFRONT_UP_DEG}°)`;
    }
  }

  /**
   * Sentadillas DE FRENTE. Ver el bloque SQUATFRONT_* de arriba: se mide la distancia
   * vertical cadera-tobillo en anchos de hombros, comparada con la de pie al armar.
   * Sin gesto de agitar la mano (los brazos suelen ir al frente en la sentadilla).
   */
  processSquatFront(lm, now) {
    // REDISEÑO 2026-09-20 tras un log real: el método cadera-tobillo exigía ver piernas enteras y con
    // la cámara cerca (hombros = 87% del ancho) caderas/tobillos daban visibilidad ~0.1 -> nunca armaba.
    // Ahora se sigue la ALTURA GENERAL DEL CUERPO: la altura de los hombros (siempre visibles) relativa
    // al ancho de hombros, contra la de pie. Si además se ven las caderas, cuentan como confirmación
    // en el debug, pero no hacen falta.
    const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
    const lH = lm[L_HIP], rH = lm[R_HIP];
    const shoulderVis = ((lS.visibility ?? 1) + (rS.visibility ?? 1)) / 2;
    const shoulderW = Math.abs(lS.x - rS.x);
    if (shoulderVis < 0.5 || shoulderW < 0.02) {
      this.announceStatus("No se te ven los hombros. Ponte de frente a la cámara.", "squatfront_novis");
      if (this.debugEl) this.debugEl.textContent = `buscando hombros de frente… vis ${shoulderVis.toFixed(2)} ancho ${shoulderW.toFixed(3)}`;
      this.frontSmooth = null;
      this.frontArmSince = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    // Gesto de fin de serie: levantar los dos brazos por encima de la cabeza estando de pie.
    if (this.state === "top") {
      const nose = lm[0], lW = lm[L_WRIST], rW = lm[R_WRIST];
      const armsUp = (lW.visibility ?? 1) >= 0.5 && (rW.visibility ?? 1) >= 0.5 &&
        lW.y < nose.y - 0.2 * shoulderW && rW.y < nose.y - 0.2 * shoulderW;
      if (armsUp) {
        if (this.frontArmsUpSince == null) this.frontArmsUpSince = now;
        if (now - this.frontArmsUpSince >= SQUATFRONT_ARMS_UP_MS) {
          this.frontArmsUpSince = null;
          this.closeActiveSet();
          return;
        }
      } else {
        this.frontArmsUpSince = null;
      }
    }

    // Altura del tronco superior: hombros (siempre visibles) + nariz si se ve. Se convierte a la
    // MISMA unidad que el ancho de hombros (x va en fracción del ancho de imagen, y en fracción del
    // alto: en vertical 9:16 sin esto la bajada parecería 1.8x mayor de lo que es).
    const nose = lm[0];
    const noseOk = (nose.visibility ?? 1) >= 0.5;
    const rawY = noseOk ? (0.5 * ((lS.y + rS.y) / 2) + 0.5 * nose.y) : (lS.y + rS.y) / 2;
    const aspect = (this.video && this.video.videoWidth) ? (this.video.videoHeight / this.video.videoWidth) : 1.78;
    const prevY = this.frontSmooth;
    this.frontSmooth = prevY == null ? rawY : SQUATFRONT_SMOOTH_ALPHA * rawY + (1 - SQUATFRONT_SMOOTH_ALPHA) * prevY;
    this.frontW = this.frontW == null ? shoulderW : 0.3 * shoulderW + 0.7 * this.frontW;
    const W = Math.max(this.frontW, 0.02);
    const y = this.frontSmooth;
    const dropOf = (yy) => ((yy - this.frontRef) * aspect) / W; // >0 = más bajo que de pie, en anchos de hombros

    if (this.state === null) {
      const still = prevY != null && (Math.abs(y - prevY) * aspect) / W <= SQUATFRONT_SHOULDER_ARM_MAX_JUMP;
      if (still) {
        if (this.frontArmSince == null) { this.frontArmSince = now; this.frontRefSum = 0; this.frontRefN = 0; this.frontRefWSum = 0; }
        this.frontRefSum += y; this.frontRefN += 1; this.frontRefWSum += W;
        if (now - this.frontArmSince >= SQUATFRONT_ARM_STABLE_MS) {
          this.frontRef = this.frontRefSum / this.frontRefN; // altura de pie
          this.frontRefW = this.frontRefWSum / this.frontRefN; // ancho de hombros de pie (distancia a la cámara)
          this.state = "top";
          this.frontArmSince = null;
          this.squatArmedAt = now;
          this.announceStatus("¡Listo! Baja en sentadilla y vuelve a subir.", "ready_to_go");
        } else {
          this.setStatus("De pie… confirmando (no te muevas)");
        }
      } else {
        this.frontArmSince = null;
        this.setStatus(this.groundWaitingMessage());
      }
    }

    let drop = 0, wChange = 0;
    if (this.frontRef != null) {
      drop = dropOf(y);
      wChange = Math.abs(W - this.frontRefW) / this.frontRefW;
    }
    if (this.state === "top") {
      if (wChange > SQUATFRONT_MAX_W_CHANGE) {
        // Te has acercado o alejado de la cámara (no es una sentadilla, que no cambia tu distancia):
        // se recalibra la altura de pie aquí en vez de contar el desplazamiento como bajada.
        this.frontRef = y;
        this.frontRefW = W;
        drop = 0;
      } else {
        const armSettled = this.squatArmedAt === null || (now - this.squatArmedAt) >= SQUATFRONT_ARM_SETTLE_MS;
        if (drop >= SQUATFRONT_SHOULDER_DROP_DOWN && armSettled) {
          this.state = "bottom";
          this.repStartTime = now;
        } else if (drop < SQUATFRONT_REF_TRACK_BAND) {
          // La referencia sigue a tu altura de pie (subes de puntillas, te mueves un poco...) y a tu distancia.
          this.frontRef = (1 - SQUATFRONT_REF_ALPHA) * this.frontRef + SQUATFRONT_REF_ALPHA * y;
          this.frontRefW = (1 - SQUATFRONT_REF_ALPHA) * this.frontRefW + SQUATFRONT_REF_ALPHA * W;
        }
      }
    } else if (this.state === "bottom") {
      if (wChange > SQUATFRONT_MAX_W_CHANGE * 1.5 || now - this.repStartTime > SQUATFRONT_MAX_REP_MS) {
        // Te has desplazado hacia/desde la cámara, o llevas demasiado abajo: se descarta, no cuenta.
        this.state = "top";
        this.frontRef = y;
        this.frontRefW = W;
        drop = 0;
      } else if (drop <= SQUATFRONT_SHOULDER_DROP_UP) {
        this.countRep((now - this.repStartTime) / 1000, now, "Sentadilla");
        this.state = "top";
      }
    }

    if (this.debugEl) {
      const hipVis = (((lH.visibility ?? 1) + (rH.visibility ?? 1)) / 2).toFixed(2);
      this.debugEl.textContent =
        `[de frente] alturaTronco ${y.toFixed(3)} (nariz ${noseOk ? nose.y.toFixed(3) : "no"}, hombros ${((lS.y + rS.y) / 2).toFixed(3)}, caderas ${((lH.y + rH.y) / 2).toFixed(3)} vis ${hipVis}) | ` +
        `de pie: ${this.frontRef != null ? this.frontRef.toFixed(3) : "sin calibrar"} | bajada: ${drop.toFixed(2)} (abajo ≥${SQUATFRONT_SHOULDER_DROP_DOWN}, arriba ≤${SQUATFRONT_SHOULDER_DROP_UP}) | ` +
        `ancho ${W.toFixed(2)} cambioAncho ${(wChange * 100).toFixed(0)}% | estado: ${this.state ?? "esperando"}`;
    }
  }

  updateSetDisplay() {
    if (this.setsEl) this.setsEl.textContent = String(this.sets.length + 1);
  }

  loop() {
    if (!this.running) return;
    const now = performance.now();
    const detectStart = performance.now();
    const result = this.poseLandmarker.detectForVideo(this.video, now);
    this.perfFrameTimes.push(performance.now() - detectStart);
    if (this.perfFrameTimes.length >= PERF_LOG_EVERY_N_FRAMES) {
      const times = this.perfFrameTimes;
      const avg = times.reduce((a, b) => a + b, 0) / times.length;
      const max = Math.max(...times);
      const min = Math.min(...times);
      const impliedFps = avg > 0 ? 1000 / avg : 0;
      this.logScissor(
        `[perf] detectForVideo: prom=${avg.toFixed(1)}ms (min ${min.toFixed(1)} / max ${max.toFixed(1)}) ` +
        `sobre ${times.length} frames ≈ ${impliedFps.toFixed(0)} fps de seguimiento real` +
        (this.perfLoggedOnce ? "" : " (primera lectura tras armar/empezar a moverte)")
      );
      this.perfLoggedOnce = true;
      this.perfFrameTimes = [];
    }
    this.drawOverlay(result);
    this.processResult(result, now);
    requestAnimationFrame(() => this.loop());
  }

  drawOverlay(result) {
    const ctx = this.ctx;
    ctx.save();
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    // Espejo, para que se vea natural (como un espejo real)
    ctx.translate(this.canvas.width, 0);
    ctx.scale(-1, 1);

    if (result.landmarks && result.landmarks.length) {
      const lm = result.landmarks[0];
      const nose = lm[NOSE];
      ctx.fillStyle = "#D8654A";
      ctx.beginPath();
      ctx.arc(nose.x * this.canvas.width, nose.y * this.canvas.height, 8, 0, Math.PI * 2);
      ctx.fill();

      if (this.shoulderWidth && this.barY !== null) {
        const moveThresh = MOVE_FACTOR * this.shoulderWidth;
        const barThresh = (this.barY + BAR_MARGIN_FACTOR * this.shoulderWidth) * this.canvas.height;

        // Línea de la barra (medida por tus muñecas al calibrar)
        ctx.strokeStyle = "rgba(201,162,39,0.95)";
        ctx.setLineDash([]);
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(0, this.barY * this.canvas.height);
        ctx.lineTo(this.canvas.width, this.barY * this.canvas.height);
        ctx.stroke();

        ctx.strokeStyle = "rgba(201,162,39,0.5)";
        ctx.setLineDash([4, 4]);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(0, barThresh);
        ctx.lineTo(this.canvas.width, barThresh);
        ctx.stroke();

        const ref = this.state === "down" ? this.localBottomY : this.localTopY;
        if (ref !== null) {
          const refY = ref * this.canvas.height;
          const triggerY =
            this.state === "down"
              ? (ref - moveThresh) * this.canvas.height
              : (ref + moveThresh) * this.canvas.height;
          ctx.strokeStyle = "rgba(122,139,111,0.7)";
          ctx.setLineDash([3, 5]);
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(0, refY);
          ctx.lineTo(this.canvas.width, refY);
          ctx.stroke();

          ctx.strokeStyle = "rgba(216,101,74,0.9)";
          ctx.setLineDash([6, 6]);
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(0, triggerY);
          ctx.lineTo(this.canvas.width, triggerY);
          ctx.stroke();
        }
      }

      if (this.counterKey === "squat" && this.squatSide) {
        const hip = this.squatSide === "left" ? lm[L_HIP] : lm[R_HIP];
        const knee = this.squatSide === "left" ? lm[L_KNEE] : lm[R_KNEE];
        const ankle = this.squatSide === "left" ? lm[L_ANKLE] : lm[R_ANKLE];
        // Verde cuando estás de pie, naranja en el tramo de bajada/sentadilla
        // — así se ve de un vistazo si el ángulo se está midiendo bien.
        ctx.strokeStyle = this.state === "bottom" ? "rgba(216,101,74,0.9)" : "rgba(122,139,111,0.9)";
        ctx.lineWidth = 3;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(hip.x * this.canvas.width, hip.y * this.canvas.height);
        ctx.lineTo(knee.x * this.canvas.width, knee.y * this.canvas.height);
        ctx.lineTo(ankle.x * this.canvas.width, ankle.y * this.canvas.height);
        ctx.stroke();
        [hip, knee, ankle].forEach((p) => {
          ctx.beginPath();
          ctx.arc(p.x * this.canvas.width, p.y * this.canvas.height, 6, 0, Math.PI * 2);
          ctx.fillStyle = "#D8654A";
          ctx.fill();
        });
      }

      if (this.counterKey === "archerpullup" && (this.archerLiveLeftAngle !== null || this.archerLiveRightAngle !== null)) {
        // Un brazo y otro a la vez (a diferencia de pushup/squat, que solo
        // trackean el lado que se ve mejor de perfil): aquí la cámara es
        // frontal, como en dominadas normales, así que se ven los dos.
        // Verde el que está claramente estirado, naranja el que está
        // claramente doblado (~90°), gris si no se distingue con
        // claridad ninguna de las dos cosas todavía.
        const drawArm = (shoulder, elbow, wrist, angleDeg) => {
          const color =
            angleDeg === null
              ? "rgba(150,150,150,0.6)"
              : angleDeg <= ARCHER_BENT_MAX_DEG
              ? "rgba(216,101,74,0.9)"
              : angleDeg >= ARCHER_STRAIGHT_MIN_DEG
              ? "rgba(122,139,111,0.9)"
              : "rgba(150,150,150,0.6)";
          ctx.strokeStyle = color;
          ctx.lineWidth = 3;
          ctx.setLineDash([]);
          ctx.beginPath();
          ctx.moveTo(shoulder.x * this.canvas.width, shoulder.y * this.canvas.height);
          ctx.lineTo(elbow.x * this.canvas.width, elbow.y * this.canvas.height);
          ctx.lineTo(wrist.x * this.canvas.width, wrist.y * this.canvas.height);
          ctx.stroke();
          [shoulder, elbow, wrist].forEach((p) => {
            ctx.beginPath();
            ctx.arc(p.x * this.canvas.width, p.y * this.canvas.height, 6, 0, Math.PI * 2);
            ctx.fillStyle = "#D8654A";
            ctx.fill();
          });
        };
        drawArm(lm[L_SHOULDER], lm[L_ELBOW], lm[L_WRIST], this.archerLiveLeftAngle);
        drawArm(lm[R_SHOULDER], lm[R_ELBOW], lm[R_WRIST], this.archerLiveRightAngle);
      }

      if ((this.counterKey === "pushup" || this.counterKey === "inclinepushup" || this.counterKey === "benchdip") && this.pushupSide) {
        const shoulder = this.pushupSide === "left" ? lm[L_SHOULDER] : lm[R_SHOULDER];
        const elbow = this.pushupSide === "left" ? lm[L_ELBOW] : lm[R_ELBOW];
        const wrist = this.pushupSide === "left" ? lm[L_WRIST] : lm[R_WRIST];
        // Verde con el brazo estirado (arriba), naranja doblándose
        // (abajo) — así se ve de un vistazo si el ángulo se está
        // midiendo bien.
        ctx.strokeStyle = this.state === "bottom" ? "rgba(216,101,74,0.9)" : "rgba(122,139,111,0.9)";
        ctx.lineWidth = 3;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(shoulder.x * this.canvas.width, shoulder.y * this.canvas.height);
        ctx.lineTo(elbow.x * this.canvas.width, elbow.y * this.canvas.height);
        ctx.lineTo(wrist.x * this.canvas.width, wrist.y * this.canvas.height);
        ctx.stroke();
        [shoulder, elbow, wrist].forEach((p) => {
          ctx.beginPath();
          ctx.arc(p.x * this.canvas.width, p.y * this.canvas.height, 6, 0, Math.PI * 2);
          ctx.fillStyle = "#D8654A";
          ctx.fill();
        });
      }
      if (this.counterKey === "dumbbellcurl" && this.curlSide) {
        const shoulder = this.curlSide === "left" ? lm[L_SHOULDER] : lm[R_SHOULDER];
        const elbow = this.curlSide === "left" ? lm[L_ELBOW] : lm[R_ELBOW];
        const wrist = this.curlSide === "left" ? lm[L_WRIST] : lm[R_WRIST];
        // Verde con el brazo estirado (posición de partida), naranja
        // doblado (arriba del curl) — igual que en flexiones/fondos.
        ctx.strokeStyle = this.state === "top" ? "rgba(216,101,74,0.9)" : "rgba(122,139,111,0.9)";
        ctx.lineWidth = 3;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(shoulder.x * this.canvas.width, shoulder.y * this.canvas.height);
        ctx.lineTo(elbow.x * this.canvas.width, elbow.y * this.canvas.height);
        ctx.lineTo(wrist.x * this.canvas.width, wrist.y * this.canvas.height);
        ctx.stroke();
        [shoulder, elbow, wrist].forEach((p) => {
          ctx.beginPath();
          ctx.arc(p.x * this.canvas.width, p.y * this.canvas.height, 6, 0, Math.PI * 2);
          ctx.fillStyle = "#D8654A";
          ctx.fill();
        });
      }
    }
    ctx.restore();
  }

  /**
   * Registra una repetición. Común a todos los ejercicios: lo único que
   * cambia entre dominadas y fondos es CÓMO se detecta, no qué se
   * apunta después.
   */
  /**
   * Dice la repetición en voz alta — para poder contar sin mirar la
   * pantalla, que es justo cuando hace falta (a media dominada).
   *
   * cancel() antes de hablar, no encolar: si las reps vienen más rápido
   * de lo que da tiempo a decir el número, mejor saltarse los
   * intermedios y decir siempre el último de verdad — como haría un
   * entrenador contando en directo, no una cola de mensajes atascada.
   */
  speakRep(n) {
    if (!this.voiceEnabled) return;
    // Ojo: a propósito NO comprueba restVoiceQuiet (a diferencia de
    // speak()) — si esto se llama es porque se acaba de contar una
    // repetición de verdad, así que el descanso ya ha terminado por
    // definición (ver countRep, que además pone restVoiceQuiet a false
    // justo antes de llamar aquí).
    //
    // Solo se anuncia de this.voiceStep en this.voiceStep (con el 1 por
    // defecto, cada rep; con 5 en los ejercicios de cadencia muy rápida,
    // 5, 10, 15…): decirlas todas en esos pocos ejercicios no daba tiempo
    // a seguir el ritmo real de la serie, la voz se quedaba atrás. El
    // contador en pantalla (repsEl, en countRep) no tiene ese problema —
    // se actualiza al instante en cada repetición, sin voz — así que el
    // número real siempre se ve aunque la voz solo marque los múltiplos
    // de voiceStep.
    if (n % this.voiceStep !== 0) return;
    speakOut(numeroEnPalabras(n), { rate: 1.1, force: true }); // un poco más rápido que el habla normal, para no quedarse atrás
  }

  countRep(duration, now, label, minSeconds = MIN_REP_SECONDS) {
    if (duration < minSeconds) return false;   // ruido, no cuenta
    if (this.exactReps && this.currentSetReps >= this.exactReps) return false; // reto de reps exactas: ya completas
    if (this.currentSetReps === 0 && this.setClosedAt !== null && now - this.setClosedAt < MIN_REST_MS && !NO_REST_COUNTERS.has(this.counterKey)) {
      // Descanso obligatorio en curso: aunque te coloques y te muevas
      // antes de tiempo, esto NO cuenta como repetición — antes sí se
      // contaba en silencio si probabas a moverte en pleno descanso.
      this.announceRestBlocked(now);
      return false;
    }
    const d = Math.round(duration * 100) / 100;
    this.reps += 1;
    this.repDurations.push(d);
    this.currentSetReps += 1;
    this.currentSetDurations.push(d);
    this.lastRepTime = now;
    this.restAlerted = false;
    // Repetición de verdad contada: se acabó el descanso (si lo había),
    // vuelve la voz.
    this.restVoiceQuiet = false;
    // Se muestran las reps de ESTA serie, no el total de la sesión (el
    // total sigue guardándose bien en this.reps al terminar). currentSetReps
    // se reinicia a 0 al cerrar cada serie (más abajo), así que la voz
    // vuelve a empezar en "uno" en la siguiente serie automáticamente.
    this.repsEl.textContent = String(this.currentSetReps);
    this.speakRep(this.currentSetReps);

    // Aviso al llegar al objetivo — sin parar nada: se puede seguir
    // contando por encima del objetivo si se quiere (se guarda tal cual,
    // el backend no lo recorta). Es solo un chivatazo, la decisión de
    // seguir o terminar la tomas tú con el botón.
    //
    // Dos niveles, pedidos explícitamente:
    //  - Objetivo DE LA SERIE: currentSetReps llega a targetReps dentro
    //    de una serie que no es la última del objetivo -- "puedes
    //    descansar o seguir", puede repetirse en cada serie.
    //  - Objetivo DE LA SESIÓN: currentSetReps llega a targetReps en la
    //    ÚLTIMA serie del objetivo (this.sets.length + 1 >= targetSets)
    //    -- sustituye al de serie (no se dan los dos avisos a la vez),
    //    se anuncia una sola vez en toda la sesión (this.targetAnnounced,
    //    igual que antes) y conserva el pitido que ya tenía este aviso.
    //
    // this.setGoalAnnouncedAtSetIndex evita repetir cualquiera de los
    // dos avisos en cada repetición extra dentro de la MISMA serie (ver
    // el comentario junto a su declaración, en el constructor).
    //
    // Va en un aviso APARTE (workout-goal-banner), no solo en el texto
    // de estado normal: ese cambia con cada repetición siguiente y el
    // mensaje del objetivo podía pasar sin que te dieras ni cuenta si no
    // estabas mirando esa línea justo en ese instante. El banner se
    // queda puesto todo lo que quieras, hasta que termines o recalibres.
    // Círculos de brazos: el objetivo NO es un total combinado ni
    // "última serie de N", es el mismo número EN CADA SENTIDO por
    // separado (pedido explícito: "30 hacia delante y 30 hacia atrás").
    // Se comprueba aparte, ANTES del disparador normal de abajo, y se
    // excluye a armcircles de ese disparador normal (ver el `this.counterKey
    // !== "armcircles"` añadido ahí) porque currentSetReps mezcla las reps
    // de los dos sentidos (armcircles es una sola serie continua) y con
    // target_sets=1 dispararía el mensaje de "sesión cumplida" en cuanto
    // sumaran 30 entre los dos sentidos, no 30 de cada uno.
    if (this.counterKey === "armcircles" && this.targetSets && this.targetReps && !this.targetAnnounced &&
        this.armCircleForwardTotal >= this.targetReps && this.armCircleBackwardTotal >= this.targetReps) {
      this.targetAnnounced = true;
      if (this.voiceEnabled) speakOut("Has llegado al objetivo de series y repeticiones de este ejercicio. Puedes seguir si quieres, o terminar la sesión.", { flush: false });
      if (this.goalBannerEl) {
        this.goalBannerEl.hidden = false;
        this.goalBannerEl.textContent = `🎯 ¡Has llegado al objetivo de series y repeticiones de este ejercicio! (${this.targetReps} de cada sentido) Puedes seguir si quieres, o terminar la sesión.`;
      }
      this.setStatus(`¡${label} ${this.currentSetReps} de esta serie! (${duration.toFixed(1)}s) — 🎯 ¡Objetivo de series y repeticiones cumplido (${this.targetReps} de cada sentido)!`);
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        [0, 0.14].forEach((t, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.frequency.value = i === 0 ? 880 : 1175;
          osc.connect(gain);
          gain.connect(ctx.destination);
          gain.gain.setValueAtTime(0.18, ctx.currentTime + t);
          osc.start(ctx.currentTime + t);
          osc.stop(ctx.currentTime + t + 0.13);
        });
      } catch (e) { /* si el navegador bloquea audio, no pasa nada */ }
      return true;
    }
    // Rotación de piernas: mismo criterio que círculos de brazos, pero
    // por PIERNA (izquierda/derecha) en vez de por sentido -- pedido
    // explícito: "30 una pierna y 30 otra". Mismo motivo para excluirla
    // también del disparador normal de abajo (currentSetReps mezcla las
    // dos piernas, y con target_sets=1 dispararía en cuanto sumaran 30
    // entre las dos, no 30 de cada una).
    if (this.counterKey === "legrotation" && this.targetSets && this.targetReps && !this.targetAnnounced &&
        this.legRotationLeftTotal >= this.targetReps && this.legRotationRightTotal >= this.targetReps) {
      this.targetAnnounced = true;
      if (this.voiceEnabled) speakOut("Has llegado al objetivo de series y repeticiones de este ejercicio. Puedes seguir si quieres, o terminar la sesión.", { flush: false });
      if (this.goalBannerEl) {
        this.goalBannerEl.hidden = false;
        this.goalBannerEl.textContent = `🎯 ¡Has llegado al objetivo de series y repeticiones de este ejercicio! (${this.targetReps} de cada pierna) Puedes seguir si quieres, o terminar la sesión.`;
      }
      this.setStatus(`¡${label} ${this.currentSetReps} de esta serie! (${duration.toFixed(1)}s) — 🎯 ¡Objetivo de series y repeticiones cumplido (${this.targetReps} de cada pierna)!`);
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        [0, 0.14].forEach((t, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.frequency.value = i === 0 ? 880 : 1175;
          osc.connect(gain);
          gain.connect(ctx.destination);
          gain.gain.setValueAtTime(0.18, ctx.currentTime + t);
          osc.start(ctx.currentTime + t);
          osc.stop(ctx.currentTime + t + 0.13);
        });
      } catch (e) { /* si el navegador bloquea audio, no pasa nada */ }
      return true;
    }
    if (this.counterKey !== "armcircles" && this.counterKey !== "legrotation" && this.targetSets && this.targetReps && this.currentSetReps >= this.targetReps &&
        this.setGoalAnnouncedAtSetIndex !== this.sets.length) {
      this.setGoalAnnouncedAtSetIndex = this.sets.length;
      const isLastSet = !this.targetAnnounced && (this.sets.length + 1 >= this.targetSets);
      if (isLastSet) {
        this.targetAnnounced = true;
        // Al número ya dicho justo antes le sigue el aviso de meta, sin
        // cancelarlo (flush:false) — cancel() en speakRep() ya se encargó
        // de que no se pisen entre sí.
        if (this.voiceEnabled) speakOut("Has llegado al objetivo de series y repeticiones de este ejercicio. Puedes seguir si quieres, o terminar la sesión.", { flush: false });
        if (this.goalBannerEl) {
          this.goalBannerEl.hidden = false;
          this.goalBannerEl.textContent = "🎯 ¡Has llegado al objetivo de series y repeticiones de este ejercicio! Puedes seguir si quieres, o terminar la sesión.";
        }
        this.setStatus(`¡${label} ${this.currentSetReps} de esta serie! (${duration.toFixed(1)}s) — 🎯 ¡Objetivo de series y repeticiones cumplido!`);
        try {
          const ctx = new (window.AudioContext || window.webkitAudioContext)();
          [0, 0.14].forEach((t, i) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.frequency.value = i === 0 ? 880 : 1175;
            osc.connect(gain);
            gain.connect(ctx.destination);
            gain.gain.setValueAtTime(0.18, ctx.currentTime + t);
            osc.start(ctx.currentTime + t);
            osc.stop(ctx.currentTime + t + 0.13);
          });
        } catch (e) { /* si el navegador bloquea audio, no pasa nada */ }
        return true;
      } else {
        if (this.voiceEnabled) speakOut("Objetivo de la serie cumplido. Puedes descansar o seguir.", { flush: false });
        if (this.goalBannerEl) {
          this.goalBannerEl.hidden = false;
          this.goalBannerEl.textContent = "🎯 ¡Objetivo de la serie cumplido! Puedes descansar o seguir.";
        }
        this.setStatus(`¡${label} ${this.currentSetReps} de esta serie! (${duration.toFixed(1)}s) — 🎯 ¡Objetivo de la serie cumplido!`);
        return true;
      }
    }
    this.setStatus(`¡${label} ${this.currentSetReps} de esta serie! (${duration.toFixed(1)}s)`);
    return true;
  }

  /**
   * Fondos: se cuentan por el ÁNGULO DEL CODO (hombro-codo-muñeca), de
   * perfil — ver el bloque DIP_* más arriba para el porqué del cambio
   * de método (antes nariz-vs-codos) y del rediseño que sustituyó la
   * cadera por el hombro como referencia de "¿sigues montada/o?" (con
   * datos reales de por qué).
   *
   * Se usa el lado (izq/der) que mejor se vea, igual que sentadillas:
   * de perfil solo se ve bien un lado del cuerpo.
   *
   * ARMADO: ya solo exige el codo recto y quieto (DIP_ARM_STABLE_MS) —
   * a propósito no se exige ninguna condición de hombro aquí. El coste
   * de armar un pelín pronto (p.ej. estando de pie con los brazos
   * rectos junto a la barra) es mínimo, porque ninguna repetición se
   * cuenta hasta que el codo se doble Y el hombro baje de verdad (ver
   * más abajo) — y a cambio se evita el problema real que sí tenía
   * exigir cadera/muñeca para armar: tardaba mucho en decir "te veo", o
   * directamente no llegaba a armar nunca.
   *
   * Mientras no estás armado (this.state === null) se va aprendiendo tu
   * altura de hombro de pie (dipGroundShoulderY, el valor MÁS BAJO
   * visto — Y crece hacia abajo), que sirve de referencia para saber
   * cuánto ha subido el hombro al montarte en las paralelas. No se
   * reinicia entre series (ver beginPrep/closeActiveSet): la cámara no
   * se mueve entre series, así que la referencia sigue siendo válida.
   * En el mismo tramo de pie se aprende TAMBIÉN, una sola vez, el largo
   * de tronco (dipTorsoLength, hombro-cadera) que se usa para normalizar
   * "cuánto ha subido/bajado el hombro" — ver el sexto bug, en el
   * bloque DIP_* de más arriba, sobre por qué ya no se mide ese largo
   * de referencia frame a frame con el brazo (hombro-codo).
   *
   * Una vez armado, cada fondo se cuenta en dos pasos, igual que
   * flexiones/sentadillas: el codo se dobla hasta ABAJO
   * (elbowAngle <= DIP_DOWN_ANGLE_DEG) y luego vuelve a estar recto
   * (elbowAngle >= DIP_UP_ANGLE_DEG) — ese regreso a ARRIBA es el que
   * intenta contar la repetición. Los dos pasos exigen ADEMÁS que el
   * hombro siga por encima de una fracción de su propio pico de subida
   * en esta serie (DIP_SHOULDER_RISE_MOUNTED_RATIO) — si no, el propio
   * gesto de montarte o bajarte de las paralelas (el codo también pasa
   * de doblado a recto, o al revés, sin ser un fondo de verdad) se
   * contaría como repetición. Y, justo antes de dar la repetición por
   * buena, se exige que el hombro haya bajado un mínimo de verdad
   * durante el tramo de abajada (DIP_MIN_SHOULDER_DROP_FACTOR) — esto
   * descarta gestos del brazo (rascarte, ajustarte algo) que doblan y
   * estiran el codo sin mover el cuerpo.
   *
   * El desmonte (bajarte de las paralelas) usa la misma idea en espejo,
   * con un umbral más estricto (DIP_SHOULDER_RISE_DISMOUNT_RATIO): codo
   * recto Y hombro de vuelta cerca de la referencia de pie. Un fondo
   * profundo de verdad nunca cumple esto a media repetición porque el
   * codo está DOBLADO en el punto más bajo. Reutiliza
   * closeActiveSet/noteAbsence/checkWaveGesture, igual que el resto de
   * GROUND_STYLE_COUNTERS, en vez de un cierre de serie propio.
   *
   * Todo lo anterior (calibración, shoulderRise, pico de la serie,
   * bajada de la repetición) usa la Y del hombro YA FILTRADA
   * (shoulderY: recorte de salto + media móvil, ver DIP_SHOULDER_MAX_
   * Y_JUMP/DIP_SHOULDER_SMOOTHING_ALPHA y el tercer bug real en el
   * bloque DIP_* de más arriba) — un salto puntual de un solo frame ya
   * no puede arrastrar ni la referencia de pie ni el pico de subida.
   * elbowAngle sigue usando el hombro BRUTO, sin este filtro, porque ahí
   * interesa la lectura más inmediata posible.
   *
   * Hay una TERCERA forma (además del desmonte "de perfil" por umbral,
   * arriba, y el gesto de la mano vía checkWaveGesture) de dar una serie
   * por terminada: girarte de frente a la cámara, para que se te vean
   * los DOS hombros a la vez con buena confianza — algo que nunca pasa
   * a media repetición, porque de perfil uno de los dos siempre queda
   * tapado por el propio cuerpo (ver DIP_FACE_CAMERA_VISIBILITY/STABLE_
   * MS y el cuarto ajuste en el bloque DIP_* de más arriba, con los
   * datos reales que lo motivaron). Se comprueba nada más entrar en la
   * función, antes incluso del chequeo de visibilidad por lado, porque
   * de frente los dos hombros se ven bien aunque de perfil uno de ellos
   * no llegara al mínimo.
   */
  processDip(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now)) {
      this.closeActiveSet();
      return;
    }

    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lElbow = lm[L_ELBOW], rElbow = lm[R_ELBOW];
    const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    // Tercera forma de terminar la serie: girarte de frente a la cámara.
    // De perfil (como se hace el ejercicio) SOLO se ve bien un hombro —
    // el otro queda tapado por el propio cuerpo — así que ver los DOS a
    // la vez con buena confianza es una señal inequívoca de que te has
    // girado a mirar a la cámara, algo que nunca pasa a media
    // repetición. Se comprueba aquí, antes del chequeo de visibilidad
    // por lado de más abajo, para que funcione aunque de perfil un
    // hombro no llegara al mínimo (ver el cuarto ajuste, DIP_* arriba).
    //
    // NOVENO BUG REAL (visto en un registro con build
    // 2026-08-25-fondos-octavo-bug-desmonte, o sea código YA con el
    // octavo arreglo puesto — este es nuevo, no es el mismo de antes):
    // con la cámara del PC colocada DE FRENTE (el usuario probando
    // "desde localhost" sentado delante del portátil, no de perfil en
    // las paralelas), hombro_izq_vis y hombro_der_vis salen ~0.99–1.00
    // TODO el rato, incluso recién armado el contador. Eso hace que
    // facingCamera sea true casi siempre y, a los DIP_FACE_CAMERA_
    // STABLE_MS (500ms) de estar armado, esto cerraba la serie solo.
    // El primer arreglo (no dejar que dispare hasta contar AL MENOS UNA
    // repetición, this.currentSetReps > 0) tapaba el caso de "nunca
    // arranca", pero UNDÉCIMO BUG REAL, con un registro de build
    // 2026-08-25-fondos-solo-baja-por-rodilla (cámara de perfil de
    // verdad esta vez, confirmado por el usuario — "llevo dejando la
    // PUTA CAMARA DE LADO TODO ESTE RATO"): hombro_izq_vis/hombro_der_vis
    // se quedan en ~0.95–1.00 SIEMPRE, en top Y TAMBIÉN en bottom —
    // ejemplos reales del registro: a 45.6s, en pleno fondo (estado=
    // bottom, ángulo=89°), hombro_izq_vis=1.00 hombro_der_vis=1.00; a
    // 46.3s, también en bottom (ángulo=162°... bajando), igual. O sea:
    // para la cámara/postura real de este usuario, MediaPipe da los DOS
    // hombros por buenos SIEMPRE, sin importar si está de perfil de
    // verdad o girado — la señal simplemente no distingue nada para él.
    // Resultado, con currentSetReps > 0 ya puesto: en cuanto se cuenta
    // la primera repetición de una serie y el cuerpo vuelve a "top"
    // (brazos estirados) más de 500ms seguidos — que es exactamente lo
    // normal entre una repetición y la siguiente — esto disparaba y
    // cerraba la serie con 1 sola repetición. Se repite IDÉNTICO tres
    // veces en el mismo registro: cierra en 47.0s (1 rep), 49.4s (1 rep)
    // y 54.6s (1 rep) — siempre justo ~500-530ms después de la rep
    // contada, nunca por un desmonte de verdad. Esto es el "cuenta 1,
    // 1, 1..." que reporta el usuario: no es que el conteo de
    // repeticiones falle, es que la serie se cierra sola después de la
    // primera.
    //
    // Con dos registros reales ahora demostrando que esta señal no sirve
    // para distinguir "de perfil, entre repeticiones" de "girado de
    // frente a la cámara" en NINGUNA cámara/postura probada hasta ahora,
    // el arreglo tampoco es subir DIP_FACE_CAMERA_VISIBILITY (ya está al
    // máximo posible, 1.00, así que no hay margen — no es adivinar un
    // número nuevo, es que el propio dato ya no deja hueco para ningún
    // umbral que funcione). Así que esta tercera forma de cerrar la
    // serie queda DESACTIVADA por ahora: this.state y
    // this.currentSetReps ya no se consultan aquí, y closeActiveSet()
    // nunca se llama desde este bloque. Las otras dos formas de cerrar
    // la serie (el desmonte por ángulo/hombro/rodilla/cadera, más abajo
    // — que si funciona: ver [DESMONTE DETECTADO] a los 63.9s del mismo
    // registro — y el gesto de la mano, checkWaveGesture) siguen intactas
    // y no dependían de esto.
    this.dipFaceCameraSince = null;

    const leftVis = (
      (lShoulder.visibility ?? 1) + (lElbow.visibility ?? 1) + (lWrist.visibility ?? 1)
    ) / 3;
    const rightVis = (
      (rShoulder.visibility ?? 1) + (rElbow.visibility ?? 1) + (rWrist.visibility ?? 1)
    ) / 3;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    if (vis < DIP_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien el hombro, el codo y la muñeca de un lado. Ponte de perfil a la cámara.");
      if (this.debugEl) this.debugEl.textContent = "buscando hombro, codo y muñeca de perfil…";
      this.logScissor(
        `[visibilidad baja] vis=${vis.toFixed(2)} (mín ${DIP_MIN_VISIBILITY}) estado=${this.state ?? "null"} — se reinicia dipArmedSince/dipBreakSince`
      );
      this.dipArmedSince = null;
      this.dipBreakSince = null;
      this.dipBreakInterruptSince = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    const shoulder = useLeft ? lShoulder : rShoulder;
    const elbow = useLeft ? lElbow : rElbow;
    const wrist = useLeft ? lWrist : rWrist;
    const hip = useLeft ? lHip : rHip;
    const knee = useLeft ? lKnee : rKnee;
    const ankle = useLeft ? lAnkle : rAnkle;

    const elbowAngle = angle(shoulder, elbow, wrist);
    if (elbowAngle === null) return;

    // Ángulo de rodilla del mismo lado — para saber si las paralelas son
    // bajas (rodilla doblada cerca de 90°, ver dipBarType más abajo). NO
    // se exige (a diferencia de elbowAngle) porque en paralelas ALTAS la
    // pierna puede quedar fuera de encuadre sin que eso sea un problema
    // — solo se usa si además se ve razonablemente bien (kneeVisOk, más
    // abajo).
    const kneeAngle = angle(hip, knee, ankle);

    // Recorte de salto + media móvil sobre la Y del hombro — SOLO para lo
    // que sigue (calibración, "cuánto ha subido", pico de la serie,
    // cuánto ha bajado en la repetición). "shoulder" de arriba (bruto,
    // sin retraso) se sigue usando tal cual para elbowAngle, porque ahí
    // interesa la lectura más inmediata posible. Mismo patrón de dos
    // pasos que las tijeretas (SCISSOR_MAX_LIFT_JUMP + SCISSOR_SMOOTHING_
    // ALPHA): primero se recorta el salto bruto de un frame al siguiente
    // a un máximo físico (DIP_SHOULDER_MAX_Y_JUMP) y LUEGO se pasa por una
    // media móvil exponencial (DIP_SHOULDER_SMOOTHING_ALPHA) — ver el
    // tercer bug (arriba, en el bloque DIP_*) para los datos reales que
    // motivaron esto: un salto puntual de Y sin recortar llegó a arrastrar
    // tanto la referencia de pie (dipGroundShoulderY) como el pico de
    // subida de la serie (dipSetPeakShoulderRise).
    let rawShoulderY = shoulder.y;
    if (this.dipShoulderRawPrevY !== null) {
      const deltaShoulderY = rawShoulderY - this.dipShoulderRawPrevY;
      if (Math.abs(deltaShoulderY) > DIP_SHOULDER_MAX_Y_JUMP) {
        rawShoulderY = this.dipShoulderRawPrevY + Math.sign(deltaShoulderY) * DIP_SHOULDER_MAX_Y_JUMP;
      }
    }
    this.dipShoulderRawPrevY = rawShoulderY;
    if (this.dipShoulderSmoothY === null) {
      this.dipShoulderSmoothY = rawShoulderY;
    } else {
      this.dipShoulderSmoothY += DIP_SHOULDER_SMOOTHING_ALPHA * (rawShoulderY - this.dipShoulderSmoothY);
    }
    const shoulderY = this.dipShoulderSmoothY;

    // Mismo recorte de salto + media móvil, pero sobre la Y de la
    // CADERA — para el caso de paralelas altas (dipBarType, más abajo),
    // donde la referencia de desmonte es la cadera en vez del hombro.
    let rawHipY = hip.y;
    if (this.dipHipRawPrevY !== null) {
      const deltaHipY = rawHipY - this.dipHipRawPrevY;
      if (Math.abs(deltaHipY) > DIP_SHOULDER_MAX_Y_JUMP) {
        rawHipY = this.dipHipRawPrevY + Math.sign(deltaHipY) * DIP_SHOULDER_MAX_Y_JUMP;
      }
    }
    this.dipHipRawPrevY = rawHipY;
    if (this.dipHipSmoothY === null) {
      this.dipHipSmoothY = rawHipY;
    } else {
      this.dipHipSmoothY += DIP_SHOULDER_SMOOTHING_ALPHA * (rawHipY - this.dipHipSmoothY);
    }
    const hipY = this.dipHipSmoothY;

    // Referencia de "altura de pie": se toma nota mientras NO estés
    // montado (this.state === null) — así, en cuanto te subes a las
    // paralelas y el hombro sube de verdad, hay algo con qué comparar.
    // Solo guarda el valor MÁS BAJO visto (Math.max de la coordenada Y,
    // que crece hacia abajo), y SOLO en frames donde el hombro en sí se
    // ve razonablemente bien (DIP_CALIBRATION_MIN_VISIBILITY) — así un
    // único frame con mala lectura no puede arruinar la referencia para
    // el resto de la sesión (ver el bloque DIP_* de más arriba para el
    // bug real que esto arregla). No se reinicia entre series (ver
    // beginPrep): la cámara no se mueve entre series, así que no hace
    // falta bajarse y volver a subir para que siga siendo válida. Si
    // por lo que sea queda mal aprendida, pulsar Recalibrar la reinicia
    // desde cero.
    const shoulderVisOk = (shoulder.visibility ?? 1) >= DIP_CALIBRATION_MIN_VISIBILITY;
    if (this.state === null && shoulderVisOk) {
      this.dipGroundShoulderY =
        this.dipGroundShoulderY === null ? shoulderY : Math.max(this.dipGroundShoulderY, shoulderY);
    }

    // Misma referencia, pero de la cadera de pie — para el caso de
    // paralelas altas (dipBarType, más abajo).
    const hipVisOk = (hip.visibility ?? 1) >= DIP_CALIBRATION_MIN_VISIBILITY;
    if (this.state === null && hipVisOk) {
      this.dipGroundHipY = this.dipGroundHipY === null ? hipY : Math.max(this.dipGroundHipY, hipY);
    }

    // Largo de referencia para normalizar "cuánto ha subido/bajado el
    // hombro": TRONCO (hombro-cadera), aprendido UNA VEZ de pie y
    // congelado para el resto de la serie — igual que dipGroundShoulderY,
    // y con el mismo filtro de recorte de salto + media móvil que la Y
    // del hombro. Ya NO se mide frame a frame con el largo de brazo
    // (hombro-codo): ese largo se acorta mucho en 2D cuando el brazo gira
    // fuera del plano de la cámara al doblarse del todo, lo que disparaba
    // hombro_subido a valores como -2.94 en mitad de fondos reales y
    // bloqueaba para siempre la transición arriba→abajo (ver el sexto bug,
    // en el bloque DIP_* de más arriba, con los datos reales).
    let rawTorsoLength = Math.hypot(shoulder.x - hip.x, shoulder.y - hip.y);
    if (this.dipTorsoLengthRawPrev !== null) {
      const deltaTorsoLength = rawTorsoLength - this.dipTorsoLengthRawPrev;
      if (Math.abs(deltaTorsoLength) > DIP_TORSO_LENGTH_MAX_JUMP) {
        rawTorsoLength = this.dipTorsoLengthRawPrev + Math.sign(deltaTorsoLength) * DIP_TORSO_LENGTH_MAX_JUMP;
      }
    }
    this.dipTorsoLengthRawPrev = rawTorsoLength;
    const torsoVisOk = shoulderVisOk && (hip.visibility ?? 1) >= DIP_CALIBRATION_MIN_VISIBILITY;
    if (this.state === null && torsoVisOk) {
      this.dipTorsoLength =
        this.dipTorsoLength === null
          ? rawTorsoLength
          : this.dipTorsoLength + DIP_SHOULDER_SMOOTHING_ALPHA * (rawTorsoLength - this.dipTorsoLength);
    }

    const shoulderRise =
      this.dipGroundShoulderY === null || !this.dipTorsoLength
        ? 0
        : (this.dipGroundShoulderY - shoulderY) / this.dipTorsoLength;

    // Mismo cálculo, con la cadera — solo se usa de verdad en paralelas
    // altas (dipBarType === "alta", más abajo), pero se calcula siempre
    // para poder decidir dipBarType nada más armar.
    const hipRise =
      this.dipGroundHipY === null || !this.dipTorsoLength
        ? 0
        : (this.dipGroundHipY - hipY) / this.dipTorsoLength;

    if (this.state === null) {
      if (this.dipGroundShoulderY === null || !this.dipTorsoLength) {
        // No debería pasar salvo que el hombro o la cadera lleven toda la
        // sesión mal vistos (shoulderVisOk/torsoVisOk siempre falso).
        this.setStatus("Ponte de pie junto a las paralelas, de perfil a la cámara, un momento…");
      } else if (elbowAngle >= DIP_UP_ANGLE_DEG) {
        // Armado solo por el ángulo del codo — ver el docstring de
        // processDip para por qué ya no se exige nada de hombro aquí.
        if (this.dipArmedSince === null) this.dipArmedSince = now;
        if (now - this.dipArmedSince >= DIP_ARM_STABLE_MS) {
          this.state = "top";
          this.dipArmedSince = null;
          // Pico de subida de hombro de la serie que empieza ahora — de
          // aquí salen, más abajo, los umbrales de montada/o y desmonte
          // (ver DIP_SHOULDER_RISE_MOUNTED_RATIO/DISMOUNT_RATIO). Mínimo
          // 0.01 para no dividir cerca de cero si por lo que sea el
          // hombro no ha subido nada todavía en este primer frame.
          this.dipSetPeakShoulderRise = Math.max(shoulderRise, 0.01);
          this.dipSetPeakHipRise = Math.max(hipRise, 0.01);
          // Se redetermina la altura de las paralelas en cada serie
          // nueva (por si acaso, aunque la cámara no se mueva entre
          // series) — ver dipBarType, más abajo, mientras estés arriba.
          this.dipBarType = null;
          // dipTopShoulderY también se reinicia en cada serie nueva (no
          // solo al Recalibrar): si no, una lectura puntual mala de un
          // solo frame en una serie podía quedarse fija como referencia
          // de "arriba" para TODAS las series siguientes de la sesión,
          // sin corregirse nunca — ver el comentario largo, más abajo,
          // junto a dipRepShoulderTopY.
          this.dipTopShoulderY = null;
          this.dipFaceCameraSince = null;
          if (!this.startupVoiceGiven) {
            this.startupVoiceGiven = true;
            this.announceStatus(
              "Te veo. ¡Listo! Baja y sube. Para terminar una serie, bájate de las paralelas, ponte de frente a la cámara, sal del encuadre, o levanta un brazo y agita la mano.",
              "startup_ready"
            );
          } else {
            this.announceStatus("¡Listo! Baja y sube.", "ready_to_go");
          }
        } else {
          this.setStatus("Postura vista… confirmando (no te muevas).");
        }
      } else {
        this.dipArmedSince = null;
        this.setStatus("Agárrate a las paralelas con los brazos estirados para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent =
          `ángulo codo (${useLeft ? "izq" : "der"}): ${elbowAngle.toFixed(0)}° | hombro subido: ${shoulderRise.toFixed(2)} | esperando`;
      }
      this.logScissor(
        `[esperando armar] ángulo=${elbowAngle.toFixed(0)}° hombro_subido=${shoulderRise.toFixed(2)} ` +
        `hombro_y=${shoulderY.toFixed(3)}(bruto ${shoulder.y.toFixed(3)}) ` +
        `dipGroundShoulderY=${this.dipGroundShoulderY === null ? "-" : this.dipGroundShoulderY.toFixed(3)}`
      );
      return;
    }

    // Ya armado: el pico de subida de hombro de ESTA serie se sigue
    // actualizando mientras estás arriba — así los umbrales de más
    // abajo se adaptan a lo que TÚ has enseñado en esta serie concreta,
    // no a un número fijo adivinado sin datos reales.
    if (this.state === "top") {
      this.dipSetPeakShoulderRise = Math.max(this.dipSetPeakShoulderRise ?? 0.01, shoulderRise);
      this.dipSetPeakHipRise = Math.max(this.dipSetPeakHipRise ?? 0.01, hipRise);

      // Décimo bug real (reaplicado): mientras estás de verdad arriba,
      // se guarda aquí la Y MÁS ALTA (más pequeña) vista DESDE que se
      // armó esta serie — así, cuando empiece la bajada, hay una
      // referencia de "arriba" de la repetición ENTERA, no solo del
      // último frame antes de cruzar el ángulo de abajo (ver el
      // comentario largo junto a dipRepShoulderTopY, más abajo, con los
      // datos que motivaron esto).
      this.dipTopShoulderY =
        this.dipTopShoulderY === null ? shoulderY : Math.min(this.dipTopShoulderY, shoulderY);

      // Altura de las paralelas (dipBarType): se decide UNA VEZ por
      // serie, mientras estés arriba, y se congela en cuanto se decide
      // (no se vuelve a tocar hasta la siguiente serie armada).
      //
      // Solo se clasifica "baja" por rodilla (≤SQUAT_DOWN_ANGLE_DEG, el
      // mismo umbral ya probado en sentadillas, con visibilidad de
      // rodilla/tobillo comprobada) — es la única señal fiable que
      // tenemos: la cadera sube al montar TANTO en paralelas bajas como
      // en altas (el propio usuario lo confirmó: montar en posición de
      // soporte sube el torso el largo del brazo en los dos casos), así
      // que un umbral de "cadera ha subido algo" no distingue nada — solo
      // distinguiría paralelas altas de verdad (estilo street workout, en
      // las que el cuerpo sube 40-50cm porque los brazos están
      // completamente estirados) si tuviéramos un umbral validado con
      // datos reales de ESE caso, que no tenemos todavía. Así que, de
      // momento, NO hay clasificación automática de "alta": si la rodilla
      // no se ve doblada (o no se ve bien), dipBarType se queda sin
      // decidir y dismountShape (más abajo) sigue usando el hombro, tal
      // como se hacía antes de este cambio — el camino "alta" (cadera)
      // queda ya escrito más abajo para el día que haya un umbral real
      // con el que activarlo, pero por ahora nada lo activa.
      if (this.dipBarType === null) {
        const kneeVisOk =
          (knee.visibility ?? 1) >= DIP_CALIBRATION_MIN_VISIBILITY &&
          (ankle.visibility ?? 1) >= DIP_CALIBRATION_MIN_VISIBILITY;
        if (kneeVisOk && kneeAngle !== null && kneeAngle <= SQUAT_DOWN_ANGLE_DEG) {
          this.dipBarType = "baja";
          this.logScissor(
            `[PARALELAS BAJAS] rodilla=${kneeAngle.toFixed(0)}° (≤${SQUAT_DOWN_ANGLE_DEG}) — se usará la rodilla para el desmonte`
          );
        }
      }
    }
    const mountedThreshold = DIP_SHOULDER_RISE_MOUNTED_RATIO * (this.dipSetPeakShoulderRise ?? 0.01);
    const dismountThreshold = DIP_SHOULDER_RISE_DISMOUNT_RATIO * (this.dipSetPeakShoulderRise ?? 0.01);
    const hipDismountThreshold = DIP_SHOULDER_RISE_DISMOUNT_RATIO * (this.dipSetPeakHipRise ?? 0.01);

    // Chequeo de desmonte — codo recto Y hombro de vuelta cerca de la
    // referencia de pie DE VERDAD (dismountThreshold, más estricto que
    // mountedThreshold — ver el bloque DIP_* de más arriba). Un fondo
    // profundo de verdad tiene el codo DOBLADO en el punto más bajo, así
    // que nunca cumple esto a media repetición.
    // Octavo bug real, con datos de un registro real donde te quedaste de
    // pie, quieto, más de diez segundos después de bajarte de las
    // paralelas, y NUNCA se cerró la serie: el contador de desmonte
    // (dipBreakSince/DIP_BREAK_STABLE_MS) llegó a 969ms de los 1000 que
    // hacían falta — dos veces — y en ambas lo tiró todo a la basura un
    // ÚNICO frame suelto en el que elbowAngle bajó a 154° (un grado por
    // debajo de DIP_UP_ANGLE_DEG) por puro ruido de un landmark, con el
    // hombro clarísimamente ya abajo (hombro_subido=0.28, muy por debajo
    // del umbral de desmonte). Ese único frame reiniciaba dipBreakSince a
    // null entero, así que el segundo siguiente volvía a empezar de cero
    // — y así indefinidamente mientras estuvieras quieto, sin que la
    // cuenta llegara nunca a buen puerto. dismountShape en sí NO se
    // suaviza (sigue siendo el ángulo bruto de este frame, igual que en
    // las transiciones top/bottom) — lo que cambia es que una interrupción
    // de un solo frame ya NO tira dipBreakSince a la basura al momento:
    // hace falta que la interrupción misma se sostenga
    // DIP_BREAK_INTERRUPT_GRACE_MS (dipBreakInterruptSince, más abajo)
    // para darla por real y reiniciar de verdad — un volver A SUBIR de
    // verdad tarda mucho más que eso, así que sigue protegido igual.
    //
    // Con paralelas bajas o altas ya identificadas (dipBarType, más
    // arriba, mientras estabas en top), esta forma de "postura de
    // desmonte" se comprueba con la señal que toca — rodilla ESTIRADA de
    // nuevo (bajas) o cadera de vuelta cerca de tu altura de pie
    // (altas) — en vez de siempre el hombro. Sin clasificar todavía
    // (dipBarType === null, por ejemplo mientras la rodilla no se ve
    // bien y la cadera tampoco ha subido lo bastante para decidir), se
    // sigue con el hombro, exactamente como se hacía antes de este
    // cambio — así que en ese caso no cambia nada del comportamiento ya
    // confirmado.
    let dismountShape;
    if (this.dipBarType === "baja") {
      dismountShape = elbowAngle >= DIP_UP_ANGLE_DEG && kneeAngle !== null && kneeAngle >= SQUAT_UP_ANGLE_DEG;
    } else if (this.dipBarType === "alta") {
      dismountShape = elbowAngle >= DIP_UP_ANGLE_DEG && hipRise < hipDismountThreshold;
    } else {
      dismountShape = elbowAngle >= DIP_UP_ANGLE_DEG && shoulderRise < dismountThreshold;
    }
    if (dismountShape) {
      this.dipBreakInterruptSince = null;
      if (this.dipBreakSince === null) this.dipBreakSince = now;
      const breakElapsed = now - this.dipBreakSince;
      if (breakElapsed >= DIP_BREAK_STABLE_MS) {
        this.logScissor(
          `[DESMONTE DETECTADO] tipo=${this.dipBarType ?? "sin_determinar(hombro)"} ángulo=${elbowAngle.toFixed(0)}° ` +
          `hombro_subido=${shoulderRise.toFixed(2)}(<${dismountThreshold.toFixed(2)}) ` +
          `cadera_subida=${hipRise.toFixed(2)}(<${hipDismountThreshold.toFixed(2)}) ` +
          `rodilla=${kneeAngle === null ? "-" : kneeAngle.toFixed(0) + "°"}(≥${SQUAT_UP_ANGLE_DEG}) ` +
          `sostenido=${breakElapsed.toFixed(0)}ms — cerrando serie`
        );
        this.dipBreakSince = null;
        this.closeActiveSet();
        return;
      }
    } else if (this.dipBreakSince !== null) {
      if (this.dipBreakInterruptSince === null) this.dipBreakInterruptSince = now;
      const interruptElapsed = now - this.dipBreakInterruptSince;
      if (interruptElapsed >= DIP_BREAK_INTERRUPT_GRACE_MS) {
        this.logScissor(
          `[desmonte interrumpido] tipo=${this.dipBarType ?? "sin_determinar(hombro)"} ángulo=${elbowAngle.toFixed(0)}° ` +
          `hombro_subido=${shoulderRise.toFixed(2)}(<${dismountThreshold.toFixed(2)}) ` +
          `cadera_subida=${hipRise.toFixed(2)}(<${hipDismountThreshold.toFixed(2)}) ` +
          `rodilla=${kneeAngle === null ? "-" : kneeAngle.toFixed(0) + "°"}(≥${SQUAT_UP_ANGLE_DEG}) ` +
          `sostenido ${interruptElapsed.toFixed(0)}ms — se reinicia el conteo de desmonte`
        );
        this.dipBreakSince = null;
        this.dipBreakInterruptSince = null;
      }
      // si no, un solo frame (o unos pocos) de ruido — se ignora, ver el
      // octavo bug arriba, y dipBreakSince sigue vivo tal cual estaba.
    } else {
      this.dipBreakInterruptSince = null;
    }

    // La transición de vuelta a ARRIBA (más abajo) exige ADEMÁS que el
    // hombro siga claramente elevado (mountedThreshold) — sin esto, el
    // propio gesto de bajarte de las paralelas contaría como repetición
    // (ver el bloque DIP_* de más arriba).
    const stillMounted = shoulderRise >= mountedThreshold;
    if (this.state === "top") {
      // Séptimo bug real, con el largo de tronco ya puesto (sexto bug,
      // arriba): en un registro real la cuenta SEGUÍA en cero — el
      // estado nunca llegaba a "bottom" en toda la sesión, aunque el
      // ángulo de codo bajara de verdad y hondo (42°, 9°...). Aquí ya NO
      // era el largo de referencia (eso lo arregló el sexto bug): con
      // el tronco puesto, hombro_subido llegó "solo" a -1.05 (antes
      // -2.94), pero seguía cruzando por debajo de mountedThreshold
      // ANTES de que el ángulo llegara a DIP_DOWN_ANGLE_DEG (se vio
      // montada/o=no ya en ángulo=127°, muy lejos de los 90° que hacen
      // falta) — con lo que exigir stillMounted AQUÍ, para entrar en
      // "bottom", seguía bloqueando la transición para siempre. La razón
      // de fondo: al inclinarte hacia delante en el tramo bajo de un
      // fondo real, el hombro se mueve también hacia delante en la
      // imagen, no solo hacia abajo, y esa componente contamina
      // shoulderRise — un ruido de cámara que ninguna referencia de
      // largo (brazo o tronco) puede arreglar por sí sola. Arreglo:
      // dejar de exigir stillMounted para ENTRAR en "bottom" (solo hace
      // falta el ángulo) — la protección real contra falsos positivos ya
      // no depende de este chequeo aquí: sigue estando, sin tocar, en la
      // transición de VUELTA a arriba (stillMounted, más abajo — evita
      // contar el punto final de un desmonte real como si fuera una
      // repetición) y en la bajada mínima de verdad del hombro
      // (DIP_MIN_SHOULDER_DROP_FACTOR, ver el bug de "rascarse la
      // nariz") antes de dar la repetición por buena.
      // DÉCIMO BUG REAL (reaplicado tras revertirlo una vez — historial
      // completo aquí porque ya se dio marcha atrás una vez sin datos
      // suficientes): en un registro real (build fondos-noveno-bug-de-
      // frente) dos fondos de verdad, con el codo llegando a 9°-21°,
      // fueron descartados con bajada_hombro=0.08 contra el mínimo de
      // 0.15 — porque aquí se copiaba shoulderY de ESTE MISMO FRAME (el
      // del cruce del ángulo de abajo), perdiendo toda la bajada previa
      // desde que tenías los brazos estirados. Se cambió a usar
      // dipTopShoulderY (la Y más alta vista de verdad desde que se
      // armó la serie, actualizada más arriba mientras this.state ===
      // "top") — el usuario reportó entonces una repetición contada por
      // accidente al "dejar el portátil en posición", así que se
      // revirtió del todo por no tener un registro de ESE caso concreto
      // con el que diagnosticarlo. Pero el registro build fondos-altura-
      // paralelas (ya con la cámara de perfil confirmada, no de frente)
      // volvió a mostrar EXACTAMENTE el mismo problema: dos fondos
      // reales, con el ángulo llegando a 5°-50°, descartados con
      // bajada_hombro=0.03 y 0.10 contra el mínimo de 0.15 — con el
      // arreglo revertido, o sea con el bug original otra vez. Se
      // reaplica aquí, y esta vez dipTopShoulderY se reinicia también al
      // armar cada serie nueva (no solo al Recalibrar, ver más arriba en
      // esta función) — para que una lectura mala de un solo frame no
      // pueda quedarse fija de por vida como referencia de "arriba" para
      // toda la sesión, que es la explicación más probable del efecto
      // que describió el usuario, aunque sin un registro de ese momento
      // exacto no se puede confirmar del todo.
      if (elbowAngle <= DIP_DOWN_ANGLE_DEG) {
        this.state = "bottom";
        this.repStartTime = now;      // la repetición empieza al bajar
        this.dipRepShoulderTopY = this.dipTopShoulderY ?? shoulderY;
        this.dipRepShoulderMaxY = shoulderY;
      }
    } else {
      // state === "bottom": sigue el punto más bajo (Y más grande) que
      // alcanza el hombro durante la bajada, para poder comprobar luego
      // que de verdad ha bajado (y no solo el codo — ver el bug de
      // "rascarse la nariz" en el bloque DIP_* de más arriba).
      this.dipRepShoulderMaxY = Math.max(this.dipRepShoulderMaxY ?? shoulderY, shoulderY);
      if (elbowAngle >= DIP_UP_ANGLE_DEG && stillMounted) {
        const shoulderDrop =
          ((this.dipRepShoulderMaxY ?? shoulderY) - (this.dipRepShoulderTopY ?? shoulderY)) / this.dipTorsoLength;
        if (shoulderDrop >= DIP_MIN_SHOULDER_DROP_FACTOR) {
          this.countRep((now - this.repStartTime) / 1000, now, "Fondo");
          this.logScissor(
            `[REP CONTADA] ángulo=${elbowAngle.toFixed(0)}° bajada_hombro=${shoulderDrop.toFixed(2)} reps_serie=${this.currentSetReps}`
          );
        } else {
          this.logScissor(
            `[rep descartada — el hombro no ha bajado] ángulo=${elbowAngle.toFixed(0)}° bajada_hombro=${shoulderDrop.toFixed(2)} ` +
            `(mín ${DIP_MIN_SHOULDER_DROP_FACTOR}) — probablemente un gesto del brazo, no un fondo`
          );
        }
        this.state = "top";
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `ángulo codo (${useLeft ? "izq" : "der"}): ${elbowAngle.toFixed(0)}° | hombro subido: ${shoulderRise.toFixed(2)} ` +
        `(mín. montada/o ${mountedThreshold.toFixed(2)}, desmonte <${dismountThreshold.toFixed(2)}) | estado: ${this.state} ` +
        `(abajo ≤${DIP_DOWN_ANGLE_DEG}°, arriba ≥${DIP_UP_ANGLE_DEG}°)`;
    }
    // Registro por frame para poder exportar y diagnosticar con datos
    // reales si hiciera falta (ver logScissor/exportScissorLog).
    this.logScissor(
      `ángulo=${elbowAngle.toFixed(0)}° hombro_subido=${shoulderRise.toFixed(2)} hombro_y=${shoulderY.toFixed(3)}(bruto ${shoulder.y.toFixed(3)}) ` +
      `(montada/o≥${mountedThreshold.toFixed(2)}, desmonte<${dismountThreshold.toFixed(2)}, pico_serie=${(this.dipSetPeakShoulderRise ?? 0).toFixed(2)}) estado=${this.state} ` +
      `tipo_paralelas=${this.dipBarType ?? "sin_determinar"} cadera_subida=${hipRise.toFixed(2)}(<${hipDismountThreshold.toFixed(2)}, pico=${(this.dipSetPeakHipRise ?? 0).toFixed(2)}) ` +
      `rodilla=${kneeAngle === null ? "-" : kneeAngle.toFixed(0) + "°"}(baja≤${SQUAT_DOWN_ANGLE_DEG}°/estirada≥${SQUAT_UP_ANGLE_DEG}°) ` +
      `montada/o=${stillMounted ? "sí" : "no"} forma_desmonte=${dismountShape ? "sí" : "no"} ` +
      `desmonte_sostenido=${this.dipBreakSince === null ? "-" : (now - this.dipBreakSince).toFixed(0) + "ms"} ` +
      // hombro_izq_vis/hombro_der_vis: se añaden aquí (aparte del chequeo
      // de "de frente a la cámara", más arriba en esta misma función) para
      // poder ver, con datos reales, a qué visibilidad se queda el hombro
      // TAPADO mientras trabajas de perfil a tu distancia normal de
      // cámara — así, si DIP_FACE_CAMERA_VISIBILITY (ver el bloque DIP_*
      // de más arriba) se queda corto o se pasa, se puede afinar con el
      // número exacto en vez de volver a adivinar.
      `hombro_izq_vis=${(lShoulder.visibility ?? 0).toFixed(2)} hombro_der_vis=${(rShoulder.visibility ?? 0).toFixed(2)}`
    );
  }

  /**
   * Flexiones: se cuentan por el ÁNGULO DEL CODO (hombro-codo-muñeca) —
   * ver el bloque PUSHUP_* más arriba para el porqué (a diferencia de
   * los fondos, aquí el ángulo SÍ se mide bien porque el movimiento ya
   * es de perfil por definición).
   *
   * ARRANQUE (corregido tras un fallo real: contaba reps sin que el
   * usuario se hubiera puesto en posición): antes solo se exigía brazo
   * recto + cuerpo en línea recta hombro-cadera-tobillo — pero esa línea
   * recta NO distingue estar tumbado boca abajo de estar de pie con los
   * brazos sueltos (de pie, esa misma línea también sale casi recta), así
   * que ponerte simplemente de pie delante de la cámara ya armaba el
   * contador. Arreglo: hace falta confirmar que estás TUMBADO Y BOCA
   * ABAJO de verdad, con la inclinación hombro-cadera respecto a la
   * HORIZONTAL (tiltFromHorizontal, la misma que usan crunch/abdominal
   * completo para su gate de "tumbado") — de pie esa inclinación es
   * ~90°, tumbado es ~0°. Con este chequeo de tilt ya no hace falta
   * exigir el codo doblado para distinguir tumbado de pie: de pie, por
   * mucho que el brazo esté recto, el tilt sale ~90° y el gate lo
   * descarta igual.
   *
   * Se pide la posición de ARRIBA para arrancar: tumbado boca abajo,
   * cuerpo en línea recta, brazos estirados (elbowAngle >=
   * PUSHUP_UP_ANGLE_DEG) y manos a la altura del pecho, codos pegados al
   * cuerpo (mirando hacia atrás, no hacia los lados). Es la postura de
   * plancha con la que se empieza una serie de flexiones de verdad —
   * igual que sentadillas arranca de pie (arriba) en vez de en cuclillas.
   * Hace falta mantener esa posición ON_GROUND_STABLE_MS seguidos (igual
   * que crunch/situp con groundStableSince) antes de armar — así
   * ponerte en posición no cuenta como nada, ni un frame ruidoso arma el
   * contador por error.
   *
   * Una vez armado (state "top"), cada flexión se cuenta en dos pasos,
   * igual que sentadillas: el codo se dobla hasta ABAJO
   * (elbowAngle <= PUSHUP_DOWN_ANGLE_DEG, state "bottom") y luego vuelve
   * a estar recto (elbowAngle >= PUSHUP_UP_ANGLE_DEG) — ese regreso a
   * ARRIBA es el que cuenta la repetición.
   *
   * Se usa el brazo que mejor se vea: de perfil, el brazo de atrás
   * queda tapado por el cuerpo — igual que en fondos y sentadillas.
   *
   * Cierre de serie: como el resto de ejercicios de suelo (crunch,
   * elevación de piernas, abdominal completo…), romper la postura —
   * levantarte, o simplemente dejar de estar tumbado boca abajo — un
   * rato seguido (OFF_GROUND_STABLE_MS) da la serie por terminada y
   * empieza la siguiente en cuanto vuelves a colocarte; también se
   * cierra saliendo del encuadre o con el gesto de agitar la mano, ver
   * noteAbsence/checkWaveGesture.
   */
  processPushup(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now)) {
      this.closeActiveSet();
      return;
    }

    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lElbow = lm[L_ELBOW], rElbow = lm[R_ELBOW];
    const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const leftVis = (
      (lShoulder.visibility ?? 1) + (lElbow.visibility ?? 1) + (lWrist.visibility ?? 1) +
      (lHip.visibility ?? 1) + (lAnkle.visibility ?? 1)
    ) / 5;
    const rightVis = (
      (rShoulder.visibility ?? 1) + (rElbow.visibility ?? 1) + (rWrist.visibility ?? 1) +
      (rHip.visibility ?? 1) + (rAnkle.visibility ?? 1)
    ) / 5;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    if (vis < PUSHUP_MIN_VISIBILITY) {
      this.announceStatus(
        "No se te ven bien el hombro, el codo, la muñeca, la cadera y el tobillo. Ponte de perfil a la " +
        "cámara, boca abajo, con las manos a la altura del pecho y los codos pegados al cuerpo."
      );
      if (this.debugEl) this.debugEl.textContent = "buscando hombro, codo, muñeca, cadera y tobillo de perfil…";
      this.pushupSide = null;
      this.groundStableSince = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    const shoulder = useLeft ? lShoulder : rShoulder;
    const elbow = useLeft ? lElbow : rElbow;
    const wrist = useLeft ? lWrist : rWrist;
    const hip = useLeft ? lHip : rHip;
    const ankle = useLeft ? lAnkle : rAnkle;

    const elbowAngle = angle(shoulder, elbow, wrist);
    const lineAngle = angle(shoulder, hip, ankle);
    const tilt = tiltFromHorizontal(shoulder, hip);
    if (elbowAngle === null || lineAngle === null || tilt === null) return;

    this.pushupSide = useLeft ? "left" : "right";
    // TUMBADO BOCA ABAJO de verdad (tilt, no la línea del cuerpo — ver
    // docstring): de pie sale ~90°, tumbado sale ~0°. Se usa tanto para
    // armar el contador como, ya armado, para detectar que has roto la
    // postura (te has levantado) y cerrar la serie — ver más abajo.
    const onGround = tilt <= ON_GROUND_MAX_TILT_DEG;

    // Ya armado (en mitad de una serie): si dejas de estar tumbado boca
    // abajo un rato seguido, se acabó la postura — se cierra la serie en
    // curso y la siguiente empieza en cuanto vuelvas a tumbarte. A
    // diferencia de crunch/elevación de piernas/abdominal completo, aquí
    // se usa un umbral MÁS LAXO (PUSHUP_BROKEN_TILT_DEG) y MÁS TIEMPO
    // seguido (PUSHUP_BREAK_STABLE_MS) que el simple onGround del gate de
    // armado — ver por qué en el bloque PUSHUP_* de más arriba (el brazo
    // pegado al cuerpo tapa la cadera en la imagen y ensucia el tilt
    // justo al bajar, así que hace falta más margen para no cortar una
    // serie real a medias).
    if (this.state !== null) {
      const broken = tilt > PUSHUP_BROKEN_TILT_DEG;
      if (broken) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= PUSHUP_BREAK_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
      } else {
        this.offGroundSince = null;
      }
    }

    if (this.state === null) {
      // Para armar el contador hace falta verte TUMBADO BOCA ABAJO de
      // verdad Y en la posición de ARRIBA (brazos estirados, manos a la
      // altura del pecho, codos pegados al cuerpo), sostenida un rato —
      // no un solo frame, para no armar por un vistazo de pasada mientras
      // te colocas. Es la misma posición de plancha con la que se
      // arranca una serie de flexiones real.
      const bodyStraight = lineAngle >= PUSHUP_LINE_MIN_DEG;
      // PUSHUP_ARM_GATE_ANGLE_DEG (145°), no PUSHUP_UP_ANGLE_DEG (160°) —
      // ver el porqué justo encima de PUSHUP_ARM_GATE_TOLERANCE_DEG.
      const armsStraight = elbowAngle >= PUSHUP_ARM_GATE_ANGLE_DEG;

      if (onGround && bodyStraight && armsStraight) {
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= ON_GROUND_STABLE_MS) {
          this.state = "top";
          this.groundStableSince = null;
          this.offGroundSince = null;
          if (!this.startupVoiceGiven) {
            this.startupVoiceGiven = true;
            this.announceStatus(
              "Te veo. ¡Listo! Puedes empezar. Para terminar una serie, ponte de pie, sal del " +
              "encuadre, o levanta un brazo y agita la mano.",
              "startup_ready"
            );
          } else {
            this.announceStatus("¡Listo! Puedes empezar.", "ready_to_go");
          }
        } else {
          this.setStatus("Postura vista… confirmando (no te muevas).");
        }
      } else {
        this.groundStableSince = null;
        this.setStatus(
          "Túmbate boca abajo, de perfil a la cámara, con los brazos estirados, las manos a la altura del " +
          "pecho y los codos pegados al cuerpo (mirando hacia atrás), para empezar."
        );
      }
    } else if (this.state === "top") {
      if (elbowAngle <= PUSHUP_COUNT_DOWN_ANGLE_DEG) {
        // Empieza a bajar: arranca la flexión. Umbral de CONTEO (con
        // margen, ver PUSHUP_FAST_REP_TOLERANCE_DEG), no el estricto de
        // PUSHUP_DOWN_ANGLE_DEG usado para el gate de armado.
        this.state = "bottom";
        this.repStartTime = now;
      }
    } else if (elbowAngle >= PUSHUP_COUNT_UP_ANGLE_DEG) {
      // El brazo ha vuelto a estar recto (con el mismo margen de conteo):
      // repetición completa.
      this.countRep((now - this.repStartTime) / 1000, now, "Flexión", PUSHUP_MIN_REP_SECONDS);
      this.state = "top";
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `ángulo codo (${useLeft ? "izq" : "der"}): ${elbowAngle.toFixed(0)}° | inclinación: ${tilt.toFixed(0)}° | estado: ${this.state ?? "esperando"} ` +
        `(abajo ≤${PUSHUP_COUNT_DOWN_ANGLE_DEG}°, arriba ≥${PUSHUP_COUNT_UP_ANGLE_DEG}°)`;
    }
  }

  /**
   * Flexiones inclinadas: MISMO gesto de brazo que processPushup (mismo
   * ángulo de codo cuenta la repetición), pero con los pies en alto — ver
   * el bloque INCLINE_PUSHUP_* más arriba para el porqué del diseño
   * (comparación directa muñeca/tobillo, no un ángulo de inclinación) y
   * de los dos bugs reales que corrigió (flexión plana contando como
   * inclinada; un gesto de brazo suelto, ya armado, contando como
   * repetición). A diferencia de la primera versión, aquí SÍ hay cierre
   * automático de serie al romper la postura (dejar de tener los pies en
   * alto, o encogerte) — ver inPosition/INCLINE_PUSHUP_BROKEN_STABLE_MS
   * más abajo.
   */
  processInclinePushup(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now)) {
      this.closeActiveSet();
      return;
    }

    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lElbow = lm[L_ELBOW], rElbow = lm[R_ELBOW];
    const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const leftVis = (
      (lShoulder.visibility ?? 1) + (lElbow.visibility ?? 1) + (lWrist.visibility ?? 1) +
      (lHip.visibility ?? 1) + (lAnkle.visibility ?? 1)
    ) / 5;
    const rightVis = (
      (rShoulder.visibility ?? 1) + (rElbow.visibility ?? 1) + (rWrist.visibility ?? 1) +
      (rHip.visibility ?? 1) + (rAnkle.visibility ?? 1)
    ) / 5;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    if (vis < PUSHUP_MIN_VISIBILITY) {
      this.announceStatus(
        "No se te ven bien el hombro, el codo, la muñeca, la cadera y el tobillo. Ponte de perfil a la " +
        "cámara, boca abajo, con los pies apoyados en alto, las manos a la altura del pecho y los codos " +
        "pegados al cuerpo."
      );
      if (this.debugEl) this.debugEl.textContent = "buscando hombro, codo, muñeca, cadera y tobillo de perfil…";
      this.pushupSide = null;
      this.groundStableSince = null;
      // Sin ver el cuerpo entero no se puede confirmar que sigues con
      // los pies en alto — no hay motivo para seguir contando nada, así
      // que esto también cuenta como salir de posición (ver más abajo)
      // además de la señal de "fuera de encuadre" ya existente
      // (noteAbsence/OUT_OF_FRAME_STABLE_MS, que sigue corriendo aparte).
      if (this.state !== null) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= INCLINE_PUSHUP_BROKEN_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
      }
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    const shoulder = useLeft ? lShoulder : rShoulder;
    const elbow = useLeft ? lElbow : rElbow;
    const wrist = useLeft ? lWrist : rWrist;
    const hip = useLeft ? lHip : rHip;
    const ankle = useLeft ? lAnkle : rAnkle;

    const elbowAngle = angle(shoulder, elbow, wrist);
    const lineAngle = angle(shoulder, hip, ankle);
    if (elbowAngle === null || lineAngle === null) return;

    // "Pies en alto de verdad", medido en DIRECTO (no con un ángulo de
    // inclinación, que se coló con una flexión plana en la primera
    // versión — ver el bloque INCLINE_PUSHUP_* de más arriba): el tobillo
    // tiene que quedar claramente por ENCIMA de la muñeca en la imagen.
    // Y crece hacia abajo, así que "por encima" es tobillo.y < muñeca.y.
    // Normalizado por el largo de tronco (hombro-cadera) del frame actual
    // para que el umbral sirva igual da igual lo lejos que estés de la
    // cámara.
    const torsoLength = Math.hypot(shoulder.x - hip.x, shoulder.y - hip.y);
    const footRise = torsoLength > 0 ? (wrist.y - ankle.y) / torsoLength : 0;
    const feetElevated = footRise >= INCLINE_PUSHUP_MIN_FOOT_RISE_FACTOR;
    const bodyStraight = lineAngle >= PUSHUP_LINE_MIN_DEG;
    const inPosition = feetElevated && bodyStraight;

    this.pushupSide = useLeft ? "left" : "right";

    if (this.state !== null) {
      // Ya armado: SIEMPRE se comprueba la postura, no solo al empezar.
      // En cuanto deja de cumplirse (pies ya no en alto, o cuerpo
      // encogido), este frame se descarta ANTES de mirar el ángulo de
      // codo — así un gesto suelto de brazo (coger el portátil,
      // rascarte…) nunca puede colarse como repetición, aunque el propio
      // ángulo de codo dibuje un ciclo arriba-abajo-arriba de casualidad.
      // Si se sostiene fuera de posición, se cierra la serie sola — el
      // equivalente de "te has puesto de pie" para esta variante.
      if (!inPosition) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= INCLINE_PUSHUP_BROKEN_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
        if (this.debugEl) {
          this.debugEl.textContent =
            `fuera de posición (pies sobre manos: ${(footRise * 100).toFixed(0)}% tronco, mínimo ` +
            `${(INCLINE_PUSHUP_MIN_FOOT_RISE_FACTOR * 100).toFixed(0)}% · cuerpo recto: ${bodyStraight ? "sí" : "no"}) — se descarta este frame`;
        }
        return;
      }
      this.offGroundSince = null;
    }

    if (this.state === null) {
      // Para armar el contador hace falta verte en la posición de ARRIBA
      // (brazos estirados, manos a la altura del pecho, codos pegados al
      // cuerpo, cuerpo estirado) Y con los pies claramente en alto —
      // sostenida un rato, no un solo frame.
      // PUSHUP_ARM_GATE_ANGLE_DEG (145°), no PUSHUP_UP_ANGLE_DEG (160°) —
      // mismo motivo que en processPushup (ver PUSHUP_ARM_GATE_TOLERANCE_DEG).
      const armsStraight = elbowAngle >= PUSHUP_ARM_GATE_ANGLE_DEG;

      if (inPosition && armsStraight) {
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= ON_GROUND_STABLE_MS) {
          this.state = "top";
          this.groundStableSince = null;
          this.offGroundSince = null;
          if (!this.startupVoiceGiven) {
            this.startupVoiceGiven = true;
            this.announceStatus(
              "Te veo. ¡Listo! Puedes empezar. Para terminar una serie, ponte de pie, sal del " +
              "encuadre, o levanta un brazo y agita la mano.",
              "startup_ready"
            );
          } else {
            this.announceStatus("¡Listo! Puedes empezar.", "ready_to_go");
          }
        } else {
          this.setStatus("Postura vista… confirmando (no te muevas).");
        }
      } else {
        this.groundStableSince = null;
        this.setStatus(
          "Túmbate boca abajo con los pies CLARAMENTE más altos que las manos (una silla, un escalón, " +
          "un sofá…), de perfil a la cámara, con los brazos estirados, las manos a la altura del pecho " +
          "y los codos pegados al cuerpo (mirando hacia atrás), para empezar."
        );
      }
    } else if (this.state === "top") {
      if (elbowAngle <= PUSHUP_COUNT_DOWN_ANGLE_DEG) {
        // Empieza a bajar: arranca la flexión. Umbral de CONTEO (con
        // margen, ver PUSHUP_FAST_REP_TOLERANCE_DEG), no el estricto de
        // PUSHUP_DOWN_ANGLE_DEG usado para el gate de armado.
        this.state = "bottom";
        this.repStartTime = now;
      }
    } else if (elbowAngle >= PUSHUP_COUNT_UP_ANGLE_DEG) {
      // El brazo ha vuelto a estar recto (con el mismo margen de conteo):
      // repetición completa.
      this.countRep((now - this.repStartTime) / 1000, now, "Flexión inclinada", PUSHUP_MIN_REP_SECONDS);
      this.state = "top";
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `ángulo codo (${useLeft ? "izq" : "der"}): ${elbowAngle.toFixed(0)}° | pies sobre manos: ${(footRise * 100).toFixed(0)}% tronco (mínimo ${(INCLINE_PUSHUP_MIN_FOOT_RISE_FACTOR * 100).toFixed(0)}%) | estado: ${this.state ?? "esperando"} ` +
        `(abajo ≤${PUSHUP_COUNT_DOWN_ANGLE_DEG}°, arriba ≥${PUSHUP_COUNT_UP_ANGLE_DEG}°)`;
    }
  }

  /**
   * Fondos en banco: mismo ángulo de codo que un fondo normal
   * (DIP_UP_ANGLE_DEG/DIP_DOWN_ANGLE_DEG) para contar la repetición,
   * con la postura comprobada en directo — manos apoyadas por encima
   * del nivel de los pies (BENCHDIP_HAND_RISE_MIN_FACTOR) — ver el
   * bloque BENCHDIP_* de más arriba para el porqué del diseño, calcado
   * del de processInclinePushup en vez del de processDip, y para la
   * nota "ARREGLO tras la primera prueba real" sobre por qué el ángulo
   * de cuerpo (L) se quedó fuera de este gate.
   *
   * La posición inicial (armado, "top": brazos rectos y manos por
   * encima de los pies, sostenida un rato) es la que arma el contador
   * y a la que hay que volver para que cuente cada repetición — igual
   * que el resto de ejercicios de este archivo, no se cuenta ninguna
   * repetición hasta no haber pasado primero por "abajo" (codo a 90°)
   * y haber vuelto a esa posición inicial. La serie se cierra sola al
   * romper esa postura (soltar las manos hacia el suelo), al ponerte
   * de pie, o al salir del encuadre.
   */
  processBenchDip(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now)) {
      this.closeActiveSet();
      return;
    }

    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lElbow = lm[L_ELBOW], rElbow = lm[R_ELBOW];
    const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const leftVis = (
      (lShoulder.visibility ?? 1) + (lElbow.visibility ?? 1) + (lWrist.visibility ?? 1) +
      (lHip.visibility ?? 1) + (lKnee.visibility ?? 1) + (lAnkle.visibility ?? 1)
    ) / 6;
    const rightVis = (
      (rShoulder.visibility ?? 1) + (rElbow.visibility ?? 1) + (rWrist.visibility ?? 1) +
      (rHip.visibility ?? 1) + (rKnee.visibility ?? 1) + (rAnkle.visibility ?? 1)
    ) / 6;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    if (vis < PUSHUP_MIN_VISIBILITY) {
      this.announceStatus(
        "No se te ven bien el hombro, el codo, la muñeca, la cadera, la rodilla y el tobillo. Ponte de " +
        "perfil a la cámara, con las manos apoyadas detrás en un banco o silla y los pies en el suelo por " +
        "delante."
      );
      if (this.debugEl) this.debugEl.textContent = "buscando hombro, codo, muñeca, cadera, rodilla y tobillo de perfil…";
      this.pushupSide = null;
      this.groundStableSince = null;
      // Igual que en flexiones inclinadas: sin ver el cuerpo entero no
      // se puede confirmar que sigues en posición — cuenta como salir
      // de posición además de la señal de "fuera de encuadre" ya
      // existente (noteAbsence/OUT_OF_FRAME_STABLE_MS, que sigue
      // corriendo aparte).
      if (this.state !== null) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= BENCHDIP_BROKEN_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
      }
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    const shoulder = useLeft ? lShoulder : rShoulder;
    const elbow = useLeft ? lElbow : rElbow;
    const wrist = useLeft ? lWrist : rWrist;
    const hip = useLeft ? lHip : rHip;
    const knee = useLeft ? lKnee : rKnee;
    const ankle = useLeft ? lAnkle : rAnkle;

    const elbowAngle = angle(shoulder, elbow, wrist);
    const bodyAngle = angle(shoulder, hip, ankle);
    const kneeAngle = angle(hip, knee, ankle);
    const torsoTilt = tiltFromHorizontal(shoulder, hip);
    if (elbowAngle === null || bodyAngle === null || kneeAngle === null || torsoTilt === null) return;

    // "Manos por encima de los pies de verdad", medido en DIRECTO —
    // mismo tipo de comparación que footRise en flexiones inclinadas,
    // pero al revés (ver el bloque BENCHDIP_* de más arriba): la
    // muñeca tiene que quedar claramente por ENCIMA del tobillo. Y
    // crece hacia abajo, así que "por encima" es muñeca.y < tobillo.y.
    // Normalizado por el largo de tronco (hombro-cadera) del frame
    // actual para que el umbral sirva igual da igual lo lejos que
    // estés de la cámara.
    const torsoLength = Math.hypot(shoulder.x - hip.x, shoulder.y - hip.y);
    const handRise = torsoLength > 0 ? (ankle.y - wrist.y) / torsoLength : 0;
    const handsElevated = handRise >= BENCHDIP_HAND_RISE_MIN_FACTOR;
    // SEGUNDO ARREGLO, a petición de Alex tras la segunda prueba real:
    // sentarte normal en el banco (sin extender las piernas) no cerraba
    // la serie, y levantarte al terminar contaba una repetición de más
    // — porque para levantarte hay que DOBLAR las rodillas (plantar los
    // pies) antes de ponerte de pie, y ese gesto se colaba en el ciclo
    // de ángulo de codo antes de que diera tiempo a salir del encuadre
    // o soltar las manos. A diferencia del ángulo de cadera (bodyInL,
    // más abajo — desactivado la vez anterior por el mismo motivo:
    // cambia de forma natural AL HACER la repetición), las piernas SÍ
    // se quedan extendidas de principio a fin durante todo un fondo en
    // banco real — doblar la rodilla nunca pasa a media repetición, así
    // que es una señal fiable de "te has movido de la postura" (sentarte
    // normal, o el primer gesto de levantarte) sin arriesgarse a cortar
    // una repetición legítima. Entra en el gate real de postura junto
    // con handsElevated.
    const legsExtended = kneeAngle >= BENCHDIP_KNEE_MIN_DEG;
    // TERCER ARREGLO, a petición de Alex tras la tercera prueba real:
    // mientras movía el soporte (banco/silla) de sitio, se armó el
    // contador y se contó una repetición "de gratis" — al mover
    // muebles te agachas y estiras los brazos de formas que, por pura
    // casualidad de un instante, pueden cumplir manos-elevadas y
    // piernas-estiradas a la vez sin que sea ni de lejos la postura de
    // un fondo en banco real. Lo que le falta a esa coincidencia es que
    // el TRONCO esté en vertical (sentado, no agachado/inclinado hacia
    // delante para coger o mover algo) — tiltFromHorizontal(hombro,
    // cadera) da 0° tumbado/agachado del todo y 90° con el tronco
    // recto de pie o sentado, así que se exige un mínimo
    // (BENCHDIP_TORSO_VERTICAL_MIN_DEG, arriba) para entrar en el gate
    // real de postura, igual que handsElevated y legsExtended.
    const bodyVertical = torsoTilt >= BENCHDIP_TORSO_VERTICAL_MIN_DEG;
    // "Cuerpo en forma de L" — YA NO gatea nada (ver la nota "ARREGLO
    // tras la primera prueba real", junto a BENCHDIP_BODY_ANGLE_MIN_DEG/
    // MAX_DEG más arriba): se deja calculado solo para el registro de
    // depuración, por si hace falta revisar el dato más adelante.
    const bodyInL = bodyAngle >= BENCHDIP_BODY_ANGLE_MIN_DEG && bodyAngle <= BENCHDIP_BODY_ANGLE_MAX_DEG;
    const inPosition = handsElevated && legsExtended && bodyVertical;

    this.pushupSide = useLeft ? "left" : "right";

    if (this.state !== null) {
      // Ya armado: SIEMPRE se comprueba la postura, no solo al empezar
      // — mismo criterio que flexiones inclinadas (ver el bloque
      // BENCHDIP_* de más arriba). En cuanto deja de cumplirse (manos
      // ya no en alto, o el cuerpo deja de estar en L), este frame se
      // descarta ANTES de mirar el ángulo de codo, así un gesto suelto
      // de brazo nunca se puede colar como repetición. Si se sostiene
      // fuera de posición, se cierra la serie sola.
      if (!inPosition) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= BENCHDIP_BROKEN_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
        if (this.debugEl) {
          this.debugEl.textContent =
            `fuera de posición (manos sobre pies: ${(handRise * 100).toFixed(0)}% tronco, mínimo ` +
            `${(BENCHDIP_HAND_RISE_MIN_FACTOR * 100).toFixed(0)}% · rodilla: ${kneeAngle.toFixed(0)}° estirada: ${legsExtended ? "sí" : "no"} ` +
            `(mínimo ${BENCHDIP_KNEE_MIN_DEG}°) · tronco: ${torsoTilt.toFixed(0)}° vertical: ${bodyVertical ? "sí" : "no"} ` +
            `(mínimo ${BENCHDIP_TORSO_VERTICAL_MIN_DEG}°) · ángulo cuerpo (informativo): ${bodyAngle.toFixed(0)}°) — se descarta este frame`;
        }
        return;
      }
      this.offGroundSince = null;
    }

    if (this.state === null) {
      // Para armar el contador hace falta verte en la posición
      // INICIAL: brazos rectos, manos claramente por encima de los
      // pies y las piernas estiradas — sostenida un rato, no un solo
      // frame, para no armar por un vistazo de pasada mientras te
      // colocas. A esta misma posición hay que volver para que cuente
      // cada repetición (ver más abajo) — no se cuenta ninguna
      // repetición hasta no haber pasado por abajo (codo a 90°) y
      // haber vuelto aquí.
      const armsStraight = elbowAngle >= DIP_UP_ANGLE_DEG;

      if (inPosition && armsStraight) {
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= ON_GROUND_STABLE_MS) {
          this.state = "top";
          this.groundStableSince = null;
          this.offGroundSince = null;
          if (!this.startupVoiceGiven) {
            this.startupVoiceGiven = true;
            this.announceStatus(
              "Te veo. ¡Listo! Puedes empezar. Para terminar una serie, ponte de pie, sal del " +
              "encuadre, o levanta un brazo y agita la mano.",
              "startup_ready"
            );
          } else {
            this.announceStatus("¡Listo! Puedes empezar.", "ready_to_go");
          }
        } else {
          this.setStatus("Postura vista… confirmando (no te muevas).");
        }
      } else {
        this.groundStableSince = null;
        this.setStatus(
          "Siéntate en el borde de un banco o silla, apoya las manos a los lados con los brazos rectos y " +
          "los codos pegados al cuerpo (mirando hacia atrás). Estira las piernas hacia delante con los " +
          "pies en el suelo, y baja la cadera hasta formar una L con el cuerpo, de perfil a la cámara, " +
          "para empezar."
        );
      }
    } else if (this.state === "top") {
      if (elbowAngle <= DIP_DOWN_ANGLE_DEG) {
        // Empieza a bajar: arranca el fondo.
        this.state = "bottom";
        this.repStartTime = now;
      }
    } else if (elbowAngle >= DIP_UP_ANGLE_DEG) {
      // El brazo ha vuelto a estar recto, en la posición inicial:
      // repetición completa.
      this.countRep((now - this.repStartTime) / 1000, now, "Fondo en banco");
      this.state = "top";
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `ángulo codo (${useLeft ? "izq" : "der"}): ${elbowAngle.toFixed(0)}° | manos sobre pies: ${(handRise * 100).toFixed(0)}% tronco (mínimo ${(BENCHDIP_HAND_RISE_MIN_FACTOR * 100).toFixed(0)}%) | rodilla: ${kneeAngle.toFixed(0)}° (mínimo ${BENCHDIP_KNEE_MIN_DEG}°) | tronco: ${torsoTilt.toFixed(0)}° (mínimo ${BENCHDIP_TORSO_VERTICAL_MIN_DEG}°) | ángulo cuerpo (informativo): ${bodyAngle.toFixed(0)}° | estado: ${this.state ?? "esperando"} ` +
        `(abajo ≤${DIP_DOWN_ANGLE_DEG}°, arriba ≥${DIP_UP_ANGLE_DEG}°)`;
    }
  }

  /**
   * Sentadillas: se cuentan por el ángulo de la rodilla (cadera-rodilla-
   * tobillo), medido de PERFIL. Es la postura que mejor deja ver la
   * flexión real de la rodilla — de frente la cámara no puede distinguir
   * bien cuánto bajas (la pierna se acorta en la imagen igual al doblarse
   * que al alejarse un poco de la cámara).
   *
   * De perfil solo se ve bien una pierna (la otra queda tapada por el
   * cuerpo), así que cada frame se usa la que tenga mejor visibilidad —
   * no se fija un lado de antemano, porque te puedes colocar de perfil
   * por cualquiera de los dos lados y hasta puedes girarte a media sesión.
   *
   * No hace falta ningún paso de calibración (a diferencia de las
   * dominadas): un ángulo no cambia aunque te acerques o alejes de la
   * cámara, así que los umbrales sirven tal cual para cualquiera.
   */
  processSquat(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now)) {
      this.closeActiveSet();
      return;
    }

    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const leftVis = ((lHip.visibility ?? 1) + (lKnee.visibility ?? 1) + (lAnkle.visibility ?? 1)) / 3;
    const rightVis = ((rHip.visibility ?? 1) + (rKnee.visibility ?? 1) + (rAnkle.visibility ?? 1)) / 3;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    // Ponerte de frente a la cámara (dejar de estar de perfil) es otra
    // forma de terminar la serie — ver SQUAT_FRONTAL_VIS_DIFF_MAX. De
    // perfil un lado siempre queda tapado por el cuerpo (visibilidades
    // muy distintas); de frente, los dos lados se ven parecido.
    const isFrontal = leftVis >= SQUAT_MIN_VISIBILITY && rightVis >= SQUAT_MIN_VISIBILITY
      && Math.abs(leftVis - rightVis) < SQUAT_FRONTAL_VIS_DIFF_MAX;
    // Justo al armar, el aviso "¡Listo!" invita a mirar un instante al
    // móvil -- no dejar que eso cuente como "de frente" hasta pasado
    // SQUAT_FRONTAL_GRACE_MS desde que se armó (ver el comentario junto
    // a esa constante).
    const frontalGuardReady = this.squatArmedAt === null || (now - this.squatArmedAt) >= SQUAT_FRONTAL_GRACE_MS;
    if (this.state !== null && isFrontal && frontalGuardReady) {
      if (this.frontalStableSince === null) this.frontalStableSince = now;
      if (now - this.frontalStableSince >= SQUAT_FRONTAL_STABLE_MS) {
        this.closeActiveSet();
        return;
      }
    } else {
      this.frontalStableSince = null;
    }

    if (vis < SQUAT_MIN_VISIBILITY) {
      this.announceStatus("No se te ve bien la cadera, la rodilla y el tobillo. Ponte de perfil a la cámara, con toda la pierna en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando cadera, rodilla y tobillo de perfil…";
      this.squatSide = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    // La primera vez en toda la sesión que se te ve bien, un aviso de
    // que ya puedes empezar — en las siguientes series no hace falta
    // repetirlo, ya sabes cómo colocarte.
    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Cadera, rodilla y tobillo a la vista. ¡Listo! Ya puedes empezar. Para terminar una serie, ponte de frente a la cámara, sal del encuadre, o levanta un brazo y agita la mano.",
        "startup_ready"
      );
    }

    const hip = useLeft ? lHip : rHip;
    const knee = useLeft ? lKnee : rKnee;
    const ankle = useLeft ? lAnkle : rAnkle;
    const kneeAngle = angle(hip, knee, ankle);
    if (kneeAngle === null) return;

    this.squatSide = useLeft ? "left" : "right";
    this.squatKneeAngle = kneeAngle;

    if (this.state === null) {
      // Hay que empezar de pie, para no contar media repetición al entrar.
      // Y no basta con un solo frame: mientras se coloca el móvil en
      // posición, una lectura ruidosa suelta puede dar un ángulo de
      // rodilla alto por casualidad y armar el contador antes de que
      // estés de verdad de pie — se exige la postura estable durante
      // SQUAT_ARM_STABLE_MS, igual que hangStableSince en dominadas.
      if (kneeAngle >= SQUAT_UP_ANGLE_DEG) {
        if (this.squatArmStableSince === null) this.squatArmStableSince = now;
        if (now - this.squatArmStableSince >= SQUAT_ARM_STABLE_MS) {
          this.state = "top";
          this.squatArmStableSince = null;
          this.squatArmedAt = now;
          this.announceStatus("¡Listo! Baja en sentadilla y vuelve a subir.", "ready_to_go");
        } else {
          this.setStatus("De pie… confirmando (no te muevas)");
        }
      } else {
        this.squatArmStableSince = null;
        this.setStatus("Ponte de pie, de perfil a la cámara, para empezar.");
      }
    } else if (this.state === "top") {
      // No basta con cruzar el ángulo de bajada: justo tras armar, un
      // reacomodo normal (peso entre pies, ajustar postura) puede hacer
      // lo mismo sin ser una sentadilla real — ver SQUAT_ARM_SETTLE_MS.
      const armSettled = this.squatArmedAt === null || (now - this.squatArmedAt) >= SQUAT_ARM_SETTLE_MS;
      if (kneeAngle <= SQUAT_DOWN_ANGLE_DEG && armSettled) {
        this.state = "bottom";
        this.repStartTime = now; // la repetición empieza al bajar
      }
    } else if (kneeAngle >= SQUAT_UP_ANGLE_DEG) {
      // Ha vuelto a subir del todo: repetición completa.
      this.countRep((now - this.repStartTime) / 1000, now, "Sentadilla");
      this.state = "top";
    }

    if (this.debugEl) {
      // Tiempo restante de los dos márgenes de asentamiento tras armar
      // (SQUAT_ARM_SETTLE_MS/SQUAT_FRONTAL_GRACE_MS) -- visible en el
      // registro de depuración para poder confirmar si estos márgenes
      // (primer valor, sin log real todavía) bastan o no la próxima vez.
      const settleMsLeft = this.squatArmedAt === null ? 0 : Math.max(0, Math.round(SQUAT_ARM_SETTLE_MS - (now - this.squatArmedAt)));
      const frontalMsLeft = this.squatArmedAt === null ? 0 : Math.max(0, Math.round(SQUAT_FRONTAL_GRACE_MS - (now - this.squatArmedAt)));
      this.debugEl.textContent =
        `ángulo rodilla (${useLeft ? "izq" : "der"}): ${kneeAngle.toFixed(0)}° | estado: ${this.state ?? "esperando"} ` +
        `(abajo ≤${SQUAT_DOWN_ANGLE_DEG}°, arriba ≥${SQUAT_UP_ANGLE_DEG}°)` +
        (settleMsLeft > 0 || frontalMsLeft > 0 ? ` | asentando tras armar: pierna ${settleMsLeft}ms, frente ${frontalMsLeft}ms` : "");
    }
  }

  /**
   * Split squat / zancada estática -- pedido con vídeo de referencia
   * (WhatsApp, 2026-09-04): de perfil, de pie con una pierna delante y
   * otra detrás, bajando la cadera hasta casi rozar la rodilla trasera
   * el suelo y volviendo a subir.
   *
   * Se cuenta igual que la sentadilla (ángulo cadera-rodilla-tobillo,
   * DE PERFIL), pero a diferencia de processSquat NO se elige "la
   * pierna más visible": en split squat las dos piernas quedan
   * separadas delante/detrás en la imagen en vez de una tapando a la
   * otra, así que de perfil normalmente se ven bien las DOS. Se usa la
   * rodilla MÁS DOBLADA entre las que se vean lo bastante -- da igual
   * cuál sea físicamente la pierna de delante, las dos se doblan en el
   * mismo ciclo de bajada/subida.
   *
   * Primera versión: umbrales de ángulo iguales a los de sentadillas
   * como punto de partida, pendientes de calibrar con cámara real igual
   * que el resto de la familia de ejercicios nuevos.
   */
  processSplitSquat(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now)) {
      this.closeActiveSet();
      return;
    }

    // Cuarta forma de terminar la serie: llevar SPLITSQUAT_IDLE_CLOSE_MS
    // sin avanzar en la repetición (por ejemplo, pararte y ponerte de
    // frente a la cámara para descansar) -- ver el razonamiento junto a
    // la constante, más arriba.
    if (this.state !== null && this.splitSquatStateEnteredAt !== null
      && now - this.splitSquatStateEnteredAt >= SPLITSQUAT_IDLE_CLOSE_MS) {
      this.closeActiveSet();
      return;
    }

    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const leftVis = ((lHip.visibility ?? 1) + (lKnee.visibility ?? 1) + (lAnkle.visibility ?? 1)) / 3;
    const rightVis = ((rHip.visibility ?? 1) + (rKnee.visibility ?? 1) + (rAnkle.visibility ?? 1)) / 3;
    const leftOk = leftVis >= SPLITSQUAT_MIN_VISIBILITY;
    const rightOk = rightVis >= SPLITSQUAT_MIN_VISIBILITY;

    if (!leftOk && !rightOk) {
      this.announceStatus("Ponte en posición.");
      if (this.debugEl) this.debugEl.textContent = "buscando cadera, rodilla y tobillo de las dos piernas…";
      this.splitSquatKneeAngle = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    // La primera vez en toda la sesión que se te ve bien, un aviso de
    // que ya puedes empezar (mismo patrón que processSquat).
    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus("¡Listo! Empieza.", "startup_ready");
    }

    const leftAngle = leftOk ? angle(lHip, lKnee, lAnkle) : null;
    const rightAngle = rightOk ? angle(rHip, rKnee, rAnkle) : null;
    let kneeAngle;
    if (leftAngle !== null && rightAngle !== null) {
      kneeAngle = Math.min(leftAngle, rightAngle);
    } else {
      kneeAngle = leftAngle !== null ? leftAngle : rightAngle;
    }
    if (kneeAngle === null) return;

    this.splitSquatKneeAngle = kneeAngle;

    if (this.state === null) {
      // Hay que empezar de pie (las dos rodillas casi rectas) y de
      // forma estable, para no contar media repetición al entrar en
      // encuadre a media bajada -- mismo patrón que squatArmStableSince.
      if (kneeAngle >= SPLITSQUAT_ARM_GATE_ANGLE_DEG) {
        if (this.splitSquatStableSince === null) this.splitSquatStableSince = now;
        if (now - this.splitSquatStableSince >= SPLITSQUAT_STABLE_MS) {
          this.state = "top";
          this.splitSquatStableSince = null;
          this.splitSquatStateEnteredAt = now;
          this.announceStatus("¡Listo!", "ready_to_go");
        } else {
          this.setStatus("Confirmando…");
        }
      } else {
        this.splitSquatStableSince = null;
        this.setStatus("Ponte en posición.");
      }
    } else if (this.state === "top") {
      // La otra pierna (la que no es la más doblada) tiene que enseñar
      // también algo de flexión real -- si sigue recta del todo, esto
      // no es un split squat, es solo una pierna moviéndose sola (ver
      // el bug de "levantar un pie y doblar la rodilla" arriba).
      const otherAngle = (leftAngle !== null && rightAngle !== null)
        ? Math.max(leftAngle, rightAngle)
        : null;
      const bothLegsBent = otherAngle === null || otherAngle <= SPLITSQUAT_SUPPORT_MAX_ANGLE_DEG;
      if (kneeAngle <= SPLITSQUAT_DOWN_ANGLE_DEG && bothLegsBent) {
        this.state = "bottom";
        this.repStartTime = now; // la repetición empieza al bajar
        this.splitSquatStateEnteredAt = now;
      }
    } else if (kneeAngle >= SPLITSQUAT_UP_ANGLE_DEG) {
      // Ha vuelto a subir del todo: repetición completa.
      this.countRep((now - this.repStartTime) / 1000, now, "Split squat");
      this.state = "top";
      this.splitSquatStateEnteredAt = now;
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `ángulo rodilla (mín. de las piernas visibles): ${kneeAngle.toFixed(0)}° | estado: ${this.state ?? "esperando"} ` +
        `(abajo ≤${SPLITSQUAT_DOWN_ANGLE_DEG}°, arriba ≥${SPLITSQUAT_UP_ANGLE_DEG}°)`;
    }
  }

  /**
   * Jumping jacks — DE FRENTE a la cámara, ciclo cerrado (brazos pegados
   * al cuerpo, pies juntos) -> abierto (brazos por encima de la cabeza,
   * piernas separadas) -> cerrado, contando la repetición al volver a
   * cerrar (ver el bloque JUMPINGJACK_* de más arriba para el porqué de
   * cada umbral).
   *
   * A diferencia del resto de GROUND_STYLE_COUNTERS, aquí NO se usa
   * checkWaveGesture para cerrar la serie a mano: levantar un brazo es
   * parte del propio gesto del ejercicio (los dos brazos suben en cada
   * repetición), así que cualquier repetición se podía confundir con
   * "quiero terminar" y cerraba la serie sola en pleno calentamiento —
   * reportado explícitamente. En su lugar, la serie se cierra si te
   * quedas JUMPINGJACK_STILL_MS sin completar ningún medio-ciclo
   * (ni abrir ni volver a cerrar) — pararte es la señal de que has
   * terminado, igual que se le pide al usuario en groundWaitingMessage.
   */
  processJumpingJack(lm, now) {
    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const vis = (
      (lShoulder.visibility ?? 1) + (rShoulder.visibility ?? 1) +
      (lHip.visibility ?? 1) + (rHip.visibility ?? 1) +
      (lWrist.visibility ?? 1) + (rWrist.visibility ?? 1) +
      (lAnkle.visibility ?? 1) + (rAnkle.visibility ?? 1)
    ) / 8;

    if (vis < JUMPINGJACK_MIN_VISIBILITY) {
      this.announceStatus("No se te ve bien de cuerpo entero. Ponte de frente a la cámara, con hombros, caderas, muñecas y tobillos en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando cuerpo entero de frente…";
      // JUMPINGJACK_OUT_OF_FRAME_MS (no el generico OUT_OF_FRAME_STABLE_MS):
      // saltando de verdad esto tambien se dispara sin haberte ido a
      // ningun lado (motion blur en munecas/tobillos durante el propio
      // salto), asi que hace falta mas margen antes de dar la serie por
      // terminada -- ver la nota junto a esa constante.
      this.noteAbsence(now, JUMPINGJACK_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    // La primera vez en toda la sesión que se te ve bien, un aviso de
    // que ya puedes empezar — en las siguientes series no hace falta
    // repetirlo (mismo patrón que processSquat/processDip).
    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Cuerpo entero a la vista. ¡Listo! Ya puedes empezar. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    // Parar de moverse (ni abrir ni cerrar) JUMPINGJACK_STILL_MS seguidos
    // es la señal de que has terminado la serie — ver la nota de más
    // arriba sobre por qué esto sustituye a checkWaveGesture aquí.
    if (this.state !== null && this.jjLastTransitionAt !== null && now - this.jjLastTransitionAt >= JUMPINGJACK_STILL_MS) {
      this.closeActiveSet();
      return;
    }

    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    const hipWidth = Math.hypot(lHip.x - rHip.x, lHip.y - rHip.y);
    const ankleWidth = Math.hypot(lAnkle.x - rAnkle.x, lAnkle.y - rAnkle.y);
    if (!shoulderWidth || !hipWidth) return;

    const shoulderMidY = (lShoulder.y + rShoulder.y) / 2;
    const wristMidY = (lWrist.y + rWrist.y) / 2;

    const armsUpNow = wristMidY < shoulderMidY - JUMPINGJACK_ARMS_UP_MARGIN_FACTOR * shoulderWidth;
    const armsDownNow = wristMidY > shoulderMidY - JUMPINGJACK_ARMS_DOWN_MARGIN_FACTOR * shoulderWidth;
    const legsOpenNow = ankleWidth > hipWidth * JUMPINGJACK_LEGS_OPEN_RATIO;
    const legsClosedNow = ankleWidth < hipWidth * JUMPINGJACK_LEGS_CLOSED_RATIO;

    if (this.state === null) {
      // Para armar hay que confirmar que estás DE VERDAD quieto en la
      // posición cerrada, estable durante JUMPINGJACK_ARM_STABLE_MS —
      // igual que sentadillas. Reportado: de pie de forma normal (sin
      // pegar los pies a propósito) el tracking de MediaPipe ya hace que
      // el ratio de piernas parpadee solo entre "juntas"/"a medio" de
      // vez en cuando, y antes CUALQUIER frame que no cumpliera del todo
      // reiniciaba el cronómetro entero — el armado podía tardar 10-15s
      // o no completarse nunca. Ahora un parpadeo aislado (hasta
      // JUMPINGJACK_ARM_NOISE_TOLERANCE_MS seguidos) no cuenta como que
      // te has movido de verdad; solo se reinicia el cronómetro si el
      // frame "malo" se sostiene más que eso.
      if (armsDownNow && legsClosedNow) {
        this.jjArmBadSince = null;
        if (this.jjArmStableSince === null) this.jjArmStableSince = now;
        if (now - this.jjArmStableSince >= JUMPINGJACK_ARM_STABLE_MS) {
          this.state = "closed";
          this.jjArmStableSince = null;
          // OJO: no se pone a "now" sin más. Reportado: la serie se
          // cerraba sola ANTES de dar tiempo a saltar ni una vez —
          // causa: el aviso hablado "¡Listo!..." tarda unos 2-3s en
          // decirse, y el reloj de "llevas quieto JUMPINGJACK_STILL_MS"
          // arrancaba en el mismo instante que empezaba a sonar, no
          // cuando terminaba — para cuando de verdad podías reaccionar
          // y saltar, el margen de 2s ya casi se había ido entero. Aquí
          // se adelanta el reloj artificialmente para dar
          // JUMPINGJACK_FIRST_JUMP_GRACE_MS de margen SOLO en este
          // primer salto (una vez ya estás saltando, entre repetición y
          // repetición sí vale el JUMPINGJACK_STILL_MS normal, más
          // ajustado, para cerrar la serie pronto cuando de verdad
          // paras).
          this.jjLastTransitionAt = now + (JUMPINGJACK_FIRST_JUMP_GRACE_MS - JUMPINGJACK_STILL_MS);
          this.announceStatus("¡Listo! Abre brazos y piernas a la vez y vuelve a cerrar.", "ready_to_go");
        } else {
          this.setStatus("Pies juntos, brazos pegados al cuerpo… confirmando (no te muevas)");
        }
      } else {
        if (this.jjArmStableSince !== null) {
          // Ya estábamos acumulando estabilidad -- puede ser un parpadeo
          // de un frame suelto. Solo se tira todo el progreso si el
          // frame "malo" persiste más que la tolerancia de ruido.
          if (this.jjArmBadSince === null) this.jjArmBadSince = now;
          if (now - this.jjArmBadSince >= JUMPINGJACK_ARM_NOISE_TOLERANCE_MS) {
            this.jjArmStableSince = null;
            this.jjArmBadSince = null;
          }
        }
        this.setStatus("Ponte de pie, de frente a la cámara, con los brazos pegados al cuerpo y los pies juntos, para empezar.");
      }
    } else if (this.state === "closed") {
      // Las PIERNAS son la única señal que decide abrir/cerrar (igual de
      // simple que el ángulo de rodilla en sentadillas) — el hueco entre
      // JUMPINGJACK_LEGS_OPEN_RATIO y JUMPINGJACK_LEGS_CLOSED_RATIO ya da
      // la histéresis necesaria, sin depender de que los brazos se lean
      // exactamente en el mismo frame.
      //
      // Reportado: se contó una serie entera sin haber saltado. Causa
      // más probable: un solo frame ruidoso (oclusión de un tobillo,
      // un roce al ajustarte la postura) leído como "piernas abiertas"
      // de golpe, sin estar saltando de verdad. Por eso aquí SÍ se exige
      // que "piernas abiertas" se sostenga JUMPINGJACK_OPEN_STABLE_MS
      // seguidos antes de dar el salto por empezado — un salto real lo
      // cumple de sobra (las piernas están arriba de ese umbral bastante
      // más que eso), un parpadeo de un frame suelto no.
      if (legsOpenNow) {
        if (this.jjLegsOpenSince === null) this.jjLegsOpenSince = now;
        if (now - this.jjLegsOpenSince >= JUMPINGJACK_OPEN_STABLE_MS) {
          this.state = "open";
          this.jjLastTransitionAt = now;
          this.jjArmsUpSeenThisRep = armsUpNow; // por si ya suben en el mismo frame que las piernas
          this.repStartTime = now; // la repetición empieza al abrir (momento real de apertura, no cuando se confirma)
          this.jjLegsOpenSince = null;
        }
      } else {
        this.jjLegsOpenSince = null;
      }
    } else {
      // state === "open": los brazos solo se comprueban como "¿han
      // estado arriba EN ALGÚN MOMENTO de esta apertura?", no en el
      // frame exacto del cierre — en un salto rápido, el pico de brazos
      // y el de piernas casi nunca caen en el mismo frame capturado, y
      // exigir coincidencia exacta perdía repeticiones (reportado: "de
      // 15 saltos solo cuenta 12" — ver la nota junto a las constantes
      // JUMPINGJACK_* de más arriba sobre el intento anterior con una
      // ventana de tiempo, que era peor: podía contar "abierto" y
      // "cerrado" a la vez y disparaba cierres de serie fantasma).
      if (armsUpNow) this.jjArmsUpSeenThisRep = true;
      if (legsClosedNow) {
        this.jjLastTransitionAt = now;
        if (this.jjArmsUpSeenThisRep) {
          // minSeconds mas bajo que el generico MIN_REP_SECONDS (0.3s):
          // repStartTime se marca DESPUES de exigir JUMPINGJACK_OPEN_STABLE_MS
          // (150ms) de piernas abiertas sostenidas, o sea que un salto real
          // rapido puede medir bastante menos de 0.3s desde ahi hasta volver a
          // cerrar sin ser ruido -- el propio debounce de apertura ya filtra los
          // parpadeos de un frame suelto, asi que aqui hace falta menos margen.
          // Reportado: yendo rapido, a partir de cierto punto dejaba de contar
          // repeticiones sueltas -- duracion por debajo de 0.3s.
          this.countRep((now - this.repStartTime) / 1000, now, "Jumping jack", JUMPINGJACK_MIN_REP_SECONDS);
        }
        this.state = "closed";
        this.jjArmsUpSeenThisRep = false;
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `piernas: ${legsOpenNow ? "abiertas" : legsClosedNow ? "juntas" : "medio"} | brazos arriba vistos en esta apertura: ${this.jjArmsUpSeenThisRep ? "sí" : "no"} | estado: ${this.state ?? "esperando"} | quieto desde hace: ${this.jjLastTransitionAt ? Math.round(now - this.jjLastTransitionAt) + "ms" : "-"}`;
    }
  }

  /**
   * Círculos de brazos — DE FRENTE a la cámara, calentamiento dinámico:
   * los dos brazos extendidos giran a la vez alrededor del hombro, un
   * giro completo (360°) cuenta como una repetición (ver el bloque
   * ARMCIRCLES_* de más arriba para la geometría, la convención de signo
   * y el porqué de cada umbral — primera versión, pendiente de calibrar
   * con un test en cámara real, mismo patrón que armcrossstretch/
   * tricepsoverheadstretch en su día).
   *
   * A diferencia de jumping jack, aquí no hay dos estados discretos
   * (abierto/cerrado) que comprobar: el "progreso" es continuo (ángulo
   * acumulado), así que this.state solo distingue "todavía sin armar"
   * (null, esperando brazos extendidos estables) de "armado y contando"
   * ("active").
   */
  processArmCircles(lm, now) {
    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];

    const vis = (
      (lShoulder.visibility ?? 1) + (rShoulder.visibility ?? 1) +
      (lWrist.visibility ?? 1) + (rWrist.visibility ?? 1)
    ) / 4;

    if (vis < ARMCIRCLES_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien los hombros y las muñecas. Ponte de frente a la cámara, con los dos brazos en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando hombros y muñecas de frente…";
      // ARMCIRCLES_OUT_OF_FRAME_MS (no el genérico OUT_OF_FRAME_STABLE_MS):
      // igual que en jumping jack, girando de verdad los brazos también
      // baja la confianza de MediaPipe en las muñecas por el propio
      // movimiento (motion blur), no solo al salirte del encuadre de verdad.
      this.noteAbsence(now, ARMCIRCLES_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Hombros y muñecas a la vista. ¡Listo! Extiende los dos brazos y empieza a girarlos. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    if (!shoulderWidth) return;

    const reachL = Math.hypot(lWrist.x - lShoulder.x, lWrist.y - lShoulder.y);
    const reachR = Math.hypot(rWrist.x - rShoulder.x, rWrist.y - rShoulder.y);
    const reachOkL = reachL > ARMCIRCLES_MIN_REACH_FACTOR * shoulderWidth;
    const reachOkR = reachR > ARMCIRCLES_MIN_REACH_FACTOR * shoulderWidth;
    const armsExtended = reachOkL && reachOkR;

    if (this.state === null) {
      // Armado: brazos extendidos sostenido ARMCIRCLES_ARM_STABLE_MS
      // seguidos, igual de simple que el armado de jumping jack pero sin
      // piernas que comprobar.
      if (armsExtended) {
        if (this.armCircleArmStableSince === null) this.armCircleArmStableSince = now;
        if (now - this.armCircleArmStableSince >= ARMCIRCLES_ARM_STABLE_MS) {
          this.state = "active";
          this.armCircleArmStableSince = null;
          // Ángulo local de cada brazo (ver el bloque ARMCIRCLES_* de más
          // arriba): X normalizado para que "hacia fuera" sea siempre
          // positivo en los dos lados, Y invertido para que "arriba" sea
          // positivo. Se fija AHORA (no antes) para que el primer delta
          // salga de una posición realmente armada, sin saltos raros.
          this.armCirclePrevAngleL = Math.atan2(-(lWrist.y - lShoulder.y), lWrist.x - lShoulder.x);
          this.armCirclePrevAngleR = Math.atan2(-(rWrist.y - rShoulder.y), -(rWrist.x - rShoulder.x));
          this.armCircleAccum = 0;
          this.armCirclePhase = null;
          this.armCirclePhaseReps = 0;
          this.armCircleDidPhaseSwitch = false;
          this.armCircleLastProgressAt = now;
          this.armCircleRepStartTime = now;
          this.announceStatus("¡Listo! Empieza a girar los brazos.", "ready_to_go");
        } else {
          this.setStatus("Brazos extendidos… confirmando (no te muevas)");
        }
      } else {
        this.armCircleArmStableSince = null;
        this.setStatus("Ponte de pie, de frente a la cámara, con los brazos extendidos, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent =
          `esperando brazos extendidos… reach_izq=${reachL.toFixed(2)} reach_der=${reachR.toFixed(2)} umbral=${(ARMCIRCLES_MIN_REACH_FACTOR * shoulderWidth).toFixed(2)}`;
      }
      return;
    }

    // state === "active": ya armado, se acumula ángulo cada frame.

    // Parar de girar ARMCIRCLES_STILL_MS seguidos es la señal de que has
    // terminado la serie (mismo patrón que JUMPINGJACK_STILL_MS) — se
    // reinicia todo el estado de fase para que la siguiente serie
    // siempre vuelva a empezar en "hacia delante".
    if (this.armCircleLastProgressAt !== null && now - this.armCircleLastProgressAt >= ARMCIRCLES_STILL_MS) {
      if (!this.armCircleDidPhaseSwitch && this.armCirclePhaseReps > 0) {
        // Te has parado, pero en esta serie todavía no has hecho el otro
        // sentido: nada de pedir bajar los brazos ni confirmar de
        // nuevo, se sigue en pleno seguimiento activo (this.state no se
        // toca) y se pasa directamente al otro sentido.
        //
        // Orden de los avisos (pedido explícito tras probarlo en cámara
        // real, 2026-09-05): antes se oía "Ahora hacia atrás/delante" de
        // entrada y "Serie de N terminada" solo mucho después, al cerrar
        // la serie de verdad -- así que si luego no llegabas a completar
        // ninguna vuelta en el sentido nuevo, esa invitación quedaba en
        // el aire seguida de un cierre sin relación aparente con ella.
        // Ahora el sentido que acabas de hacer se cierra aquí mismo como
        // una serie completa en sí misma (reps guardadas, contador de
        // reps de pantalla a cero) y ESE aviso ("Serie de N terminada")
        // suena primero, con la invitación al otro sentido pegada justo
        // detrás en el mismo mensaje.
        const closedReps = this.currentSetReps;
        if (closedReps > 0) {
          this.sets.push({ reps: this.currentSetReps, durations: [...this.currentSetDurations] });
          this.currentSetReps = 0;
          this.currentSetDurations = [];
          this.updateSetDisplay();
          if (this.repsEl) this.repsEl.textContent = "0";
          this.setClosedAt = now;
        }
        this.armCirclePhase = this.armCirclePhase === "forward" ? "backward" : "forward";
        this.armCircleDidPhaseSwitch = true;
        this.armCirclePhaseReps = 0;
        this.armCircleAccum = 0;
        this.armCirclePrevAngleL = null;
        this.armCirclePrevAngleR = null;
        this.armCircleLastProgressAt = now; // para no volver a disparar esto mismo con la misma quietud
        this.announceSetComplete(
          `Serie de ${closedReps}`,
          this.armCirclePhase === "forward" ? "Ahora hacia delante." : "Ahora hacia atrás."
        );
        return;
      }
      // Ya has hecho los dos sentidos en esta serie (o te has parado sin
      // llegar a completar ninguna repetición): aquí sí se cierra la serie.
      this.closeActiveSet();
      this.armCirclePhase = null;
      this.armCirclePhaseReps = 0;
      this.armCircleAccum = 0;
      this.armCirclePrevAngleL = null;
      this.armCirclePrevAngleR = null;
      this.armCircleDidPhaseSwitch = false;
      return;
    }

    const angleL = Math.atan2(-(lWrist.y - lShoulder.y), lWrist.x - lShoulder.x);
    const angleR = Math.atan2(-(rWrist.y - rShoulder.y), -(rWrist.x - rShoulder.x));

    // Cada brazo se acepta o descarta POR SEPARADO este frame (antes se
    // exigían los dos a la vez y un frame entero se perdía si solo uno
    // fallaba): reportado en el primer test real que la cuenta se
    // quedaba corta -- el vídeo de referencia cruza las dos muñecas
    // cerca de la cara en lo alto del círculo, momento en que una
    // muñeca queda parcialmente detrás/pegada a la otra y su "radio"
    // (reach) se hunde una fracción de segundo aunque el otro brazo
    // siga perfectamente fiable. Con el brazo pegado al cuerpo (radio
    // casi cero) el ángulo no es de fiar -- cualquier ruido de tracking
    // se nota muchísimo -- así que ese brazo no acumula nada este
    // frame, pero SÍ se actualiza su ángulo previo, para no generar un
    // salto falso cuando vuelva a extenderse. Además, incluso con radio
    // suficiente, un salto de ángulo mayor que ARMCIRCLES_MAX_SINGLE_ARM_DELTA
    // en un solo frame se descarta como fallo puntual de tracking (visto
    // en el primer test: saltos aislados de 30-57°/frame, alguno con el
    // signo cambiado, justo en ese mismo punto del círculo).
    let deltaL = 0, deltaR = 0, validL = false, validR = false;
    if (this.armCirclePrevAngleL === null) {
      this.armCirclePrevAngleL = angleL;
    } else if (reachOkL) {
      const dl = wrapAngleDelta(angleL - this.armCirclePrevAngleL);
      if (Math.abs(dl) <= ARMCIRCLES_MAX_SINGLE_ARM_DELTA) {
        deltaL = dl;
        validL = true;
        this.armCirclePrevAngleL = angleL;
      }
      // Si el salto supera el margen, el ángulo previo se deja SIN
      // actualizar (a diferencia de antes) -- así el giro real que hubo
      // en este frame no se pierde del todo, se arrastra al siguiente
      // (ver comentario más arriba, junto a ARMCIRCLES_MAX_SINGLE_ARM_DELTA).
    } else {
      // Brazo demasiado pegado al cuerpo para fiarse del ángulo: aquí sí
      // se actualiza siempre, para no generar un salto falso cuando
      // vuelva a extenderse.
      this.armCirclePrevAngleL = angleL;
    }
    if (this.armCirclePrevAngleR === null) {
      this.armCirclePrevAngleR = angleR;
    } else if (reachOkR) {
      const dr = wrapAngleDelta(angleR - this.armCirclePrevAngleR);
      if (Math.abs(dr) <= ARMCIRCLES_MAX_SINGLE_ARM_DELTA) {
        deltaR = dr;
        validR = true;
        this.armCirclePrevAngleR = angleR;
      }
    } else {
      this.armCirclePrevAngleR = angleR;
    }

    // Promedio solo de los brazos que SÍ se han aceptado este frame --
    // si solo uno es de fiar, su delta entero es la mejor estimación
    // disponible (los dos brazos giran a la vez, en teoría al mismo
    // ritmo), no la mitad de su valor.
    const validCount = (validL ? 1 : 0) + (validR ? 1 : 0);
    const avgDelta = validCount > 0 ? (deltaL + deltaR) / validCount : 0;

    if (Math.abs(avgDelta) >= ARMCIRCLES_MIN_ANGULAR_DELTA) {
      this.armCircleLastProgressAt = now;
    }

    this.armCircleAccum += avgDelta;

    if (Math.abs(this.armCircleAccum) >= 2 * Math.PI) {
      // Vuelta completa: el signo del acumulado dice el sentido (ver la
      // convención documentada junto a las constantes ARMCIRCLES_* —
      // ángulo decreciente = "forward"/hacia delante).
      const repDirection = this.armCircleAccum < 0 ? "forward" : "backward";
      const seconds = (now - this.armCircleRepStartTime) / 1000;
      if (this.armCirclePhase === null) {
        // Primera vuelta completa de la serie: el sentido que sea que
        // hagas primero pasa a ser el "pedido" desde ahora (antes se
        // exigía "adelante" siempre al arrancar, y si en realidad
        // girabas al revés se descartaba cada vuelta en silencio, sin
        // avisar de nada -- reportado como "hacia delante no me deja
        // nunca, solo hacia atrás").
        this.armCirclePhase = repDirection;
      }
      if (repDirection === this.armCirclePhase) {
        const counted = this.countRep(
          seconds, now,
          this.armCirclePhase === "forward" ? "Círculo adelante" : "Círculo atrás",
          ARMCIRCLES_MIN_REP_SECONDS
        );
        if (counted) {
          // El cambio de sentido sigue llegando solo al pararte de
          // verdad (ver ARMCIRCLES_STILL_MS más arriba), no por llegar a
          // un número concreto -- pero el objetivo (30 de cada sentido,
          // ver countRep) sí necesita saber cuántas van hechas en CADA
          // sentido a lo largo de toda la sesión, no solo en la serie
          // actual (armCirclePhaseReps se resetea en cada cambio de
          // sentido; esto no).
          this.armCirclePhaseReps += 1;
          if (this.armCirclePhase === "forward") this.armCircleForwardTotal += 1;
          else this.armCircleBackwardTotal += 1;
        }
      }
      // Se descuenta una vuelta completa del acumulado, no se resetea a
      // 0 del todo -- por si ya llevabas parte de la siguiente vuelta
      // encadenada en el mismo frame (giro rápido).
      this.armCircleAccum -= Math.sign(this.armCircleAccum) * 2 * Math.PI;
      this.armCircleRepStartTime = now;
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `sentido pedido: ${this.armCirclePhase === null ? "(por detectar)" : (this.armCirclePhase === "forward" ? "adelante" : "atrás")} (${this.armCirclePhaseReps}) | ` +
        `acumulado: ${Math.round(this.armCircleAccum * 180 / Math.PI)}° | ` +
        `delta_izq: ${validL ? (deltaL * 180 / Math.PI).toFixed(1) : "—"}°/f | delta_der: ${validR ? (deltaR * 180 / Math.PI).toFixed(1) : "—"}°/f | ` +
        `reach_izq=${reachL.toFixed(2)}${reachOkL ? "" : "✗"} reach_der=${reachR.toFixed(2)}${reachOkR ? "" : "✗"} | ` +
        `quieto desde hace: ${this.armCircleLastProgressAt ? Math.round(now - this.armCircleLastProgressAt) + "ms" : "-"}`;
    }
  }

  /**
   * Inclinaciones laterales de cuello (oreja al hombro) — DE FRENTE a la
   * cámara, de pie o sentada/o: la nariz se separa del centro (punto
   * medio de los hombros) hacia un lado, acercando la oreja al hombro,
   * y vuelve al centro; un vaivén completo (centro -> lado -> centro)
   * cuenta como una repetición (ver el bloque NECKLATERAL_* de más
   * arriba para la geometría y cada umbral — primera versión, pendiente
   * de calibrar con un test en cámara real, mismo patrón que
   * armcrossstretch/tricepsoverheadstretch/armcircles en su día).
   *
   * Pedido explícitamente por el usuario con un vídeo de referencia
   * (WhatsApp, 2026-09-05): "que detecte cuando la nariz va a un lado
   * sin que el cuello se mueva de sitio" — por eso, aparte de contar el
   * vaivén, se vigila el punto medio de los HOMBROS (no de la cara): si
   * se desplaza más de NECKLATERAL_DRIFT_TOLERANCE_FACTOR mientras
   * estás a un lado, es que el torso entero se está inclinando en vez
   * de solo la cabeza/cuello, y se avisa — sin dejar de contar la
   * repetición (mismo espíritu "se avisa, no se penaliza" que el
   * sentido equivocado en círculos de brazos).
   *
   * Primera prueba real (2026-09-05): tirar la cabeza hacia
   * delante/abajo (barbilla al pecho) se contaba como repetición -- ese
   * movimiento también corre algo la nariz en horizontal (no es un eje
   * puro). Por eso además se compara cuánto CAE la nariz respecto a tu
   * centro (ver NECKLATERAL_MAX_VERTICAL_FACTOR): si el componente
   * vertical domina, no se acepta como "ir a un lado" -- esto sí
   * bloquea la confirmación del lado (a diferencia del desplazamiento
   * de hombros de arriba, que solo avisa).
   *
   * this.state sigue el mismo patrón que jumping jack: null (todavía
   * sin armar, esperando centrado estable) -> "center" (armado,
   * esperando que te vayas a un lado) -> "left"/"right" (lado
   * confirmado, esperando que vuelvas al centro para cerrar el vaivén).
   */
  processNeckLateral(lm, now) {
    const nose = lm[NOSE];
    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];

    const vis = ((nose.visibility ?? 1) + (lShoulder.visibility ?? 1) + (rShoulder.visibility ?? 1)) / 3;

    if (vis < NECKLATERAL_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien la cara y los hombros. Ponte de frente a la cámara.");
      if (this.debugEl) this.debugEl.textContent = "buscando cara y hombros de frente…";
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Cara y hombros a la vista. ¡Listo! Ya puedes empezar. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    const shoulderMidX = (lShoulder.x + rShoulder.x) / 2;
    const shoulderMidY = (lShoulder.y + rShoulder.y) / 2;
    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    if (!shoulderWidth) return;

    const rawOffset = (nose.x - shoulderMidX) / shoulderWidth;
    const rawVerticalOffset = (nose.y - shoulderMidY) / shoulderWidth;

    if (this.state === null) {
      // Armado: nariz centrada (respecto a los hombros) sostenida
      // NECKLATERAL_CENTER_STABLE_MS seguidos — fija tu propio "centro"
      // real como baseline, para no exigir que la nariz esté
      // perfectamente centrada de fábrica (encuadre de cámara, postura
      // natural...).
      if (Math.abs(rawOffset) < NECKLATERAL_ENTER_FACTOR) {
        if (this.neckLateralStableSince === null) this.neckLateralStableSince = now;
        if (now - this.neckLateralStableSince >= NECKLATERAL_CENTER_STABLE_MS) {
          this.state = "center";
          this.neckLateralStableSince = null;
          this.neckLateralBaselineOffset = rawOffset;
          this.neckLateralBaselineVerticalOffset = rawVerticalOffset;
          this.neckLateralLastTransitionAt = now;
          this.announceStatus("¡Listo! Oreja al hombro, y vuelta al centro.", "ready_to_go");
        } else {
          this.setStatus("Mirando al frente, centrada/o… confirmando (no te muevas)");
        }
      } else {
        this.neckLateralStableSince = null;
        this.setStatus("Ponte de frente a la cámara, mirando al frente, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = `esperando centro… desviación=${rawOffset.toFixed(3)} umbral=±${NECKLATERAL_ENTER_FACTOR.toFixed(3)}`;
      }
      return;
    }

    // Ya armado: parar de completar ningún vaivén NECKLATERAL_STILL_MS
    // seguidos es la señal de que has terminado la serie (mismo patrón
    // que JUMPINGJACK_STILL_MS/ARMCIRCLES_STILL_MS).
    if (this.neckLateralLastTransitionAt !== null && now - this.neckLateralLastTransitionAt >= NECKLATERAL_STILL_MS) {
      this.closeActiveSet();
      return;
    }

    const offset = rawOffset - this.neckLateralBaselineOffset;
    const verticalOffset = rawVerticalOffset - this.neckLateralBaselineVerticalOffset;

    if (this.state === "center") {
      // Esperando que la nariz se separe del centro hacia un lado —
      // igual que jumping jack exige que "piernas abiertas" se sostenga
      // un rato antes de dar el lado por confirmado (NECKLATERAL_SIDE_STABLE_MS),
      // para no armar el vaivén con un pico de un frame suelto.
      // Si la nariz ha caído más de la cuenta (NECKLATERAL_MAX_VERTICAL_FACTOR)
      // respecto a tu centro, esto es un movimiento hacia delante/abajo
      // (barbilla al pecho), no hacia un lado -- no cuenta como sideNow
      // aunque el desplazamiento horizontal por sí solo pareciera
      // suficiente (ver NECKLATERAL_MAX_VERTICAL_FACTOR para el porqué).
      const verticalOk = Math.abs(verticalOffset) < NECKLATERAL_MAX_VERTICAL_FACTOR;
      const sideNow = !verticalOk ? null : offset > NECKLATERAL_ENTER_FACTOR ? "right" : offset < -NECKLATERAL_ENTER_FACTOR ? "left" : null;
      if (sideNow) {
        if (this.neckLateralSide !== sideNow) {
          this.neckLateralSide = sideNow;
          this.neckLateralSideSince = now;
        } else if (now - this.neckLateralSideSince >= NECKLATERAL_SIDE_STABLE_MS) {
          this.state = sideNow;
          this.repStartTime = now; // la repetición empieza al confirmarse el lado (momento real de llegada, no cuando vuelves al centro)
          this.neckLateralAnchorX = shoulderMidX; // hombros AHORA MISMO -- lo que se desplacen desde aquí es lo que se vigila
          this.neckLateralDrifted = false;
          this.neckLateralSideSince = null;
        }
      } else {
        this.neckLateralSide = null;
        this.neckLateralSideSince = null;
      }
    } else {
      // state === "left" | "right": lado confirmado, vigilando que el
      // torso (punto medio de hombros) no se desplace de sitio mientras
      // esperas a volver al centro.
      const drift = Math.abs(shoulderMidX - this.neckLateralAnchorX) / shoulderWidth;
      if (drift > NECKLATERAL_DRIFT_TOLERANCE_FACTOR && !this.neckLateralDrifted) {
        this.neckLateralDrifted = true;
      }
      if (this.neckLateralDrifted) {
        // Solo texto (setStatus), sin voz -- es una corrección, no algo
        // imprescindible para seguir contando (la repetición se cuenta
        // igual, ver más abajo), así que no hace falta interrumpir con
        // audio cada vez que pasa.
        this.setStatus("Mueves el cuerpo entero — intenta girar solo la cabeza, sin desplazar los hombros.");
      }
      if (Math.abs(offset) < NECKLATERAL_EXIT_FACTOR) {
        // Vuelta al centro: se cierra el vaivén.
        this.neckLateralLastTransitionAt = now;
        this.countRep(
          (now - this.repStartTime) / 1000, now,
          this.state === "left" ? "Giro a la izquierda" : "Giro a la derecha",
          NECKLATERAL_MIN_REP_SECONDS
        );
        this.state = "center";
        this.neckLateralSide = null;
        this.neckLateralSideSince = null;
        this.neckLateralAnchorX = null;
        this.neckLateralDrifted = false;
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `estado: ${this.state} | desviación=${offset.toFixed(3)} vertical=${verticalOffset.toFixed(3)}${Math.abs(verticalOffset) >= NECKLATERAL_MAX_VERTICAL_FACTOR ? "✗" : ""} umbral_entrada=±${NECKLATERAL_ENTER_FACTOR.toFixed(3)} umbral_salida=±${NECKLATERAL_EXIT_FACTOR.toFixed(3)} umbral_vertical=${NECKLATERAL_MAX_VERTICAL_FACTOR.toFixed(3)} | ` +
        `desplazamiento hombros: ${this.neckLateralAnchorX !== null ? (Math.abs(shoulderMidX - this.neckLateralAnchorX) / shoulderWidth).toFixed(3) : "-"}${this.neckLateralDrifted ? " ⚠" : ""} | ` +
        `quieto desde hace: ${this.neckLateralLastTransitionAt ? Math.round(now - this.neckLateralLastTransitionAt) + "ms" : "-"}`;
    }
  }

  /**
   * Giro de cabeza a los lados — DE FRENTE a la cámara, de pie o
   * sentada/o: la cabeza GIRA sobre el eje vertical del cuello (como
   * decir "no" con la cabeza, sin inclinarla), mirando hacia un lado y
   * volviendo a mirar al frente; un vaivén completo (centro -> lado ->
   * centro) cuenta como una repetición (ver el bloque NECKTURN_* de más
   * arriba para la geometría y cada umbral).
   *
   * DISTINTO de processNeckLateral (movilidad lateral de cuello): ese
   * ejercicio es una inclinación (oreja hacia el hombro); este es un
   * giro puro, sin inclinar la cabeza ni completar ninguna
   * circunferencia (a diferencia de processNeckCircles/
   * processNeckHalfTurn). Misma geometría de base que processNeckLateral
   * (desplazamiento horizontal de la nariz respecto al punto medio de
   * los hombros) reutilizada tal cual bajo constantes/campos propios —
   * primera versión de este ejercicio, pendiente de calibrar con un
   * test en cámara real.
   *
   * this.state sigue el mismo patrón que processNeckLateral: null
   * (todavía sin armar, esperando centrado estable) -> "center" (armado,
   * esperando que gires hacia un lado) -> "left"/"right" (lado
   * confirmado, esperando que vuelvas a mirar al frente para cerrar el
   * vaivén).
   */
  processNeckTurn(lm, now) {
    const nose = lm[NOSE];
    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];

    const vis = ((nose.visibility ?? 1) + (lShoulder.visibility ?? 1) + (rShoulder.visibility ?? 1)) / 3;

    if (vis < NECKTURN_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien la cara y los hombros. Ponte de frente a la cámara.");
      if (this.debugEl) this.debugEl.textContent = "buscando cara y hombros de frente…";
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Cara y hombros a la vista. ¡Listo! Ya puedes empezar. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    const shoulderMidX = (lShoulder.x + rShoulder.x) / 2;
    const shoulderMidY = (lShoulder.y + rShoulder.y) / 2;
    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    if (!shoulderWidth) return;

    const rawOffset = (nose.x - shoulderMidX) / shoulderWidth;
    const rawVerticalOffset = (nose.y - shoulderMidY) / shoulderWidth;

    if (this.state === null) {
      // Armado: nariz centrada (respecto a los hombros) sostenida
      // NECKTURN_CENTER_STABLE_MS seguidos — fija tu propio "centro"
      // real como baseline, para no exigir que la nariz esté
      // perfectamente centrada de fábrica (encuadre de cámara, postura
      // natural...).
      if (Math.abs(rawOffset) < NECKTURN_ENTER_FACTOR) {
        if (this.neckTurnStableSince === null) this.neckTurnStableSince = now;
        if (now - this.neckTurnStableSince >= NECKTURN_CENTER_STABLE_MS) {
          this.state = "center";
          this.neckTurnStableSince = null;
          this.neckTurnBaselineOffset = rawOffset;
          this.neckTurnBaselineVerticalOffset = rawVerticalOffset;
          this.neckTurnLastTransitionAt = now;
          this.announceStatus("¡Listo! Mira hacia un lado, y vuelve a mirar al frente.", "ready_to_go");
        } else {
          this.setStatus("Mirando al frente, centrada/o… confirmando (no te muevas)");
        }
      } else {
        this.neckTurnStableSince = null;
        this.setStatus("Ponte de frente a la cámara, mirando al frente, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = `esperando centro… desviación=${rawOffset.toFixed(3)} umbral=±${NECKTURN_ENTER_FACTOR.toFixed(3)}`;
      }
      return;
    }

    // Ya armado: parar de completar ningún vaivén NECKTURN_STILL_MS
    // seguidos es la señal de que has terminado la serie (mismo patrón
    // que NECKLATERAL_STILL_MS).
    if (this.neckTurnLastTransitionAt !== null && now - this.neckTurnLastTransitionAt >= NECKTURN_STILL_MS) {
      this.closeActiveSet();
      return;
    }

    const offset = rawOffset - this.neckTurnBaselineOffset;
    const verticalOffset = rawVerticalOffset - this.neckTurnBaselineVerticalOffset;

    if (this.state === "center") {
      // Esperando que la nariz se separe del centro hacia un lado —
      // igual que necklateral, exige que "girada/o hacia un lado" se
      // sostenga un rato antes de dar el lado por confirmado
      // (NECKTURN_SIDE_STABLE_MS), para no armar el vaivén con un pico
      // de un frame suelto. Si la nariz ha caído más de la cuenta
      // (NECKTURN_MAX_VERTICAL_FACTOR) respecto a tu centro, esto es un
      // movimiento hacia delante/abajo (barbilla al pecho), no un giro
      // hacia un lado -- no cuenta como sideNow aunque el desplazamiento
      // horizontal por sí solo pareciera suficiente.
      const verticalOk = Math.abs(verticalOffset) < NECKTURN_MAX_VERTICAL_FACTOR;
      const sideNow = !verticalOk ? null : offset > NECKTURN_ENTER_FACTOR ? "right" : offset < -NECKTURN_ENTER_FACTOR ? "left" : null;
      if (sideNow) {
        if (this.neckTurnSide !== sideNow) {
          this.neckTurnSide = sideNow;
          this.neckTurnSideSince = now;
        } else if (now - this.neckTurnSideSince >= NECKTURN_SIDE_STABLE_MS) {
          this.state = sideNow;
          this.repStartTime = now; // la repetición empieza al confirmarse el lado (momento real de llegada, no cuando vuelves al centro)
          this.neckTurnAnchorX = shoulderMidX; // hombros AHORA MISMO -- lo que se desplacen desde aquí es lo que se vigila
          this.neckTurnDrifted = false;
          this.neckTurnSideSince = null;
        }
      } else {
        this.neckTurnSide = null;
        this.neckTurnSideSince = null;
      }
    } else {
      // state === "left" | "right": lado confirmado, vigilando que el
      // torso (punto medio de hombros) no se desplace de sitio mientras
      // esperas a volver a mirar al frente.
      const drift = Math.abs(shoulderMidX - this.neckTurnAnchorX) / shoulderWidth;
      if (drift > NECKTURN_DRIFT_TOLERANCE_FACTOR && !this.neckTurnDrifted) {
        this.neckTurnDrifted = true;
      }
      if (this.neckTurnDrifted) {
        // Solo texto (setStatus), sin voz -- es una corrección, no algo
        // imprescindible para seguir contando (la repetición se cuenta
        // igual, ver más abajo), así que no hace falta interrumpir con
        // audio cada vez que pasa.
        this.setStatus("Mueves el cuerpo entero — intenta girar solo la cabeza, sin desplazar los hombros.");
      }
      if (Math.abs(offset) < NECKTURN_EXIT_FACTOR) {
        // Vuelta al centro: se cierra el vaivén.
        this.neckTurnLastTransitionAt = now;
        this.countRep(
          (now - this.repStartTime) / 1000, now,
          this.state === "left" ? "Giro a la izquierda" : "Giro a la derecha",
          NECKTURN_MIN_REP_SECONDS
        );
        this.state = "center";
        this.neckTurnSide = null;
        this.neckTurnSideSince = null;
        this.neckTurnAnchorX = null;
        this.neckTurnDrifted = false;
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `estado: ${this.state} | desviación=${offset.toFixed(3)} vertical=${verticalOffset.toFixed(3)}${Math.abs(verticalOffset) >= NECKTURN_MAX_VERTICAL_FACTOR ? "✗" : ""} umbral_entrada=±${NECKTURN_ENTER_FACTOR.toFixed(3)} umbral_salida=±${NECKTURN_EXIT_FACTOR.toFixed(3)} umbral_vertical=${NECKTURN_MAX_VERTICAL_FACTOR.toFixed(3)} | ` +
        `desplazamiento hombros: ${this.neckTurnAnchorX !== null ? (Math.abs(shoulderMidX - this.neckTurnAnchorX) / shoulderWidth).toFixed(3) : "-"}${this.neckTurnDrifted ? " ⚠" : ""} | ` +
        `quieto desde hace: ${this.neckTurnLastTransitionAt ? Math.round(now - this.neckTurnLastTransitionAt) + "ms" : "-"}`;
    }
  }

  /**
   * Círculo completo de cuello — DE FRENTE a la cámara, de pie o
   * sentada/o: la cabeza da una vuelta entera alrededor del cuello (de
   * frente, hacia un lado, barbilla al pecho, hacia el otro lado, y
   * hacia atrás/arriba de vuelta al frente); una vuelta completa cuenta
   * como una repetición (ver el bloque NECKCIRCLE_* de más arriba para
   * la geometría y cada umbral — primera versión, pendiente de calibrar
   * con un test en cámara real, mismo patrón que armcircles en su día).
   *
   * Mismo mecanismo que processArmCircles (ángulo acumulado del vector
   * punto-medio-de-hombros->nariz, wrapAngleDelta por fotograma, una
   * repetición cada ±2π), pero SIN el bloqueo de sentido de círculos de
   * brazos (armCirclePhase): aquí cualquiera de los dos sentidos
   * (horario o antihorario) cuenta siempre, sin tener que completar
   * antes el otro ni pararte para cambiar de sentido — pedido
   * explícitamente por el usuario ("que también cuenten si los hago en
   * sentido contrario").
   *
   * this.state solo distingue "todavía sin armar" (null, esperando de
   * frente y centrada/o estable) de "armado y contando" ("active"),
   * igual que círculos de brazos.
   */
  processNeckCircles(lm, now) {
    const nose = lm[NOSE];
    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];

    const vis = ((nose.visibility ?? 1) + (lShoulder.visibility ?? 1) + (rShoulder.visibility ?? 1)) / 3;

    if (vis < NECKCIRCLE_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien la cara y los hombros. Ponte de frente a la cámara.");
      if (this.debugEl) this.debugEl.textContent = "buscando cara y hombros de frente…";
      this.noteAbsence(now, NECKCIRCLE_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Cara y hombros a la vista. ¡Listo! Empieza a girar la cabeza, en el sentido que prefieras. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    const shoulderMidX = (lShoulder.x + rShoulder.x) / 2;
    const shoulderMidY = (lShoulder.y + rShoulder.y) / 2;
    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    if (!shoulderWidth) return;

    if (this.state === null) {
      // Armado: cabeza centrada (nariz cerca del punto medio de
      // hombros) sostenido NECKCIRCLE_CENTER_STABLE_MS seguidos — para
      // no arrancar a mitad de un giro (mismo espíritu que el armado de
      // círculos de brazos, pero comprobando "de frente" en vez de
      // "brazos extendidos").
      const centered = Math.abs((nose.x - shoulderMidX) / shoulderWidth) < NECKCIRCLE_CENTER_ENTER_FACTOR;
      if (centered) {
        if (this.neckCircleCenterStableSince === null) this.neckCircleCenterStableSince = now;
        if (now - this.neckCircleCenterStableSince >= NECKCIRCLE_CENTER_STABLE_MS) {
          this.state = "active";
          this.neckCircleCenterStableSince = null;
          this.neckCirclePrevAngle = Math.atan2(-(nose.y - shoulderMidY), nose.x - shoulderMidX);
          this.neckCircleAccum = 0;
          this.neckCircleLastProgressAt = now;
          this.neckCircleRepStartTime = now;
          this.announceStatus("¡Listo! Empieza a girar la cabeza.", "ready_to_go");
        } else {
          this.setStatus("Mirando al frente, centrada/o… confirmando (no te muevas)");
        }
      } else {
        this.neckCircleCenterStableSince = null;
        this.setStatus("Ponte de frente a la cámara, mirando al frente, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = "esperando cabeza centrada…";
      }
      return;
    }

    // state === "active": ya armado, se acumula ángulo cada frame.

    // Parar de girar NECKCIRCLE_STILL_MS seguidos es la señal de que has
    // terminado la serie (mismo patrón que ARMCIRCLES_STILL_MS).
    if (this.neckCircleLastProgressAt !== null && now - this.neckCircleLastProgressAt >= NECKCIRCLE_STILL_MS) {
      this.closeActiveSet();
      this.neckCirclePrevAngle = null;
      this.neckCircleAccum = 0;
      return;
    }

    const angle = Math.atan2(-(nose.y - shoulderMidY), nose.x - shoulderMidX);

    let delta = 0;
    if (this.neckCirclePrevAngle === null) {
      this.neckCirclePrevAngle = angle;
    } else {
      const d = wrapAngleDelta(angle - this.neckCirclePrevAngle);
      if (Math.abs(d) <= NECKCIRCLE_MAX_SINGLE_FRAME_DELTA) {
        delta = d;
        this.neckCirclePrevAngle = angle;
      }
      // Si el salto supera el margen, se descarta como fallo puntual de
      // tracking y el ángulo previo NO se actualiza (mismo motivo que
      // ARMCIRCLES_MAX_SINGLE_ARM_DELTA): el giro real de este frame se
      // arrastra al siguiente en vez de perderse del todo.
    }

    if (Math.abs(delta) >= NECKCIRCLE_MIN_ANGULAR_DELTA) {
      this.neckCircleLastProgressAt = now;
    }

    this.neckCircleAccum += delta;

    if (Math.abs(this.neckCircleAccum) >= 2 * Math.PI) {
      // Vuelta completa, en cualquier sentido -- a diferencia de
      // círculos de brazos, aquí no hay que comprobar que el sentido
      // coincida con uno "pedido": todo giro completo cuenta.
      const seconds = (now - this.neckCircleRepStartTime) / 1000;
      this.countRep(seconds, now, "Círculo completo de cuello", NECKCIRCLE_MIN_REP_SECONDS);
      // Se descuenta una vuelta completa del acumulado, no se resetea a
      // 0 del todo -- por si ya llevabas parte de la siguiente vuelta
      // encadenada en el mismo frame (mismo motivo que armCircleAccum).
      this.neckCircleAccum -= Math.sign(this.neckCircleAccum) * 2 * Math.PI;
      this.neckCircleRepStartTime = now;
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `acumulado: ${Math.round(this.neckCircleAccum * 180 / Math.PI)}° | delta: ${(delta * 180 / Math.PI).toFixed(1)}°/f | ` +
        `quieto desde hace: ${this.neckCircleLastProgressAt ? Math.round(now - this.neckCircleLastProgressAt) + "ms" : "-"}`;
    }
  }

  /**
   * Media vuelta de cuello — DE FRENTE a la cámara, de pie o sentada/o:
   * la cabeza va de un lado al otro pasando por el centro con la
   * barbilla hacia el pecho, SIN llegar a completar el círculo entero
   * (sin inclinar la cabeza hacia atrás) — pedido explícitamente como
   * "que pare a la mitad", con un segundo vídeo de referencia (WhatsApp,
   * 2026-09-04) para diferenciarlo del círculo completo de arriba (ver
   * el bloque NECKHALFTURN_* de más arriba para el porqué del cambio a
   * v2, contando por CAMBIO DE SENTIDO en vez de por ángulo acumulado
   * fijo — pedido explícitamente por el usuario: "haz que cuente una
   * rep cada vez que paro y cambio de direccion").
   *
   * Mismo vector que processNeckCircles (punto-medio-de-hombros->nariz,
   * wrapAngleDelta por fotograma), pero en vez de acumular hasta un
   * ángulo fijo, aquí se seguye el sentido del vaivén EN CURSO
   * (neckHalfTurnDirection) y se cuenta una repetición cuando el
   * movimiento en el sentido CONTRARIO se sostiene
   * NECKHALFTURN_REVERSE_STABLE_MS seguidos (cambio de sentido
   * confirmado, no un temblor de un fotograma) Y el vaivén que se
   * cierra giró al menos NECKHALFTURN_MIN_SWING_RAD. Sin bloqueo de
   * sentido: el primer movimiento de cada vaivén, en cualquier sentido,
   * es válido — pedido explícitamente por el usuario ("que también
   * cuenten si los hago en sentido contrario"). Sin diferenciación de
   * lado en la voz (mismo espíritu minimalista que rodillas altas):
   * solo se anuncia el número de repeticiones.
   */
  processNeckHalfTurn(lm, now) {
    const nose = lm[NOSE];
    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];

    const vis = ((nose.visibility ?? 1) + (lShoulder.visibility ?? 1) + (rShoulder.visibility ?? 1)) / 3;

    if (vis < NECKHALFTURN_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien la cara y los hombros. Ponte de frente a la cámara.");
      if (this.debugEl) this.debugEl.textContent = "buscando cara y hombros de frente…";
      this.noteAbsence(now, NECKHALFTURN_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Cara y hombros a la vista. ¡Listo! Lleva la cabeza de un lado a otro pasando por el centro, en cualquier sentido. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    const shoulderMidX = (lShoulder.x + rShoulder.x) / 2;
    const shoulderMidY = (lShoulder.y + rShoulder.y) / 2;
    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    if (!shoulderWidth) return;

    if (this.state === null) {
      const centered = Math.abs((nose.x - shoulderMidX) / shoulderWidth) < NECKHALFTURN_CENTER_ENTER_FACTOR;
      if (centered) {
        if (this.neckHalfTurnCenterStableSince === null) this.neckHalfTurnCenterStableSince = now;
        if (now - this.neckHalfTurnCenterStableSince >= NECKHALFTURN_CENTER_STABLE_MS) {
          this.state = "active";
          this.neckHalfTurnCenterStableSince = null;
          this.neckHalfTurnPrevAngle = Math.atan2(-(nose.y - shoulderMidY), nose.x - shoulderMidX);
          this.neckHalfTurnAccum = 0;
          this.neckHalfTurnDirection = null;
          this.neckHalfTurnReverseSince = null;
          this.neckHalfTurnLastProgressAt = now;
          this.neckHalfTurnRepStartTime = now;
          this.announceStatus("¡Listo! Empieza a mover la cabeza de un lado a otro.", "ready_to_go");
        } else {
          this.setStatus("Mirando al frente, centrada/o… confirmando (no te muevas)");
        }
      } else {
        this.neckHalfTurnCenterStableSince = null;
        this.setStatus("Ponte de frente a la cámara, mirando al frente, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = "esperando cabeza centrada…";
      }
      return;
    }

    if (this.neckHalfTurnLastProgressAt !== null && now - this.neckHalfTurnLastProgressAt >= NECKHALFTURN_STILL_MS) {
      this.closeActiveSet();
      this.neckHalfTurnPrevAngle = null;
      this.neckHalfTurnAccum = 0;
      this.neckHalfTurnDirection = null;
      this.neckHalfTurnReverseSince = null;
      return;
    }

    const angle = Math.atan2(-(nose.y - shoulderMidY), nose.x - shoulderMidX);

    let delta = 0;
    if (this.neckHalfTurnPrevAngle === null) {
      this.neckHalfTurnPrevAngle = angle;
    } else {
      const d = wrapAngleDelta(angle - this.neckHalfTurnPrevAngle);
      if (Math.abs(d) <= NECKHALFTURN_MAX_SINGLE_FRAME_DELTA) {
        delta = d;
        this.neckHalfTurnPrevAngle = angle;
      }
    }

    // Un movimiento de verdad (por encima del ruido de tracking) es lo
    // único que cuenta para seguir el sentido del vaivén o detectar un
    // cambio de sentido -- un delta minúsculo no es ni "seguir igual"
    // ni "invertir", así que se ignora del todo (ver v2 en el
    // comentario de NECKHALFTURN_* para el porqué de este cambio).
    if (Math.abs(delta) >= NECKHALFTURN_MIN_ANGULAR_DELTA) {
      this.neckHalfTurnLastProgressAt = now;

      const deltaSign = Math.sign(delta);

      if (this.neckHalfTurnDirection === null) {
        // Primer movimiento de verdad de la serie (o del vaivén que
        // sigue a una repetición ya contada): fija el sentido de este
        // vaivén, sea cual sea -- sin bloqueo de sentido.
        this.neckHalfTurnDirection = deltaSign;
        this.neckHalfTurnAccum = delta;
        this.neckHalfTurnReverseSince = null;
      } else if (deltaSign === this.neckHalfTurnDirection) {
        // Sigues en el mismo sentido: acumula, y olvida cualquier amago
        // de cambio de sentido que no haya llegado a confirmarse.
        this.neckHalfTurnAccum += delta;
        this.neckHalfTurnReverseSince = null;
      } else {
        // Moviéndote en el sentido contrario -- posible cambio de
        // sentido, pero hace falta que se sostenga
        // NECKHALFTURN_REVERSE_STABLE_MS seguidos (no el pico de un
        // solo fotograma) antes de confirmarlo.
        if (this.neckHalfTurnReverseSince === null) {
          this.neckHalfTurnReverseSince = now;
        } else if (now - this.neckHalfTurnReverseSince >= NECKHALFTURN_REVERSE_STABLE_MS) {
          // Cambio de sentido confirmado: cuenta la media vuelta que
          // acabas de completar, siempre que hayas girado lo
          // suficiente (NECKHALFTURN_MIN_SWING_RAD) -- filtra una
          // inversión real pero minúscula, no un vaivén de verdad.
          if (Math.abs(this.neckHalfTurnAccum) >= NECKHALFTURN_MIN_SWING_RAD) {
            const seconds = (now - this.neckHalfTurnRepStartTime) / 1000;
            this.countRep(seconds, now, "Media vuelta de cuello", NECKHALFTURN_MIN_REP_SECONDS);
          }
          // Empieza a vigilar el vaivén nuevo, en el sentido que
          // acabas de confirmar -- se cuente o no la repetición
          // anterior.
          this.neckHalfTurnDirection = deltaSign;
          this.neckHalfTurnAccum = delta;
          this.neckHalfTurnReverseSince = null;
          this.neckHalfTurnRepStartTime = now;
        }
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `sentido: ${this.neckHalfTurnDirection === null ? "-" : (this.neckHalfTurnDirection > 0 ? "+" : "-")} | acumulado vaivén: ${Math.round(this.neckHalfTurnAccum * 180 / Math.PI)}° | delta: ${(delta * 180 / Math.PI).toFixed(1)}°/f | ` +
        `invirtiendo desde hace: ${this.neckHalfTurnReverseSince ? Math.round(now - this.neckHalfTurnReverseSince) + "ms" : "-"} | ` +
        `quieto desde hace: ${this.neckHalfTurnLastProgressAt ? Math.round(now - this.neckHalfTurnLastProgressAt) + "ms" : "-"}`;
    }
  }

  /**
   * Balanceo lateral de cadera — DE FRENTE a la cámara, de pie, con los
   * pies bien separados (más que el ancho de cadera) y SIN moverlos del
   * sitio: la cadera se desplaza de un lado a otro y vuelve al centro;
   * un vaivén completo (centro -> lado -> centro) cuenta como una
   * repetición (ver el bloque HIPLATERAL_* de más arriba para la
   * geometría y cada umbral).
   *
   * Antes de armar, además de esperar a que la cadera esté centrada, se
   * exige que la base de apoyo (tobillo a tobillo) sea más ancha que la
   * cadera (HIPLATERAL_MIN_STANCE_FACTOR) -- pedido explícitamente por
   * el usuario -- sostenida HIPLATERAL_CENTER_STABLE_MS seguidos (subida
   * a 1500ms en v3 para que la primera "repetición" no salga de estar
   * aún colocándote, ver el comentario junto a esa constante). Mientras
   * un lado está confirmado se vigila que el punto medio de los
   * tobillos no se desplace (HIPLATERAL_FEET_DRIFT_TOLERANCE_FACTOR):
   * los pies tienen que quedarse plantados, solo la cadera se mueve --
   * si se superan, el vaivén NO cuenta como repetición al volver al
   * centro, y hay que re-armar desde cero (a diferencia de giros de
   * cuello, donde el mismo desplazamiento solo avisa sin bloquear --
   * aquí hacía falta bloquear de verdad: se detectó que al terminar
   * una serie y caminar hacia la cámara con las manos fuera de la
   * cadera, ese desplazamiento se contaba igualmente como repetición
   * válida, reportado en una prueba real, 2026-09-07). Además, para
   * confirmar un lado hace falta que el
   * desplazamiento sea sobre todo lateral y no en profundidad
   * (HIPLATERAL_MAX_DEPTH_FACTOR) -- mover la cadera hacia delante y
   * hacia atrás, sin ir a ningún lado, NO cuenta (reportado en la
   * primera prueba real, 2026-09-07).
   *
   * this.state sigue el mismo patrón que giros de cuello: null (todavía
   * sin armar, esperando pies separados + cadera centrada estable) ->
   * "center" (armado, esperando que la cadera se vaya a un lado) ->
   * "left"/"right" (lado confirmado, esperando que vuelva al centro
   * para cerrar el vaivén).
   */
  processHipLateral(lm, now) {
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const vis = ((lHip.visibility ?? 1) + (rHip.visibility ?? 1) + (lAnkle.visibility ?? 1) + (rAnkle.visibility ?? 1)) / 4;

    if (vis < HIPLATERAL_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien la cadera y los pies. Ponte de frente a la cámara, con la cadera y los pies en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando cadera y tobillos de frente…";
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Cadera y pies a la vista. ¡Listo! Ya puedes empezar. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    const rawHipMidX = (lHip.x + rHip.x) / 2;
    const rawHipMidZ = (lHip.z + rHip.z) / 2;
    const rawHipWidth = Math.hypot(lHip.x - rHip.x, lHip.y - rHip.y);
    const rawAnkleMidX = (lAnkle.x + rAnkle.x) / 2;
    const rawStanceWidth = Math.hypot(lAnkle.x - rAnkle.x, lAnkle.y - rAnkle.y);
    if (!rawStanceWidth || !rawHipWidth) return;

    // Suavizado (media móvil exponencial, ver HIPLATERAL_GEOMETRY_SMOOTHING_
    // ALPHA): un solo fotograma con hipWidth/stanceWidth raras (ruido de
    // tracking, sobre todo con la cadera casi de frente) no debe poder
    // desarmar un vaivén ya en marcha ni disparar sideNow por su cuenta.
    if (this.hipLateralSmoothHipMidX === null) {
      this.hipLateralSmoothHipMidX = rawHipMidX;
      this.hipLateralSmoothHipMidZ = rawHipMidZ;
      this.hipLateralSmoothHipWidth = rawHipWidth;
      this.hipLateralSmoothAnkleMidX = rawAnkleMidX;
      this.hipLateralSmoothStanceWidth = rawStanceWidth;
    } else {
      this.hipLateralSmoothHipMidX += HIPLATERAL_GEOMETRY_SMOOTHING_ALPHA * (rawHipMidX - this.hipLateralSmoothHipMidX);
      this.hipLateralSmoothHipMidZ += HIPLATERAL_GEOMETRY_SMOOTHING_ALPHA * (rawHipMidZ - this.hipLateralSmoothHipMidZ);
      this.hipLateralSmoothHipWidth += HIPLATERAL_GEOMETRY_SMOOTHING_ALPHA * (rawHipWidth - this.hipLateralSmoothHipWidth);
      this.hipLateralSmoothAnkleMidX += HIPLATERAL_GEOMETRY_SMOOTHING_ALPHA * (rawAnkleMidX - this.hipLateralSmoothAnkleMidX);
      this.hipLateralSmoothStanceWidth += HIPLATERAL_GEOMETRY_SMOOTHING_ALPHA * (rawStanceWidth - this.hipLateralSmoothStanceWidth);
    }
    const hipMidX = this.hipLateralSmoothHipMidX;
    const hipMidZ = this.hipLateralSmoothHipMidZ;
    const hipWidth = this.hipLateralSmoothHipWidth;
    const ankleMidX = this.hipLateralSmoothAnkleMidX;
    const stanceWidth = this.hipLateralSmoothStanceWidth;

    if (stanceWidth < hipWidth * HIPLATERAL_MIN_STANCE_FACTOR) {
      // Pies demasiado juntos -- no se arma el contador hasta que se
      // separen más que la cadera (pedido explícitamente por el
      // usuario). Se reinicia cualquier armado a medias para no dejar
      // "centro" fijado con una base de apoyo que ya no vale.
      this.state = null;
      this.hipLateralStableSince = null;
      this.setStatus("Separa más los pies -- más ancho que la cadera -- para empezar.");
      if (this.debugEl) this.debugEl.textContent = `pies muy juntos: base=${stanceWidth.toFixed(3)} cadera=${hipWidth.toFixed(3)} (necesitas ≥${(hipWidth * HIPLATERAL_MIN_STANCE_FACTOR).toFixed(3)})`;
      return;
    }

    const rawOffset = (hipMidX - ankleMidX) / stanceWidth;

    if (this.state === null) {
      // Armado: cadera centrada (respecto a los tobillos) sostenida
      // HIPLATERAL_CENTER_STABLE_MS seguidos, con los pies ya separados
      // más que la cadera -- fija tu propio "centro" real (posición Y
      // profundidad) como baseline, para no exigir que la cadera esté
      // perfectamente centrada de fábrica.
      if (Math.abs(rawOffset) < HIPLATERAL_ENTER_FACTOR) {
        if (this.hipLateralStableSince === null) this.hipLateralStableSince = now;
        if (now - this.hipLateralStableSince >= HIPLATERAL_CENTER_STABLE_MS) {
          this.state = "center";
          this.hipLateralStableSince = null;
          this.hipLateralBaselineOffset = rawOffset;
          this.hipLateralBaselineDepth = hipMidZ;
          this.hipLateralLastTransitionAt = now;
          this.announceStatus("¡Listo! Lleva la cadera a un lado, y vuelta al centro, sin mover los pies ni inclinarte hacia delante o atrás.", "ready_to_go");
        } else {
          this.setStatus("Pies separados, cadera centrada… confirmando (no te muevas)");
        }
      } else {
        this.hipLateralStableSince = null;
        this.setStatus("Ponte de frente a la cámara, con la cadera centrada, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = `esperando centro… desviación=${rawOffset.toFixed(3)} umbral=±${HIPLATERAL_ENTER_FACTOR.toFixed(3)} base=${stanceWidth.toFixed(3)} cadera=${hipWidth.toFixed(3)}`;
      }
      return;
    }

    // Ya armado: parar de completar ningún vaivén HIPLATERAL_STILL_MS
    // seguidos es la señal de que has terminado la serie (mismo patrón
    // que NECKLATERAL_STILL_MS).
    if (this.hipLateralLastTransitionAt !== null && now - this.hipLateralLastTransitionAt >= HIPLATERAL_STILL_MS) {
      this.closeActiveSet();
      return;
    }

    const offset = rawOffset - this.hipLateralBaselineOffset;
    const depthOffset = (hipMidZ - this.hipLateralBaselineDepth) / stanceWidth;

    if (this.state === "center") {
      // Esperando que la cadera se separe del centro hacia un lado --
      // igual que giros de cuello, exige que el lado se sostenga un
      // rato (HIPLATERAL_SIDE_STABLE_MS) antes de confirmarse, para no
      // armar el vaivén con un pico de un frame suelto. Si la cadera se
      // ha alejado/acercado de la cámara más de la cuenta
      // (HIPLATERAL_MAX_DEPTH_FACTOR) respecto a tu profundidad de
      // referencia, esto es un movimiento hacia delante/atrás, no hacia
      // un lado -- no cuenta como sideNow aunque el desplazamiento
      // horizontal por sí solo pareciera suficiente (reportado en la
      // primera prueba real, 2026-09-07).
      const depthOk = Math.abs(depthOffset) < HIPLATERAL_MAX_DEPTH_FACTOR;
      const sideNow = !depthOk ? null : offset > HIPLATERAL_ENTER_FACTOR ? "right" : offset < -HIPLATERAL_ENTER_FACTOR ? "left" : null;
      if (sideNow) {
        if (this.hipLateralSide !== sideNow) {
          this.hipLateralSide = sideNow;
          this.hipLateralSideSince = now;
        } else if (now - this.hipLateralSideSince >= HIPLATERAL_SIDE_STABLE_MS) {
          this.state = sideNow;
          this.repStartTime = now; // la repetición empieza al confirmarse el lado (momento real de llegada, no cuando vuelves al centro)
          this.hipLateralAnkleAnchorX = ankleMidX; // tobillos AHORA MISMO -- lo que se desplacen desde aquí es lo que se vigila
          this.hipLateralFeetDrifted = false;
          this.hipLateralSideSince = null;
        }
      } else {
        this.hipLateralSide = null;
        this.hipLateralSideSince = null;
      }
    } else {
      // state === "left" | "right": lado confirmado, vigilando que los
      // pies (punto medio de tobillos) no se desplacen de sitio
      // mientras esperas a volver al centro.
      const feetDrift = Math.abs(ankleMidX - this.hipLateralAnkleAnchorX) / stanceWidth;
      if (feetDrift > HIPLATERAL_FEET_DRIFT_TOLERANCE_FACTOR && !this.hipLateralFeetDrifted) {
        this.hipLateralFeetDrifted = true;
      }
      if (this.hipLateralFeetDrifted) {
        // Solo texto (setStatus), sin voz -- es una corrección, no algo
        // imprescindible para seguir contando (la repetición se cuenta
        // igual, ver más abajo), mismo espíritu que el desplazamiento
        // de hombros en giros de cuello.
        this.setStatus("Mueves los pies -- déjalos plantados, balancea solo la cadera.");
      }
      if (Math.abs(offset) < HIPLATERAL_EXIT_FACTOR) {
        // Vuelta al centro: se cierra el vaivén -- pero si los pies se
        // han desplazado más de la cuenta (hipLateralFeetDrifted, ver
        // arriba) esto no es un balanceo de cadera de verdad sino que
        // te has movido/caminado, así que no cuenta como repetición:
        // se reinicia a "sin armar" para obligar a recolocarse y volver
        // a confirmar la postura de partida (reportado en una prueba
        // real, 2026-09-07: al terminar una serie y caminar hacia la
        // cámara con las manos fuera de la cadera, este desplazamiento
        // se contaba igualmente como repetición válida).
        this.hipLateralLastTransitionAt = now;
        if (this.hipLateralFeetDrifted) {
          this.state = null;
          this.hipLateralStableSince = null;
          this.hipLateralSide = null;
          this.hipLateralSideSince = null;
          this.hipLateralAnkleAnchorX = null;
          this.hipLateralFeetDrifted = false;
          this.setStatus("Te has movido de sitio -- ponte de frente de nuevo, con los pies bien separados, para seguir.");
        } else {
          this.countRep(
            (now - this.repStartTime) / 1000, now,
            this.state === "left" ? "Cadera a la izquierda" : "Cadera a la derecha",
            HIPLATERAL_MIN_REP_SECONDS
          );
          this.state = "center";
          this.hipLateralSide = null;
          this.hipLateralSideSince = null;
          this.hipLateralAnkleAnchorX = null;
          this.hipLateralFeetDrifted = false;
        }
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `estado: ${this.state} | desviación=${offset.toFixed(3)} profundidad=${depthOffset.toFixed(3)}${Math.abs(depthOffset) >= HIPLATERAL_MAX_DEPTH_FACTOR ? "✗" : ""} umbral_entrada=±${HIPLATERAL_ENTER_FACTOR.toFixed(3)} umbral_salida=±${HIPLATERAL_EXIT_FACTOR.toFixed(3)} umbral_profundidad=${HIPLATERAL_MAX_DEPTH_FACTOR.toFixed(3)} | ` +
        `base=${stanceWidth.toFixed(3)} cadera=${hipWidth.toFixed(3)} | ` +
        `desplazamiento pies: ${this.hipLateralAnkleAnchorX !== null ? (Math.abs(ankleMidX - this.hipLateralAnkleAnchorX) / stanceWidth).toFixed(3) : "-"}${this.hipLateralFeetDrifted ? " ⚠" : ""} | ` +
        `quieto desde hace: ${this.hipLateralLastTransitionAt ? Math.round(now - this.hipLateralLastTransitionAt) + "ms" : "-"}`;
    }
  }

  /**
   * Cadera adelante y atrás — DE PERFIL a la cámara (a diferencia de
   * processHipLateral, que pide de frente), de pie, con los pies
   * quietos en el suelo: la cadera se lleva hacia delante y hacia
   * atrás, volviendo cada vez al centro (ver el bloque HIPFORWARDBACK_*
   * de más arriba para la geometría y cada umbral).
   *
   * De perfil las dos caderas/tobillos casi se solapan en la imagen
   * (mismo problema que talones al glúteo/rodillas altas), así que solo
   * se vigila un lado (cadera+tobillo), elegido UNA vez al armar según
   * cuál se ve mejor y fijo el resto de la serie (this.hipForwardBackTrackedSide
   * — mismo criterio que heelKickTrackedSide). El desplazamiento
   * cadera-tobillo se normaliza por la propia longitud cadera-tobillo,
   * no por una anchura de base tobillo-tobillo (que de perfil sería
   * casi cero).
   *
   * v3 (2026-09-08, pedido explícito del usuario tras una prueba real):
   * dos cambios.
   *   1) Ya NO hace falta ver hombros ni nariz -- todo el ejercicio
   *      (visibilidad, geometría del vaivén Y el sentido "adelante" real)
   *      se calcula solo con cadera+tobillo+punta del pie (L_FOOT_INDEX/
   *      R_FOOT_INDEX, mismos landmarks que ya usa el estiramiento de
   *      isquiotibiales sentado), nunca con hombros/nariz.
   *   2) Se exige estar de perfil de VERDAD, no solo tener la cadera
   *      centrada: si la separación aparente cadera-cadera (que de
   *      perfil casi se solapa) crece por encima de
   *      HIPFORWARDBACK_PROFILE_MAX_HIP_WIDTH_FACTOR sostenido
   *      HIPFORWARDBACK_PROFILE_CONFIRM_MS (te has girado hacia la
   *      cámara, por ejemplo acercándote caminando), no se arma el
   *      contador, y si ya estaba armado el vaivén en curso NO cuenta
   *      como repetición al volver al centro (this.hipForwardBackTurnedAway,
   *      mismo mecanismo que hipForwardBackFeetDrifted) -- exactamente
   *      el caso reportado: las últimas repeticiones de una serie se
   *      contaron mientras el usuario se acercaba a la cámara, dejando
   *      de estar de perfil.
   *
   * this.state sigue el mismo patrón que processHipLateral: null
   * (todavía sin armar, esperando cadera centrada estable Y de perfil)
   * -> "center" (armado, esperando que la cadera se vaya a delante o
   * atrás) -> "front"/"back" (dirección confirmada, esperando que
   * vuelva al centro para cerrar el vaivén).
   */
  processHipForwardBack(lm, now) {
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const visL = ((lHip.visibility ?? 1) + (lAnkle.visibility ?? 1)) / 2;
    const visR = ((rHip.visibility ?? 1) + (rAnkle.visibility ?? 1)) / 2;
    const vis = Math.max(visL, visR);

    if (vis < HIPFORWARDBACK_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien la cadera y el tobillo. Ponte de perfil a la cámara, con la cadera y el tobillo en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando cadera y tobillo de perfil…";
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Cadera y tobillo a la vista. ¡Listo! Ya puedes empezar. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    // Lado a vigilar: el elegido al armar (this.hipForwardBackTrackedSide),
    // o mientras tanto el que mejor se ve ahora mismo (ver el comentario
    // de la función para el porqué de fijarlo solo una vez).
    const side = this.hipForwardBackTrackedSide ?? (visL >= visR ? "left" : "right");
    const hip = side === "left" ? lHip : rHip;
    const ankle = side === "left" ? lAnkle : rAnkle;
    const foot = side === "left" ? lm[L_FOOT_INDEX] : lm[R_FOOT_INDEX];

    const rawHipX = hip.x;
    const rawAnkleX = ankle.x;
    const rawLegLength = Math.hypot(hip.x - ankle.x, hip.y - ankle.y);
    if (!rawLegLength) return;

    // Separación aparente cadera-cadera (ver el bloque HIPFORWARDBACK_
    // PROFILE_* de más arriba): de perfil de verdad casi se solapan, de
    // frente crece mucho respecto a la longitud de la pierna -- es la
    // señal de "¿sigo de perfil?", calculada con caderas nada más (no
    // hace falta ver hombros para esto).
    const rawHipWidth = Math.hypot(lHip.x - rHip.x, lHip.y - rHip.y);

    // Suavizado (media móvil exponencial, ver HIPFORWARDBACK_GEOMETRY_
    // SMOOTHING_ALPHA): un solo fotograma ruidoso no debe poder desarmar
    // un vaivén ya en marcha ni disparar una dirección por su cuenta.
    if (this.hipForwardBackSmoothHipX === null) {
      this.hipForwardBackSmoothHipX = rawHipX;
      this.hipForwardBackSmoothAnkleX = rawAnkleX;
      this.hipForwardBackSmoothLegLength = rawLegLength;
      this.hipForwardBackSmoothHipWidth = rawHipWidth;
    } else {
      this.hipForwardBackSmoothHipX += HIPFORWARDBACK_GEOMETRY_SMOOTHING_ALPHA * (rawHipX - this.hipForwardBackSmoothHipX);
      this.hipForwardBackSmoothAnkleX += HIPFORWARDBACK_GEOMETRY_SMOOTHING_ALPHA * (rawAnkleX - this.hipForwardBackSmoothAnkleX);
      this.hipForwardBackSmoothLegLength += HIPFORWARDBACK_GEOMETRY_SMOOTHING_ALPHA * (rawLegLength - this.hipForwardBackSmoothLegLength);
      this.hipForwardBackSmoothHipWidth += HIPFORWARDBACK_GEOMETRY_SMOOTHING_ALPHA * (rawHipWidth - this.hipForwardBackSmoothHipWidth);
    }
    const hipX = this.hipForwardBackSmoothHipX;
    const ankleX = this.hipForwardBackSmoothAnkleX;
    const legLength = this.hipForwardBackSmoothLegLength;
    const hipWidth = this.hipForwardBackSmoothHipWidth;

    const rawOffset = (hipX - ankleX) / legLength;

    // ¿Sigo de perfil? -- separación cadera-cadera respecto a la pierna,
    // sostenida HIPFORWARDBACK_PROFILE_CONFIRM_MS seguidos por encima del
    // umbral antes de actuar (filtra un pico suelto de ruido de tracking).
    const hipWidthRatio = hipWidth / legLength;
    if (hipWidthRatio > HIPFORWARDBACK_PROFILE_MAX_HIP_WIDTH_FACTOR) {
      if (this.hipForwardBackNotProfileSince === null) this.hipForwardBackNotProfileSince = now;
    } else {
      this.hipForwardBackNotProfileSince = null;
    }
    const notProfileConfirmed =
      this.hipForwardBackNotProfileSince !== null &&
      now - this.hipForwardBackNotProfileSince >= HIPFORWARDBACK_PROFILE_CONFIRM_MS;

    if (this.state === null) {
      // Armado: cadera centrada (respecto al tobillo) sostenida
      // HIPFORWARDBACK_CENTER_STABLE_MS seguidos, Y de perfil de verdad
      // (notProfileConfirmed) -- fija tu propio "centro" real como
      // baseline, para no exigir que la cadera esté perfectamente
      // centrada de fábrica.
      if (Math.abs(rawOffset) < HIPFORWARDBACK_CENTER_GATE_TOLERANCE_FACTOR && !notProfileConfirmed) {
        if (this.hipForwardBackStableSince === null) this.hipForwardBackStableSince = now;
        if (now - this.hipForwardBackStableSince >= HIPFORWARDBACK_CENTER_STABLE_MS) {
          this.state = "center";
          this.hipForwardBackStableSince = null;
          this.hipForwardBackTrackedSide = side; // fijado a partir de aquí, ver el comentario de la función
          this.hipForwardBackBaselineOffset = rawOffset;
          // Sentido "hacia delante" real: la punta del pie sobresale del
          // tobillo hacia el lado al que apunta el pie (mismo lado al
          // que se mira, de pie normal) -- se fija una vez, al armar,
          // para poder anunciar "adelante"/"atrás" con sentido anatómico
          // y no solo izquierda/derecha de pantalla. Solo cadera/tobillo/
          // pie, sin hombros ni nariz (v3). Heurística sin contrastar
          // todavía en cámara real -- si sale al revés, cifra a invertir.
          this.hipForwardBackFacingSign = Math.sign(foot.x - ankleX) || 1;
          this.hipForwardBackLastTransitionAt = now;
          this.announceStatus("¡Listo! Lleva la cadera hacia delante o hacia atrás, y vuelta al centro, sin mover los pies.", "ready_to_go");
        } else {
          this.setStatus("De perfil, cadera centrada… confirmando (no te muevas)");
        }
      } else {
        this.hipForwardBackStableSince = null;
        this.setStatus(
          notProfileConfirmed
            ? "Ponte de perfil (de lado) a la cámara, no de frente, para empezar."
            : "Ponte de perfil a la cámara, de pie, con la cadera centrada, para empezar."
        );
      }
      if (this.debugEl) {
        this.debugEl.textContent = `esperando centro… desviación=${rawOffset.toFixed(3)} umbral=±${HIPFORWARDBACK_CENTER_GATE_TOLERANCE_FACTOR.toFixed(3)} perfil=${hipWidthRatio.toFixed(3)}(máx ${HIPFORWARDBACK_PROFILE_MAX_HIP_WIDTH_FACTOR})${notProfileConfirmed ? " ✗" : ""} lado=${side}`;
      }
      return;
    }

    // Ya armado: parar de completar ningún vaivén HIPFORWARDBACK_STILL_MS
    // seguidos es la señal de que has terminado la serie (mismo patrón
    // que HIPLATERAL_STILL_MS).
    if (this.hipForwardBackLastTransitionAt !== null && now - this.hipForwardBackLastTransitionAt >= HIPFORWARDBACK_STILL_MS) {
      this.closeActiveSet();
      return;
    }

    // Te has girado hacia la cámara estando ya armado y en el centro
    // (todavía sin empezar un vaivén nuevo): se desarma del todo, en vez
    // de esperar a que completes un vaivén que ni siquiera has empezado
    // -- este es justo el caso reportado (te acercas caminando entre
    // repetición y repetición, o al terminar, y se vuelve a armar solo).
    if (this.state === "center" && notProfileConfirmed) {
      this.state = null;
      this.hipForwardBackStableSince = null;
      this.hipForwardBackDirection = null;
      this.hipForwardBackDirectionSince = null;
      this.hipForwardBackAnkleAnchorX = null;
      this.hipForwardBackFeetDrifted = false;
      this.hipForwardBackTurnedAway = false;
      this.setStatus("Te has girado hacia la cámara -- ponte de perfil de nuevo para seguir.");
      if (this.debugEl) this.debugEl.textContent = `desarmado: girado hacia la cámara (perfil=${hipWidthRatio.toFixed(3)})`;
      return;
    }

    const offset = (rawOffset - this.hipForwardBackBaselineOffset) * this.hipForwardBackFacingSign;

    if (this.state === "center") {
      // Esperando que la cadera se separe del centro hacia delante o
      // hacia atrás -- exige que la dirección se sostenga un rato
      // (HIPFORWARDBACK_DIRECTION_STABLE_MS) antes de confirmarse, para
      // no armar el vaivén con un pico de un frame suelto.
      const dirNow = offset > HIPFORWARDBACK_ENTER_FACTOR ? "front" : offset < -HIPFORWARDBACK_ENTER_FACTOR ? "back" : null;
      if (dirNow) {
        if (this.hipForwardBackDirection !== dirNow) {
          this.hipForwardBackDirection = dirNow;
          this.hipForwardBackDirectionSince = now;
        } else if (now - this.hipForwardBackDirectionSince >= HIPFORWARDBACK_DIRECTION_STABLE_MS) {
          this.state = dirNow;
          this.repStartTime = now; // la repetición empieza al confirmarse la dirección (momento real de llegada, no cuando vuelves al centro)
          this.hipForwardBackAnkleAnchorX = ankleX; // tobillo AHORA MISMO -- lo que se desplace desde aquí es lo que se vigila
          this.hipForwardBackFeetDrifted = false;
          this.hipForwardBackTurnedAway = false;
          this.hipForwardBackDirectionSince = null;
        }
      } else {
        this.hipForwardBackDirection = null;
        this.hipForwardBackDirectionSince = null;
      }
    } else {
      // state === "front" | "back": dirección confirmada, vigilando que
      // el tobillo no se desplace de sitio, y que sigas de perfil,
      // mientras esperas a volver al centro.
      const feetDrift = Math.abs(ankleX - this.hipForwardBackAnkleAnchorX) / legLength;
      if (feetDrift > HIPFORWARDBACK_FEET_DRIFT_TOLERANCE_FACTOR && !this.hipForwardBackFeetDrifted) {
        this.hipForwardBackFeetDrifted = true;
      }
      if (notProfileConfirmed && !this.hipForwardBackTurnedAway) {
        this.hipForwardBackTurnedAway = true;
      }
      if (this.hipForwardBackFeetDrifted || this.hipForwardBackTurnedAway) {
        // Solo texto (setStatus), sin voz -- es una corrección, no algo
        // que interrumpa a media repetición (la decisión de contarla o
        // no se toma al volver al centro, ver más abajo), mismo espíritu
        // que el desplazamiento de pies en balanceo lateral de cadera.
        this.setStatus(
          this.hipForwardBackTurnedAway
            ? "Te has girado hacia la cámara -- ponte de perfil (esta repetición no contará)."
            : "Mueves los pies -- déjalos plantados, balancea solo la cadera."
        );
      }
      if (Math.abs(offset) < HIPFORWARDBACK_EXIT_FACTOR) {
        // Vuelta al centro: se cierra el vaivén -- pero si los pies se
        // han desplazado más de la cuenta (hipForwardBackFeetDrifted) o
        // has dejado de estar de perfil (hipForwardBackTurnedAway, ver
        // arriba) esto no es un vaivén de verdad sino que te has
        // movido/girado hacia la cámara, así que no cuenta como
        // repetición: se reinicia a "sin armar" para obligar a
        // recolocarse y volver a confirmar la postura de partida (mismo
        // mecanismo que processHipLateral).
        this.hipForwardBackLastTransitionAt = now;
        if (this.hipForwardBackFeetDrifted || this.hipForwardBackTurnedAway) {
          const wasTurnedAway = this.hipForwardBackTurnedAway;
          this.state = null;
          this.hipForwardBackStableSince = null;
          this.hipForwardBackDirection = null;
          this.hipForwardBackDirectionSince = null;
          this.hipForwardBackAnkleAnchorX = null;
          this.hipForwardBackFeetDrifted = false;
          this.hipForwardBackTurnedAway = false;
          this.setStatus(
            wasTurnedAway
              ? "Te has girado hacia la cámara -- ponte de perfil de nuevo, con los pies quietos, para seguir."
              : "Te has movido de sitio -- ponte de perfil de nuevo, con los pies quietos, para seguir."
          );
        } else {
          this.countRep(
            (now - this.repStartTime) / 1000, now,
            this.state === "front" ? "Cadera adelante" : "Cadera atrás",
            HIPFORWARDBACK_MIN_REP_SECONDS
          );
          this.state = "center";
          this.hipForwardBackDirection = null;
          this.hipForwardBackDirectionSince = null;
          this.hipForwardBackAnkleAnchorX = null;
          this.hipForwardBackFeetDrifted = false;
          this.hipForwardBackTurnedAway = false;
        }
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `estado: ${this.state} | lado=${this.hipForwardBackTrackedSide} desviación=${offset.toFixed(3)} umbral_entrada=±${HIPFORWARDBACK_ENTER_FACTOR.toFixed(3)} umbral_salida=±${HIPFORWARDBACK_EXIT_FACTOR.toFixed(3)} | ` +
        `perfil=${hipWidthRatio.toFixed(3)}(máx ${HIPFORWARDBACK_PROFILE_MAX_HIP_WIDTH_FACTOR})${this.hipForwardBackTurnedAway ? " ✗" : ""} | ` +
        `desplazamiento pies: ${this.hipForwardBackAnkleAnchorX !== null ? (Math.abs(ankleX - this.hipForwardBackAnkleAnchorX) / legLength).toFixed(3) : "-"}${this.hipForwardBackFeetDrifted ? " ⚠" : ""} | ` +
        `quieto desde hace: ${this.hipForwardBackLastTransitionAt ? Math.round(now - this.hipForwardBackLastTransitionAt) + "ms" : "-"}`;
    }
  }

  /**
   * Tijeras de brazos — DE FRENTE a la cámara, calentamiento/estiramiento
   * dinámico: los brazos se extienden en cruz (a los lados) y se cruzan
   * por delante del pecho, volviendo después a extendidos; un vaivén
   * completo (extendidos -> cruzados -> extendidos) cuenta como una
   * repetición (ver el bloque ARMSCISSORS_* de más arriba para la
   * geometría y cada umbral — primera versión, pendiente de calibrar con
   * un test en cámara real, mismo patrón que el resto de la familia).
   *
   * this.state sigue el mismo patrón que giros de cuello: null (todavía
   * sin armar, esperando brazos extendidos estables) -> "center"
   * (armado, esperando que cruces los brazos) -> "crossed" (cruce
   * confirmado, esperando que vuelvas a extender para cerrar el vaivén).
   */
  processArmScissors(lm, now) {
    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];

    const vis = (
      (lShoulder.visibility ?? 1) + (rShoulder.visibility ?? 1) +
      (lWrist.visibility ?? 1) + (rWrist.visibility ?? 1)
    ) / 4;

    if (vis < ARMSCISSORS_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien los hombros y las muñecas. Ponte de frente a la cámara, con los dos brazos en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando hombros y muñecas de frente…";
      this.noteAbsence(now, ARMSCISSORS_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Hombros y muñecas a la vista. ¡Listo! Extiende los brazos en cruz y crúzalos por delante. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    if (!shoulderWidth) return;

    const reachL = Math.hypot(lWrist.x - lShoulder.x, lWrist.y - lShoulder.y) / shoulderWidth;
    const reachR = Math.hypot(rWrist.x - rShoulder.x, rWrist.y - rShoulder.y) / shoulderWidth;

    if (this.state === null) {
      // Armado: brazos extendidos sostenido ARMSCISSORS_CENTER_STABLE_MS
      // seguidos, mismo espíritu que el armado de círculos de brazos.
      const extended = reachL > ARMSCISSORS_MIN_REACH_FACTOR && reachR > ARMSCISSORS_MIN_REACH_FACTOR;
      if (extended) {
        if (this.armScissorsCenterStableSince === null) this.armScissorsCenterStableSince = now;
        if (now - this.armScissorsCenterStableSince >= ARMSCISSORS_CENTER_STABLE_MS) {
          this.state = "center";
          this.armScissorsCenterStableSince = null;
          this.armScissorsLastTransitionAt = now;
          this.announceStatus("¡Listo! Cruza los brazos por delante, y vuelve a extenderlos.", "ready_to_go");
        } else {
          this.setStatus("Brazos extendidos… confirmando (no te muevas)");
        }
      } else {
        this.armScissorsCenterStableSince = null;
        this.setStatus("Ponte de pie, de frente a la cámara, con los brazos extendidos en cruz, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent =
          `esperando brazos extendidos… reach_izq=${reachL.toFixed(2)} reach_der=${reachR.toFixed(2)} umbral=${ARMSCISSORS_MIN_REACH_FACTOR.toFixed(2)}`;
      }
      return;
    }

    // Ya armado: parar de completar ningún vaivén ARMSCISSORS_STILL_MS
    // seguidos es la señal de que has terminado la serie (mismo patrón
    // que NECKLATERAL_STILL_MS/ARMCIRCLES_STILL_MS).
    if (this.armScissorsLastTransitionAt !== null && now - this.armScissorsLastTransitionAt >= ARMSCISSORS_STILL_MS) {
      this.closeActiveSet();
      this.armScissorsCrossSince = null;
      return;
    }

    // Fracción, en horizontal, de lo que cada muñeca ha recorrido hacia
    // el hombro contrario (misma fórmula self-relativa que checkArmCrossStretch,
    // aspect-ratio-independiente y válida sea cual sea la orientación de
    // la imagen).
    const crossL = (lWrist.x - lShoulder.x) / (rShoulder.x - lShoulder.x);
    const crossR = (rWrist.x - rShoulder.x) / (lShoulder.x - rShoulder.x);

    if (this.state === "center") {
      // Esperando que los dos brazos crucen a la vez — sostenido
      // ARMSCISSORS_CROSS_STABLE_MS para no armar el vaivén con un pico
      // de un frame suelto (ruido de tracking).
      const crossedNow = crossL >= ARMSCISSORS_CROSS_MIN_FRACTION && crossR >= ARMSCISSORS_CROSS_MIN_FRACTION;
      if (crossedNow) {
        if (this.armScissorsCrossSince === null) this.armScissorsCrossSince = now;
        if (now - this.armScissorsCrossSince >= ARMSCISSORS_CROSS_STABLE_MS) {
          this.state = "crossed";
          this.repStartTime = now; // la repetición empieza al confirmarse el cruce (momento real de llegada, no cuando vuelves a extender)
          this.armScissorsCrossSince = null;
        }
      } else {
        this.armScissorsCrossSince = null;
      }
    } else {
      // state === "crossed": cruce confirmado, esperando que las dos
      // muñecas vuelvan a bajar de ARMSCISSORS_CROSS_EXIT_FRACTION (no se
      // mide con reach, ver el porqué junto a esa constante) para cerrar
      // el vaivén.
      const backToCenter = crossL < ARMSCISSORS_CROSS_EXIT_FRACTION && crossR < ARMSCISSORS_CROSS_EXIT_FRACTION;
      if (backToCenter) {
        this.armScissorsLastTransitionAt = now;
        this.countRep((now - this.repStartTime) / 1000, now, "Cruce de brazos", ARMSCISSORS_MIN_REP_SECONDS);
        this.state = "center";
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `estado: ${this.state} | cruce_izq=${crossL.toFixed(2)} cruce_der=${crossR.toFixed(2)} umbral_cruce=${ARMSCISSORS_CROSS_MIN_FRACTION.toFixed(2)} umbral_salida=${ARMSCISSORS_CROSS_EXIT_FRACTION.toFixed(2)} | reach_izq=${reachL.toFixed(2)} reach_der=${reachR.toFixed(2)} | ` +
        `quieto desde hace: ${this.armScissorsLastTransitionAt ? Math.round(now - this.armScissorsLastTransitionAt) + "ms" : "-"}`;
    }
  }

  /**
   * Rotación de piernas — DE FRENTE a la cámara, de pie en equilibrio
   * sobre una pierna: la otra rodilla se levanta y gira alrededor de su
   * propia cadera (ver el bloque LEGROTATION_* de más arriba para la
   * geometría y cada umbral — primera versión, pendiente de calibrar
   * con un test en cámara real, mismo patrón que el resto de la
   * familia).
   *
   * A diferencia del resto de la familia (armcrossstretch/armcircles/
   * necklateral/armscissors), aquí NO hay una postura de reposo que
   * exigir entre repeticiones: apoyar el pie en el suelo es justo el
   * momento normal de cierre de cada subida, no un fallo (pedido
   * explícitamente por el usuario). this.state solo distingue "todavía
   * sin armar" (null, esperando de pie estable con las dos piernas
   * apoyadas) de "armado y vigilando" ("active"); dentro de "active",
   * legRotationActiveSide (null mientras las dos piernas están
   * apoyadas, "left"/"right" mientras una está levantada) lleva la
   * cuenta de la subida en curso.
   */
  processLegRotation(lm, now) {
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const vis = (
      (lHip.visibility ?? 1) + (rHip.visibility ?? 1) +
      (lKnee.visibility ?? 1) + (rKnee.visibility ?? 1) +
      (lAnkle.visibility ?? 1) + (rAnkle.visibility ?? 1)
    ) / 6;

    if (vis < LEGROTATION_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien las caderas, las rodillas y los tobillos. Ponte de frente a la cámara, con caderas, rodillas y tobillos en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando caderas, rodillas y tobillos de frente…";
      this.legRotationVisibleSince = null; // corta la racha -- el aviso de "a la vista" exige LEGROTATION_VISIBLE_CONFIRM_MS SEGUIDOS por encima del umbral (ver más abajo)
      this.noteAbsence(now, LEGROTATION_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    // Reportado en vivo: el aviso de "a la vista" saltaba con un único
    // frame suelto que superaba el umbral (p.ej. durante el calentamiento
    // del modelo, justo después de "Cargando el modelo de seguimiento")
    // y el instante siguiente volvía a "sin detección" del todo -- ahora
    // hace falta mantenerse por encima del umbral LEGROTATION_VISIBLE_CONFIRM_MS
    // seguidos antes de anunciarlo, para no decir que se ve algo que en
    // realidad no se veía.
    if (this.legRotationVisibleSince === null) this.legRotationVisibleSince = now;
    if (!this.startupVoiceGiven && now - this.legRotationVisibleSince >= LEGROTATION_VISIBLE_CONFIRM_MS) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Caderas, rodillas y tobillos a la vista. ¡Listo! Levanta una rodilla y gírala. Para terminar una serie, párate quieto unos segundos, o sal del encuadre.",
        "startup_ready"
      );
    }

    // Fracción cadera->rodilla, en vertical, respecto a la longitud real
    // del muslo (distancia cadera-rodilla, que no cambia al girar la
    // pierna, es un segmento rígido) -- 1 = pierna colgando recta hacia
    // abajo (de pie normal), 0 = rodilla a la misma altura que la
    // cadera. Self-relativa (no depende de lo lejos que estés de la
    // cámara), mismo espíritu que crossFraction en checkArmCrossStretch.
    const thighL = Math.hypot(lKnee.x - lHip.x, lKnee.y - lHip.y) || 1;
    const thighR = Math.hypot(rKnee.x - rHip.x, rKnee.y - rHip.y) || 1;
    // Debounce de rearme (ver LEGROTATION_REARM_STABLE_MS) -- se calcula en
    // TODO frame, sin importar el estado, para que ya lleve acumulado el
    // tiempo suficiente en cuanto termina el armado inicial (que ya exige
    // LEGROTATION_STABLE_MS >= LEGROTATION_REARM_STABLE_MS de las dos piernas
    // apoyadas) y no bloquee la primera repetición de la serie.
    const bothGroundedNow = dropFractionL >= LEGROTATION_RAISE_EXIT_FRACTION && dropFractionR >= LEGROTATION_RAISE_EXIT_FRACTION;
    if (bothGroundedNow) {
      if (this.legRotationGroundedSince === null) this.legRotationGroundedSince = now;
    } else {
      this.legRotationGroundedSince = null;
    }

    const dropFractionL = (lKnee.y - lHip.y) / thighL;
    const dropFractionR = (rKnee.y - rHip.y) / thighR;

    if (this.state === null) {
      // Armado: de pie con las dos piernas apoyadas (ninguna levantada)
      // sostenido LEGROTATION_STABLE_MS seguidos, mismo espíritu que el
      // armado del resto de la familia.
      const bothGrounded = dropFractionL >= LEGROTATION_RAISE_EXIT_FRACTION && dropFractionR >= LEGROTATION_RAISE_EXIT_FRACTION;
      if (bothGrounded) {
        if (this.legRotationStableSince === null) this.legRotationStableSince = now;
        if (now - this.legRotationStableSince >= LEGROTATION_STABLE_MS) {
          this.state = "active";
          this.legRotationStableSince = null;
          this.legRotationActiveSide = null;
          this.legRotationPrevAngle = null;
          this.legRotationAccum = 0;
          this.legRotationRepStartTime = null;
          this.legRotationLastActivityAt = now;
          this.announceStatus("¡Listo! Levanta una rodilla y gírala.", "ready_to_go");
        } else {
          this.setStatus("De pie, con las dos piernas apoyadas… confirmando (no te muevas)");
        }
      } else {
        this.legRotationStableSince = null;
        this.setStatus("Ponte de pie, de frente a la cámara, con las dos piernas apoyadas, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent =
          `esperando de pie… bajada_izq=${dropFractionL.toFixed(2)} bajada_der=${dropFractionR.toFixed(2)} umbral=${LEGROTATION_RAISE_EXIT_FRACTION.toFixed(2)}`;
      }
      return;
    }

    // Ya armado: sin empezar ninguna subida nueva ni completar ninguna
    // repetición durante LEGROTATION_STILL_MS seguidos, se interpreta
    // que has terminado la serie (mismo patrón que ARMCIRCLES_STILL_MS/
    // NECKLATERAL_STILL_MS/ARMSCISSORS_STILL_MS, con el valor pedido).
    if (this.legRotationLastActivityAt !== null && now - this.legRotationLastActivityAt >= LEGROTATION_STILL_MS) {
      this.closeActiveSet();
      this.legRotationActiveSide = null;
      this.legRotationPrevAngle = null;
      this.legRotationAccum = 0;
      this.legRotationRepStartTime = null;
      this.legRotationGroundedSince = null;
      this.legRotationLastCountedSide = null; // serie nueva: vuelve a avisar del lado en la primera repetición que se cuente
      return;
    }

    if (this.legRotationActiveSide === null) {
      // Las dos piernas estaban apoyadas: ¿se ha levantado alguna? Si
      // las dos parecen levantadas a la vez (raro, normalmente ruido),
      // se elige la que esté más claramente levantada.
      const raisedL = dropFractionL < LEGROTATION_RAISE_ENTER_FRACTION;
      const raisedR = dropFractionR < LEGROTATION_RAISE_ENTER_FRACTION;
      const rearmSettled = this.legRotationGroundedSince !== null && (now - this.legRotationGroundedSince) >= LEGROTATION_REARM_STABLE_MS;
      if ((raisedL || raisedR) && rearmSettled) {
        const side = (raisedL && raisedR)
          ? (dropFractionL < dropFractionR ? "left" : "right")
          : (raisedL ? "left" : "right");
        this.legRotationActiveSide = side;
        const knee = side === "left" ? lKnee : rKnee;
        const hip = side === "left" ? lHip : rHip;
        this.legRotationPrevAngle = Math.atan2(-(knee.y - hip.y), knee.x - hip.x);
        this.legRotationAccum = 0;
        this.legRotationRepStartTime = now;
        this.legRotationLastActivityAt = now; // subida nueva empezada: cuenta como actividad, aunque el giro todavía no llegue a LEGROTATION_MIN_ROTATION_DEG
        // Punto medio de caderas AL EMPEZAR esta subida -- referencia
        // para detectar al cerrarla si el cuerpo entero se ha
        // desplazado (caminando) en vez de girar la pierna en el sitio
        // (ver LEGROTATION_MAX_HIP_DRIFT_FACTOR).
        this.legRotationExcursionHipMidX = (lHip.x + rHip.x) / 2;
        this.legRotationExcursionHipMidY = (lHip.y + rHip.y) / 2;
        this.legRotationExcursionHipWidth = Math.hypot(lHip.x - rHip.x, lHip.y - rHip.y) || 1;
        // Las dos piernas valen igual, en cualquier orden -- pedido
        // explícitamente: "que funcione para las dos piernas a la vez,
        // tanto un lado como otro, que sea capaz de diferenciarlo". Se
        // avisa por voz SOLO cuando el lado cambia respecto a la última
        // repetición contada (key distinta por lado en announceStatus,
        // así el cambio se dice casi al momento sin repetir "pierna
        // izquierda" en cada repetición seguida del mismo lado).
        if (this.legRotationLastCountedSide !== null && this.legRotationLastCountedSide !== side) {
          this.announceStatus(
            side === "left" ? "Pierna izquierda." : "Pierna derecha.",
            `legrotation_side_${side}`
          );
        }
      }
      if (this.debugEl) {
        this.debugEl.textContent =
          `esperando subida… bajada_izq=${dropFractionL.toFixed(2)} bajada_der=${dropFractionR.toFixed(2)} umbral_subida=${LEGROTATION_RAISE_ENTER_FRACTION.toFixed(2)} | rearme: ${rearmSettled ? "listo" : (this.legRotationGroundedSince ? Math.round(now - this.legRotationGroundedSince) + "/" + LEGROTATION_REARM_STABLE_MS + "ms" : "esperando apoyo real")} | quieto desde hace: ${this.legRotationLastActivityAt ? Math.round(now - this.legRotationLastActivityAt) + "ms" : "-"}`;
      }
      return;
    }

    // legRotationActiveSide !== null: una pierna está en el aire, se le
    // sigue el ángulo cadera->rodilla frame a frame.
    const side = this.legRotationActiveSide;
    const knee = side === "left" ? lKnee : rKnee;
    const hip = side === "left" ? lHip : rHip;
    const dropFraction = side === "left" ? dropFractionL : dropFractionR;

    if (dropFraction >= LEGROTATION_RAISE_EXIT_FRACTION) {
      // La pierna ha vuelto a apoyarse: aquí es donde se decide si lo
      // girado cuenta como repetición -- apoyar el pie NO es un fallo,
      // es el cierre normal de la subida (pedido explícitamente: "si el
      // usuario toca el suelo entre reps no pasa nada").
      const rotationDeg = Math.abs(this.legRotationAccum) * 180 / Math.PI;
      // Detección de desplazamiento (caminar hacia/desde la cámara, u
      // otro sitio, en vez de girar la pierna quieto donde estabas):
      // reportado en vivo -- "estaba yendo de camino a la silla y la ha
      // contado". Caminar también levanta la rodilla y el ángulo del
      // vector cadera->rodilla puede acumular de sobra según cambia la
      // perspectiva, así que la geometría del giro sola no basta para
      // descartarlo. Se compara el punto medio de las dos caderas de
      // AHORA con el que tenía al empezar la subida (ver el bloque de
      // arriba, en el arranque de la subida), normalizado por el ancho
      // de cadera medio de los dos instantes (para no depender de si te
      // has acercado o alejado de la cámara mientras tanto).
      const hipMidX = (lHip.x + rHip.x) / 2;
      const hipMidY = (lHip.y + rHip.y) / 2;
      const hipWidthNow = Math.hypot(lHip.x - rHip.x, lHip.y - rHip.y) || 1;
      const avgHipWidth = (this.legRotationExcursionHipWidth + hipWidthNow) / 2;
      const hipDrift = Math.hypot(hipMidX - this.legRotationExcursionHipMidX, hipMidY - this.legRotationExcursionHipMidY) / avgHipWidth;
      const walked = hipDrift > LEGROTATION_MAX_HIP_DRIFT_FACTOR;
      if (rotationDeg >= LEGROTATION_MIN_ROTATION_DEG && !walked) {
        const seconds = (now - this.legRotationRepStartTime) / 1000;
        // Etiqueta por lado (no genérica) -- se ve en pantalla vía
        // countRep/setStatus ("¡Rotación pierna derecha 2 de esta
        // serie!"), para diferenciar de un vistazo qué pierna se acaba
        // de contar, además del aviso de voz al cambiar de lado (ver
        // más arriba).
        const label = side === "left" ? "Rotación pierna izquierda" : "Rotación pierna derecha";
        if (this.countRep(seconds, now, label, LEGROTATION_MIN_REP_SECONDS)) {
          this.legRotationLastActivityAt = now;
          this.legRotationLastCountedSide = side;
          if (side === "left") this.legRotationLeftTotal += 1;
          else this.legRotationRightTotal += 1;
        }
      } else if (walked && rotationDeg >= LEGROTATION_MIN_ROTATION_DEG) {
        // Habría contado por el giro, pero el cuerpo se ha desplazado de
        // sitio -- se avisa (announceStatus ya limita la repetición de
        // este mismo aviso, ver STATUS_VOICE_REPEAT_GAP_MS) en vez de
        // fallar en silencio, para que quede claro por qué no ha contado.
        this.announceStatus("Eso no cuenta, te has desplazado -- quédate en el mismo sitio.", "legrotation_walked");
      }
      this.legRotationActiveSide = null;
      this.legRotationPrevAngle = null;
      this.legRotationAccum = 0;
      this.legRotationRepStartTime = null;
      if (this.debugEl) {
        this.debugEl.textContent = `pierna ${side === "left" ? "izquierda" : "derecha"} apoyada de nuevo — giro visto: ${rotationDeg.toFixed(0)}° (umbral ${LEGROTATION_MIN_ROTATION_DEG}°) | desplazamiento: ${hipDrift.toFixed(2)} (umbral ${LEGROTATION_MAX_HIP_DRIFT_FACTOR})${walked ? " ⚠ cuerpo desplazado, no cuenta" : ""}`;
      }
      return;
    }

    const angle = Math.atan2(-(knee.y - hip.y), knee.x - hip.x);
    if (this.legRotationPrevAngle === null) {
      this.legRotationPrevAngle = angle;
    } else {
      const delta = wrapAngleDelta(angle - this.legRotationPrevAngle);
      if (Math.abs(delta) <= LEGROTATION_MAX_SINGLE_LEG_DELTA) {
        this.legRotationAccum += delta;
        this.legRotationPrevAngle = angle;
        if (Math.abs(delta) >= LEGROTATION_MIN_ANGULAR_DELTA) {
          this.legRotationLastActivityAt = now;
        }
      }
      // Salto mayor que LEGROTATION_MAX_SINGLE_LEG_DELTA en un frame: se
      // descarta como fallo puntual de tracking (mismo motivo que
      // ARMCIRCLES_MAX_SINGLE_ARM_DELTA), sin actualizar el ángulo
      // previo, para no perder del todo el giro real de este frame.
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `pierna ${side === "left" ? "izquierda" : "derecha"} levantada | bajada=${dropFraction.toFixed(2)} | ` +
        `giro acumulado: ${Math.round(Math.abs(this.legRotationAccum) * 180 / Math.PI)}° (umbral ${LEGROTATION_MIN_ROTATION_DEG}°) | ` +
        `quieto desde hace: ${this.legRotationLastActivityAt ? Math.round(now - this.legRotationLastActivityAt) + "ms" : "-"}`;
    }
  }

  /**
   * 2026-09-19 (frontpos-v1): compuerta de posicion compartida por rodillas altas y talones al gluteo (de frente).
   * Devuelve {ok, reason, msg} si NO estas bien colocado (cuerpo entero visible y dentro del encuadre, erguido, de
   * frente, a buena distancia), o {ok:true, moving, settled, swayX, swayY, scale} si lo estas.
   * `moving` = te estas desplazando o acercando/alejando de la camara (ventana FRONTPOS_WINDOW_MS); `settled` = ya hay
   * datos limpios suficientes (FRONTPOS_SETTLED_MS) para fiarse de `moving`.
   * anklesMode: "both" = los dos pies deben verse dentro del encuadre; "one" = basta uno (el otro puede quedar
   * detras del gluteo en talones al gluteo).
   */
  frontPositionCheck(lm, now, anklesMode = "both") {
    const fail = (reason, msg) => ({ ok: false, moving: true, settled: false, reason, msg });
    const inFrame = (p) => p.x > FRONTPOS_EDGE_MARGIN && p.x < 1 - FRONTPOS_EDGE_MARGIN && p.y > FRONTPOS_EDGE_MARGIN && p.y < 1 - FRONTPOS_EDGE_MARGIN;
    const seen = (p) => !!p && (p.visibility ?? 1) >= FRONTPOS_MIN_VIS;
    const body = [L_SHOULDER, R_SHOULDER, L_HIP, R_HIP, L_KNEE, R_KNEE];
    for (const i of body) {
      if (!seen(lm[i])) return fail("cuerpo", "Colócate de frente a la cámara con el cuerpo entero a la vista, de los hombros a los pies.");
    }
    for (const i of body) {
      if (!inFrame(lm[i])) return fail("encuadre", "Te sales del encuadre. Colócate de frente con el cuerpo entero a la vista.");
    }
    const lA = lm[L_ANKLE], rA = lm[R_ANKLE];
    const okL = seen(lA) && inFrame(lA), okR = seen(rA) && inFrame(rA);
    if (anklesMode === "both" ? !(okL && okR) : !(okL || okR)) {
      return fail("pies", "No se te ven los pies. Colócate de frente con el cuerpo entero a la vista.");
    }
    const shMidY = (lm[L_SHOULDER].y + lm[R_SHOULDER].y) / 2;
    const hipMidX = (lm[L_HIP].x + lm[R_HIP].x) / 2;
    const hipMidY = (lm[L_HIP].y + lm[R_HIP].y) / 2;
    const kneeMidY = (lm[L_KNEE].y + lm[R_KNEE].y) / 2;
    const sw = Math.abs(lm[L_SHOULDER].x - lm[R_SHOULDER].x);
    if (sw < FRONTPOS_MIN_SHOULDER_W) return fail("lado", "Ponte de frente a la cámara, no de lado.");
    if (hipMidY - shMidY < FRONTPOS_MIN_TORSO_H) return fail("lejos", "Acércate un poco a la cámara.");
    if (kneeMidY - hipMidY < FRONTPOS_MIN_THIGH_H) return fail("postura", "Ponte de pie, erguido, de frente a la cámara.");
    const lowestAnkleY = Math.max(okL ? lA.y : -1, okR ? rA.y : -1);
    if (lowestAnkleY < kneeMidY + 0.05) return fail("postura", "Ponte de pie, erguido, de frente a la cámara.");

    // Ventana de movimiento: punto medio de caderas + ancho de hombros (escala) en los ultimos FRONTPOS_WINDOW_MS.
    if (!this.frontPosSamples) this.frontPosSamples = [];
    const S = this.frontPosSamples;
    S.push({ t: now, x: hipMidX, y: hipMidY, w: sw });
    while (S.length > 1 && now - S[0].t > FRONTPOS_WINDOW_MS) S.shift();
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity, minW = Infinity, maxW = -Infinity, sumW = 0;
    for (const s of S) {
      if (s.x < minX) minX = s.x; if (s.x > maxX) maxX = s.x;
      if (s.y < minY) minY = s.y; if (s.y > maxY) maxY = s.y;
      if (s.w < minW) minW = s.w; if (s.w > maxW) maxW = s.w;
      sumW += s.w;
    }
    const avgW = sumW / S.length || sw;
    const swayX = (maxX - minX) / avgW;
    const swayY = (maxY - minY) / avgW;
    const scale = maxW / (minW || 1) - 1;
    const settled = now - S[0].t >= FRONTPOS_SETTLED_MS;
    const moving = swayX > FRONTPOS_MAX_SWAY_X || swayY > FRONTPOS_MAX_SWAY_Y || scale > FRONTPOS_MAX_SCALE_CHANGE;
    return { ok: true, moving, settled, swayX, swayY, scale };
  }

  /**
   * Rodillas altas -- DE PERFIL a la cámara, de pie, marchando en el
   * sitio: se alterna levantar una rodilla y volver a apoyar el pie,
   * sin pausa entre piernas (ver el bloque KNEERAISE_* de más arriba
   * para el porqué de cada umbral y de los cuatro puntos pedidos por
   * el usuario).
   *
   * Misma geometría self-relativa que rotación de piernas (fracción
   * cadera->rodilla respecto al muslo), pero sin seguir ningún giro ni
   * comprobar desplazamiento de cadera -- aquí solo importa si la
   * rodilla se ha levantado lo suficiente y ha vuelto a bajar, nada
   * más. Menos cálculo por fotograma == menos riesgo de perder una
   * repetición real en un ritmo rápido.
   *
   * this.state solo distingue "todavía sin armar" (null, esperando de
   * pie estable con las dos piernas apoyadas) de "armado y vigilando"
   * ("active"); dentro de "active", kneeRaiseActiveSide (null mientras
   * las dos piernas están apoyadas, "left"/"right" mientras una está
   * levantada) lleva la cuenta de la subida en curso -- igual que
   * legRotationActiveSide, pero sin lado "pegajoso" entre
   * repeticiones: no se ha pedido diferenciar left/right aquí, solo
   * contar el total.
   *
   * Apoyar el pie entre repeticiones NO es un fallo -- es el cierre
   * normal de cada subida, igual que en rotación de piernas.
   */
  processKneeRaises(lm, now) {
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const vis = (
      (lHip.visibility ?? 1) + (rHip.visibility ?? 1) +
      (lKnee.visibility ?? 1) + (rKnee.visibility ?? 1) +
      (lAnkle.visibility ?? 1) + (rAnkle.visibility ?? 1)
    ) / 6;

    if (vis < KNEERAISE_MIN_VISIBILITY) {
      this.announceStatus("No se te ve bien la cadera, la rodilla y el tobillo. Ponte de frente a la cámara, con toda la pierna en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando cadera, rodilla y tobillo de frente…";
      this.kneeRaiseVisibleSince = null; // corta la racha -- el aviso de "a la vista" exige KNEERAISE_VISIBLE_CONFIRM_MS SEGUIDOS por encima del umbral (ver más abajo)
      this.noteAbsence(now, KNEERAISE_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    // 2026-09-19 (frontpos-v1): compuerta de posicion (ver frontPositionCheck): sin verte entero, erguido, de frente y
    // en tu sitio no se arma ni se cuenta nada; caminar hacia la camara/el boton ya no cuela repeticiones falsas.
    const pos = this.frontPositionCheck(lm, now, "both");
    if (!pos.ok) {
      if (this.frontPosBadSince == null) this.frontPosBadSince = now;
      const badFor = now - this.frontPosBadSince;
      if (badFor >= FRONTPOS_LOST_MS) {
        this.kneeRaiseVisibleSince = null;
        this.kneeRaiseStableSince = null;
        this.kneeRaiseActiveSide = null;
        this.kneeRaiseRepStartTime = null;
        this.announceStatus(pos.msg, "frontpos_" + pos.reason);
      }
      if (this.debugEl) this.debugEl.textContent = `fuera de posición (${pos.reason}) hace ${Math.round(badFor)}ms -- no cuenta nada hasta verte entero y de frente`;
      if (this.state !== null && this.kneeRaiseLastActivityAt !== null && now - this.kneeRaiseLastActivityAt >= KNEERAISE_STILL_MS) {
        this.closeActiveSet();
        this.kneeRaiseActiveSide = null;
        this.kneeRaiseRepStartTime = null;
      }
      return;
    }
    this.frontPosBadSince = null;
    const posDbg = ` | sway=${pos.swayX.toFixed(2)} y=${pos.swayY.toFixed(2)} esc=${pos.scale.toFixed(2)}${pos.settled ? "" : " (ajustando)"}`;

    // Fracción cadera->rodilla en vertical, respecto al muslo (segmento
    // rígido cadera-rodilla, no cambia al levantar la pierna) -- 1 =
    // pierna colgando recta (de pie normal), 0 = rodilla a la misma
    // altura que la cadera. Self-relativa (no depende de lo lejos que
    // estés de la cámara), mismo cálculo que dropFraction en
    // processLegRotation.
    // DE FRENTE (2026-09-19): en vez de medir cada muslo por separado se compara la altura de las dos piernas.
    // rawDiff > 0 = la izquierda (rodilla y tobillo, promediados) va mas alta que la derecha; < 0 al reves.
    // Normalizado por la longitud de pierna (cadera->tobillo, la mayor de las dos = la que esta apoyada).
    const legLen = Math.max(
      Math.hypot(lAnkle.x - lHip.x, lAnkle.y - lHip.y),
      Math.hypot(rAnkle.x - rHip.x, rAnkle.y - rHip.y)
    ) || 1;
    const rawDiff = ((rKnee.y - lKnee.y) + (rAnkle.y - lAnkle.y)) / 2 / legLen;
    // Desnivel de reposo (camara/suelo torcidos): se aprende al armar y se sigue afinando despacio mientras las piernas estan apoyadas.
    if (this.kneeRaiseBias == null) this.kneeRaiseBias = 0;
    if (this.state === null) {
      if (Math.abs(rawDiff) < KNEERAISE_ARM_MAX_DIFF) this.kneeRaiseBias += 0.2 * (rawDiff - this.kneeRaiseBias);
    } else if (Math.abs(rawDiff - this.kneeRaiseBias) < 0.04) {
      this.kneeRaiseBias += 0.02 * (rawDiff - this.kneeRaiseBias);
    }
    const diff = rawDiff - this.kneeRaiseBias;
    // Se reutiliza la escala 'bajada' de siempre (1 = apoyada, 0 = rodilla a la altura de la cadera) para no tocar la maquina de estados ni los umbrales.
    const dropFractionL = 1 - diff / KNEERAISE_LIFT_FULL;
    const dropFractionR = 1 + diff / KNEERAISE_LIFT_FULL;

    if (this.state === null) {
      // Armado: de pie con las dos piernas apoyadas (ninguna levantada)
      // sostenido KNEERAISE_STABLE_MS seguidos, para no contar media
      // repetición si entras en encuadre a media zancada.
      const bothGrounded = dropFractionL >= KNEERAISE_RAISE_EXIT_FRACTION && dropFractionR >= KNEERAISE_RAISE_EXIT_FRACTION;
      const steady = pos.settled && !pos.moving;
      if (bothGrounded && steady) {
        if (this.kneeRaiseStableSince === null) this.kneeRaiseStableSince = now;
        if (now - this.kneeRaiseStableSince >= KNEERAISE_STABLE_MS) {
          this.state = "active";
          this.kneeRaiseStableSince = null;
          this.kneeRaiseActiveSide = null;
          this.kneeRaiseRepStartTime = null;
          this.kneeRaiseRepTainted = false;
          this.kneeRaiseLastActivityAt = now;
          if (!this.startupVoiceGiven) {
            this.startupVoiceGiven = true;
            this.announceStatus(
              "Listo, te veo entero, puedes empezar.",
              "startup_ready"
            );
          } else {
            this.setStatus("Listo, te veo entero, puedes empezar.");
          }
        } else {
          this.setStatus("De pie, con las dos piernas apoyadas… confirmando (no te muevas)");
        }
      } else {
        this.kneeRaiseStableSince = null;
        this.setStatus(pos.moving ? "Quédate quieto en tu sitio un momento…" : "Ponte de pie, de frente a la cámara, con las dos piernas apoyadas, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent =
          `esperando de pie… bajada_izq=${dropFractionL.toFixed(2)} bajada_der=${dropFractionR.toFixed(2)} umbral=${KNEERAISE_RAISE_EXIT_FRACTION.toFixed(2)}` + posDbg;
      }
      return;
    }

    // Ya armado: sin empezar ninguna subida nueva ni completar ninguna
    // repetición durante KNEERAISE_STILL_MS seguidos, se interpreta que
    // has terminado la serie (mismo patrón que rotación de
    // piernas/jumping jacks, con un valor más corto porque esto es un
    // ritmo continuo rápido, no una pausa de equilibrio entre
    // repeticiones).
    if (this.kneeRaiseLastActivityAt !== null && now - this.kneeRaiseLastActivityAt >= KNEERAISE_STILL_MS) {
      this.closeActiveSet();
      this.kneeRaiseActiveSide = null;
      this.kneeRaiseRepStartTime = null;
      return;
    }

    if (this.kneeRaiseActiveSide === null) {
      // Las dos piernas estaban apoyadas: ¿se ha levantado alguna? Si
      // las dos parecen levantadas a la vez (raro, normalmente ruido en
      // la transición rápida entre piernas), se elige la que esté más
      // claramente levantada. Sin lado "pegajoso": cualquier pierna
      // vale para la siguiente subida, sin esperar a que sea la otra ni
      // avisar por voz de cuál es (no se ha pedido diferenciarlas aquí,
      // solo contar el total -- a diferencia de rotación de piernas).
      const raisedL = dropFractionL < KNEERAISE_RAISE_ENTER_FRACTION;
      const raisedR = dropFractionR < KNEERAISE_RAISE_ENTER_FRACTION;
      if (!pos.moving && (raisedL || raisedR)) {
        const side = (raisedL && raisedR)
          ? (dropFractionL < dropFractionR ? "left" : "right")
          : (raisedL ? "left" : "right");
        this.kneeRaiseActiveSide = side;
        this.kneeRaiseRepStartTime = now;
        this.kneeRaiseLastActivityAt = now; // subida nueva empezada: ya cuenta como actividad
        this.kneeRaiseRepTainted = false;
      }
      if (this.debugEl) {
        this.debugEl.textContent =
          `esperando subida… bajada_izq=${dropFractionL.toFixed(2)} bajada_der=${dropFractionR.toFixed(2)} umbral_subida=${KNEERAISE_RAISE_ENTER_FRACTION.toFixed(2)} | quieto desde hace: ${this.kneeRaiseLastActivityAt ? Math.round(now - this.kneeRaiseLastActivityAt) + "ms" : "-"}` + posDbg;
      }
      return;
    }

    // kneeRaiseActiveSide !== null: una pierna está en el aire -- solo
    // se vigila cuándo vuelve a bajar, sin ángulo ni rotación de por
    // medio (ver la nota de más arriba sobre por qué, a propósito, para
    // no arriesgarse a perder ningún fotograma real de la subida en un
    // ritmo rápido).
    const side = this.kneeRaiseActiveSide;
    const dropFraction = side === "left" ? dropFractionL : dropFractionR;

    // frontpos-v1: si te moviste de sitio (caminar, acercarte/alejarte) durante esta subida, o la rodilla lleva
    // demasiado arriba para ser marcha, la repeticion NO cuenta.
    if (pos.moving) this.kneeRaiseRepTainted = true;
    if ((now - this.kneeRaiseRepStartTime) / 1000 > KNEERAISE_MAX_UP_SECONDS) {
      this.kneeRaiseActiveSide = null;
      this.kneeRaiseRepStartTime = null;
      if (this.debugEl) this.debugEl.textContent = `rodilla arriba demasiado rato -- descartada (no es marcha)` + posDbg;
      return;
    }
    if (dropFraction >= KNEERAISE_REARM_EXIT_FRACTION) {
      const seconds = (now - this.kneeRaiseRepStartTime) / 1000;
      const tainted = this.kneeRaiseRepTainted;
      if (!tainted && this.countRep(seconds, now, "Rodilla arriba", KNEERAISE_MIN_REP_SECONDS)) {
        this.kneeRaiseLastActivityAt = now;
      }
      this.kneeRaiseActiveSide = null;
      this.kneeRaiseRepStartTime = null;
      if (this.debugEl) {
        this.debugEl.textContent = `pierna ${side === "left" ? "izquierda" : "derecha"} apoyada de nuevo${tainted ? " -- rechazada (te movías de sitio)" : ""} | bajada_izq=${dropFractionL.toFixed(2)} bajada_der=${dropFractionR.toFixed(2)}` + posDbg;
      }
      return;
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `pierna ${side === "left" ? "izquierda" : "derecha"} levantada | bajada=${dropFraction.toFixed(2)} (umbral_subida ${KNEERAISE_RAISE_ENTER_FRACTION.toFixed(2)}) | quieto desde hace: ${this.kneeRaiseLastActivityAt ? Math.round(now - this.kneeRaiseLastActivityAt) + "ms" : "-"}` + posDbg;
    }
  }

  /**
   * Talones al gluteo -- DE FRENTE a la camara (2026-09-19), de pie, marchando en el sitio: cada talon que sube hacia
   * el gluteo y vuelve a apoyarse cuenta UNA repeticion (antes: se vigilaba una sola pierna y cada ciclo sumaba DOS,
   * pensado para verse de perfil -- ya no hace falta, de frente se ven las dos piernas).
   *
   * Talon arriba = ese tobillo queda por encima del otro (fraccion de la longitud de pierna, con el desnivel de
   * reposo aprendido al armar) O el pie desaparece por detras (visibilidad del tobillo baja con la rodilla bien vista).
   * Solo una pierna 'arriba' a la vez; al volver a apoyarse se cuenta +1 y la siguiente subida puede ser de cualquier pierna.
   *
   * frontpos-v1 (2026-09-19): nada se arma ni se cuenta hasta verte entero (hombros a pies) dentro del encuadre, erguido,
   * de frente, y EN TU SITIO (ver frontPositionCheck) -- antes 'tobillo oculto' contaba aunque solo se viera la cara, y
   * caminar hacia la camara o hacia el boton colaba repeticiones falsas. Una repeticion se descarta si te moviste de sitio
   * mientras duraba, si el talon estuvo arriba demasiado rato (no es marcha), o si solo la sostuvo 'tobillo oculto' en
   * menos de HEELKICK_HIDDEN_ONLY_MIN_SECONDS.
   */
  processHeelKicks(lm, now) {
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const vis = (
      (lHip.visibility ?? 1) + (rHip.visibility ?? 1) +
      (lKnee.visibility ?? 1) + (rKnee.visibility ?? 1) +
      (lAnkle.visibility ?? 1) + (rAnkle.visibility ?? 1)
    ) / 6;

    if (vis < HEELKICK_MIN_VISIBILITY) {
      this.announceStatus("No se te ve bien la cadera, la rodilla y el tobillo. Ponte de frente a la camara, con toda la pierna en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando cadera, rodilla y tobillo de frente…";
      this.heelKickVisibleSince = null;
      this.heelKickSteadySince = null;
      this.noteAbsence(now, HEELKICK_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    // Compuerta de posicion (ver frontPositionCheck): sin ella no se arma ni se cuenta nada.
    const pos = this.frontPositionCheck(lm, now, "one");
    if (!pos.ok) {
      if (this.frontPosBadSince == null) this.frontPosBadSince = now;
      const badFor = now - this.frontPosBadSince;
      if (badFor >= FRONTPOS_LOST_MS) {
        this.heelKickVisibleSince = null;
        this.heelKickSteadySince = null;
        this.heelKickUp = false;
        this.heelKickRepStart = null;
        this.announceStatus(pos.msg, "frontpos_" + pos.reason);
      }
      if (this.debugEl) this.debugEl.textContent = `fuera de posición (${pos.reason}) hace ${Math.round(badFor)}ms -- no cuenta nada hasta verte entero y de frente`;
      if (this.state !== null && this.heelKickLastActivityAt !== null && now - this.heelKickLastActivityAt >= HEELKICK_STILL_MS) {
        this.closeActiveSet();
        this.heelKickUp = false;
        this.heelKickRepStart = null;
      }
      return;
    }
    this.frontPosBadSince = null;
    const posDbg = ` | sway=${pos.swayX.toFixed(2)} y=${pos.swayY.toFixed(2)} esc=${pos.scale.toFixed(2)}${pos.settled ? "" : " (ajustando)"}`;

    if (this.heelKickVisibleSince === null) this.heelKickVisibleSince = now;
    if (now - this.heelKickVisibleSince < HEELKICK_VISIBLE_CONFIRM_MS) {
      if (this.debugEl) this.debugEl.textContent = "confirmando seguimiento…" + posDbg;
      return;
    }

    // Subida de cada tobillo respecto al otro, en fracciones de la longitud de pierna.
    const legLenH = Math.max(
      Math.hypot(lAnkle.x - lHip.x, lAnkle.y - lHip.y),
      Math.hypot(rAnkle.x - rHip.x, rAnkle.y - rHip.y)
    ) || 1;
    if ((lAnkle.visibility ?? 1) >= HEELKICK_ANKLE_SEEN_VIS) this.heelKickAnkleSeenAtL = now;
    if ((rAnkle.visibility ?? 1) >= HEELKICK_ANKLE_SEEN_VIS) this.heelKickAnkleSeenAtR = now;
    const hiddenL = (lAnkle.visibility ?? 1) < HEELKICK_ANKLE_HIDDEN_VIS && (lKnee.visibility ?? 1) >= HEELKICK_ANKLE_SEEN_VIS && now - (this.heelKickAnkleSeenAtL ?? -1e9) < HEELKICK_HIDDEN_MAX_MS;
    const hiddenR = (rAnkle.visibility ?? 1) < HEELKICK_ANKLE_HIDDEN_VIS && (rKnee.visibility ?? 1) >= HEELKICK_ANKLE_SEEN_VIS && now - (this.heelKickAnkleSeenAtR ?? -1e9) < HEELKICK_HIDDEN_MAX_MS;
    // rawDiff > 0 = el tobillo izquierdo va mas alto que el derecho.
    const rawDiff = (rAnkle.y - lAnkle.y) / legLenH;
    if (this.heelKickBias == null) this.heelKickBias = 0;
    if (!hiddenL && !hiddenR) {
      if (this.state === null) {
        if (Math.abs(rawDiff) < HEELKICK_ARM_MAX_DIFF) this.heelKickBias += 0.2 * (rawDiff - this.heelKickBias);
      } else if (Math.abs(rawDiff - this.heelKickBias) < 0.04) {
        this.heelKickBias += 0.02 * (rawDiff - this.heelKickBias);
      }
    }
    const diff = rawDiff - this.heelKickBias;
    let rawLiftL = diff, rawLiftR = -diff;
    // Con un tobillo oculto su 'y' no es fiable: el otro pie se da por apoyado (no puede 'subir' por culpa de un dato basura).
    if (hiddenL) rawLiftR = Math.min(rawLiftR, 0);
    if (hiddenR) rawLiftL = Math.min(rawLiftL, 0);
    let liftL = hiddenL ? Math.max(rawLiftL, HEELKICK_LIFT_HIDDEN_VALUE) : rawLiftL;
    let liftR = hiddenR ? Math.max(rawLiftR, HEELKICK_LIFT_HIDDEN_VALUE) : rawLiftR;
    this.heelKickSmoothAngleL = this.heelKickSmoothAngleL == null ? liftL : this.heelKickSmoothAngleL + HEELKICK_ANGLE_SMOOTHING_ALPHA * (liftL - this.heelKickSmoothAngleL);
    this.heelKickSmoothAngleR = this.heelKickSmoothAngleR == null ? liftR : this.heelKickSmoothAngleR + HEELKICK_ANGLE_SMOOTHING_ALPHA * (liftR - this.heelKickSmoothAngleR);
    liftL = this.heelKickSmoothAngleL;
    liftR = this.heelKickSmoothAngleR;

    if (this.state === null) {
      // Armado: en tu sitio, entero y de frente, sostenido HEELKICK_ARM_STEADY_MS (ademas de la ventana FRONTPOS_SETTLED_MS).
      // No exige las dos piernas apoyadas (marchando rapido casi nunca ocurre), solo estar quieto de sitio.
      const steady = pos.settled && !pos.moving;
      if (steady) {
        if (this.heelKickSteadySince == null) this.heelKickSteadySince = now;
      } else {
        this.heelKickSteadySince = null;
      }
      if (steady && now - this.heelKickSteadySince >= HEELKICK_ARM_STEADY_MS) {
        this.state = "active";
        this.heelKickSteadySince = null;
        this.heelKickLastActivityAt = now;
        this.heelKickUp = false;
        this.heelKickActiveSide = null;
        this.heelKickRepStart = null;
        this.heelKickRepTainted = false;
        if (!this.startupVoiceGiven) {
          this.startupVoiceGiven = true;
          this.announceStatus(
            "Listo, te veo entero, puedes empezar.",
            "startup_ready"
          );
        } else {
          this.setStatus("Listo, te veo entero, puedes empezar.");
        }
      } else {
        this.setStatus(pos.moving ? "Quédate quieto en tu sitio un momento…" : "Te veo. Quieto un momento para empezar…");
        if (this.debugEl) this.debugEl.textContent = `esperando posición estable | ${steady ? "estable desde hace " + Math.round(now - this.heelKickSteadySince) + "ms" : "aún no estable"}${posDbg}`;
        return;
      }
    }

    // Serie en marcha: sin subida nueva ni repeticion completada durante HEELKICK_STILL_MS => has terminado.
    if (this.heelKickLastActivityAt !== null && now - this.heelKickLastActivityAt >= HEELKICK_STILL_MS) {
      this.closeActiveSet();
      this.heelKickUp = false;
      this.heelKickActiveSide = null;
      this.heelKickRepStart = null;
      return;
    }

    if (!this.heelKickUp) {
      const upL = liftL >= HEELKICK_LIFT_ENTER, upR = liftR >= HEELKICK_LIFT_ENTER;
      if (!pos.moving && (upL || upR)) {
        this.heelKickUp = true;
        this.heelKickActiveSide = (upL && upR) ? (liftL >= liftR ? "left" : "right") : (upL ? "left" : "right");
        this.heelKickRepStart = now;
        this.heelKickLastActivityAt = now;
        this.heelKickRepTainted = false;
        this.heelKickRepMaxRaw = 0;
      }
      if (this.debugEl) {
        this.debugEl.textContent =
          `esperando talón | izq=${liftL.toFixed(2)}${hiddenL ? " (oculto)" : ""} der=${liftR.toFixed(2)}${hiddenR ? " (oculto)" : ""} umbral_subida=${HEELKICK_LIFT_ENTER} | quieto desde hace: ${this.heelKickLastActivityAt ? Math.round(now - this.heelKickLastActivityAt) + "ms" : "-"}${posDbg}`;
      }
      return;
    }

    // Un talon esta arriba: ¿ha vuelto a apoyarse?
    const side = this.heelKickActiveSide || "left";
    const sideLabel = side === "left" ? "izquierda" : "derecha";
    const lift = side === "left" ? liftL : liftR;
    const rawLift = side === "left" ? rawLiftL : rawLiftR;
    const hidden = side === "left" ? hiddenL : hiddenR;
    if (pos.moving) this.heelKickRepTainted = true;
    if (rawLift > (this.heelKickRepMaxRaw || 0)) this.heelKickRepMaxRaw = rawLift;
    const upSeconds = (now - this.heelKickRepStart) / 1000;
    if (upSeconds > HEELKICK_MAX_UP_SECONDS) {
      // No es marcha (un paso, o estirar el cuadriceps): se descarta sin contar y sin cerrar la serie.
      this.heelKickUp = false;
      this.heelKickActiveSide = null;
      this.heelKickRepStart = null;
      if (this.debugEl) this.debugEl.textContent = `talón ${sideLabel} arriba ${upSeconds.toFixed(1)}s -- descartado (no es marcha)${posDbg}`;
      return;
    }
    if (lift > HEELKICK_LIFT_EXIT) {
      if (this.debugEl) {
        this.debugEl.textContent =
          `talón ${sideLabel} arriba subida=${lift.toFixed(2)} (bruta ${rawLift.toFixed(2)}, oculto=${hidden}) (umbral_bajada ${HEELKICK_LIFT_EXIT}) | quieto desde hace: ${this.heelKickLastActivityAt ? Math.round(now - this.heelKickLastActivityAt) + "ms" : "-"}${posDbg}`;
      }
      return;
    }

    const seconds = upSeconds;
    const tainted = this.heelKickRepTainted;
    const hiddenOnly = (this.heelKickRepMaxRaw || 0) < HEELKICK_LIFT_EXIT && seconds < HEELKICK_HIDDEN_ONLY_MIN_SECONDS;
    this.heelKickUp = false;
    this.heelKickActiveSide = null;
    this.heelKickRepStart = null;
    if (tainted || hiddenOnly) {
      if (this.debugEl) this.debugEl.textContent = `talón ${sideLabel} apoyado de nuevo -- rechazada (${tainted ? "te movías de sitio" : "solo 'tobillo oculto', demasiado corta"})${posDbg}`;
      return;
    }
    // +1 por cada talon que sube y baja (ya no se cuenta de 2 en 2).
    if (this.countRep(seconds, now, "Talón al glúteo", HEELKICK_MIN_REP_SECONDS)) {
      this.heelKickLastActivityAt = now;
    }
    if (this.debugEl) {
      this.debugEl.textContent = `talón ${sideLabel} apoyado de nuevo (+1)${posDbg}`;
    }
  }

  /**
   * Rotación de brazo sujetando el codo — ver el bloque
   * FOREARMROTATION_* de más arriba para la geometría y el porqué de
   * cada umbral (primera versión, pendiente de calibrar con un test en
   * cámara real, mismo patrón que el resto de la familia).
   *
   * Vale cualquiera de los dos brazos (uno gira, el otro agarra el
   * codo) y se puede cambiar de brazo sin cerrar la serie — this.state
   * solo distingue "todavía sin armar" (null, esperando un agarre
   * válido en cualquiera de los dos lados) de "armado y contando"
   * ("active"); dentro de "active", forearmRotationActiveSide
   * ("left"/"right") dice qué brazo gira ahora mismo.
   */
  processForearmRotation(lm, now) {
    const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
    const lE = lm[L_ELBOW], rE = lm[R_ELBOW];
    const lW = lm[L_WRIST], rW = lm[R_WRIST];

    const vis = (
      (lS.visibility ?? 1) + (rS.visibility ?? 1) +
      (lE.visibility ?? 1) + (rE.visibility ?? 1) +
      (lW.visibility ?? 1) + (rW.visibility ?? 1)
    ) / 6;

    if (vis < FOREARMROTATION_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien los hombros, los codos y las muñecas. Ponte de frente a la cámara, con los dos brazos en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando hombros, codos y muñecas de frente…";
      this.noteAbsence(now, FOREARMROTATION_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y);
    if (!shoulderWidth) return;

    // Agarre válido: la muñeca de UNA mano cerca del codo del brazo
    // CONTRARIO (self-relativo al ancho de hombros, no a la distancia a
    // la cámara — mismo cálculo que grabDist en checkArmCrossStretch).
    const grabLeftRotates = Math.hypot(rW.x - lE.x, rW.y - lE.y) / shoulderWidth <= FOREARMROTATION_GRAB_MAX_FACTOR;  // brazo izquierdo gira, mano derecha agarra su codo
    const grabRightRotates = Math.hypot(lW.x - rE.x, lW.y - rE.y) / shoulderWidth <= FOREARMROTATION_GRAB_MAX_FACTOR; // brazo derecho gira, mano izquierda agarra su codo

    if (this.state === null) {
      if (!this.startupVoiceGiven) {
        this.startupVoiceGiven = true;
        this.announceStatus(
          "Hombros, codos y muñecas a la vista. ¡Listo! Agarra el codo de un brazo con la otra mano y empieza a girar ese brazo. Vale cualquiera de los dos, y puedes cambiar de brazo cuando quieras. Para terminar una serie, párate quieto unos segundos, o sal del encuadre.",
          "startup_ready"
        );
      }
      const side = grabLeftRotates ? "left" : grabRightRotates ? "right" : null;
      if (side !== null) {
        if (this.forearmRotationStableSince === null) this.forearmRotationStableSince = now;
        if (now - this.forearmRotationStableSince >= FOREARMROTATION_STABLE_MS) {
          this.state = "active";
          this.forearmRotationStableSince = null;
          this.forearmRotationActiveSide = side;
          this.forearmRotationGrabBrokenSince = null;
          const elbow = side === "left" ? lE : rE;
          const wrist = side === "left" ? lW : rW;
          this.forearmRotationPrevAngle = Math.atan2(-(wrist.y - elbow.y), wrist.x - elbow.x);
          this.forearmRotationAccum = 0;
          this.forearmRotationLastActivityAt = now;
          this.forearmRotationRepStartTime = now;
          if (this.forearmRotationLastCountedSide !== null && this.forearmRotationLastCountedSide !== side) {
            this.announceStatus(side === "left" ? "Brazo izquierdo." : "Brazo derecho.", `forearmrotation_side_${side}`);
          }
          this.announceStatus("¡Listo! Empieza a girar el brazo.", "ready_to_go");
        } else {
          this.setStatus("Agarrando el codo… confirmando (no te muevas)");
        }
      } else {
        this.forearmRotationStableSince = null;
        this.setStatus("Agarra el codo de un brazo con la otra mano, cerca del cuerpo, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = `esperando agarre… agarre_izq_gira=${grabLeftRotates} agarre_der_gira=${grabRightRotates} umbral=${FOREARMROTATION_GRAB_MAX_FACTOR.toFixed(2)}`;
      }
      return;
    }

    // state === "active": sin ningún agarre válido (en ningún lado) ni
    // giro de verdad durante FOREARMROTATION_STILL_MS seguidos, se
    // interpreta que has terminado (mismo patrón que ARMSCISSORS_STILL_MS
    // /ARMCIRCLES_STILL_MS).
    if (this.forearmRotationLastActivityAt !== null && now - this.forearmRotationLastActivityAt >= FOREARMROTATION_STILL_MS) {
      this.closeActiveSet();
      this.forearmRotationActiveSide = null;
      this.forearmRotationPrevAngle = null;
      this.forearmRotationAccum = 0;
      this.forearmRotationRepStartTime = null;
      this.forearmRotationGrabBrokenSince = null;
      this.forearmRotationLastCountedSide = null; // serie nueva: vuelve a avisar del lado en la primera repetición que se cuente
      return;
    }

    const side = this.forearmRotationActiveSide;
    const grabbedNow = side === "left" ? grabLeftRotates : grabRightRotates;

    if (!grabbedNow) {
      // El agarre del brazo activo se ha soltado — no es un fallo
      // inmediato (un fotograma suelto de ruido de tracking no cuenta,
      // ver FOREARMROTATION_GRAB_BREAK_MS): mientras tanto se sigue
      // acumulando el giro con normalidad (se cae al bloque de más
      // abajo sin volver), por si vuelve a agarrar en el mismo instante.
      if (this.forearmRotationGrabBrokenSince === null) this.forearmRotationGrabBrokenSince = now;
      if (now - this.forearmRotationGrabBrokenSince >= FOREARMROTATION_GRAB_BREAK_MS) {
        // Agarre soltado de verdad: ¿ha cambiado al otro brazo? Se
        // permite cambiar de brazo sin cerrar la serie (pedido
        // explícitamente, "que sirva para las dos manos") — solo si el
        // OTRO lado agarra ya de verdad; si no, se espera sin perder el
        // progreso acumulado por si retoma el mismo brazo enseguida.
        const otherSide = side === "left" ? "right" : "left";
        const otherGrabbed = otherSide === "left" ? grabLeftRotates : grabRightRotates;
        if (otherGrabbed) {
          this.forearmRotationActiveSide = otherSide;
          this.forearmRotationGrabBrokenSince = null;
          const elbow = otherSide === "left" ? lE : rE;
          const wrist = otherSide === "left" ? lW : rW;
          this.forearmRotationPrevAngle = Math.atan2(-(wrist.y - elbow.y), wrist.x - elbow.x);
          this.forearmRotationAccum = 0;
          this.forearmRotationRepStartTime = now;
          this.forearmRotationLastActivityAt = now;
          if (this.forearmRotationLastCountedSide !== null && this.forearmRotationLastCountedSide !== otherSide) {
            this.announceStatus(otherSide === "left" ? "Brazo izquierdo." : "Brazo derecho.", `forearmrotation_side_${otherSide}`);
          }
        }
        // Ninguno de los dos agarra: se sigue esperando (sin cerrar la
        // serie todavía, ver FOREARMROTATION_STILL_MS más arriba) sin
        // tocar el ángulo acumulado, por si retoma el agarre enseguida.
        if (this.debugEl) {
          this.debugEl.textContent = `agarre soltado (brazo ${side === "left" ? "izquierdo" : "derecho"}) | quieto desde hace: ${Math.round(now - this.forearmRotationLastActivityAt)}ms`;
        }
        return;
      }
    } else {
      this.forearmRotationGrabBrokenSince = null;
    }

    const elbow = side === "left" ? lE : rE;
    const wrist = side === "left" ? lW : rW;
    const reach = Math.hypot(wrist.x - elbow.x, wrist.y - elbow.y);
    const reachOk = reach > FOREARMROTATION_MIN_REACH_FACTOR * shoulderWidth;

    const angle = Math.atan2(-(wrist.y - elbow.y), wrist.x - elbow.x);
    if (this.forearmRotationPrevAngle === null) {
      this.forearmRotationPrevAngle = angle;
    } else if (reachOk) {
      const delta = wrapAngleDelta(angle - this.forearmRotationPrevAngle);
      if (Math.abs(delta) <= FOREARMROTATION_MAX_SINGLE_FRAME_DELTA) {
        this.forearmRotationAccum += delta;
        this.forearmRotationPrevAngle = angle;
        if (Math.abs(delta) >= FOREARMROTATION_MIN_ANGULAR_DELTA) {
          this.forearmRotationLastActivityAt = now;
        }
      }
      // Salto mayor que FOREARMROTATION_MAX_SINGLE_FRAME_DELTA en un
      // fotograma: se descarta como fallo puntual de tracking (mismo
      // motivo que ARMCIRCLES_MAX_SINGLE_ARM_DELTA), sin actualizar el
      // ángulo previo, para no perder del todo el giro real de este
      // fotograma.
    } else {
      // Antebrazo demasiado pegado al codo para fiarse del ángulo (radio
      // casi cero): se actualiza igualmente el ángulo previo, para no
      // generar un salto falso cuando vuelva a extenderse.
      this.forearmRotationPrevAngle = angle;
    }

    if (Math.abs(this.forearmRotationAccum) >= 2 * Math.PI) {
      const seconds = (now - this.forearmRotationRepStartTime) / 1000;
      const label = side === "left" ? "Giro brazo izquierdo" : "Giro brazo derecho";
      if (this.countRep(seconds, now, label, FOREARMROTATION_MIN_REP_SECONDS)) {
        this.forearmRotationLastActivityAt = now;
        this.forearmRotationLastCountedSide = side;
      }
      this.forearmRotationAccum -= Math.sign(this.forearmRotationAccum) * 2 * Math.PI;
      this.forearmRotationRepStartTime = now;
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `brazo ${side === "left" ? "izquierdo" : "derecho"} girando | giro acumulado: ${Math.round(Math.abs(this.forearmRotationAccum) * 180 / Math.PI)}°/360° | ` +
        `quieto desde hace: ${this.forearmRotationLastActivityAt ? Math.round(now - this.forearmRotationLastActivityAt) + "ms" : "-"}`;
    }
  }

  /**
   * Rotación de muñecas con los dedos entrelazados — de pie o
   * sentada/o, de frente a la cámara: manos juntas, dedos entrelazados
   * como al rezar, delante del pecho/barbilla, girando juntas en
   * círculo (ver el bloque WRISTROTATION_* de más arriba para la
   * geometría, el porqué de cada umbral, y el razonamiento sobre por
   * qué esto ya distingue "dar vueltas" de "ir de un lado a otro" sin
   * lógica aparte — primera versión, pendiente de calibrar con un test
   * en cámara real, mismo patrón que el resto de la familia).
   *
   * Mismo mecanismo que processNeckCircles (ángulo acumulado del
   * vector punto-medio-de-hombros->punto medio de muñecas,
   * wrapAngleDelta por fotograma, una repetición cada ±2π, sin bloqueo
   * de sentido), con el añadido de que aquí SÍ hay una postura que
   * mantener durante todo el giro (manos juntas) — comprobada con la
   * misma histéresis de soltado que el agarre de processForearmRotation
   * (WRISTROTATION_TOGETHER_BREAK_MS), para no cortar la serie por un
   * solo fotograma de tracking ruidoso separando las manos un instante.
   */
  processWristRotation(lm, now) {
    const lS = lm[L_SHOULDER], rS = lm[R_SHOULDER];
    const lW = lm[L_WRIST], rW = lm[R_WRIST];

    const vis = (
      (lS.visibility ?? 1) + (rS.visibility ?? 1) +
      (lW.visibility ?? 1) + (rW.visibility ?? 1)
    ) / 4;

    if (vis < WRISTROTATION_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien los hombros y las muñecas. Ponte de frente a la cámara, con las manos en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando hombros y muñecas de frente…";
      this.noteAbsence(now, WRISTROTATION_OUT_OF_FRAME_MS);
      return;
    }
    this.outOfFrameSince = null;

    const shoulderMidX = (lS.x + rS.x) / 2;
    const shoulderMidY = (lS.y + rS.y) / 2;
    const shoulderWidth = Math.hypot(lS.x - rS.x, lS.y - rS.y);
    if (!shoulderWidth) return;

    const handMidX = (lW.x + rW.x) / 2;
    const handMidY = (lW.y + rW.y) / 2;
    const wristDist = Math.hypot(lW.x - rW.x, lW.y - rW.y);
    const together = wristDist <= WRISTROTATION_TOGETHER_MAX_FACTOR * shoulderWidth;

    if (this.state === null) {
      if (!this.startupVoiceGiven) {
        this.startupVoiceGiven = true;
        this.announceStatus(
          "Hombros y muñecas a la vista. ¡Listo! Junta las manos con los dedos entrelazados, delante del pecho, y empieza a girarlas en círculo. Para terminar una serie, párate quieto un par de segundos, o sal del encuadre.",
          "startup_ready"
        );
      }
      if (together) {
        if (this.wristRotationTogetherStableSince === null) this.wristRotationTogetherStableSince = now;
        if (now - this.wristRotationTogetherStableSince >= WRISTROTATION_TOGETHER_STABLE_MS) {
          this.state = "active";
          this.wristRotationTogetherStableSince = null;
          this.wristRotationBrokenSince = null;
          // v2: no hay ángulo fiable todavía -- el centro se siembra en la
          // posición actual de las manos (radio 0) y se deja que el EMA se
          // asiente en el centro real del círculo con las primeras vueltas
          // (ver el bloque WRISTROTATION_CENTER_EMA_ALPHA de más arriba).
          this.wristRotationCenterX = handMidX;
          this.wristRotationCenterY = handMidY;
          this.wristRotationPrevAngle = null;
          this.wristRotationAccum = 0;
          this.wristRotationLastActivityAt = now;
          this.wristRotationRepStartTime = now;
          this.announceStatus("¡Listo! Empieza a girar las muñecas.", "ready_to_go");
        } else {
          this.setStatus("Manos juntas… confirmando (no te muevas)");
        }
      } else {
        this.wristRotationTogetherStableSince = null;
        this.setStatus("Junta las manos con los dedos entrelazados, delante del pecho, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = `esperando manos juntas… distancia_muñecas=${wristDist.toFixed(3)} umbral=${(WRISTROTATION_TOGETHER_MAX_FACTOR * shoulderWidth).toFixed(3)}`;
      }
      return;
    }

    // state === "active": sin manos juntas de verdad ni giro de verdad
    // durante WRISTROTATION_STILL_MS seguidos, se interpreta que has
    // terminado (mismo patrón que ARMCIRCLES_STILL_MS/FOREARMROTATION_STILL_MS).
    if (this.wristRotationLastActivityAt !== null && now - this.wristRotationLastActivityAt >= WRISTROTATION_STILL_MS) {
      this.closeActiveSet();
      this.wristRotationPrevAngle = null;
      this.wristRotationAccum = 0;
      this.wristRotationRepStartTime = null;
      this.wristRotationBrokenSince = null;
      this.wristRotationCenterX = null;
      this.wristRotationCenterY = null;
      return;
    }

    if (!together) {
      // Manos separadas — no es un fallo inmediato (un fotograma suelto
      // de ruido de tracking no cuenta, ver WRISTROTATION_TOGETHER_BREAK_MS):
      // mientras tanto se sigue acumulando el giro con normalidad (se
      // cae al bloque de más abajo sin volver), por si vuelven a
      // juntarse en el mismo instante.
      if (this.wristRotationBrokenSince === null) this.wristRotationBrokenSince = now;
      if (now - this.wristRotationBrokenSince >= WRISTROTATION_TOGETHER_BREAK_MS) {
        // Manos separadas de verdad: se espera sin cerrar la serie
        // todavía (ver WRISTROTATION_STILL_MS más arriba) ni tocar el
        // ángulo acumulado, por si vuelves a juntarlas enseguida.
        if (this.debugEl) {
          this.debugEl.textContent = `manos separadas | quieto desde hace: ${Math.round(now - this.wristRotationLastActivityAt)}ms`;
        }
        return;
      }
    } else {
      this.wristRotationBrokenSince = null;
    }

    // v2: el centro del círculo NO es un punto anatómico fijo (a
    // diferencia de círculos de cuello/brazos) -- se re-estima cada
    // fotograma con una EMA lenta hacia la posición actual de las manos
    // (ver el porqué en el bloque WRISTROTATION_CENTER_EMA_ALPHA de más
    // arriba). Esto se hace SIEMPRE en estado activo (haya o no radio
    // fiable todavía), para que el centro converja de verdad.
    if (this.wristRotationCenterX === null) {
      this.wristRotationCenterX = handMidX;
      this.wristRotationCenterY = handMidY;
    } else {
      this.wristRotationCenterX += (handMidX - this.wristRotationCenterX) * WRISTROTATION_CENTER_EMA_ALPHA;
      this.wristRotationCenterY += (handMidY - this.wristRotationCenterY) * WRISTROTATION_CENTER_EMA_ALPHA;
    }

    const reach = Math.hypot(handMidX - this.wristRotationCenterX, handMidY - this.wristRotationCenterY);
    const reachOk = reach > WRISTROTATION_MIN_RADIUS_FACTOR * shoulderWidth;

    const angle = Math.atan2(-(handMidY - this.wristRotationCenterY), handMidX - this.wristRotationCenterX);
    let delta = 0;
    if (this.wristRotationPrevAngle === null) {
      this.wristRotationPrevAngle = angle;
    } else if (reachOk) {
      const d = wrapAngleDelta(angle - this.wristRotationPrevAngle);
      if (Math.abs(d) <= WRISTROTATION_MAX_SINGLE_FRAME_DELTA) {
        delta = d;
        this.wristRotationPrevAngle = angle;
      }
      // Salto mayor que WRISTROTATION_MAX_SINGLE_FRAME_DELTA en un
      // fotograma: se descarta como fallo puntual de tracking (mismo
      // motivo que ARMCIRCLES_MAX_SINGLE_ARM_DELTA), sin actualizar el
      // ángulo previo, para no perder del todo el giro real de este
      // fotograma.
    } else {
      // Radio (distancia mano-centro_estimado) todavía demasiado
      // pequeño para fiarse del ángulo -- normal justo al armar o justo
      // tras un cambio real de dirección, mientras el centro EMA se
      // asienta: se actualiza igualmente el ángulo previo, para no
      // generar un salto falso cuando el radio vuelva a ser fiable.
      this.wristRotationPrevAngle = angle;
    }

    if (Math.abs(delta) >= WRISTROTATION_MIN_ANGULAR_DELTA) {
      this.wristRotationLastActivityAt = now;
    }

    this.wristRotationAccum += delta;

    if (Math.abs(this.wristRotationAccum) >= 2 * Math.PI) {
      const seconds = (now - this.wristRotationRepStartTime) / 1000;
      if (this.countRep(seconds, now, "Círculo completo de muñecas", WRISTROTATION_MIN_REP_SECONDS)) {
        this.wristRotationLastActivityAt = now;
      }
      this.wristRotationAccum -= Math.sign(this.wristRotationAccum) * 2 * Math.PI;
      this.wristRotationRepStartTime = now;
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `manos juntas girando | acumulado: ${Math.round(Math.abs(this.wristRotationAccum) * 180 / Math.PI)}°/360° | delta: ${(delta * 180 / Math.PI).toFixed(1)}°/f | ` +
        `quieto desde hace: ${this.wristRotationLastActivityAt ? Math.round(now - this.wristRotationLastActivityAt) + "ms" : "-"}`;
    }
  }

  /**
   * Mensaje de "vuelve a colocarte" propio de cada ejercicio de este
   * grupo (sentadillas y los tres abdominales tumbado) — usado tanto al
   * esperar la primera vez como al reabrir tras cerrar una serie.
   */
  groundWaitingMessage() {
    switch (this.counterKey) {
      case "crunch":
        return "Túmbate boca arriba, con los hombros en el suelo, para empezar.";
      case "legraise":
        return "Túmbate boca arriba con las piernas estiradas para empezar.";
      case "lsit":
        return "Ponte de pie junto a las paralelas, de perfil, y luego súbete con los brazos estirados para empezar.";
      case "situp":
        return "Túmbate boca arriba del todo para empezar.";
      case "pushupfront":
        return "Túmbate boca abajo, mirando a la cámara, con los brazos estirados en el encuadre, para empezar.";
      case "squatfront":
        return "Ponte de pie, de frente a la cámara, con el cuerpo entero en el encuadre, para empezar.";
      case "squat":
        return "Ponte de pie, de perfil a la cámara, para empezar.";
      case "jumpingjack":
        return "Ponte de pie, de frente a la cámara, con los brazos pegados al cuerpo y los pies juntos, para empezar.";
      case "armcircles":
        return "Ponte de pie, de frente a la cámara, con los brazos extendidos, para empezar.";
      case "scissor":
        return "Túmbate boca arriba y levanta los pies a un palmo del suelo para empezar.";
      case "doublecrunch":
        return "Túmbate boca arriba, levanta el torso hasta una posición intermedia y mantenla, para empezar.";
      case "pushup":
        return "Túmbate boca abajo, de perfil a la cámara, con los brazos estirados, las manos a la altura del pecho y los codos pegados al cuerpo, para empezar.";
      case "dip":
        return "Ponte de perfil a la cámara, agárrate a las paralelas con los brazos estirados, para empezar.";
      case "dumbbellcurl":
        return "Ponte de perfil a la cámara, de pie, con la mancuerna colgando y el brazo estirado, para empezar.";
      case "necklateral":
        return "Ponte de frente a la cámara, mirando al frente, para empezar.";
      case "neckcircles":
        return "Ponte de frente a la cámara, mirando al frente, para empezar.";
      case "neckhalfturn":
        return "Ponte de frente a la cámara, mirando al frente, para empezar.";
      case "neckturn":
        return "Ponte de frente a la cámara, mirando al frente, para empezar.";
      case "hiplateral":
        return "Ponte de frente a la cámara, con los pies bien separados, para empezar.";
      case "armscissors":
        return "Ponte de pie, de frente a la cámara, con los brazos extendidos en cruz, para empezar.";
      case "legrotation":
        return "Ponte de pie, de frente a la cámara, con las dos piernas apoyadas, para empezar.";
      case "kneeraises":
        return "Ponte de pie, de frente a la cámara, con las dos piernas apoyadas, para empezar.";
      case "heelkicks":
        return "Ponte de pie, de frente a la cámara, con las dos piernas apoyadas, para empezar.";
      case "forearmrotation":
        return "Agarra el codo de un brazo con la otra mano, cerca del cuerpo, para empezar.";
      case "wristrotation":
        return "Junta las manos con los dedos entrelazados, delante del pecho, para empezar.";
      case "splitsquat":
        return "Ponte en posición: de perfil, una pierna delante y otra detrás.";
      default:
        return "Ponte en posición para empezar.";
    }
  }

  /**
   * Mensaje de "vuelve a colocarte" para plancha/plancha lateral —
   * equivalente a groundWaitingMessage() pero para CAMERA_POSTURE_COUNTERS,
   * que no comparten su lógica de cierre (ver esa constante).
   */
  postureWaitingMessage() {
    // Pedir la postura (plancha o plancha lateral) directamente, de
    // entrada, es pedir demasiado de golpe — primero hace falta un paso
    // más sencillo: tumbarte del todo (en cualquier postura, boca arriba
    // vale) para que la cámara confirme que te ve entera/o de perfil, y
    // solo entonces pedir la postura de verdad — ver postureGroundConfirmed
    // en processPosture.
    if (this.counterKey === "sideplank") {
      return this.postureGroundConfirmed
        ? "Ponte de lado, apoyada/o en el codo y en los pies, y levanta el cuerpo del suelo hasta quedar en línea recta."
        : "Túmbate boca arriba, con la cámara de lado, y encuadra el cuerpo entero.";
    }
    if (this.counterKey === "plank") {
      return this.postureGroundConfirmed
        ? "Ponte boca abajo, en posición de plancha, apoyada/o en los antebrazos, con el cuerpo en línea recta."
        : "Túmbate boca arriba en el suelo, de perfil a la cámara, con el cuerpo entero en el encuadre.";
    }
    // Silla en pared: SÍ tiene paso 1 (ver checkStanding/postureGroundConfirmed
    // en processPosture) — confirmar que te ve de pie, con la pierna
    // estirada, antes de pedir la postura doblada. Se añadió porque,
    // pidiendo la postura de la silla directamente, sentarte en una
    // silla de verdad (rodilla y cadera ya dobladas desde el principio,
    // sin haber hecho el ejercicio) pasaba el chequeo igualmente.
    if (this.counterKey === "wallsit") {
      return this.postureGroundConfirmed
        ? "Ponte de espaldas a un apoyo (pared, barra o poste), de perfil a la cámara y algo alejada/o (para que quepa la pierna entera), y dobla las rodillas deslizando la espalda por el apoyo hasta que los muslos queden paralelos al suelo."
        : "Ponte de pie del todo, de perfil a la cámara y algo alejada/o (para que quepa la pierna entera), con la pierna estirada, para confirmar que te veo antes de pedirte que te agaches.";
    }
    // Kneehold en barra: también tiene paso 1, uno más simple que
    // plancha/plancha lateral: solo confirmar que
    // te has agarrado a la barra (checkKneeHoldBarHanging), no hace falta
    // una postura intermedia rara como tumbarse. Antes se pedía la
    // postura completa (colgarte Y subir las rodillas) de golpe desde el
    // principio, con lo que mientras te acercabas a la barra el único
    // aviso que salía era el genérico de "no se te ve entera/o" — nada
    // que te dijera qué hacer. Ahora, mientras no se confirma el
    // agarre, el aviso es accionable de verdad.
    if (this.counterKey === "kneeholdbar") {
      return this.postureGroundConfirmed
        ? "Dobla las rodillas y súbelas hasta dejarlas más o menos a la altura de la cadera."
        : "Ve y agárrate a la barra, con los brazos estirados, de frente a la cámara y algo alejada/o (para que quepa el cuerpo entero).";
    }
    // Pino: sin paso 1 — la señal de "cuerpo invertido" ya es lo bastante
    // clara como para pedir la postura directamente (ver
    // checkHandstandPosture); a diferencia de silla en pared, aquí no hay
    // ninguna postura cotidiana (sentarse en una silla…) que pueda colarse
    // como un falso positivo.
    if (this.counterKey === "lsithold") {
      return "Ponte de pie junto a las paralelas, de perfil, un momento; luego súbete con los brazos estirados y sube las piernas rectas hasta la altura de la cadera (forma de L).";
    }
    if (this.counterKey === "handstand") {
      return "Sube a un pino (con o sin apoyo en la pared) hasta que la cadera quede por encima de los hombros y los brazos por debajo de la cadera, aguantando el peso cerca del suelo.";
    }
    // Estiramiento cruzado de brazo: paso 1 pide standby; paso 2, si ya
    // se sabe qué brazo se estiró la vez anterior (stretchLastSide),
    // sugiere el contrario — no es obligatorio (no se comprueba qué
    // brazo es), solo una ayuda para acordarse de alternar.
    if (this.counterKey === "armcrossstretch") {
      if (!this.postureGroundConfirmed) {
        return "Ponte de pie, relajada/o, con los brazos sueltos a los lados (posición standby), para confirmar que te veo.";
      }
      return this.stretchLastSide
        ? "Ahora el otro brazo: estíralo hacia el lado contrario, más o menos a la altura del hombro, y agárralo con el otro brazo por el codo, tirando de él hacia el pecho."
        : "Estira un brazo hacia el lado contrario, más o menos a la altura del hombro, y agárralo con el otro brazo por el codo, tirando de él hacia el pecho.";
    }
    // Estiramiento de tríceps por encima de la cabeza: mismo patrón que
    // el cruzado de brazo (paso 1 standby, paso 2 sugiere el lado
    // contrario al último aguantado).
    if (this.counterKey === "tricepsoverheadstretch") {
      if (!this.postureGroundConfirmed) {
        return "Ponte de pie, relajada/o, con los brazos sueltos a los lados (posición standby), para confirmar que te veo.";
      }
      return this.stretchLastSide
        ? "Ahora el otro brazo: dóblalo por el codo, llevando la mano por detrás de la nuca, y con el otro brazo agarra ese codo (no la mano) tirando de él hacia el centro."
        : "Dobla un brazo por el codo, llevando la mano por detrás de la nuca, y con el otro brazo agarra ese codo (no la mano) tirando de él hacia el centro.";
    }
    // Estiramiento de isquiotibiales sentado: mismo patrón (paso 1
    // standby, paso 2 sugiere la pierna contraria a la última
    // aguantada), pero paso 2 es sentado en el suelo, no de pie.
    if (this.counterKey === "seatedhamstringstretch") {
      if (!this.postureGroundConfirmed) {
        return "Ponte de pie, relajada/o, con los brazos sueltos a los lados (posición standby), para confirmar que te veo.";
      }
      return this.stretchLastSide
        ? "Ahora la otra pierna: siéntate de perfil en el suelo, estírala del todo y dobla la otra, e inclínate hacia delante para agarrarte el pie o el tobillo con la mano."
        : "Siéntate de perfil en el suelo, con una pierna estirada del todo y la otra doblada, e inclínate hacia delante para agarrarte el pie o el tobillo de la pierna estirada con la mano.";
    }
    if (this.counterKey === "standingquadstretch") {
      if (!this.postureGroundConfirmed) {
        return "Ponte de pie, relajada/o, con los brazos sueltos a los lados (posición standby), para confirmar que te veo.";
      }
      return this.stretchLastSide
        ? "Ahora la otra pierna: dobla la rodilla llevando el talón hacia el glúteo por detrás, y agárrate el pie con la mano por detrás de la espalda, de frente a la cámara."
        : "De pie y de frente a la cámara, dobla una rodilla llevando el talón hacia el glúteo por detrás, y agárrate el pie con la mano por detrás de la espalda, aguantando el equilibrio con la pierna contraria.";
    }
    return "Ponte en posición de plancha, apoyada/o en los antebrazos, con el cuerpo en línea recta, para empezar.";
  }

  /**
   * Se cierra la serie en curso por cualquiera de las formas de "quiero
   * terminar" de este grupo de ejercicios (ver GROUND_STYLE_COUNTERS):
   * ponerte de pie (abdominales tumbado, ON_GROUND_STABLE_MS), ponerte
   * de frente a la cámara (sentadillas, SQUAT_FRONTAL_STABLE_MS), salir
   * del encuadre (noteAbsence), o agitar la mano con el brazo levantado
   * (checkWaveGesture) — o, para cualquier ejercicio, pulsando el botón
   * de Recalibrar. Igual que soltarte de la barra en dominadas o de las
   * paralelas en fondos: si tenías alguna repetición en la serie en
   * curso, se da por terminada. Si no tenías ninguna repetición todavía,
   * simplemente se vuelve a esperar a que te coloques.
   */
  closeActiveSet() {
    this.state = null;
    this.groundStableSince = null;
    this.offGroundSince = null;
    this.outOfFrameSince = null;
    this.waveSamples = [];
    this.frontalStableSince = null;
    this.torsoBandStableSince = null;
    this.torsoOutOfBandSince = null;
    const waitingMessage = this.groundWaitingMessage();

    if (this.currentSetReps > 0) {
      const closedReps = this.currentSetReps;
      this.sets.push({ reps: this.currentSetReps, durations: [...this.currentSetDurations] });
      this.currentSetReps = 0;
      this.currentSetDurations = [];
      this.updateSetDisplay();
      if (this.repsEl) this.repsEl.textContent = "0";
      this.setClosedAt = performance.now();
      this.restBlockedVoiceGiven = false;
      // "Al fallo" (this.targetReps null -- PROG_FAILURE, ver el objetivo
      // del constructor): countRep() ya avisa de "objetivo cumplido"
      // cuando hay targetReps, pero eso no puede pasar aquí porque no hay
      // ningún número de reps que comprobar en marcha -- el único
      // objetivo real es el número de SERIES, y solo se sabe si se ha
      // cumplido cuando una serie se cierra de verdad (aquí), no antes.
      // Mismo aviso/sonido que el de countRep(), una sola vez por sesión
      // (this.targetAnnounced) y ANTES de announceSetComplete para que
      // se oiga primero "objetivo cumplido" y después "serie terminada".
      if (this.targetSets && !this.targetReps && !this.targetAnnounced &&
          this.sets.length >= this.targetSets) {
        this.targetAnnounced = true;
        if (this.voiceEnabled) speakOut("Has llegado al objetivo de las series de esta sesión. Puedes seguir si quieres, o pasar al siguiente ejercicio.", { flush: false });
        if (this.goalBannerEl) {
          this.goalBannerEl.hidden = false;
          this.goalBannerEl.textContent = "🎯 ¡Has llegado al objetivo de las series de esta sesión! Puedes seguir si quieres, o pasar al siguiente ejercicio.";
        }
        try {
          const ctx = new (window.AudioContext || window.webkitAudioContext)();
          [0, 0.14].forEach((t, i) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.frequency.value = i === 0 ? 880 : 1175;
            osc.connect(gain);
            gain.connect(ctx.destination);
            gain.gain.setValueAtTime(0.18, ctx.currentTime + t);
            osc.start(ctx.currentTime + t);
            osc.stop(ctx.currentTime + t + 0.13);
          });
        } catch (e) { /* si el navegador bloquea audio, no pasa nada */ }
      }
      // El aviso de descanso obligatorio SÍ tiene que oírse — por eso va
      // antes de silenciar la voz (restVoiceQuiet), no después.
      this.announceSetComplete(`Serie de ${closedReps}`, waitingMessage);
      this.restVoiceQuiet = true;
    } else {
      this.setStatus(waitingMessage);
    }
  }

  /**
   * No se te detecta (nada, o casi nada) este frame, en un ejercicio de
   * los que no tienen su propio cierre de serie (ver GROUND_STYLE_COUNTERS).
   * Si se mantiene un rato seguido (OUT_OF_FRAME_STABLE_MS, más largo
   * que un simple parpadeo de la detección), se interpreta como que te
   * has salido del encuadre a propósito y se cierra la serie en curso.
   *
   * thresholdMs es opcional (por defecto OUT_OF_FRAME_STABLE_MS) -- lo
   * usa jumping jacks con JUMPINGJACK_OUT_OF_FRAME_MS, más largo, porque
   * ahí la visibilidad baja también salta sola en pleno movimiento rápido
   * (motion blur), no solo al salirte de verdad del encuadre.
   */
  noteAbsence(now, thresholdMs = OUT_OF_FRAME_STABLE_MS) {
    if (this.outOfFrameSince === null) this.outOfFrameSince = now;
    if (now - this.outOfFrameSince >= thresholdMs) {
      this.closeActiveSet();
    }
  }

  /**
   * Guarda (si había algo que guardar) el tramo de plancha/plancha
   * lateral aguantado hasta ahora como una serie más — reps: 0, con la
   * duración aguantada en vez de un ciclo de repeticiones (mismo formato
   * que ya usa routine_save en el backend para ejercicios cronometrados).
   * Devuelve los segundos guardados (0 si no había ningún tramo abierto).
   * Solo mueve datos de sitio, no anuncia nada ni toca el texto en
   * pantalla — eso lo hace quien la llama (closeActivePostureSet, o
   * beginPrep si se pulsa Recalibrar a media plancha).
   */
  _flushPostureHold() {
    if (this.currentHoldSeconds < PLANK_MIN_HOLD_TO_COUNT_SECONDS) {
      this.currentHoldSeconds = 0;
      return 0;
    }
    const held = Math.round(this.currentHoldSeconds * 10) / 10;
    this.sets.push({ reps: 0, durations: [held] });
    this.totalHeldSeconds += held;
    this.currentHoldSeconds = 0;
    this.updateSetDisplay();
    return held;
  }

  /**
   * Postura de plancha/plancha lateral correcta este frame: suma el
   * tiempo transcurrido desde el último frame válido al tramo en curso,
   * actualiza el cronómetro en pantalla, y de vez en cuando suelta un
   * consejo rotativo (ver PLANK_TIPS/SIDEPLANK_TIPS).
   */
  notePostureOk(now) {
    this.postureInvalidSince = null;

    if (this.postureValidSince === null && this.setClosedAt !== null && now - this.setClosedAt < MIN_REST_MS && !NO_REST_COUNTERS.has(this.counterKey)) {
      // Mismo descanso obligatorio que countRep() (ver MIN_REST_MS): no
      // arranca el cronómetro de aguante hasta que pase, aunque vuelvas
      // a colocarte en postura antes de tiempo.
      this.announceRestBlocked(now);
      return;
    }

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      // El texto completo (técnica, cómo terminar la serie…) se sigue
      // viendo en pantalla, pero por VOZ se pidió lo mínimo — "listo, en
      // posición" y ya está, nada de explicar la técnica ni cómo cerrar
      // la serie hablado (eso ya sale por pantalla si hace falta).
      const startupTip =
        this.counterKey === "sideplank"
          ? "Postura correcta. ¡Listo! Aguanta la postura, con el abdomen apretado y la cadera alineada, sin caer ni subir. Para terminar una serie, rompe la postura, ponte de pie, sal del encuadre, o levanta un brazo y agita la mano."
          : this.counterKey === "wallsit"
          ? "Postura correcta. ¡Listo! Aguanta la postura, con la espalda bien pegada al apoyo y el peso repartido entre los dos pies. Para terminar una serie, ponte de pie del todo, sal del encuadre, o levanta un brazo y agita la mano."
          : this.counterKey === "kneeholdbar"
          ? "Postura correcta. ¡Listo! Aguanta con las rodillas arriba, sin balancearte. Para terminar una serie, suelta la barra o sal del encuadre."
          : this.counterKey === "handstand"
          ? "Postura correcta. ¡Listo! Aguanta el pino, con el abdomen apretado y el cuerpo recto. Para terminar una serie, baja del pino o sal del encuadre."
          : this.counterKey === "lsithold"
          ? "Postura correcta. ¡Listo! Aguanta las piernas rectas en L, con los brazos estirados y los hombros hacia abajo. Para terminar una serie, baja las piernas, bájate de las paralelas o sal del encuadre."
          : this.counterKey === "armcrossstretch" || this.counterKey === "tricepsoverheadstretch"
          ? "Postura correcta. ¡Listo! Aguanta el estiramiento, sin tirar de golpe. Para terminar, suelta el brazo (vuelve a standby) o sal del encuadre."
          : this.counterKey === "seatedhamstringstretch"
          ? "Postura correcta. ¡Listo! Aguanta el estiramiento, sin tirar de golpe. Para terminar, suelta el pie (vuelve a standby) o sal del encuadre."
          : this.counterKey === "standingquadstretch"
          ? "Postura correcta. ¡Listo! Aguanta el estiramiento, sin tirar de golpe. Para terminar, suelta el pie (vuelve a standby) o sal del encuadre."
          : "Postura correcta. ¡Listo! Aguanta la postura, apretando el abdomen y metiendo el culo hacia dentro, sin dejar caer la cadera. Para terminar una serie, rompe la postura, ponte de pie, sal del encuadre, o levanta un brazo y agita la mano.";
      this.announceStatus(startupTip, "startup_ready", "Listo. En posición.");
    }

    if (this.postureValidSince === null) {
      this.state = "holding";
      this.postureValidSince = now;
      this.lastPostureTickTs = now;
      // Postura válida de verdad: se acabó el descanso (si lo había),
      // vuelve la voz.
      this.restVoiceQuiet = false;
      // OJO: tipIndex NO se reinicia aquí. Antes se ponía a 0 cada vez que
      // arrancaba un tramo nuevo, así que los mismos consejos se repetían
      // en CADA serie de la sesión — justo la "tabarra" de la que se quejó
      // el usuario. Ahora tipIndex es por sesión (solo se reinicia en
      // beginPrep, al empezar de cero o recalibrar): cada consejo se dice
      // una vez y, una vez agotada la lista, no vuelve a sonar más en esta
      // sesión aunque hagas más series aguantando.
      this.lastTipAt = now; // no sueltes un consejo en el primer instante, deja asentar la postura
      // La cuenta atrás/adelante SÍ es por tramo (a diferencia de
      // tipIndex): cada vez que empiezas a aguantar de cero, vuelve a
      // contar desde el objetivo.
      this.postureCountdownLastSecond = null;
      this.postureGoalAnnouncedThisHold = false;
    }

    const delta = (now - this.lastPostureTickTs) / 1000;
    this.lastPostureTickTs = now;
    this.currentHoldSeconds += Math.max(0, delta);
    // El número en pantalla tiene que corresponder con lo que se dice en
    // voz alta (más abajo): si hay un targetSeconds, la voz hace cuenta
    // atrás hasta el objetivo y luego cuenta hacia adelante los segundos
    // de propina - antes aquí siempre se mostraba currentHoldSeconds
    // (contando hacia arriba desde 0), así que con objetivo la pantalla y
    // la voz iban cada una por su lado (voz "30, 29, 28…", pantalla
    // "0s, 1s, 2s…") - se reportó como confuso. Con targetSeconds, se
    // muestra lo mismo que se está a punto de anunciar; sin objetivo
    // (modo freestyle), se mantiene el conteo hacia arriba de siempre.
    const displaySeconds = this.targetSeconds
      ? (this.currentHoldSeconds < this.targetSeconds
          ? Math.max(0, this.targetSeconds - this.currentHoldSeconds)
          : this.currentHoldSeconds - this.targetSeconds)
      : this.currentHoldSeconds;
    if (this.repsEl) this.repsEl.textContent = formatHoldSeconds(displaySeconds);
    this.setStatus(`Aguantando… ${formatHoldSeconds(displaySeconds)}`);

    // Cuenta atrás/adelante hablada hacia el objetivo de este tramo
    // (targetSeconds, si el ejercicio viene de un plan o de un circuito
    // con meta fija). Antes se decía cada segundo entero, pero se
    // reportó que la voz "no da abasto" leyendo un número cada segundo
    // (se solapan/se cortan a medias - "veinti u", "ventid", "venti
    // tr..." en vez de veintiuno/veintidós/veintitrés) - ahora se dice
    // solo cada 5 segundos (múltiplos de 5), tiempo de sobra para que
    // termine de decir un número antes del siguiente: cuenta atrás
    // mientras falta para el objetivo, y en cuanto se alcanza, pasa a
    // contar hacia ADELANTE los segundos de propina cada 5s — así se
    // nota de oído que vas por encima del 100%, igual que seguir
    // oyendo "9", "10" al pasarte de un objetivo de 8 dominadas.
    // Sustituye a los consejos rotativos mientras dura (ver más abajo):
    // los dos se hablan por el mismo canal de voz y se pisarían entre sí.
    if (this.targetSeconds) {
      if (this.currentHoldSeconds < this.targetSeconds) {
        const remaining = Math.ceil(this.targetSeconds - this.currentHoldSeconds);
        if (remaining >= 1 && remaining % 5 === 0 && remaining !== this.postureCountdownLastSecond) {
          this.postureCountdownLastSecond = remaining;
          this.speak(numeroEnPalabras(remaining), { flush: true });
        }
      } else if (!this.postureGoalAnnouncedThisHold) {
        this.postureGoalAnnouncedThisHold = true;
        this.postureCountdownLastSecond = 0;
        this.speak(numeroEnPalabras(0), { flush: true });
        if (this.goalBannerEl) {
          this.goalBannerEl.hidden = false;
          this.goalBannerEl.textContent = `🎯 ¡Objetivo cumplido! (${formatHoldSeconds(this.targetSeconds)}) Sigue si quieres, o termina cuando acabes.`;
        }
        try {
          const ctx = new (window.AudioContext || window.webkitAudioContext)();
          [0, 0.14].forEach((t, i) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.frequency.value = i === 0 ? 880 : 1175;
            osc.connect(gain);
            gain.connect(ctx.destination);
            gain.gain.setValueAtTime(0.18, ctx.currentTime + t);
            osc.start(ctx.currentTime + t);
            osc.stop(ctx.currentTime + t + 0.13);
          });
        } catch (e) { /* si el navegador bloquea audio, no pasa nada */ }
      } else {
        const over = Math.floor(this.currentHoldSeconds - this.targetSeconds) + 1;
        if (over % 5 === 0 && over !== this.postureCountdownLastSecond) {
          this.postureCountdownLastSecond = over;
          this.speak(numeroEnPalabras(over), { flush: true });
        }
      }
      return; // sin consejos rotativos mezclándose por encima, ver comentario de arriba
    }

    // Modo freestyle SIN objetivo (targetSeconds vacío: ejercicio suelto,
    // sin plan ni meta guardada) — se reportó que aquí no se oía nada de
    // los segundos, a diferencia de un circuito (runTimerWithPosture en
    // session-runner.js/circuit.js, que siempre cuenta porque el work
    // del circuito SÍ hace de objetivo). Sin objetivo no hay hacia dónde
    // contar atrás, así que se cuenta hacia ADELANTE los aguantados,
    // igual que el tramo "over" de arriba una vez pasado el objetivo —
    // así cualquier aguante se puede seguir de oído, tenga meta o no.
    const heldWhole = Math.floor(this.currentHoldSeconds);
    if (heldWhole >= 1 && heldWhole % 5 === 0 && heldWhole !== this.postureCountdownLastSecond) {
      this.postureCountdownLastSecond = heldWhole;
      this.speak(numeroEnPalabras(heldWhole), { flush: true });
    }

    // Antes, aquí salían ADEMÁS consejos rotativos hablados cada
    // PLANK_TIP_INTERVAL_MS (PLANK_TIPS/SIDEPLANK_TIPS/…: "aprieta el
    // abdomen", "respira con normalidad"…) — se quitó la voz a
    // propósito: se pidió reducir la voz al mínimo indispensable, y
    // estos consejos, por útiles que sean, no son imprescindibles para
    // seguir el ejercicio (a diferencia del conteo o de "sal de
    // posición"). PLANK_TIPS y compañía se quedan definidas por si algún
    // día se quieren mostrar en pantalla en vez de hablarlos, pero
    // this.tipIndex/this.lastTipAt ya no se usan.
  }

  /**
   * Postura de plancha/plancha lateral rota este frame (o no se te
   * detecta en absoluto). No se cierra la serie a la primera — se da un
   * margen (PLANK_INVALID_STABLE_MS) por si es solo un parpadeo de la
   * cámara o un ajuste rápido, igual que ARMS_DOWN_STABLE_MS en
   * dominadas — y solo entonces se cierra el tramo aguantado (si había
   * alguno) como una serie terminada.
   *
   * Por voz SIEMPRE se dice el mensaje corto genérico ("Ponte en
   * posición" / "...de perfil" si el ejercicio se hace así, ver
   * PROFILE_POSTURE_COUNTERS) — sea cual sea el motivo concreto de por
   * qué se rompió (encuadre, cadera, rodillas…). Antes solo se acortaba
   * el aviso de "no te veo"; las correcciones de forma (p.ej. "baja un
   * poco más…") se seguían diciendo enteras, y se pidió quitarlas
   * también de la voz — el texto completo de CUALQUIER motivo se sigue
   * viendo en pantalla igual que siempre (setStatus, más abajo en
   * announceStatus), esto solo acorta lo que se OYE.
   */
  notePostureBroken(now, reason, rawOk = false) {
    // Estiramientos (STRETCH_HOLD_COUNTERS): a diferencia de plancha y
    // compañia, aqui "postura rota" incluye TODO el rato en el que
    // frame_ok todavia no se ha confirmado 300ms seguidos (ver
    // STRETCH_FLICKER_STABLE_MS) - asi que el reloj de "llevas
    // STRETCH_INVALID_STABLE_MS sin conseguirlo, vuelve a standby"
    // seguia corriendo IGUAL durante una racha de frames ya
    // geometricamente correctos (frame_ok=si) que solo le faltaban unos
    // pocos frames para confirmarse. Con un registro real (build v7, ver
    // notas 2026-09-05) se ve un intento (14.2s-17.3s) que pasa los
    // primeros ~2.3s totalmente quieto y luego, en los ultimos ~0.7s,
    // cruza el brazo del todo y llega a frame_ok=si tres frames
    // seguidos (~cruce=0.53 a 0.72, codo bajando de 156 a 145: la
    // MISMA pinta que el aguante que si cuenta mas adelante en el
    // mismo registro) - pero el aviso de "date por vencido" (que llevaba
    // sonando desde el frame 1 del intento, sin enterarse de que en los
    // ultimos frames SI se estaba consiguiendo) expiraba practicamente
    // en el mismo instante, cortando el intento antes de que le diera
    // tiempo a acumular STRETCH_FLICKER_STABLE_MS de frames buenos
    // seguidos para confirmarse. Por eso aqui, solo para estos
    // ejercicios, un frame CRUDO ya correcto (rawOk, aunque el debounce
    // todavia no lo haya confirmado) reinicia este reloj en vez de
    // dejarlo correr - asi el margen de STRETCH_INVALID_STABLE_MS es de
    // verdad "llevas tanto tiempo SIN NI SIQUIERA ACERCARTE", no "llevas
    // tanto tiempo sin que se confirme del todo", que es una barra much
    // mas alta y penaliza justo los intentos que van por buen camino.
    if (rawOk && STRETCH_HOLD_COUNTERS.has(this.counterKey)) {
      // OJO: a "now", no a null - si se pusiera a null, la comprobacion de
      // mas abajo (now - this.postureInvalidSince) lo tomaria como 0 y
      // "now - 0" siempre es >= invalidStableMs, cerrando la serie AHORA
      // MISMO en cuanto hay un frame bueno (justo lo contrario de lo que
      // se busca). Poniendolo a "now" reinicia la cuenta atras de
      // STRETCH_INVALID_STABLE_MS desde este instante, sin disparar el
      // cierre en este frame.
      this.postureInvalidSince = now;
    } else if (this.postureInvalidSince === null) {
      this.postureInvalidSince = now;
    }
    this.postureValidSince = null;
    this.lastPostureTickTs = null;
    if (reason) {
      let speechText = PROFILE_POSTURE_COUNTERS.has(this.counterKey)
        ? "Ponte en posición de perfil."
        : "Ponte en posición.";
      if (this.counterKey === "lsithold") {
        // El aviso hablado genérico ("ponte de perfil") despistaba: aquí se dice lo que falta de verdad.
        speechText = /^Agárrate/.test(reason) ? "Agárrate a las paralelas."
          : /^Estira los brazos/.test(reason) ? "Estira los brazos y sube un poco."
          : /^Ponte de pie/.test(reason) ? "Ponte de pie, quieto, un momento."
          : /^(Sube|Estira las rodillas)/.test(reason) ? "Sube las piernas rectas."
          : speechText;
      }
      this.announceStatus(reason, "posture_broken", speechText);
    }

    // Kneehold en barra usa un margen más largo que el resto (ver
    // KNEEHOLDBAR_INVALID_STABLE_MS, junto a POSTURE_FLICKER_STABLE_MS):
    // más propenso a rachas de mal seguimiento de más de un frame suelto
    // con la rodilla muy flexionada.
    const invalidStableMs =
      this.counterKey === "kneeholdbar" ? KNEEHOLDBAR_INVALID_STABLE_MS
      : this.counterKey === "lsithold" ? LSITHOLD_INVALID_STABLE_MS
      : this.counterKey === "handstand" ? HANDSTAND_INVALID_STABLE_MS
      : this.counterKey === "armcrossstretch" || this.counterKey === "tricepsoverheadstretch" || this.counterKey === "seatedhamstringstretch" || this.counterKey === "standingquadstretch" ? STRETCH_INVALID_STABLE_MS
      : PLANK_INVALID_STABLE_MS;
    if (now - this.postureInvalidSince >= invalidStableMs) {
      this.closeActivePostureSet();
    }
  }

  /**
   * Cierra el tramo de plancha/plancha lateral en curso — equivalente a
   * closeActiveSet() pero para CAMERA_POSTURE_COUNTERS (ver esa
   * constante para por qué no comparten la misma lógica).
   */
  closeActivePostureSet() {
    this.postureInvalidSince = null;
    this.postureValidSince = null;
    this.lastPostureTickTs = null;
    this.postureLastOk = null;
    this.postureCandidateOk = null;
    this.postureCandidateSince = null;
    this.sidePlankDownSide = null;
    // Estiramientos (ver STRETCH_HOLD_COUNTERS): a diferencia del resto
    // de CAMERA_POSTURE_COUNTERS (donde, una vez confirmado el paso 1,
    // se pueden encadenar series sin volver a confirmarlo), aquí SÍ hace
    // falta volver a standby entre lado y lado — pedido explícitamente:
    // standby, un lado, standby, el otro lado. Al resetear
    // postureGroundConfirmed, processPosture vuelve a pedir el paso 1
    // (checkStandbyPosture) antes de aceptar el siguiente estiramiento.
    if (STRETCH_HOLD_COUNTERS.has(this.counterKey)) {
      this.postureGroundConfirmed = false;
      this.postureGroundSince = null;
      this.startupVoiceGiven = false;
    }
    this.state = null;
    const held = this._flushPostureHold();
    if (this.repsEl) this.repsEl.textContent = formatHoldSeconds(0);
    // tipIndex NO se reinicia aquí — ver notePostureOk() para el porqué.
    this.lastTipAt = null;
    // La cuenta atrás/adelante SÍ es por tramo — se reinicia también al
    // arrancar uno nuevo (ver notePostureOk), pero limpiarla aquí además
    // evita arrastrar un "objetivo ya cumplido" al primer frame del
    // siguiente tramo por si acaso.
    this.postureCountdownLastSecond = null;
    this.postureGoalAnnouncedThisHold = false;

    if (held > 0) {
      this.setClosedAt = performance.now();
      this.restBlockedVoiceGiven = false;
      let waitingMessage;
      if (this.counterKey === "armcrossstretch" || this.counterKey === "tricepsoverheadstretch") {
        waitingMessage = "Vuelve a standby (de pie, brazos sueltos) y prueba con el otro brazo.";
      } else if (this.counterKey === "seatedhamstringstretch" || this.counterKey === "standingquadstretch") {
        waitingMessage = "Vuelve a standby (de pie, brazos sueltos) y prueba con la otra pierna.";
      } else {
        waitingMessage = this.postureWaitingMessage();
      }
      // "Al fallo" (this.targetSeconds null -- PROG_FAILURE): aquí no hay
      // segundos objetivo por tramo, así que notePostureOk() nunca avisa
      // de "objetivo cumplido" (ver ese método) -- lo único prescrito es
      // el número de SERIES, y solo se sabe si se ha cumplido al cerrar
      // una serie de verdad, aquí. Mismo mecanismo que closeActiveSet()
      // para el caso equivalente en reps.
      if (this.targetSets && !this.targetSeconds && !this.targetAnnounced &&
          this.sets.length >= this.targetSets) {
        this.targetAnnounced = true;
        if (this.voiceEnabled) speakOut("Has llegado al objetivo de las series de esta sesión. Puedes seguir si quieres, o pasar al siguiente ejercicio.", { flush: false });
        if (this.goalBannerEl) {
          this.goalBannerEl.hidden = false;
          this.goalBannerEl.textContent = "🎯 ¡Has llegado al objetivo de las series de esta sesión! Puedes seguir si quieres, o pasar al siguiente ejercicio.";
        }
        try {
          const ctx = new (window.AudioContext || window.webkitAudioContext)();
          [0, 0.14].forEach((t, i) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.frequency.value = i === 0 ? 880 : 1175;
            osc.connect(gain);
            gain.connect(ctx.destination);
            gain.gain.setValueAtTime(0.18, ctx.currentTime + t);
            osc.start(ctx.currentTime + t);
            osc.stop(ctx.currentTime + t + 0.13);
          });
        } catch (e) { /* si el navegador bloquea audio, no pasa nada */ }
      }
      this.announceSetComplete(`Serie de ${formatHoldSeconds(held)}`, waitingMessage);
      this.restVoiceQuiet = true;
    } else {
      this.setStatus(this.postureWaitingMessage());
    }
  }

  /**
   * Plancha / plancha lateral: usa checkPlankPosture()/checkSidePlankPosture()
   * (compartidas con circuit.js/session-runner.js, ver esas funciones más
   * arriba) para decidir, frame a frame, si la postura es correcta.
   */
  processPosture(lm, now) {
    // Paso 1, común a plancha y plancha lateral: tumbarte del todo, en
    // cualquier orientación, antes de pedir la postura en sí — ver la
    // nota junto a checkLyingFlat/postureGroundConfirmed. Antes la
    // plancha lateral no pasaba por esto (se asumía que su postura de
    // partida ya era fácil de detectar a la primera), pero en la
    // práctica pedía la postura completa de golpe nada más empezar la
    // serie — ahora sigue el mismo patrón de dos pasos que la plancha
    // normal.
    // Kneehold en barra reutiliza el mismo patrón de dos pasos, pero con
    // su propio paso 1 (checkKneeHoldBarHanging: confirmar el agarre) en
    // vez de tumbarte del todo — ver postureWaitingMessage/
    // checkKneeHoldBarHanging para el porqué.
    //
    // Silla en pared TAMBIÉN tiene su propio paso 1 (checkStanding:
    // confirmar que te ve DE PIE, con la pierna estirada) — ver el
    // comentario junto a checkStanding() para el porqué (sentarte en una
    // silla de verdad, sin más, no debe empezar a contar como si fuera
    // el ejercicio).
    // Estiramientos (ver STRETCH_HOLD_COUNTERS): paso 1 propio,
    // independiente del de plancha/silla en pared/kneehold en barra —
    // se comprueba la postura "standby" (checkStandbyPosture) antes de
    // pedir la postura del estiramiento en sí. Bloque aparte (en vez de
    // sumarlo a los ternarios de isKneeHoldStep1/isWallsitStep1 de
    // abajo) para no complicar más esos, y porque futuros estiramientos
    // podrán compartir este mismo paso 1 sin más que añadirse aquí.
    const isStretchStep1 = STRETCH_HOLD_COUNTERS.has(this.counterKey) && !this.postureGroundConfirmed;
    if (isStretchStep1) {
      const standby = checkStandbyPosture(lm);
      if (standby.visible && !this.startupVoiceGiven) {
        this.startupVoiceGiven = true;
        this.announceStatus("¡Listo! Ponte de pie, relajada/o, con los brazos sueltos a los lados, para empezar.", "startup_ready", "Ponte en posición standby.");
      }
      if (standby.ok) {
        if (this.postureGroundSince === null) this.postureGroundSince = now;
        if (now - this.postureGroundSince >= STRETCH_STANDBY_STABLE_MS) {
          this.postureGroundConfirmed = true;
          this.postureGroundSince = null;
          this.postureLastOk = null;
          this.postureCandidateOk = null;
          this.postureCandidateSince = null;
          const stretchReadyMessage =
            this.counterKey === "tricepsoverheadstretch"
              ? "¡Bien, en standby! Ahora dobla un brazo por el codo, llevando la mano por detrás de la nuca, y con el otro brazo agarra ese codo (no la mano) tirando de él hacia el centro."
              : this.counterKey === "seatedhamstringstretch"
              ? "¡Bien, en standby! Ahora siéntate de perfil en el suelo, con una pierna estirada del todo y la otra doblada, e inclínate hacia delante para agarrarte el pie o el tobillo de la pierna estirada con la mano."
              : this.counterKey === "standingquadstretch"
              ? "¡Bien, en standby! Ahora, de frente a la cámara, dobla una rodilla llevando el talón hacia el glúteo por detrás, y agárrate el pie con la mano por detrás de la espalda, aguantando el equilibrio con la pierna contraria."
              : "¡Bien, en standby! Ahora estira un brazo hacia el lado contrario, más o menos a la altura del hombro, y agárralo con el otro brazo por el codo, tirando de él hacia el pecho.";
          this.announceStatus(
            stretchReadyMessage,
            "stretch_ready",
            "Listo. Estira un brazo y agárralo con el otro."
          );
        } else {
          this.setStatus("Standby… confirmando (no te muevas)");
        }
      } else {
        this.postureGroundSince = null;
        this.setStatus(this.postureWaitingMessage());
      }
      if (this.debugEl) {
        this.debugEl.textContent = `paso 1 de 2: standby — ${standby.ok ? "sí, confirmando" : "todavía no"}`;
      }
      this.logScissor(`[estiramiento, paso 1] tipo=${this.counterKey} ok=${standby.ok ? "sí" : "no"}`);
      return;
    }

    const isKneeHoldStep1 = this.counterKey === "kneeholdbar" && !this.postureGroundConfirmed;
    const isWallsitStep1 = this.counterKey === "wallsit" && !this.postureGroundConfirmed;
    if (((this.counterKey === "plank" || this.counterKey === "sideplank") && !this.postureGroundConfirmed) || isKneeHoldStep1 || isWallsitStep1) {
      const flat = isKneeHoldStep1 ? checkKneeHoldBarHanging(lm) : isWallsitStep1 ? checkStanding(lm) : checkLyingFlat(lm);
      const stableMs = isKneeHoldStep1 ? HANG_STABLE_MS : isWallsitStep1 ? WALLSIT_STANDING_STABLE_MS : ON_GROUND_STABLE_MS;
      // Igual que dominadas (ver startupVoiceGiven junto a HANG_STABLE_MS,
      // más abajo): nada más verte aparecer en la cámara, aunque todavía
      // no estés colgada/o, un aviso por voz de qué hacer — antes esto se
      // quedaba en texto en pantalla nada más, sin decirse en voz alta.
      if (isKneeHoldStep1 && flat.visible && !this.startupVoiceGiven) {
        this.startupVoiceGiven = true;
        this.announceStatus("¡Listo! Cuélgate de la barra con los brazos estirados para empezar.", "startup_ready", "Cuélgate de la barra.");
      }
      if (isWallsitStep1 && flat.visible && !this.startupVoiceGiven) {
        this.startupVoiceGiven = true;
        this.announceStatus("¡Listo! Ponte de pie del todo, con la pierna estirada, para empezar.", "startup_ready", "Te quiero ver recto.");
      }
      if (flat.ok) {
        if (this.postureGroundSince === null) this.postureGroundSince = now;
        if (now - this.postureGroundSince >= stableMs) {
          this.postureGroundConfirmed = true;
          this.postureGroundSince = null;
          this.postureLastOk = null;
          this.postureCandidateOk = null;
          this.postureCandidateSince = null;
          const flipMessage = isKneeHoldStep1
            ? "¡Listo! Ya puedes subir las rodillas, doblándolas, hasta dejarlas más o menos a la altura de la cadera."
            : isWallsitStep1
            ? "¡Bien, te veo de pie! Ahora dobla las rodillas apoyando la espalda en un apoyo (pared, barra o poste) hasta que los muslos queden paralelos al suelo."
            : this.counterKey === "sideplank"
            ? "¡Bien, te veo! Ahora ponte de lado, apoya el codo justo debajo del hombro y los pies uno sobre otro, y levanta el cuerpo del suelo hasta quedar en línea recta, de los hombros a los tobillos."
            : "¡Bien, te veo! Ahora date la vuelta, boca abajo, y ponte en posición de plancha: apoyada/o en los antebrazos, con los codos justo debajo de los hombros y el cuerpo entero alzado del suelo, en línea recta.";
          // Por voz, la versión corta — el texto completo de arriba se ve
          // en pantalla (setStatus, dentro de announceStatus) para quien
          // lo necesite, pero se pidió que la voz diga lo mínimo.
          const flipSpeech = isKneeHoldStep1
            ? "Listo. Sube las rodillas."
            : isWallsitStep1
            ? "Listo. Ponte de perfil, en posición."
            : this.counterKey === "sideplank"
            ? "Listo. De lado, en posición."
            : "Listo. Boca abajo, en posición.";
          this.announceStatus(flipMessage, isKneeHoldStep1 ? "kneehold_ready" : isWallsitStep1 ? "wallsit_ready" : "plank_flip", flipSpeech);
        } else {
          this.setStatus(isKneeHoldStep1 ? "Colgada/o… confirmando (no te muevas)" : isWallsitStep1 ? "De pie… confirmando (no te muevas)" : "Tumbada/o… confirmando (no te muevas)");
        }
      } else {
        this.postureGroundSince = null;
        this.setStatus(this.postureWaitingMessage());
      }
      if (this.debugEl) {
        this.debugEl.textContent = isKneeHoldStep1
          ? `paso 1 de 2: agarrada/o a la barra — ${flat.ok ? "sí, confirmando" : "todavía no"}`
          : isWallsitStep1
          ? `paso 1 de 2: de pie — ${flat.ok ? "sí, confirmando" : "todavía no"} | ` +
            `rodilla: ${flat.kneeAngle ?? "-"}° (mínimo ${WALLSIT_STANDING_KNEE_MIN_DEG}) | ` +
            `cadera: ${flat.hipAngle ?? "-"}° (mínimo ${WALLSIT_STANDING_HIP_MIN_DEG})`
          : `paso 1 de 2: tumbarte del todo — ${flat.ok ? "sí, confirmando" : "todavía no"} | ` +
            `ángulo cadera: ${flat.lineAngle ?? "-"}° (mínimo ${LYING_FLAT_MIN_DEG}) | ` +
            `largo cuerpo/hombros: ${flat.bodyLengthFactor} (mínimo ${MIN_BODY_LENGTH_FACTOR})`;
      }
      this.logScissor(
        isKneeHoldStep1
          ? `[kneehold en barra, paso 1] ok=${flat.ok ? "sí" : "no"}`
          : isWallsitStep1
          ? `[silla en pared, paso 1] ok=${flat.ok ? "sí" : "no"} rodilla=${flat.kneeAngle ?? "-"} cadera=${flat.hipAngle ?? "-"}`
          : `[${this.counterKey === "sideplank" ? "plancha lateral" : "plancha"}, paso 1] ok=${flat.ok ? "sí" : "no"} motivo=${flat.reason ?? "-"} ` +
            `angulo=${flat.lineAngle ?? "-"} largo=${flat.bodyLengthFactor}`
      );
      return;
    }

    const check =
      this.counterKey === "sideplank"
        ? checkSidePlankPosture(lm, this.sidePlankDownSide)
        : this.counterKey === "wallsit"
        ? checkWallSitPosture(lm)
        : this.counterKey === "kneeholdbar"
        ? checkKneeHoldBarPosture(lm)
        : this.counterKey === "handstand"
        ? checkHandstandPosture(lm)
        : this.counterKey === "lsithold"
        ? this.lsitHoldChecker(lm)
        : this.counterKey === "armcrossstretch"
        ? checkArmCrossStretch(lm)
        : this.counterKey === "tricepsoverheadstretch"
        ? checkTricepsOverheadStretch(lm)
        : this.counterKey === "seatedhamstringstretch"
        ? checkSeatedHamstringStretch(lm)
        : this.counterKey === "standingquadstretch"
        ? checkStandingQuadStretch(lm)
        : checkPlankPosture(lm);
    if (this.counterKey === "sideplank" && check.downSide) this.sidePlankDownSide = check.downSide;
    if ((this.counterKey === "armcrossstretch" || this.counterKey === "tricepsoverheadstretch" || this.counterKey === "seatedhamstringstretch" || this.counterKey === "standingquadstretch") && check.side) this.stretchLastSide = check.side;
    // Antes este texto tenía los nombres de los campos de checkPlankPosture
    // escritos a mano — para checkSidePlankPosture (campos distintos:
    // hipLift, elbowDrop…) siempre salía en blanco ("-"). Ahora se vuelca
    // sin más lo que devuelva check.debug, sirva para el contador que sirva.
    if (this.debugEl && check.debug) {
      const parts = Object.entries(check.debug).map(([k, v]) => `${k}: ${v ?? "-"}`);
      this.debugEl.textContent = `${parts.join(" | ")} | ${check.ok ? "postura OK" : "postura incorrecta"}`;
    }

    // Un par de frames sueltos con una lectura ruidosa, justo en el
    // borde de un umbral, no deberían hacer parpadear el aviso entre
    // "aguantando" y "postura incorrecta" todo el rato — ver
    // POSTURE_FLICKER_STABLE_MS. Se actúa según el último estado ya
    // CONFIRMADO (this.postureLastOk), no según la lectura de este
    // frame suelto.
    if (this.postureLastOk === null) {
      this.postureLastOk = check.ok;
      this.postureCandidateOk = null;
      this.postureCandidateSince = null;
    } else if (check.ok === this.postureLastOk) {
      this.postureCandidateOk = null;
      this.postureCandidateSince = null;
    } else if (check.ok === this.postureCandidateOk) {
      const flickerStableMs =
        this.counterKey === "kneeholdbar" ? KNEEHOLDBAR_FLICKER_STABLE_MS
        : this.counterKey === "handstand" ? HANDSTAND_FLICKER_STABLE_MS
        : this.counterKey === "armcrossstretch" || this.counterKey === "tricepsoverheadstretch" || this.counterKey === "seatedhamstringstretch" || this.counterKey === "standingquadstretch" ? STRETCH_FLICKER_STABLE_MS
        : POSTURE_FLICKER_STABLE_MS;
      if (now - this.postureCandidateSince >= flickerStableMs) {
        this.postureLastOk = check.ok;
        this.postureCandidateOk = null;
        this.postureCandidateSince = null;
      }
    } else {
      this.postureCandidateOk = check.ok;
      this.postureCandidateSince = now;
    }

    const debugStr = check.debug
      ? Object.entries(check.debug).map(([k, v]) => `${k}=${v ?? "-"}`).join(" ")
      : "-";
    const postureLabel =
      this.counterKey === "sideplank"
        ? "plancha lateral"
        : this.counterKey === "wallsit"
        ? "silla en pared"
        : this.counterKey === "kneeholdbar"
        ? "kneehold en barra"
        : this.counterKey === "handstand"
        ? "pino"
        : this.counterKey === "lsithold"
        ? "L-sit en paralelas"
        : this.counterKey === "armcrossstretch"
        ? "estiramiento cruzado de brazo"
        : this.counterKey === "tricepsoverheadstretch"
        ? "estiramiento de tríceps por encima de la cabeza"
        : this.counterKey === "seatedhamstringstretch"
        ? "estiramiento de isquiotibiales sentado"
        : this.counterKey === "standingquadstretch"
        ? "estiramiento de cuádriceps de pie"
        : "plancha";
    this.logScissor(
      `[${postureLabel}, paso 2] frame_ok=${check.ok ? "sí" : "no"} confirmado=${this.postureLastOk ? "sí" : "no"} ` +
      `motivo=${check.reason ?? "-"} ${debugStr} ` +
      `aguantado=${this.currentHoldSeconds.toFixed(1)}s`
    );

    if (!this.postureLastOk) {
      this.notePostureBroken(now, check.reason, check.ok);
      return;
    }
    this.notePostureOk(now);
  }

  /**
   * Escala estable cadera-rodilla para checkWaveGesture en los ejercicios
   * "de perfil" (tumbado boca arriba: crunch, elevación de piernas,
   * abdominal completo, tijeras, doble crunch) -- ver el porqué en el
   * comentario de checkWaveGesture. Usa el lado que dé un valor mayor (más
   * fiable si un lado está algo ocluido de perfil), sin exigir visibilidad
   * mínima -- basta como referencia de tamaño aproximada, no hace falta la
   * precisión del tracking normal del ejercicio.
   */
  profileGestureScale(lm) {
    const lHip = lm[L_HIP], rHip = lm[R_HIP], lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const left = Math.hypot(lHip.x - lKnee.x, lHip.y - lKnee.y);
    const right = Math.hypot(rHip.x - rKnee.x, rHip.y - rKnee.y);
    return Math.max(left, right) || null;
  }

  /**
   * Gesto para terminar la serie sin ponerte de pie ni salir del
   * encuadre: levanta un brazo por encima del hombro y agita la mano a
   * los lados un par de veces. Guarda un historial corto (WAVE_WINDOW_MS)
   * de la posición horizontal de la muñeca levantada y cuenta los
   * cambios de sentido (izquierda-derecha-izquierda…) de amplitud
   * suficiente (WAVE_MIN_AMPLITUDE_FACTOR) para no confundir un temblor
   * de la mano con un vaivén de verdad. Devuelve true en cuanto detecta
   * suficientes cambios de sentido (WAVE_MIN_DIRECTION_CHANGES).
   */
  checkWaveGesture(lm, now, scale = null) {
    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];
    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    // Reportado en vivo (2026-09-18): en crunch, poner las manos detrás de
    // la nuca (postura normal del ejercicio) o simplemente rascarte la nariz
    // cerraba la serie sola. Causa real: DE PERFIL (crunch/elevación de
    // piernas/abdominales/tijeras/doble crunch, todos tumbados de lado a la
    // cámara) los dos hombros casi se solapan en la imagen -- shoulderWidth
    // se queda casi a cero, así que hasta el margen ya subido (ver
    // WAVE_RAISE_MARGIN_FACTOR/WAVE_MIN_AMPLITUDE_FACTOR) equivale a un
    // umbral minúsculo en la práctica. Quien llama desde un ejercicio de
    // perfil pasa aquí una referencia de escala que SÍ se mantiene con el
    // cuerpo de lado (p.ej. distancia cadera-rodilla) -- si no se pasa nada,
    // se sigue usando shoulderWidth tal cual (ejercicios de frente, donde ya
    // funcionaba bien).
    const refScale = (scale && scale > 0) ? scale : shoulderWidth;
    if (!refScale) return false;
    const shoulderMidY = (lShoulder.y + rShoulder.y) / 2;
    const raiseThreshold = shoulderMidY - WAVE_RAISE_MARGIN_FACTOR * refScale;

    const lRaised = (lWrist.visibility ?? 1) >= WAVE_MIN_VISIBILITY && lWrist.y < raiseThreshold;
    const rRaised = (rWrist.visibility ?? 1) >= WAVE_MIN_VISIBILITY && rWrist.y < raiseThreshold;

    if (!lRaised && !rRaised) {
      this.waveSamples = [];
      return false;
    }
    // Si se levantan los dos brazos a la vez, cualquiera de los dos vale
    // — no hace falta saber cuál, solo que se mueva de un lado a otro.
    const wrist = lRaised ? lWrist : rWrist;

    this.waveSamples.push({ t: now, x: wrist.x });
    this.waveSamples = this.waveSamples.filter((s) => now - s.t <= WAVE_WINDOW_MS);
    if (this.waveSamples.length < 3) return false;

    let dirChanges = 0;
    let lastDir = null;
    let extremeX = this.waveSamples[0].x;
    for (let i = 1; i < this.waveSamples.length; i++) {
      const dx = this.waveSamples[i].x - extremeX;
      if (Math.abs(dx) < WAVE_MIN_AMPLITUDE_FACTOR * refScale) continue;
      const dir = dx > 0 ? "right" : "left";
      if (lastDir !== null && dir !== lastDir) dirChanges++;
      lastDir = dir;
      extremeX = this.waveSamples[i].x;
    }

    if (dirChanges >= WAVE_MIN_DIRECTION_CHANGES) {
      this.waveSamples = [];
      return true;
    }
    return false;
  }

  /**
   * Crunch: cuenta cuánto sube el HOMBRO por encima de la CADERA (que
   * se queda fija en el suelo y sirve de referencia de escala junto al
   * muslo). Ver el bloque de comentarios junto a CRUNCH_UP_FACTOR más
   * arriba para por qué no se usa un ángulo aquí, a diferencia de
   * elevación de piernas o abdominal completo.
   *
   * Antes de armar el contador hace falta verte tumbado (inclinación
   * hombro-cadera) y QUIETO un rato (ON_GROUND_STABLE_MS) — si no,
   * ponerte en el suelo, o el rato en que te levantas de la silla para
   * ir a tumbarte, ya contaba como una repetición por sí solo (visto en
   * pruebas reales). Ese mismo gate, una vez armado, también sirve para
   * cerrar la serie en cuanto te vuelves a poner de pie, te sales del
   * encuadre un momento, o agitas la mano con el brazo levantado (ver
   * closeActiveSet, noteAbsence y checkWaveGesture) — así hay varias
   * formas de pasar a la siguiente serie sin tener que levantarte si no
   * quieres (o, como siempre, pulsando el botón de Recalibrar).
   */
  processCrunch(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now, this.profileGestureScale(lm))) {
      this.logScissor("[gesto de mano detectado] cerrando serie");
      this.closeActiveSet();
      return;
    }

    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];

    const leftVis = ((lShoulder.visibility ?? 1) + (lHip.visibility ?? 1) + (lKnee.visibility ?? 1)) / 3;
    const rightVis = ((rShoulder.visibility ?? 1) + (rHip.visibility ?? 1) + (rKnee.visibility ?? 1)) / 3;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    if (vis < CRUNCH_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien el hombro, la cadera y la rodilla. Ponte de perfil a la cámara, tumbado boca arriba.");
      if (this.debugEl) this.debugEl.textContent = "buscando hombro, cadera y rodilla de perfil…";
      this.groundStableSince = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    const shoulder = useLeft ? lShoulder : rShoulder;
    const hip = useLeft ? lHip : rHip;
    const knee = useLeft ? lKnee : rKnee;
    const thighLength = Math.hypot(hip.x - knee.x, hip.y - knee.y);
    if (!thighLength) return;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Te veo. ¡Listo! Túmbate boca arriba y empieza cuando quieras. Para terminar una serie, levántate, sal del encuadre, o levanta un brazo y agita la mano.",
        "startup_ready"
      );
    }

    // Cuánto sube el hombro por ENCIMA de la cadera (en pantalla, arriba
    // es "y" menor), en proporción al muslo.
    const lift = (hip.y - shoulder.y) / thighLength;
    const tilt = tiltFromHorizontal(shoulder, hip);
    if (tilt === null) return;
    const onGround = tilt <= ON_GROUND_MAX_TILT_DEG;

    const crunchStillResting = this.currentSetReps === 0 && this.setClosedAt !== null && now - this.setClosedAt < MIN_REST_MS;

    if (this.state === null) {
      // Para armar hace falta el umbral MÁS ESTRICTO (ver
      // ON_GROUND_ARM_MAX_TILT_DEG) — no basta con "no estás de pie", hace
      // falta estar de verdad tumbado, no solo agachado colocando la
      // cámara.
      const onGroundToArm = tilt <= ON_GROUND_ARM_MAX_TILT_DEG;
      if (onGroundToArm && crunchStillResting) {
        // Ya se ve que estás tumbado y listo, pero el descanso
        // obligatorio todavía no ha terminado -- no se arma el contador
        // ni se anuncia "¡Listo!" todavía (eso confundía: parecía que ya
        // podías seguir en pleno descanso). En su lugar, el mismo aviso
        // de cuenta atrás que ya usa countRep() para esto.
        this.groundStableSince = null;
        this.announceRestBlocked(now);
      } else if (onGroundToArm) {
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= ON_GROUND_STABLE_MS) {
          this.state = "down";
          this.offGroundSince = null;
          this.crunchArmedAt = now;
          this.announceStatus("¡Listo! Sube los hombros y vuelve a bajar.", "ready_to_go");
        } else {
          this.setStatus("Tumbado… confirmando (no te muevas)");
        }
      } else {
        this.groundStableSince = null;
        this.setStatus("Túmbate boca arriba, con los hombros en el suelo, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = `inclinación torso: ${tilt.toFixed(0)}° | tumbado: ${onGroundToArm ? "sí" : "no"} | esperando a armar${crunchStillResting ? " (en descanso)" : ""}`;
      }
      return;
    }

    if (this.state === "down") {
      if (!onGround) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= OFF_GROUND_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
      } else {
        this.offGroundSince = null;
      }
    }

    if (this.state === "down") {
      const armSettled = this.crunchArmedAt === null || (now - this.crunchArmedAt) >= CRUNCH_ARM_SETTLE_MS;
      if (lift >= CRUNCH_UP_FACTOR && armSettled) {
        this.state = "up";
        this.repStartTime = now;
      }
    } else if (lift <= CRUNCH_DOWN_FACTOR) {
      this.countRep((now - this.repStartTime) / 1000, now, "Crunch");
      this.state = "down";
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `hombro sobre cadera: ${lift.toFixed(2)} | estado: ${this.state ?? "esperando"} ` +
        `(tumbado ≤${CRUNCH_DOWN_FACTOR}, arriba ≥${CRUNCH_UP_FACTOR})`;
    }
  }

  /**
   * Elevación de piernas: ángulo de cadera (hombro-cadera-tobillo).
   * Mismo enfoque que la rodilla en sentadillas, aplicado a la cadera
   * como pivote — ver el comentario junto a LEG_RAISE_DOWN_ANGLE_DEG.
   *
   * Igual que en crunch, hace falta verte tumbado y quieto un rato para
   * armar el contador (ver processCrunch) — y aquí, ADEMÁS, con las
   * piernas estiradas del todo (ángulo de rodilla cadera-rodilla-tobillo
   * ≥ LEG_RAISE_STRAIGHT_MIN_DEG): con las rodillas dobladas no es
   * elevación de piernas. Antes de este cambio, levantarte de la silla
   * para ir a tumbarte ya colaba una repetición completa sin haber
   * llegado siquiera a tumbarte (visto en pruebas reales) — el gate de
   * "tumbado y quieto" lo evita.
   */
  processLegRaise(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now, this.profileGestureScale(lm))) {
      this.logScissor("[gesto de mano detectado] cerrando serie");
      this.closeActiveSet();
      return;
    }

    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    const leftVis = ((lShoulder.visibility ?? 1) + (lHip.visibility ?? 1) + (lKnee.visibility ?? 1) + (lAnkle.visibility ?? 1)) / 4;
    const rightVis = ((rShoulder.visibility ?? 1) + (rHip.visibility ?? 1) + (rKnee.visibility ?? 1) + (rAnkle.visibility ?? 1)) / 4;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    if (vis < LEG_RAISE_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien el hombro, la cadera, la rodilla y el tobillo. Ponte de perfil a la cámara, tumbado boca arriba, con las piernas enteras en el encuadre.");
      if (this.debugEl) this.debugEl.textContent = "buscando hombro, cadera, rodilla y tobillo de perfil…";
      this.legRaiseSide = null;
      this.groundStableSince = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Te veo. ¡Listo! Túmbate boca arriba con las piernas estiradas y empieza cuando quieras. Para terminar una serie, levántate, sal del encuadre, o levanta un brazo y agita la mano.",
        "startup_ready"
      );
    }

    const shoulder = useLeft ? lShoulder : rShoulder;
    const hip = useLeft ? lHip : rHip;
    const knee = useLeft ? lKnee : rKnee;
    const ankle = useLeft ? lAnkle : rAnkle;
    const hipAngle = angle(shoulder, hip, ankle);
    const kneeAngle = angle(hip, knee, ankle);
    const tilt = tiltFromHorizontal(shoulder, hip);
    if (hipAngle === null || kneeAngle === null || tilt === null) return;

    this.legRaiseSide = useLeft ? "left" : "right";
    const onGround = tilt <= ON_GROUND_MAX_TILT_DEG;
    const legsStraight = kneeAngle >= LEG_RAISE_STRAIGHT_MIN_DEG;

    if (this.state === null) {
      // Para armar hace falta el umbral MÁS ESTRICTO (ver
      // ON_GROUND_ARM_MAX_TILT_DEG) — no basta con "no estás de pie", hace
      // falta estar de verdad tumbado, no solo agachado colocando la
      // cámara.
      const onGroundToArm = tilt <= ON_GROUND_ARM_MAX_TILT_DEG;
      if (onGroundToArm && legsStraight) {
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= ON_GROUND_STABLE_MS) {
          this.state = "down";
          this.offGroundSince = null;
          this.announceStatus("¡Listo! Sube las piernas y vuelve a bajar.", "ready_to_go");
        } else {
          this.setStatus("Tumbado, piernas estiradas… confirmando (no te muevas)");
        }
      } else {
        this.groundStableSince = null;
        this.setStatus(
          !onGroundToArm ? "Túmbate boca arriba para empezar." : "Estira las piernas del todo, en el suelo, para empezar."
        );
      }
      if (this.debugEl) {
        this.debugEl.textContent =
          `tumbado: ${onGroundToArm ? "sí" : "no"} | piernas estiradas: ${legsStraight ? "sí" : "no"} (rodilla ${kneeAngle.toFixed(0)}°) | esperando a armar`;
      }
      return;
    }

    if (this.state === "down") {
      if (!onGround) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= LEG_RAISE_OFF_GROUND_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
      } else {
        this.offGroundSince = null;
      }
    }

    if (this.state === "down") {
      if (hipAngle <= LEG_RAISE_UP_ANGLE_DEG) {
        this.state = "up";
        this.repStartTime = now;
      }
    } else if (hipAngle >= LEG_RAISE_DOWN_ANGLE_DEG) {
      this.countRep((now - this.repStartTime) / 1000, now, "Elevación");
      this.state = "down";
      // Consejo de forma, no cada vez (sería cansino) sino con el mismo
      // margen que cualquier otro aviso hablado (STATUS_VOICE_REPEAT_GAP_MS) —
      // ver LEG_RAISE_TOUCHDOWN_ANGLE_DEG. No afecta al conteo: la
      // repetición ya se ha contado justo arriba, esto es solo un aviso.
      if (hipAngle >= LEG_RAISE_TOUCHDOWN_ANGLE_DEG) {
        this.announceStatus("Consejo: intenta no tocar el suelo con los talones al bajar, para justo antes.", "tip_legraise_touchdown");
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `ángulo cadera (${useLeft ? "izq" : "der"}): ${hipAngle.toFixed(0)}° | rodilla: ${kneeAngle.toFixed(0)}° | tilt: ${tilt.toFixed(0)}° (${onGround ? "en el suelo" : "fuera del suelo"}) | estado: ${this.state ?? "esperando"} ` +
        `(abajo ≥${LEG_RAISE_DOWN_ANGLE_DEG}°, arriba ≤${LEG_RAISE_UP_ANGLE_DEG}°)`;
    }
  }

  /**
   * L-sit en paralelas (repeticiones). Ver el bloque LSIT_* de más arriba. Se arma al SUBIRTE a las
   * paralelas (LSitTracker.mounted); una repetición = piernas rectas subidas a la L (rodilla y
   * tobillo a la altura de la cadera) y de vuelta abajo, colgando. La serie se cierra al bajarte de
   * las paralelas o al salir del encuadre (no hay gesto de mano: las manos están agarradas).
   */
  processLSit(lm, now) {
    const logTick = !this.lsitLastLogAt || now - this.lsitLastLogAt >= LSIT_LOG_INTERVAL_MS;
    if (logTick) this.lsitLastLogAt = now;
    const info = this.lsitTracker.update(lm, now);
    if (!info.visible) {
      if (logTick) {
        this.announceStatus(LSIT_NOT_VISIBLE_MSG);
        if (this.debugEl) this.debugEl.textContent = "buscando hombro, cadera, rodilla y tobillo de perfil…";
      }
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Te veo. Ponte de pie junto a las paralelas, de perfil, un momento; luego agárrate y levántate un par de centímetros con los brazos estirados. Cuando te detecte subido te aviso, y entonces sube y baja las piernas rectas hasta la altura de la cadera. Para terminar una serie, bájate de las paralelas o sal del encuadre.",
        "startup_ready",
        "Te veo. Ponte de pie junto a las paralelas."
      );
    }

    const dbg = Object.entries(info.debug).map(([k, v]) => `${k}=${v ?? "-"}`).join(" ");
    if (logTick) this.logScissor(`[lsit] estado=${this.state ?? "null"} ${dbg} L=${info.legsUp ? 1 : 0} abajo=${info.legsDown ? 1 : 0}`);

    if (this.state === null) {
      if (info.mounted) {
        this.state = "down";
        this.lsitDownConfirmed = false;
        this.lsitUpSince = null;
        this.lsitDownSince = null;
        this.logScissor("[lsit] ARMADO: montado en las paralelas");
        this.announceStatus("¡Listo! Sube las piernas rectas hasta la L y bájalas.", "ready_to_go", "Listo. Sube las piernas.");
      } else if (logTick) {
        this.setStatus(`${info.mountReason} (subida ${info.rise === null ? "-" : info.rise.toFixed(2)} de ${LSIT_MOUNT_RISE_FACTOR})`);
      }
      if (this.debugEl && logTick) this.debugEl.textContent = `esperando a que te subas | ${dbg}`;
      return;
    }

    if (!info.mounted) {
      this.logScissor("[lsit] desmonte detectado, cerrando serie");
      this.closeActiveSet();
      return;
    }

    if (this.state === "down") {
      if (info.legsDown) this.lsitDownConfirmed = true;
      if (this.lsitDownConfirmed && info.legsUp) {
        if (this.lsitUpSince === null) this.lsitUpSince = now;
        if (now - this.lsitUpSince >= LSIT_UP_STABLE_MS) {
          this.state = "up";
          this.repStartTime = now;
          this.logScissor(`[lsit] ARRIBA (L) tobillo=${info.ankleRel.toFixed(2)} rodilla=${info.kneeRel.toFixed(2)} ang_rodilla=${info.kneeAngle.toFixed(0)}`);
          this.lsitUpSince = null;
          this.lsitDownSince = null;
        }
      } else {
        this.lsitUpSince = null;
        if (!this.lsitDownConfirmed && logTick) this.setStatus("Deja las piernas colgando del todo para empezar.");
      }
    } else if (this.state === "up") {
      if (info.legsDown) {
        if (this.lsitDownSince === null) this.lsitDownSince = now;
        if (now - this.lsitDownSince >= LSIT_DOWN_STABLE_MS) {
          const repSeconds = (now - this.repStartTime) / 1000;
          const counted = this.countRep(repSeconds, now, "L-sit", LSIT_MIN_REP_SECONDS);
          this.logScissor(`[lsit] ABAJO: rep ${counted ? "CONTADA" : "descartada"} (${repSeconds.toFixed(2)}s en L, mín ${LSIT_MIN_REP_SECONDS}s)`);
          this.state = "down";
          this.lsitDownConfirmed = true;
          this.lsitDownSince = null;
        }
      } else {
        this.lsitDownSince = null;
      }
    }

    if (this.debugEl && logTick) {
      this.debugEl.textContent =
        `${dbg} | estado: ${this.state} ` +
        `(L: tobillo ≤${LSIT_UP_ANKLE_REL}, rodilla ≤${LSIT_UP_KNEE_REL}; abajo: tobillo ≥${LSIT_DOWN_ANKLE_REL}, rodilla ≥${LSIT_DOWN_KNEE_REL})`;
    }
  }

  /**
   * Abdominal completo (situp): a diferencia del crunch (que solo
   * levanta cabeza y hombros), aquí sube el torso ENTERO hasta sentarte.
   * Se mide con la misma inclinación hombro-cadera respecto a la
   * horizontal que el gate de "tumbado" (ver tiltFromHorizontal) — de
   * tumbado (≤SITUP_DOWN_TILT_DEG) a sentado (≥SITUP_UP_TILT_DEG) — y a
   * propósito NO con un ángulo de cadera-rodilla como en la versión
   * anterior: ese dependía de dónde estuviera la rodilla, así que
   * alguien tumbado con las rodillas dobladas (lo normal, con los pies
   * apoyados) nunca llegaba al ángulo de "tumbado" y el contador iba a
   * su aire. La inclinación del torso no se entera de si la rodilla está
   * doblada, ni de si el cuello está levantado — ninguno de los dos
   * afecta a la cuenta.
   *
   * El gate de "tumbado y quieto" para armar/cerrar la serie es el mismo
   * que en crunch y elevación de piernas (ver processCrunch).
   */
  processSitup(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now, this.profileGestureScale(lm))) {
      this.logScissor("[gesto de mano detectado] cerrando serie");
      this.closeActiveSet();
      return;
    }

    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];

    const leftVis = ((lShoulder.visibility ?? 1) + (lHip.visibility ?? 1)) / 2;
    const rightVis = ((rShoulder.visibility ?? 1) + (rHip.visibility ?? 1)) / 2;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    if (vis < SITUP_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien el hombro y la cadera. Ponte de perfil a la cámara, tumbado boca arriba.");
      if (this.debugEl) this.debugEl.textContent = "buscando hombro y cadera de perfil…";
      this.groundStableSince = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Te veo. ¡Listo! Túmbate boca arriba, con las rodillas dobladas si quieres, y empieza cuando quieras. Para terminar una serie, levántate, sal del encuadre, o levanta un brazo y agita la mano.",
        "startup_ready"
      );
    }

    const shoulder = useLeft ? lShoulder : rShoulder;
    const hip = useLeft ? lHip : rHip;
    const tilt = tiltFromHorizontal(shoulder, hip);
    if (tilt === null) return;
    const onGround = tilt <= ON_GROUND_MAX_TILT_DEG;

    if (this.state === null) {
      // Para armar hace falta el umbral MÁS ESTRICTO (ver
      // ON_GROUND_ARM_MAX_TILT_DEG) — no basta con "no estás de pie", hace
      // falta estar de verdad tumbado, no solo agachado colocando la
      // cámara.
      const onGroundToArm = tilt <= ON_GROUND_ARM_MAX_TILT_DEG;
      if (onGroundToArm) {
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= ON_GROUND_STABLE_MS) {
          this.state = "down";
          this.offGroundSince = null;
          this.announceStatus("¡Listo! Sube hasta sentarte y vuelve a bajar.", "ready_to_go");
        } else {
          this.setStatus("Tumbado… confirmando (no te muevas)");
        }
      } else {
        this.groundStableSince = null;
        this.setStatus("Túmbate boca arriba del todo para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = `inclinación torso: ${tilt.toFixed(0)}° | tumbado: ${onGroundToArm ? "sí" : "no"} | esperando a armar`;
      }
      return;
    }

    if (this.state === "down") {
      if (!onGround) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= OFF_GROUND_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
      } else {
        this.offGroundSince = null;
      }
    }

    if (this.state === "down") {
      if (tilt >= SITUP_UP_TILT_DEG) {
        this.state = "up";
        this.repStartTime = now;
      }
    } else if (tilt <= SITUP_DOWN_TILT_DEG) {
      this.countRep((now - this.repStartTime) / 1000, now, "Abdominal");
      this.state = "down";
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `inclinación torso: ${tilt.toFixed(0)}° | estado: ${this.state ?? "esperando"} ` +
        `(tumbado ≤${SITUP_DOWN_TILT_DEG}°, sentado ≥${SITUP_UP_TILT_DEG}°)`;
    }
  }

  /**
   * Guarda una línea en el registro de depuración de tijeretas (buffer
   * en memoria, sin mandar nada a ningún sitio) — pensado para poder
   * revisar luego, con el botón "Copiar registro" de la pantalla, qué
   * estaba viendo el contador justo en el momento de un fallo, sin tener
   * que leer el texto de depuración en directo (que queda ilegible si
   * estás tumbado lejos de la cámara). Se recorta a scissorLogMax líneas
   * (FIFO) para no crecer sin límite en una sesión larga.
   */
  logScissor(line) {
    this.scissorLog.push(`${((performance.now() - this.scissorLogStart) / 1000).toFixed(1)}s ${line}`);
    if (this.scissorLog.length > this.scissorLogMax) this.scissorLog.shift();
  }

  /**
   * Tijeretas: piernas estiradas, levantadas "a un palmo" del suelo, y
   * alternando cuál pierna queda más alta (como una tijera). Se cuenta
   * cada vez que cambia cuál tobillo está más arriba — no hay un ciclo
   * "abajo-arriba" como en el resto de abdominales tumbado, así que se
   * cuenta cada cambio de lado en vez de un ciclo completo.
   *
   * El gate de armado exige, además de estar tumbado (como el resto de
   * este bloque), tener las dos piernas YA levantadas dentro del rango
   * "a un palmo" (ver SCISSOR_LIFT_MIN/MAX_FACTOR) — esa es la postura
   * de partida del propio ejercicio, no solo "estar tumbado".
   */
  processScissor(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now, this.profileGestureScale(lm))) {
      this.logScissor("[gesto de mano detectado] cerrando serie");
      this.closeActiveSet();
      return;
    }

    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];
    const lAnkle = lm[L_ANKLE], rAnkle = lm[R_ANKLE];

    // A diferencia del resto de este bloque (que solo necesita ver bien
    // UN lado del cuerpo, el más cercano a la cámara), aquí hace falta
    // seguir los DOS tobillos para compararlos entre sí. Vistos de
    // perfil, un tobillo tapa parcialmente al otro sobre todo cuando
    // están a una altura parecida — que es justo lo que pasa todo el
    // rato en este ejercicio — así que MediaPipe le baja la confianza al
    // que queda detrás, aunque siga estimando su posición razonablemente
    // bien. Exigir visibilidad alta en los DOS tobillos A LA VEZ (como se
    // hacía antes, con el mínimo de los 8 puntos de ambos lados) casi
    // nunca se cumplía a la vez y el contador no llegaba ni a armarse —
    // por eso no contaba NINGUNA repetición, ni una. El gate de "te veo"
    // ahora solo mira el torso (hombros + cadera, del lado mejor visto —
    // igual que en crunch/elevación de piernas/abdominal); los tobillos
    // se usan tal cual los reporte MediaPipe, tenga la confianza que
    // tenga cada uno.
    const leftTrunkVis = ((lShoulder.visibility ?? 1) + (lHip.visibility ?? 1)) / 2;
    const rightTrunkVis = ((rShoulder.visibility ?? 1) + (rHip.visibility ?? 1)) / 2;
    const useLeft = leftTrunkVis >= rightTrunkVis;
    const trunkVis = useLeft ? leftTrunkVis : rightTrunkVis;

    if (trunkVis < SCISSOR_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien el hombro y la cadera. Túmbate boca arriba, de perfil (de lado a la cámara).");
      if (this.debugEl) this.debugEl.textContent = "buscando hombro y cadera de perfil…";
      this.groundStableSince = null;
      this.scissorSide = null;
      this.scissorCandidateSide = null;
      this.scissorCandidateSince = null;
      this.scissorSmoothA = null;
      this.scissorSmoothB = null;
      this.scissorRawPrevA = null;
      this.scissorRawPrevB = null;
      this.scissorTrackA = null;
      this.scissorTrackB = null;
      this.scissorSwitchCount = 0;
      // Antes esta rama no dejaba rastro en el registro de depuración --
      // un cierre de serie por pérdida de visibilidad del torso aquí era
      // invisible al leer el log después (solo se veía el aviso hablado,
      // sin ninguna línea [tijeretas] que lo explicase). Se registra ahora
      // igual que el resto del ejercicio.
      this.logScissor(`[torso no visible] trunkVis=${trunkVis.toFixed(2)} (mínimo ${SCISSOR_MIN_VISIBILITY})`);
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    // Solo hace falta ver hombro, cadera y rodilla (para la referencia
    // del muslo) del lado mejor visto.
    const shoulder = useLeft ? lShoulder : rShoulder;
    const hip = useLeft ? lHip : rHip;
    const knee = useLeft ? lKnee : rKnee;
    const thighLength = Math.hypot(hip.x - knee.x, hip.y - knee.y) || 1;

    // La cadera se queda apoyada en el suelo durante todo el ejercicio y
    // sirve de referencia de altura "0" — se mide cuánto sube cada
    // TOBILLO por encima de esa referencia, en proporción al muslo.
    const groundY = (lHip.y + rHip.y) / 2;

    // === Seguir cada pierna por su POSICIÓN, no por la etiqueta
    // izquierda/derecha de MediaPipe ===
    // De perfil, cuando los dos pies están a una altura parecida (que es
    // todo el rato en este ejercicio, sobre todo justo en el cruce),
    // MediaPipe tiene que ADIVINAR en cada frame, desde cero y sin
    // memoria del frame anterior, cuál tobillo es el "izquierdo" y cuál
    // el "derecho" del cuerpo — una decisión anatómica ambigua vista de
    // lado. El modelo se equivoca y se corrige solo de un frame al
    // siguiente, haciendo que la etiqueta salte de un tobillo físico a
    // otro sin que hayas movido nada. Esto explica el síntoma que se
    // veía: el MISMO movimiento, repetido igual, contado unas veces 1,
    // otras 2, otras hasta 4 o 6 — no era ruido en la posición (eso ya
    // se filtraba), era la etiqueta izq/dcha cambiando de pierna a media
    // repetición.
    //
    // La solución: en vez de fiarnos de esa etiqueta, reconocemos cada
    // tobillo por CERCANÍA con el frame anterior (el que esté más cerca
    // de donde estaba esa pierna antes, se queda con esa identidad). Así
    // aunque MediaPipe cambie la etiqueta izq/dcha, la pierna que
    // rastreamos como "1" sigue siendo la misma pierna física de
    // principio a fin — el emparejamiento se decide comparando la suma
    // de distancias de las dos asignaciones posibles y quedándose con la
    // más corta.
    const p1 = { x: lAnkle.x, y: lAnkle.y };
    const p2 = { x: rAnkle.x, y: rAnkle.y };
    let trackA, trackB;
    if (this.scissorTrackA === null || this.scissorTrackB === null) {
      trackA = p1;
      trackB = p2;
    } else {
      const distKeep =
        Math.hypot(this.scissorTrackA.x - p1.x, this.scissorTrackA.y - p1.y) +
        Math.hypot(this.scissorTrackB.x - p2.x, this.scissorTrackB.y - p2.y);
      const distSwap =
        Math.hypot(this.scissorTrackA.x - p2.x, this.scissorTrackA.y - p2.y) +
        Math.hypot(this.scissorTrackB.x - p1.x, this.scissorTrackB.y - p1.y);
      if (distSwap < distKeep) {
        trackA = p2;
        trackB = p1;
      } else {
        trackA = p1;
        trackB = p2;
      }
    }
    this.scissorTrackA = trackA;
    this.scissorTrackB = trackB;

    let rawLiftA = (groundY - trackA.y) / thighLength;
    let rawLiftB = (groundY - trackB.y) / thighLength;

    // Recorta saltos de un frame al siguiente que ninguna pierna real
    // puede hacer (ver SCISSOR_MAX_LIFT_JUMP) — ANTES de la media móvil:
    // un salto así de grande, si se deja entrar aunque sea para
    // suavizarlo, puede arrastrar la media lo bastante como para
    // disparar un cambio de pierna que en realidad no ha pasado (un
    // registro real enseñó saltos de hasta varias veces la longitud del
    // muslo en una fracción de segundo — eso es un fallo de tracking
    // puntual, no la pierna moviéndose).
    if (this.scissorRawPrevA !== null) {
      const deltaA = rawLiftA - this.scissorRawPrevA;
      if (Math.abs(deltaA) > SCISSOR_MAX_LIFT_JUMP) {
        rawLiftA = this.scissorRawPrevA + Math.sign(deltaA) * SCISSOR_MAX_LIFT_JUMP;
      }
    }
    if (this.scissorRawPrevB !== null) {
      const deltaB = rawLiftB - this.scissorRawPrevB;
      if (Math.abs(deltaB) > SCISSOR_MAX_LIFT_JUMP) {
        rawLiftB = this.scissorRawPrevB + Math.sign(deltaB) * SCISSOR_MAX_LIFT_JUMP;
      }
    }
    this.scissorRawPrevA = rawLiftA;
    this.scissorRawPrevB = rawLiftB;

    // Suaviza la altura de cada pierna con una media móvil exponencial
    // (ver SCISSOR_SMOOTHING_ALPHA) antes de usarla para nada: el ruido
    // de un frame suelto —típico justo cuando un tobillo tapa al otro al
    // cruzarse— apenas mueve la media, así que todo lo de aquí en
    // adelante (armar el contador, los consejos, y sobre todo detectar
    // el cambio de pierna) trabaja con una lectura más limpia sin
    // necesitar un margen ni un tiempo de confirmación exagerados.
    if (this.scissorSmoothA === null) {
      this.scissorSmoothA = rawLiftA;
      this.scissorSmoothB = rawLiftB;
    } else {
      this.scissorSmoothA += SCISSOR_SMOOTHING_ALPHA * (rawLiftA - this.scissorSmoothA);
      this.scissorSmoothB += SCISSOR_SMOOTHING_ALPHA * (rawLiftB - this.scissorSmoothB);
    }
    const liftA = this.scissorSmoothA;
    const liftB = this.scissorSmoothB;
    const legsLifted =
      liftA >= SCISSOR_LIFT_MIN_FACTOR && liftA <= SCISSOR_LIFT_MAX_FACTOR &&
      liftB >= SCISSOR_LIFT_MIN_FACTOR && liftB <= SCISSOR_LIFT_MAX_FACTOR;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Te veo. Túmbate boca arriba, levanta los pies a un palmo del suelo y alterna las piernas, sin llegar a tocar el suelo ni subirlas de más. Para terminar una serie, baja las piernas y ponte de pie, sal del encuadre, o levanta un brazo y agita la mano.",
        "startup_ready"
      );
    }

    if (this.state === null) {
      if (legsLifted) {
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= ON_GROUND_STABLE_MS) {
          this.state = "active";
          this.scissorSide = liftA >= liftB ? "1" : "2";
          this.scissorCandidateSide = null;
          this.scissorCandidateSince = null;
          this.scissorSwitchCount = 0;
          this.repStartTime = now;
          this.offGroundSince = null;
          this.announceStatus("¡Listo! Alterna las piernas.", "ready_to_go");
        } else {
          this.setStatus("Piernas a un palmo del suelo… confirmando (no te muevas)");
        }
      } else {
        this.groundStableSince = null;
        this.setStatus("Levanta los pies a un palmo del suelo, piernas estiradas, para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = `piernas a la altura: ${legsLifted ? "sí" : "no"} | esperando a armar`;
      }
      this.logScissor(
        `[esperando armar] piernasAltura=${legsLifted ? "sí" : "no"} ` +
        `1=${liftA.toFixed(2)}(${rawLiftA.toFixed(2)}) 2=${liftB.toFixed(2)}(${rawLiftB.toFixed(2)})`
      );
      return;
    }

    // Cierre de serie por "te has parado": las dos piernas caídas cerca
    // del suelo un rato seguido. También se puede cerrar la serie
    // saliendo del encuadre o con el gesto de la mano (ver arriba).
    const bothLegsDown = liftA < SCISSOR_LIFT_MIN_FACTOR * 0.5 && liftB < SCISSOR_LIFT_MIN_FACTOR * 0.5;
    if (bothLegsDown) {
      if (this.offGroundSince === null) this.offGroundSince = now;
      if (now - this.offGroundSince >= OFF_GROUND_STABLE_MS) {
        this.closeActiveSet();
        return;
      }
    } else {
      this.offGroundSince = null;
    }

    // El consejo de forma (no tocar el suelo / no subir de más) ya se
    // dice una vez al empezar (ver startupVoiceGiven más arriba) — antes
    // se repetía por voz aquí mismo cada pocos segundos mientras haces
    // el ejercicio, y sonaba a media repetición, molestando. No afecta
    // al conteo, así que no hace falta más que decirlo una vez.

    // Justo cuando un pie pasa por encima/detrás del otro (el momento
    // exacto del cambio, y también si te quedas con los pies pegados o
    // montados uno sobre el otro) es cuando peor se distingue una pierna
    // de otra — ahí es fácil que la lectura salte de un lado a otro y
    // hacia atrás en un puñado de frames sin que hayas hecho un cambio
    // real, contando de más (varias reps por un solo cambio de pierna).
    // Por eso un cambio de lado no se cuenta al instante: hace falta que
    // la nueva pierna "de arriba" se mantenga así un ratito seguido
    // (SCISSOR_SWITCH_STABLE_MS) antes de darlo por bueno — el mismo
    // patrón de "candidato + tiempo seguido" que groundStableSince/
    // hangStableSince usan en el resto del fichero, aplicado aquí a cuál
    // pierna está arriba en vez de a una postura.
    //
    // Un registro real (con el seguimiento por cercanía ya puesto)
    // enseñó cambios de pierna limpios y bien separados — el problema
    // real no era ruido, era la definición de "repetición": cada cruce
    // de piernas (pierna 1 arriba → pierna 2 arriba) se estaba contando
    // como una repetición entera, así que un vaivén completo (pierna 1
    // arriba → pierna 2 arriba → pierna 1 arriba de nuevo, que es "una
    // tijereta") contaba 2. Encaja con lo que describías: el doble todo
    // el rato. Ahora una repetición es un vaivén COMPLETO — se cuenta
    // solo cuando la pierna que estaba arriba al principio del ejercicio
    // vuelve a estar arriba (cada dos cambios de pierna, no cada uno).
    let scissorRepCountedThisFrame = false;
    const diff = liftA - liftB;
    if (Math.abs(diff) >= SCISSOR_SWITCH_MARGIN_FACTOR) {
      const topLeg = diff > 0 ? "1" : "2";
      if (topLeg === this.scissorSide) {
        // Sigues con la misma pierna arriba: no hay cambio en marcha.
        this.scissorCandidateSide = null;
        this.scissorCandidateSince = null;
      } else if (topLeg === this.scissorCandidateSide) {
        // Llevas un rato dando la otra pierna por arriba: si ya ha
        // pasado suficiente tiempo seguido, se confirma el cambio.
        if (now - this.scissorCandidateSince >= SCISSOR_SWITCH_STABLE_MS) {
          this.scissorSwitchCount = (this.scissorSwitchCount ?? 0) + 1;
          if (this.scissorSwitchCount % 2 === 0) {
            const counted = this.countRep((now - this.repStartTime) / 1000, now, "Repetición");
            scissorRepCountedThisFrame = counted !== false;
            this.repStartTime = now;
          }
          this.scissorSide = topLeg;
          this.scissorCandidateSide = null;
          this.scissorCandidateSince = null;
        }
      } else {
        // Primera lectura de un posible cambio: empieza a contar el
        // tiempo, sin confirmar nada todavía.
        this.scissorCandidateSide = topLeg;
        this.scissorCandidateSince = now;
      }
    }

    this.logScissor(
      `1=${liftA.toFixed(2)}(${rawLiftA.toFixed(2)}) 2=${liftB.toFixed(2)}(${rawLiftB.toFixed(2)}) ` +
      `diff=${diff.toFixed(2)} pierna=${this.scissorSide ?? "-"} candidata=${this.scissorCandidateSide ?? "-"} cambios=${this.scissorSwitchCount ?? 0} reps=${this.currentSetReps}` +
      (scissorRepCountedThisFrame ? "  ←←← REP CONTADA AQUÍ" : "")
    );

    if (this.debugEl) {
      this.debugEl.textContent =
        `pierna 1: ${liftA.toFixed(2)} (bruto ${rawLiftA.toFixed(2)}) | pierna 2: ${liftB.toFixed(2)} (bruto ${rawLiftB.toFixed(2)}) | ` +
        `arriba: ${this.scissorSide ?? "-"}${this.scissorCandidateSide ? ` (candidata: ${this.scissorCandidateSide})` : ""} ` +
        `(rango ${SCISSOR_LIFT_MIN_FACTOR}-${SCISSOR_LIFT_MAX_FACTOR})`;
    }
  }

  /**
   * Doble crunch: el torso se mantiene LEVANTADO todo el rato (una
   * posición intermedia entre tumbado del todo y sentado del todo) —
   * mientras se doblan y estiran las piernas, llevando las rodillas al
   * pecho y volviendo a estirar, una y otra vez. Ver el bloque de
   * comentarios junto a DOUBLECRUNCH_TILT_MIN_DEG más arriba para el
   * porqué del rango de inclinación, y junto a DOUBLECRUNCH_TUCK_MAX_FACTOR
   * para el porqué de medir la distancia rodilla-hombro en vez de un
   * ángulo de cadera-rodilla.
   */
  processDoubleCrunch(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now, this.profileGestureScale(lm))) {
      this.logScissor("[gesto de mano detectado] cerrando serie");
      this.closeActiveSet();
      return;
    }

    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];
    const lKnee = lm[L_KNEE], rKnee = lm[R_KNEE];

    const leftVis = ((lShoulder.visibility ?? 1) + (lHip.visibility ?? 1) + (lKnee.visibility ?? 1)) / 3;
    const rightVis = ((rShoulder.visibility ?? 1) + (rHip.visibility ?? 1) + (rKnee.visibility ?? 1)) / 3;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    if (vis < DOUBLECRUNCH_MIN_VISIBILITY) {
      this.announceStatus("No se te ven bien el hombro, la cadera y la rodilla. Ponte de perfil a la cámara, tumbado boca arriba.");
      if (this.debugEl) this.debugEl.textContent = "buscando hombro, cadera y rodilla de perfil…";
      this.torsoBandStableSince = null;
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    const shoulder = useLeft ? lShoulder : rShoulder;
    const hip = useLeft ? lHip : rHip;
    const knee = useLeft ? lKnee : rKnee;
    const torsoLength = Math.hypot(shoulder.x - hip.x, shoulder.y - hip.y);
    if (!torsoLength) return;

    if (!this.startupVoiceGiven) {
      this.startupVoiceGiven = true;
      this.announceStatus(
        "Te veo. Levanta el torso y mantenlo ahí, doblando y estirando las piernas para llevar las rodillas al pecho. Para terminar una serie, túmbate del todo, ponte de pie, sal del encuadre, o levanta un brazo y agita la mano.",
        "startup_ready"
      );
    }

    const tilt = tiltFromHorizontal(hip, shoulder);
    if (tilt === null) return;
    const inBand = tilt >= DOUBLECRUNCH_TILT_MIN_DEG && tilt <= DOUBLECRUNCH_TILT_MAX_DEG;
    const kneeToShoulder = Math.hypot(knee.x - shoulder.x, knee.y - shoulder.y) / torsoLength;

    if (this.state === null) {
      if (inBand) {
        if (this.torsoBandStableSince === null) this.torsoBandStableSince = now;
        if (now - this.torsoBandStableSince >= ON_GROUND_STABLE_MS) {
          this.state = "extended";
          this.torsoOutOfBandSince = null;
          this.announceStatus("¡Listo! Lleva las rodillas al pecho y vuelve a estirar.", "ready_to_go");
        } else {
          this.setStatus("Torso levantado… confirmando (no te muevas)");
        }
      } else {
        this.torsoBandStableSince = null;
        this.setStatus("Levanta el torso hasta una posición intermedia y mantenla ahí para empezar.");
      }
      if (this.debugEl) {
        this.debugEl.textContent = `inclinación torso: ${tilt.toFixed(0)}° | en banda: ${inBand ? "sí" : "no"} | esperando a armar`;
      }
      return;
    }

    // Mientras ya se está siguiendo una repetición en marcha, solo se
    // considera "fuera de banda" (para cerrar la serie) si el torso ha
    // vuelto a quedar prácticamente tumbado -- no basta con salirse por
    // el extremo bajo de la banda de armado, que el propio movimiento de
    // llevar las rodillas al pecho ya toca de forma normal.
    const activeOutOfBand = tilt > DOUBLECRUNCH_TILT_MAX_DEG || tilt < DOUBLECRUNCH_ACTIVE_MIN_TILT_DEG;
    if (activeOutOfBand) {
      if (this.torsoOutOfBandSince === null) this.torsoOutOfBandSince = now;
      if (now - this.torsoOutOfBandSince >= OFF_GROUND_STABLE_MS) {
        this.closeActiveSet();
        return;
      }
    } else {
      this.torsoOutOfBandSince = null;
    }

    if (this.state === "extended") {
      if (kneeToShoulder <= DOUBLECRUNCH_TUCK_MAX_FACTOR) {
        this.state = "tucked";
        this.repStartTime = now;
      }
    } else if (kneeToShoulder >= DOUBLECRUNCH_EXTEND_MIN_FACTOR) {
      this.countRep((now - this.repStartTime) / 1000, now, "Crunch");
      this.state = "extended";
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `inclinación torso: ${tilt.toFixed(0)}° | rodilla-hombro: ${kneeToShoulder.toFixed(2)} | estado: ${this.state ?? "esperando"} ` +
        `(estirado ≥${DOUBLECRUNCH_EXTEND_MIN_FACTOR}, doblado ≤${DOUBLECRUNCH_TUCK_MAX_FACTOR})`;
    }
  }

  /**
   * Dominadas de arquero: mismo criterio de subida/bajada que las
   * dominadas normales (calibrar la altura de la barra colgado quieto y
   * seguir la nariz respecto a esa barra — ver el bloque para
   * counterKey "pullup" un poco más abajo en processResult), con un
   * añadido: en el punto más alto de cada repetición, un brazo tiene
   * que estar doblado a ~90° (el que tira) y el otro estirado (el que
   * se desliza por la barra) — ver ARCHER_BENT_MAX_DEG /
   * ARCHER_STRAIGHT_MIN_DEG y archerDetectSide().
   *
   * La repetición cuenta igual aunque no se distinga bien qué lado
   * usaste (cámara mal encuadrada, ángulo ambiguo, ambos brazos muy
   * parecidos): el aviso de lado es una ayuda de técnica para recordarte
   * que alternes, no un requisito para que la rep cuente.
   */
  processArcherPullup(lm, now) {
    const nose = lm[NOSE];
    const lShoulder = lm[L_SHOULDER];
    const rShoulder = lm[R_SHOULDER];
    const lElbow = lm[L_ELBOW];
    const rElbow = lm[R_ELBOW];
    const lWrist = lm[L_WRIST];
    const rWrist = lm[R_WRIST];
    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    const y = nose.y; // 0 = arriba del todo del encuadre, 1 = abajo del todo
    const wristMidY = (lWrist.y + rWrist.y) / 2;
    const elbowMidY = (lElbow.y + rElbow.y) / 2;
    const wristVisible = ((lWrist.visibility ?? 1) + (rWrist.visibility ?? 1)) / 2 > 0.4;
    const elbowVisible = ((lElbow.visibility ?? 1) + (rElbow.visibility ?? 1)) / 2 > 0.4;

    const shoulderMidYRaw = (lShoulder.y + rShoulder.y) / 2;
    const armsUpNow = wristVisible
      ? wristMidY < shoulderMidYRaw - HANG_MARGIN_FACTOR * shoulderWidth
      : elbowVisible && elbowMidY < shoulderMidYRaw - HANG_MARGIN_FACTOR * shoulderWidth;
    // Distinto de armsUpNow (ver RELEASE_MARGIN_FACTOR): solo esto cuenta
    // como "te has soltado de la barra de verdad" para cerrar la serie.
    const armsClearlyReleased = wristVisible
      ? wristMidY > shoulderMidYRaw + RELEASE_MARGIN_FACTOR * shoulderWidth
      : elbowVisible && elbowMidY > shoulderMidYRaw + RELEASE_MARGIN_FACTOR * shoulderWidth;

    if (this.prepping) {
      const waitedSeconds = Math.floor((now - this.prepStartTs) / 1000);
      if ((wristVisible || elbowVisible) && !this.startupVoiceGiven) {
        this.startupVoiceGiven = true;
        this.announceStatus("¡Listo! Cuélgate de la barra con los brazos estirados para empezar.", "startup_ready", "Cuélgate de la barra.");
      }

      if (armsUpNow) {
        if (this.hangStableSince === null) this.hangStableSince = now;
        if (now - this.hangStableSince >= HANG_STABLE_MS) {
          this.prepping = false;
          this.calibrating = true;
          this.calibrationStartTs = now;
          this.calibrationSamples = [];
        } else {
          this.setStatus("Te veo colgado… confirmando (no te muevas)");
        }
      } else {
        this.hangStableSince = null;
        this.setStatus(
          waitedSeconds < 8
            ? "Ve a la barra y cuélgate con los brazos estirados…"
            : `Esperando a verte colgado (llevas ${waitedSeconds}s)… comprueba que la cámara vea tus brazos y hombros enteros`
        );
      }
      if (this.debugEl) {
        this.debugEl.textContent = `brazos en alto: ${armsUpNow ? "sí" : "no"} | espera: ${waitedSeconds}s`;
      }
      return;
    }

    if (this.calibrating) {
      if (!armsUpNow) {
        this.prepping = true;
        this.calibrating = false;
        this.hangStableSince = null;
        this.prepStartTs = now;
        this.calibrationSamples = [];
        return;
      }
      const barRefY = wristVisible ? wristMidY : elbowMidY;
      this.calibrationSamples.push({ y, shoulderWidth, barRefY });
      const elapsed = now - this.calibrationStartTs;
      const remaining = Math.max(0, Math.ceil((CALIBRATION_MS - elapsed) / 1000));
      this.setStatus(`Calibrando, quédate colgado y quieto… (${remaining || 1}s)`);
      if (elapsed >= CALIBRATION_MS) {
        const ys = this.calibrationSamples.map((s) => s.y).sort((a, b) => a - b);
        const ws = this.calibrationSamples.map((s) => s.shoulderWidth).sort((a, b) => a - b);
        const wy = this.calibrationSamples.map((s) => s.barRefY).sort((a, b) => a - b);
        this.shoulderWidth = ws[Math.floor(ws.length / 2)];
        this.localBottomY = ys[Math.floor(ys.length / 2)];
        this.localTopY = this.localBottomY;
        this.barY = wy[Math.floor(wy.length / 2)] - BAR_OFFSET_FACTOR * this.shoulderWidth;
        this.calibrating = false;
        this.repStartTime = now;
        this.lastRepTime = now;
        this.restAlerted = false;
        this.updateSetDisplay();
        this.logScissor(`[CALIBRADO] barra_y=${this.barY.toFixed(3)} hombros=${this.shoulderWidth.toFixed(3)}`);
        // Si el descanso obligatorio (MIN_REST_MS) todavía no ha pasado
        // desde que se cerró la serie anterior, no se anuncia "empieza"
        // aunque ya estés calibrada/o y colgada/o -- decirlo aquí
        // contradice al propio descanso obligatorio (countRep ya bloquea
        // en silencio cualquier intento de contar antes de tiempo, y
        // announceRestBlocked() lo explica si insistes). El aviso real de
        // que ya puedes empezar lo da tickRestTimer en cuanto el descanso
        // termina de verdad (ver pendingHangReminder).
        if (this.setClosedAt === null || now - this.setClosedAt >= MIN_REST_MS) {
          this.announceStatus(
            "¡Listo! Empieza a hacer dominadas de arquero: al subir, lleva un brazo a 90° y estira el otro, alternando de lado en cada repetición."
          );
        }
      }
      return;
    }

    if (!this.shoulderWidth || this.barY === null) return;

    const scaleChange = Math.abs(shoulderWidth - this.shoulderWidth) / this.shoulderWidth;
    const scaleOk = scaleChange < SCALE_TOLERANCE;

    if (!armsUpNow || !scaleOk) {
      this.logScissor(
        `[frame descartado] brazos_arriba=${armsUpNow} escala_ok=${scaleOk} cambio_escala=${scaleChange.toFixed(2)}(máx ${SCALE_TOLERANCE}) ` +
        `estado=${this.state} reps_serie=${this.currentSetReps}`
      );
      // Solo se borran las referencias de la repeticion en curso si de
      // verdad no se ven los brazos arriba (soltaste la barra, saliste
      // del encuadre) -- si siguen arriba y solo ha fallado el cambio de
      // escala (motion blur de un tiron rapido), NO se tocan: reportado
      // en vivo -- si el salto de escala coincidia justo con el instante
      // de llegar arriba del todo, el siguiente frame valido tomaba esa
      // posicion ALTA como nuevo "punto de abajo" y esa repeticion se
      // perdia sin contarse. Aqui se descarta SOLO este frame, no el
      // progreso de la repeticion.
      if (!armsUpNow) {
        this.localBottomY = null;
        this.localTopY = null;
        this.liftoffTime = null;
        this.archerPeakLeftAngle = null;
        this.archerPeakRightAngle = null;
        this.archerLiveLeftAngle = null;
        this.archerLiveRightAngle = null;
      }

      if (armsClearlyReleased) {
        if (this.armsDownSince === null) this.armsDownSince = now;
        if (now - this.armsDownSince >= ARMS_DOWN_STABLE_MS && this.currentSetReps > 0) {
          const closedReps = this.currentSetReps;
          this.armsDownSince = null;
          // El aviso de descanso obligatorio SÍ tiene que oírse — por eso
          // va antes de silenciar la voz (restVoiceQuiet), no después.
          // setClosedAt lo marca beginPrep() justo debajo (currentSetReps
          // todavía es > 0 en este punto).
          // El "cuélgate otra vez" ya NO se dice aquí — se dice cuando el
          // descanso obligatorio de verdad termina (ver tickRestTimer /
          // pendingHangReminder): decirlo ahora, con 90s de descanso todavía
          // por delante, no tiene sentido.
          this.pendingHangReminder = true;
          this.announceSetComplete(`Serie de ${closedReps}`, "");
          this.restVoiceQuiet = true;
          this.beginPrep();
          return;
        }
      } else {
        // Zona ambigua (aguantando arriba) o solo falló el cambio de
        // escala: no cuenta como que te has soltado de verdad.
        this.armsDownSince = null;
      }

      if (this.debugEl) {
        this.debugEl.textContent = !armsUpNow
          ? "esperando a que agarres la barra (brazos en alto)…"
          : "distancia a la cámara cambió demasiado, recalibra si sigue así";
      }
      return;
    }

    this.armsDownSince = null;

    const moveThresh = MOVE_FACTOR * this.shoulderWidth;
    const barThresh = this.barY + BAR_MARGIN_FACTOR * this.shoulderWidth;

    // Ángulo de codo de cada brazo en ESTE frame (null si no se ven bien
    // codo/muñeca de ese lado — angle() no comprueba visibilidad por su
    // cuenta). Se usan para ir capturando el ángulo del frame con el
    // punto más alto durante la subida, ver más abajo.
    const leftAngle = elbowVisible && wristVisible ? angle(lShoulder, lElbow, lWrist) : null;
    const rightAngle = elbowVisible && wristVisible ? angle(rShoulder, rElbow, rWrist) : null;
    // Para el overlay (ver drawOverlay): el ángulo EN VIVO de este frame,
    // no el capturado en el pico — así el dibujo reacciona al instante
    // mientras te mueves, aunque lo que cuenta para decidir el lado siga
    // siendo solo el del punto más alto.
    this.archerLiveLeftAngle = leftAngle;
    this.archerLiveRightAngle = rightAngle;

    if (this.state === "down") {
      // sigue bajando (o igual) -> este es el nuevo punto de referencia "abajo",
      // y todavia no has "despegado" (reinicia la marca de despegue)
      if (this.localBottomY === null || y > this.localBottomY) {
        this.localBottomY = y;
        this.liftoffTime = null;
      }
      const risenFromBottom = this.localBottomY - y;

      // primer indicio de que te has empezado a mover de verdad
      if (this.liftoffTime === null && risenFromBottom > LIFTOFF_FACTOR * this.shoulderWidth) {
        this.liftoffTime = now;
      }

      const reachedBar = y <= barThresh;
      if (reachedBar && risenFromBottom > moveThresh) {
        this.state = "up";
        this.localTopY = y;
        this.repStartTime = this.liftoffTime ?? now;
        // Empieza a trackear el punto más alto de ESTA subida desde cero.
        this.archerPeakLeftAngle = leftAngle;
        this.archerPeakRightAngle = rightAngle;
      }
    } else {
      // state === "up": sigue subiendo (o igual) -> nuevo punto de referencia "arriba"
      if (this.localTopY === null || y < this.localTopY) {
        this.localTopY = y;
        // Nuevo punto más alto -> los ángulos de este frame son los que
        // se guardan como "postura arriba del todo": se sobrescriben
        // cada vez que subes un poco más, así el valor que queda al
        // final es el del pico real, no el de un frame cualquiera de la
        // subida (que era justo lo que se pidió: comprobar solo arriba
        // del todo).
        this.archerPeakLeftAngle = leftAngle;
        this.archerPeakRightAngle = rightAngle;
      }
      const fallenFromTop = y - this.localTopY;
      if (fallenFromTop > moveThresh) {
        // ha vuelto a bajar lo suficiente -> repetición completa
        const side = this.archerDetectSide(this.archerPeakLeftAngle, this.archerPeakRightAngle);
        this.logScissor(
          `[REP intentada] duración=${((now - this.repStartTime) / 1000).toFixed(2)}s lado=${side ?? "?"} ` +
          `pico_izq=${this.archerPeakLeftAngle === null ? "-" : this.archerPeakLeftAngle.toFixed(0) + "°"} ` +
          `pico_der=${this.archerPeakRightAngle === null ? "-" : this.archerPeakRightAngle.toFixed(0) + "°"}`
        );
        this.countRep((now - this.repStartTime) / 1000, now, "Dominada de arquero");
        if (side !== null) {
          if (this.archerLastSide !== null && this.archerLastSide === side) {
            this.announceStatus(
              `Llevas dos seguidas al lado ${side === "left" ? "izquierdo" : "derecho"} — alterna de lado.`,
              "archer_same_side"
            );
          }
          this.archerLastSide = side;
        }
        this.state = "down";
        this.localBottomY = y;
        this.archerPeakLeftAngle = null;
        this.archerPeakRightAngle = null;
      }
    }

    if (this.debugEl) {
      const fmt = (v) => (v === null ? "-" : `${v.toFixed(0)}°`);
      this.debugEl.textContent =
        `estado: ${this.state} | nariz-barra: ${((y - this.barY) / this.shoulderWidth).toFixed(2)} ` +
        `(umbral ${BAR_MARGIN_FACTOR}) | codo izq: ${fmt(leftAngle)} | codo der: ${fmt(rightAngle)} | último lado: ${this.archerLastSide ?? "-"}`;
    }
    this.logScissor(
      `estado=${this.state} nariz_y=${y.toFixed(3)} barra_y=${this.barY.toFixed(3)} dist_barra=${((y - this.barY) / this.shoulderWidth).toFixed(2)}(umbral ${BAR_MARGIN_FACTOR}) ` +
      `hombros=${this.shoulderWidth.toFixed(3)} abajo_ref=${this.localBottomY === null ? "-" : this.localBottomY.toFixed(3)} arriba_ref=${this.localTopY === null ? "-" : this.localTopY.toFixed(3)} ` +
      `despegue=${this.liftoffTime === null ? "no" : "sí"}`
    );
  }

  /**
   * A partir de los ángulos de codo capturados en el punto más alto de
   * la repetición, decide qué lado se usó (un brazo doblado ~90° y el
   * otro estirado) — o null si no se distingue con claridad (ambos
   * ángulos parecidos, o no se veían bien codo/muñeca de algún lado).
   * Ver ARCHER_BENT_MAX_DEG / ARCHER_STRAIGHT_MIN_DEG.
   */
  archerDetectSide(leftAngle, rightAngle) {
    if (leftAngle === null || rightAngle === null) return null;
    if (leftAngle <= ARCHER_BENT_MAX_DEG && rightAngle >= ARCHER_STRAIGHT_MIN_DEG) return "left";
    if (rightAngle <= ARCHER_BENT_MAX_DEG && leftAngle >= ARCHER_STRAIGHT_MIN_DEG) return "right";
    return null;
  }

  /**
   * Curl de bíceps con mancuernas: cámara DE PERFIL, igual que
   * flexiones/fondos/sentadillas — ver el bloque CURL_* más arriba
   * (SEGUNDA VERSIÓN, con el porqué del cambio desde la primera versión
   * de frente, que no contaba nada en cámara real). Se usa el lado
   * (izq/der) que mejor se vea, exactamente igual que processSquat/
   * processPushup: de perfil solo se ve bien un lado, el otro queda
   * tapado por el propio cuerpo.
   *
   * Se cuenta una repetición cuando el ÁNGULO DEL CODO (hombro-codo-
   * muñeca) completa el ciclo estirado (CURL_EXTENDED_ANGLE_DEG) →
   * doblado (CURL_FLEXED_ANGLE_DEG) → estirado — mismo patrón de dos
   * pasos que flexiones/fondos.
   *
   * Ver el bloque CURL_* más arriba para el porqué de "codo pegado al
   * costado" / "muñeca por debajo de la cara" — los dos falsos positivos
   * concretos que pidió Alex evitar (levantar las manos sin querer,
   * mirar el móvil) — y checkCameraShake para el tercero (el móvil
   * sujeto en la mano en vez de apoyado). Las tres comprobaciones se
   * hacen en TODOS los frames mientras la serie está armada, no solo al
   * principio: si se rompen, el frame se descarta ANTES de mirar el
   * ángulo de codo, así que un gesto suelto nunca puede colarse como
   * repetición aunque el ángulo por sí solo dibuje el ciclo completo.
   *
   * LIMITACIÓN CONOCIDA: MediaPipe Pose da hombro/codo/muñeca, no la
   * forma de la mano — no hay forma de comprobar literalmente si hay
   * algo agarrado (una mancuerna, el móvil, o nada). Lo de arriba es una
   * aproximación por la FORMA del movimiento, no reconocimiento de
   * objetos.
   */
  processDumbbellCurl(lm, now) {
    if (this.state !== null && this.checkWaveGesture(lm, now)) {
      this.closeActiveSet();
      return;
    }

    const nose = lm[NOSE];
    const lShoulder = lm[L_SHOULDER], rShoulder = lm[R_SHOULDER];
    const lElbow = lm[L_ELBOW], rElbow = lm[R_ELBOW];
    const lWrist = lm[L_WRIST], rWrist = lm[R_WRIST];
    const lHip = lm[L_HIP], rHip = lm[R_HIP];

    const leftVis = ((lShoulder.visibility ?? 1) + (lElbow.visibility ?? 1) + (lWrist.visibility ?? 1) + (lHip.visibility ?? 1)) / 4;
    const rightVis = ((rShoulder.visibility ?? 1) + (rElbow.visibility ?? 1) + (rWrist.visibility ?? 1) + (rHip.visibility ?? 1)) / 4;
    const useLeft = leftVis >= rightVis;
    const vis = useLeft ? leftVis : rightVis;

    if (vis < CURL_MIN_VISIBILITY) {
      this.announceStatus(
        "No se te ven bien el hombro, el codo, la muñeca y la cadera. Ponte de perfil a la cámara, de pie, " +
        "con la mancuerna en la mano del lado que mira a la cámara."
      );
      if (this.debugEl) this.debugEl.textContent = "buscando hombro, codo, muñeca y cadera de perfil…";
      this.logScissor(
        `[visibilidad baja] lado_elegido=${useLeft ? "izq" : "der"} vis=${vis.toFixed(2)} (mín ${CURL_MIN_VISIBILITY}) ` +
        `izq: hombro=${(lShoulder.visibility ?? 1).toFixed(2)} codo=${(lElbow.visibility ?? 1).toFixed(2)} muñeca=${(lWrist.visibility ?? 1).toFixed(2)} cadera=${(lHip.visibility ?? 1).toFixed(2)} total=${leftVis.toFixed(2)} | ` +
        `der: hombro=${(rShoulder.visibility ?? 1).toFixed(2)} codo=${(rElbow.visibility ?? 1).toFixed(2)} muñeca=${(rWrist.visibility ?? 1).toFixed(2)} cadera=${(rHip.visibility ?? 1).toFixed(2)} total=${rightVis.toFixed(2)} | ` +
        `estado=${this.state ?? "null"}`
      );
      this.curlSide = null;
      this.groundStableSince = null;
      if (this.state !== null) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= CURL_BROKEN_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
      }
      this.noteAbsence(now);
      return;
    }
    this.outOfFrameSince = null;

    const shoulder = useLeft ? lShoulder : rShoulder;
    const elbow = useLeft ? lElbow : rElbow;
    const wrist = useLeft ? lWrist : rWrist;
    const hip = useLeft ? lHip : rHip;

    const elbowAngle = angle(shoulder, elbow, wrist);
    if (elbowAngle === null) return;
    this.curlSide = useLeft ? "left" : "right";
    this.curlElbowAngle = elbowAngle;

    const torsoLength = Math.hypot(shoulder.x - hip.x, shoulder.y - hip.y);
    if (!torsoLength) return;
    // De perfil, el eje x de la imagen es el eje delante-atrás del
    // cuerpo: un codo pegado al costado no se adelanta ni se atrasa
    // respecto a la cadera. Ver el bloque CURL_* más arriba.
    const elbowDrift = Math.abs(elbow.x - hip.x) / torsoLength;
    // BUG REAL (encontrado con el registro de depuración que pegó Alex —
    // el contador nunca llegaba a armarse ni con el ángulo recorriendo
    // el ciclo completo de un curl real): elbowRise se comparaba antes
    // contra un umbral FIJO de codo-por-encima-de-la-cadera, pero
    // anatómicamente el codo YA está muy por encima de la cadera con el
    // brazo colgando en reposo (el codo cuelga a media altura del
    // tronco hombro-cadera, no a la altura de la cadera). En los datos
    // de Alex, con el brazo estirado en reposo (~175-180°), elbowRise
    // salía 0.4-0.6, muy por encima del 0.25 exigido, así que "pegado"
    // nunca daba true y no se podía ni armar. Arreglo: en vez de
    // comparar contra la cadera, se guarda la altura del codo en el
    // momento de armar (curlElbowBaselineY) y se mide cuánto SUBE el
    // codo respecto a ESA referencia — eso sí detecta el tramposeo real
    // (levantar todo el brazo por el hombro en vez de solo doblar el
    // antebrazo), y no se dispara con la postura de reposo normal.
    // Mientras no hay referencia todavía (antes de armar), esta
    // comprobación no bloquea nada.
    const elbowRise = this.curlElbowBaselineY !== null
      ? (this.curlElbowBaselineY - elbow.y) / torsoLength
      : 0;
    const risePinned = this.curlElbowBaselineY === null || elbowRise <= CURL_ELBOW_RISE_MAX_FACTOR;
    const wristDrop = (wrist.y - nose.y) / torsoLength;
    const pinned = elbowDrift <= CURL_ELBOW_DRIFT_MAX_FACTOR && risePinned;
    const belowFace = wristDrop >= CURL_WRIST_FACE_MARGIN_FACTOR;
    const shaking = this.checkCameraShake(shoulder, hip, torsoLength, now);
    const shapeOk = pinned && belowFace && !shaking;

    if (this.state !== null) {
      if (!shapeOk) {
        if (this.offGroundSince === null) this.offGroundSince = now;
        if (now - this.offGroundSince >= CURL_BROKEN_STABLE_MS) {
          this.closeActiveSet();
          return;
        }
        if (this.debugEl) {
          this.debugEl.textContent =
            `fuera de forma (codo pegado: ${pinned ? "sí" : "no"} · muñeca bajo la cara: ${belowFace ? "sí" : "no"} · ` +
            `cámara estable: ${shaking ? "no" : "sí"}) — se descarta este frame`;
        }
        this.logScissor(
          `[forma rota, se descarta frame] ángulo=${elbowAngle.toFixed(0)}° lado=${useLeft ? "izq" : "der"} ` +
          `codo_drift=${elbowDrift.toFixed(2)}(máx ${CURL_ELBOW_DRIFT_MAX_FACTOR}) codo_subido=${elbowRise.toFixed(2)}(máx ${CURL_ELBOW_RISE_MAX_FACTOR}) ` +
          `muñeca_bajo_cara=${wristDrop.toFixed(2)}(mín ${CURL_WRIST_FACE_MARGIN_FACTOR}) pegado=${pinned} bajo_cara=${belowFace} ` +
          `temblando=${shaking} estado=${this.state}`
        );
        return;
      }
      this.offGroundSince = null;
    }

    if (this.state === null) {
      // Referencia siempre fresca: mientras se espera para armar, no
      // hay tramposeo de "codo subido" que juzgar todavía (ver arriba).
      this.curlElbowBaselineY = null;
      const armReady = elbowAngle >= CURL_EXTENDED_ANGLE_DEG;
      if (shapeOk && armReady) {
        if (this.groundStableSince === null) this.groundStableSince = now;
        if (now - this.groundStableSince >= CURL_ARM_STABLE_MS) {
          this.state = "bottom";
          this.groundStableSince = null;
          this.offGroundSince = null;
          this.repStartTime = now;
          this.curlTopHoldSince = null;
          this.curlElbowBaselineY = elbow.y;
          this.logScissor(`[ARMADO] lado=${useLeft ? "izq" : "der"} ángulo=${elbowAngle.toFixed(0)}° codo_y_referencia=${elbow.y.toFixed(3)}`);
          if (!this.startupVoiceGiven) {
            this.startupVoiceGiven = true;
            this.announceStatus(
              "Te veo. ¡Listo! Empieza a hacer curls. Para terminar una serie, sal del encuadre o levanta un brazo y " +
              "agita la mano.",
              "startup_ready"
            );
          } else {
            this.announceStatus("¡Listo! Empieza a hacer curls.", "ready_to_go");
          }
        } else {
          this.setStatus("Postura vista… confirmando (no te muevas).");
        }
      } else {
        this.groundStableSince = null;
        this.setStatus(
          "Ponte de perfil a la cámara, de pie, con la mancuerna colgando, el brazo estirado y el codo pegado " +
          "al cuerpo, para empezar."
        );
      }
      if (this.debugEl) {
        this.debugEl.textContent = `ángulo codo (${useLeft ? "izq" : "der"}): ${elbowAngle.toFixed(0)}° | esperando posición inicial`;
      }
      this.logScissor(
        `[esperando armar] ángulo=${elbowAngle.toFixed(0)}° (mín ${CURL_EXTENDED_ANGLE_DEG} para armar) lado=${useLeft ? "izq" : "der"} ` +
        `forma_ok=${shapeOk} codo_drift=${elbowDrift.toFixed(2)}(máx ${CURL_ELBOW_DRIFT_MAX_FACTOR}) codo_subido=${elbowRise.toFixed(2)}(máx ${CURL_ELBOW_RISE_MAX_FACTOR}) ` +
        `muñeca_bajo_cara=${wristDrop.toFixed(2)}(mín ${CURL_WRIST_FACE_MARGIN_FACTOR}) pegado=${pinned} bajo_cara=${belowFace} temblando=${shaking} ` +
        `armado_desde=${this.groundStableSince === null ? "-" : ((now - this.groundStableSince) / 1000).toFixed(1) + "s"}`
      );
      return;
    }

    if (this.state === "bottom") {
      this.curlTopHoldSince = null;
      if (elbowAngle <= CURL_FLEXED_ANGLE_DEG) {
        this.state = "top";
        this.curlTopHoldSince = now;
        this.curlRestSince = null;
        this.logScissor(`[arriba del curl] ángulo=${elbowAngle.toFixed(0)}° (≤${CURL_FLEXED_ANGLE_DEG} para llegar arriba)`);
      } else if (elbowAngle >= CURL_EXTENDED_ANGLE_DEG) {
        // Brazo estirado del todo y sin doblar: podría ser que has
        // terminado la serie y estás descansando — ver
        // CURL_REST_AUTO_CLOSE_MS más arriba para el porqué.
        if (this.curlRestSince === null) this.curlRestSince = now;
        const restMs = now - this.curlRestSince;
        if (this.currentSetReps > 0 && restMs >= CURL_REST_AUTO_CLOSE_MS) {
          this.logScissor(
            `[serie cerrada por descanso] brazo estirado y quieto ${(restMs / 1000).toFixed(1)}s ` +
            `(≥${(CURL_REST_AUTO_CLOSE_MS / 1000).toFixed(1)}s) reps_serie=${this.currentSetReps}`
          );
          this.curlRestSince = null;
          this.closeActiveSet();
          return;
        }
        if (this.currentSetReps > 0 && restMs >= CURL_REST_WARN_MS) {
          const remaining = ((CURL_REST_AUTO_CLOSE_MS - restMs) / 1000).toFixed(1);
          this.setStatus(`Brazo abajo, quieto… si sigues así se cierra la serie sola en ${remaining}s.`);
        }
      } else {
        // Zona intermedia: se está moviendo (ni estirado del todo ni
        // doblado del todo), así que no cuenta como "quieto en reposo".
        this.curlRestSince = null;
      }
    } else {
      // state === "top": aguantando arriba, o volviendo a bajar.
      if (elbowAngle >= CURL_EXTENDED_ANGLE_DEG) {
        // El brazo ha vuelto a estirarse: repetición completa.
        this.logScissor(`[REP CONTADA] ángulo=${elbowAngle.toFixed(0)}° duración=${((now - this.repStartTime) / 1000).toFixed(2)}s`);
        this.countRep((now - this.repStartTime) / 1000, now, "Curl");
        this.state = "bottom";
        this.repStartTime = now;
        this.curlTopHoldSince = null;
        this.curlRestSince = null;
      } else if (this.curlTopHoldSince !== null && now - this.curlTopHoldSince >= CURL_TOP_HOLD_WARN_MS) {
        // Temporizador pedido por Alex: te has quedado arriba sin bajar
        // — no es un curl, es una sujeción aguantada. Ya NO se cuenta
        // como repetición (el ciclo de arriba solo cuenta al volver a
        // estirar el brazo), pero se avisa en pantalla de cuánto llevas
        // así para que quede claro que no se está contando nada
        // mientras tanto.
        const heldSeconds = ((now - this.curlTopHoldSince) / 1000).toFixed(1);
        this.setStatus(`Aguantando arriba: ${heldSeconds}s (no cuenta como repetición hasta que bajes del todo)`);
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `ángulo codo (${useLeft ? "izq" : "der"}): ${elbowAngle.toFixed(0)}° | estado: ${this.state ?? "esperando"} ` +
        `(estirado ≥${CURL_EXTENDED_ANGLE_DEG}°, doblado ≤${CURL_FLEXED_ANGLE_DEG}°) | ` +
        `codo pegado: ${pinned ? "sí" : "no"} · muñeca bajo la cara: ${belowFace ? "sí" : "no"}`;
    }
  }


  /**
   * Detección de cámara temblando (el móvil sujeto en la mano en vez de
   * apoyado en algún sitio fijo) — ver el bloque CURL_CAMERA_SHAKE_* más
   * arriba. Se mide en el punto medio de los hombros porque no depende
   * de qué brazo está haciendo el curl: si TODO el cuerpo detectado
   * tiembla igual de un frame a otro, el problema es la cámara, no el
   * usuario.
   */
  checkCameraShake(shoulder, hip, torsoLength, now) {
    // BUG REAL (encontrado con los datos de Alex — 0 repeticiones
    // contadas incluso con el móvil totalmente quieto): esto se
    // normalizaba antes contra el ANCHO ENTRE HOMBROS (hombro izq vs.
    // hombro der), que funciona de frente pero se colapsa casi a CERO
    // de perfil (los dos hombros quedan casi superpuestos en la imagen,
    // uno detrás del otro) — al dividir por un número casi cero,
    // cualquier ruido normal de MediaPipe entre frame y frame (que
    // existe siempre, cámara quieta o no) se disparaba muy por encima
    // de CURL_CAMERA_SHAKE_FACTOR, así que "shaking" salía true casi
    // todos los frames y shapeOk nunca llegaba a true — el contador no
    // podía ni armarse. Arreglo: normalizar contra torsoLength (hombro-
    // cadera del MISMO lado, ya calculado en processDumbbellCurl), que
    // no se colapsa de perfil, y trackear el hombro del lado
    // seleccionado en vez del punto medio entre los dos hombros.
    let jitter = 0;
    if (this.curlShoulderMidPrev && torsoLength) {
      jitter = Math.hypot(shoulder.x - this.curlShoulderMidPrev.x, shoulder.y - this.curlShoulderMidPrev.y) / torsoLength;
    }
    this.curlShoulderMidPrev = { x: shoulder.x, y: shoulder.y };
    if (jitter >= CURL_CAMERA_SHAKE_FACTOR) {
      if (this.curlCameraShakeSince === null) this.curlCameraShakeSince = now;
    } else {
      this.curlCameraShakeSince = null;
    }
    return this.curlCameraShakeSince !== null && now - this.curlCameraShakeSince >= CURL_CAMERA_SHAKE_STABLE_MS;
  }

  processResult(result, now) {
    this.maybeAnnounceRestEnd(now);
    if (!result.landmarks || !result.landmarks.length) {
      if (this.debugEl) this.debugEl.textContent = "sin detección — ¿sales entero en el encuadre?";
      // Sentadillas y los abdominales tumbado no tienen su propio cierre
      // de serie (a diferencia de dominadas y fondos): sin esto, salir
      // del encuadre dejaba la serie abierta en silencio. Aquí también
      // sirve de "siguiente serie" sin moverte del suelo, para quien no
      // quiera levantarse entre series — basta con salir un momento del
      // encuadre y volver a entrar.
      if (GROUND_STYLE_COUNTERS.has(this.counterKey)) this.noteAbsence(now);
      // Plancha / plancha lateral: salir del encuadre también rompe la
      // postura, así que cierra el tramo aguantado por el mismo camino
      // que cualquier otra forma de romperla (ver notePostureBroken).
      if (CAMERA_POSTURE_COUNTERS.has(this.counterKey)) this.notePostureBroken(now, "No se te detecta en el encuadre.");
      return;
    }
    const lm = result.landmarks[0];

    // Cada ejercicio se detecta a su manera. Los fondos y las sentadillas
    // no necesitan calibrar ninguna barra, así que salen antes de todo eso.
    this.worldLm = (result.worldLandmarks && result.worldLandmarks[0]) ? result.worldLandmarks[0] : null;
    if (this.counterKey === "pushupfront") {
      this.processPushupFront(lm, now);
      return;
    }
    if (this.counterKey === "squatfront") {
      this.processSquatFront(lm, now);
      return;
    }
    if (this.counterKey === "dip") {
      this.processDip(lm, now);
      return;
    }
    if (this.counterKey === "pushup") {
      this.processPushup(lm, now);
      return;
    }
    if (this.counterKey === "inclinepushup") {
      this.processInclinePushup(lm, now);
      return;
    }
    if (this.counterKey === "benchdip") {
      this.processBenchDip(lm, now);
      return;
    }
    if (this.counterKey === "squat") {
      this.processSquat(lm, now);
      return;
    }
    if (this.counterKey === "splitsquat") {
      this.processSplitSquat(lm, now);
      return;
    }
    if (this.counterKey === "jumpingjack") {
      this.processJumpingJack(lm, now);
      return;
    }
    if (this.counterKey === "armcircles") {
      this.processArmCircles(lm, now);
      return;
    }
    if (this.counterKey === "necklateral") {
      this.processNeckLateral(lm, now);
      return;
    }
    if (this.counterKey === "neckturn") {
      this.processNeckTurn(lm, now);
      return;
    }
    if (this.counterKey === "neckcircles") {
      this.processNeckCircles(lm, now);
      return;
    }
    if (this.counterKey === "neckhalfturn") {
      this.processNeckHalfTurn(lm, now);
      return;
    }
    if (this.counterKey === "hiplateral") {
      this.processHipLateral(lm, now);
      return;
    }
    if (this.counterKey === "armscissors") {
      this.processArmScissors(lm, now);
      return;
    }
    if (this.counterKey === "legrotation") {
      this.processLegRotation(lm, now);
      return;
    }
    if (this.counterKey === "kneeraises") {
      this.processKneeRaises(lm, now);
      return;
    }
    if (this.counterKey === "heelkicks") {
      this.processHeelKicks(lm, now);
      return;
    }
    if (this.counterKey === "forearmrotation") {
      this.processForearmRotation(lm, now);
      return;
    }
    if (this.counterKey === "wristrotation") {
      this.processWristRotation(lm, now);
      return;
    }
    if (this.counterKey === "hipforwardback") {
      this.processHipForwardBack(lm, now);
      return;
    }
    if (this.counterKey === "crunch") {
      this.processCrunch(lm, now);
      return;
    }
    if (this.counterKey === "legraise") {
      this.processLegRaise(lm, now);
      return;
    }
    if (this.counterKey === "lsit") {
      this.processLSit(lm, now);
      return;
    }
    if (this.counterKey === "situp") {
      this.processSitup(lm, now);
      return;
    }
    if (this.counterKey === "scissor") {
      this.processScissor(lm, now);
      return;
    }
    if (this.counterKey === "doublecrunch") {
      this.processDoubleCrunch(lm, now);
      return;
    }
    if (this.counterKey === "archerpullup") {
      this.processArcherPullup(lm, now);
      return;
    }
    if (this.counterKey === "dumbbellcurl") {
      this.processDumbbellCurl(lm, now);
      return;
    }
    if (CAMERA_POSTURE_COUNTERS.has(this.counterKey)) {
      this.processPosture(lm, now);
      return;
    }

    const nose = lm[NOSE];
    const lShoulder = lm[L_SHOULDER];
    const rShoulder = lm[R_SHOULDER];
    const lElbow = lm[L_ELBOW];
    const rElbow = lm[R_ELBOW];
    const lWrist = lm[L_WRIST];
    const rWrist = lm[R_WRIST];
    const shoulderWidth = Math.hypot(lShoulder.x - rShoulder.x, lShoulder.y - rShoulder.y);
    const y = nose.y; // 0 = arriba del todo del encuadre, 1 = abajo del todo
    const wristMidY = (lWrist.y + rWrist.y) / 2;
    const elbowMidY = (lElbow.y + rElbow.y) / 2;
    const wristVisible = ((lWrist.visibility ?? 1) + (rWrist.visibility ?? 1)) / 2 > 0.4;
    const elbowVisible = ((lElbow.visibility ?? 1) + (rElbow.visibility ?? 1)) / 2 > 0.4;

    const shoulderMidYRaw = (lShoulder.y + rShoulder.y) / 2;
    // detección de "brazos en alto" usando la escala del frame actual
    // (para poder usarla ANTES de tener una calibración de referencia).
    // Si la muñeca se ve bien, manda ella sola (si la muñeca está claramente
    // abajo, un codo todavía algo elevado ya no debe contar como "colgado").
    // El codo solo se usa como reserva cuando no se ve bien la muñeca.
    const armsUpNow = wristVisible
      ? wristMidY < shoulderMidYRaw - HANG_MARGIN_FACTOR * shoulderWidth
      : elbowVisible && elbowMidY < shoulderMidYRaw - HANG_MARGIN_FACTOR * shoulderWidth;
    // Distinto de armsUpNow (ver RELEASE_MARGIN_FACTOR): solo esto cuenta
    // como "te has soltado de la barra de verdad" para cerrar la serie.
    const armsClearlyReleased = wristVisible
      ? wristMidY > shoulderMidYRaw + RELEASE_MARGIN_FACTOR * shoulderWidth
      : elbowVisible && elbowMidY > shoulderMidYRaw + RELEASE_MARGIN_FACTOR * shoulderWidth;

    if (this.prepping) {
      const waitedSeconds = Math.floor((now - this.prepStartTs) / 1000);
      // La primera vez en toda la sesión que se te ve lo bastante (muñeca
      // o codo visibles) para intentar detectarte, un aviso de que ya
      // puedes empezar — en las siguientes series no hace falta
      // repetirlo, ya sabes cómo colocarte.
      if ((wristVisible || elbowVisible) && !this.startupVoiceGiven) {
        this.startupVoiceGiven = true;
        this.announceStatus("¡Listo! Cuélgate de la barra con los brazos estirados para empezar.", "startup_ready", "Cuélgate de la barra.");
      }

      if (armsUpNow) {
        if (this.hangStableSince === null) this.hangStableSince = now;
        if (now - this.hangStableSince >= this.hangStableMs) {
          // Llevas ya un ratito con los brazos en alto de verdad -> calibra ya,
          // da igual si has tardado 3 segundos o 30 en llegar a la barra.
          this.prepping = false;
          this.calibrating = true;
          this.calibrationStartTs = now;
          this.calibrationSamples = [];
        } else {
          this.setStatus("Te veo colgado… confirmando (no te muevas)");
        }
      } else {
        this.hangStableSince = null;
        this.setStatus(
          waitedSeconds < 8
            ? "Ve a la barra y cuélgate con los brazos estirados…"
            : `Esperando a verte colgado (llevas ${waitedSeconds}s)… comprueba que la cámara vea tus brazos y hombros enteros`
        );
      }
      if (this.debugEl) {
        this.debugEl.textContent = `brazos en alto: ${armsUpNow ? "sí" : "no"} | espera: ${waitedSeconds}s`;
      }
      return;
    }

    if (this.calibrating) {
      // Si en medio de la calibración bajas los brazos (falsa alarma),
      // aborta y vuelve a esperar en vez de calibrar con datos malos.
      if (!armsUpNow) {
        this.prepping = true;
        this.calibrating = false;
        this.hangStableSince = null;
        this.prepStartTs = now;
        this.calibrationSamples = [];
        return;
      }
      // Para calibrar la altura de "la barra" usamos la muñeca si se ve
      // bien; si no, el codo (menos preciso, pero mucho más fiable que los
      // dedos, que MediaPipe no trackea bien cuando están curvados
      // agarrando algo — probado, y hacía que la barra quedara mal puesta).
      const barRefY = wristVisible ? wristMidY : elbowMidY;
      this.calibrationSamples.push({ y, shoulderWidth, barRefY });
      const elapsed = now - this.calibrationStartTs;
      const remaining = Math.max(0, Math.ceil((this.calibrationMs - elapsed) / 1000));
      this.setStatus(`Calibrando, quédate colgado y quieto… (${remaining || 1}s)`);
      if (elapsed >= this.calibrationMs) {
        const ys = this.calibrationSamples.map((s) => s.y).sort((a, b) => a - b);
        const ws = this.calibrationSamples.map((s) => s.shoulderWidth).sort((a, b) => a - b);
        const wy = this.calibrationSamples.map((s) => s.barRefY).sort((a, b) => a - b);
        this.shoulderWidth = ws[Math.floor(ws.length / 2)];
        this.localBottomY = ys[Math.floor(ys.length / 2)];
        this.localTopY = this.localBottomY;
        // altura de la barra = altura de tu muñeca al colgar, con un
        // empujón extra hacia arriba (BAR_OFFSET_FACTOR) para que la línea
        // cuadre mejor con la barra real (agarras por encima de la muñeca).
        // No hay forma de saber tu escala real en cm sin un objeto de
        // referencia, pero con un ancho de hombros típico (~35-40cm) un
        // factor de 0.05 equivale a ~2cm. Sube/baja el número si hace falta.
        this.barY = wy[Math.floor(wy.length / 2)] - BAR_OFFSET_FACTOR * this.shoulderWidth;
        this.calibrating = false;
        this.repStartTime = now;
        this.lastRepTime = now;
        this.restAlerted = false;
        this.updateSetDisplay();
        this.logScissor(`[CALIBRADO] barra_y=${this.barY.toFixed(3)} hombros=${this.shoulderWidth.toFixed(3)}`);
        if (this.exactReps && this.counterKey === "pullup") _pullupCalibCache = { shoulderWidth: this.shoulderWidth, barY: this.barY, localBottomY: this.localBottomY };
        // Si el descanso obligatorio (MIN_REST_MS) todavía no ha pasado
        // desde que se cerró la serie anterior, no se anuncia "empieza"
        // aunque ya estés calibrada/o y colgada/o -- decirlo aquí
        // contradice al propio descanso obligatorio (countRep ya bloquea
        // en silencio cualquier intento de contar antes de tiempo, y
        // announceRestBlocked() lo explica si insistes). El aviso real de
        // que ya puedes empezar lo da tickRestTimer en cuanto el descanso
        // termina de verdad (ver pendingHangReminder).
        if (this.setClosedAt === null || now - this.setClosedAt >= MIN_REST_MS) {
          this.announceStatus("¡Listo! Empieza a hacer dominadas.");
        }
      }
      return;
    }

    if (!this.shoulderWidth || this.barY === null) return;

    const scaleChange = Math.abs(shoulderWidth - this.shoulderWidth) / this.shoulderWidth;
    const scaleOk = scaleChange < SCALE_TOLERANCE;

    if (!armsUpNow || !scaleOk) {
      // No pareces estar colgado de la barra (o te has acercado/alejado de
      // la cámara) — no cuentes nada de lo que pase ahora mismo, y cuando
      // vuelvas a agarrar la barra, empieza a medir desde cero otra vez.
      this.logScissor(
        `[frame descartado] brazos_arriba=${armsUpNow} escala_ok=${scaleOk} cambio_escala=${scaleChange.toFixed(2)}(máx ${SCALE_TOLERANCE}) ` +
        `estado=${this.state} reps_serie=${this.currentSetReps}`
      );
      // Solo se borran las referencias de la repeticion en curso si de
      // verdad no se ven los brazos arriba (soltaste la barra, saliste
      // del encuadre) -- si siguen arriba y solo ha fallado el cambio de
      // escala (motion blur de un tiron rapido), NO se tocan: reportado
      // en vivo -- si el salto de escala coincidia justo con el instante
      // de llegar arriba del todo, el siguiente frame valido tomaba esa
      // posicion ALTA como nuevo "punto de abajo" y esa repeticion se
      // perdia sin contarse. Aqui se descarta SOLO este frame, no el
      // progreso de la repeticion.
      if (!armsUpNow) {
        this.localBottomY = null;
        this.localTopY = null;
        this.liftoffTime = null;
      }

      if (armsClearlyReleased) {
        // Te has soltado de la barra de verdad (bajaste los brazos, no es
        // solo que te acercaras/alejaras de la cámara ni que estés
        // aguantando arriba a media dominada): esto es el final de la
        // serie en curso. Pero solo lo damos por bueno si se mantiene un
        // ratito seguido — un solo frame ruidoso (oclusión, ángulo raro
        // agarrando la barra) no debe cerrar la serie por error.
        if (this.armsDownSince === null) this.armsDownSince = now;
        if (now - this.armsDownSince >= ARMS_DOWN_STABLE_MS && this.currentSetReps > 0) {
          const closedReps = this.currentSetReps;
          this.armsDownSince = null;
          // El aviso de descanso obligatorio SÍ tiene que oírse — por eso
          // va antes de silenciar la voz (restVoiceQuiet), no después.
          // setClosedAt lo marca beginPrep() justo debajo (currentSetReps
          // todavía es > 0 en este punto).
          // El "cuélgate otra vez" ya NO se dice aquí — se dice cuando el
          // descanso obligatorio de verdad termina (ver tickRestTimer /
          // pendingHangReminder): decirlo ahora, con 90s de descanso todavía
          // por delante, no tiene sentido.
          this.pendingHangReminder = true;
          this.announceSetComplete(`Serie de ${closedReps}`, "");
          this.restVoiceQuiet = true;
          this.beginPrep();
          return;
        }
      } else {
        // Sin señal clara de que te hayas soltado (scaleOk falló con los
        // brazos arriba, o estás en la zona ambigua de "aguantando arriba":
        // ni armsUpNow ni armsClearlyReleased) — no cuenta como fin de
        // serie, reinicia el contador de "brazos abajo".
        this.armsDownSince = null;
      }

      if (this.debugEl) {
        this.debugEl.textContent = !armsUpNow
          ? "esperando a que agarres la barra (brazos en alto)…"
          : "distancia a la cámara cambió demasiado, recalibra si sigue así";
      }
      return;
    }

    this.armsDownSince = null;

    const moveThresh = MOVE_FACTOR * this.shoulderWidth;
    const barThresh = this.barY + BAR_MARGIN_FACTOR * this.shoulderWidth;

    if (this.state === "down") {
      // sigue bajando (o igual) -> este es el nuevo punto de referencia "abajo",
      // y todavia no has "despegado" (reinicia la marca de despegue)
      if (this.localBottomY === null || y > this.localBottomY) {
        this.localBottomY = y;
        this.liftoffTime = null;
      }
      const risenFromBottom = this.localBottomY - y;

      // primer indicio de que te has empezado a mover de verdad
      if (this.liftoffTime === null && risenFromBottom > LIFTOFF_FACTOR * this.shoulderWidth) {
        this.liftoffTime = now;
      }

      const reachedBar = y <= barThresh;
      if (reachedBar && risenFromBottom > moveThresh) {
        this.state = "up";
        this.localTopY = y;
        this.repStartTime = this.liftoffTime ?? now;
      }
    } else {
      // state === "up": sigue subiendo (o igual) -> nuevo punto de referencia "arriba"
      if (this.localTopY === null || y < this.localTopY) {
        this.localTopY = y;
      }
      const fallenFromTop = y - this.localTopY;
      if (fallenFromTop > moveThresh) {
        // ha vuelto a bajar lo suficiente -> repetición completa
        this.logScissor(`[REP intentada] duración=${((now - this.repStartTime) / 1000).toFixed(2)}s`);
        this.countRep((now - this.repStartTime) / 1000, now, "Dominada");
        this.state = "down";
        this.localBottomY = y;
      }
    }

    if (this.debugEl) {
      this.debugEl.textContent =
        `estado: ${this.state} | nariz-barra: ${((y - this.barY) / this.shoulderWidth).toFixed(2)} ` +
        `(umbral ${BAR_MARGIN_FACTOR}) | hombros: ${this.shoulderWidth.toFixed(3)}`;
    }
    this.logScissor(
      `estado=${this.state} nariz_y=${y.toFixed(3)} barra_y=${this.barY.toFixed(3)} dist_barra=${((y - this.barY) / this.shoulderWidth).toFixed(2)}(umbral ${BAR_MARGIN_FACTOR}) ` +
      `hombros=${this.shoulderWidth.toFixed(3)} abajo_ref=${this.localBottomY === null ? "-" : this.localBottomY.toFixed(3)} arriba_ref=${this.localTopY === null ? "-" : this.localTopY.toFixed(3)} ` +
      `despegue=${this.liftoffTime === null ? "no" : "sí"}`
    );
  }

  tickRestTimer() {
    // El cronómetro de sesión y el de descanso tienen que seguir corriendo
    // aunque estés en "prepping" (esperando a colgarte) o calibrando: es
    // justo el rato de descanso entre series, no hay motivo para congelarlos.
    if (!this.running || !this.sessionStart) return;
    const now = performance.now();
    this.timerEl.textContent = this.formatTime((now - this.sessionStart) / 1000);

    if (this.lastRepTime === null) return;
    const restSeconds = (now - this.lastRepTime) / 1000;
    this.restEl.textContent = this.formatTime(restSeconds);

    if (restSeconds >= REST_ALERT_SECONDS && !this.restAlerted && !NO_REST_COUNTERS.has(this.counterKey)) {
      this.restAlerted = true;
      this.restAlertsTriggered += 1;
      // Han pasado los 1:30 de descanso: a partir de aquí la voz ya
      // puede volver a hablar (este mismo aviso incluido).
      this.restVoiceQuiet = false;
      beep();
      if (this.pendingHangReminder) {
        this.pendingHangReminder = false;
        this.announceStatus("⏰ ¡Descanso acabado! Cuélgate de la barra para empezar la siguiente serie…");
      } else {
        this.announceStatus("⏰ ¡Descanso acabado! Volviendo a calibrar para la siguiente serie…");
      }
      this.beginPrep();
    }
  }

  formatTime(totalSeconds) {
    const s = Math.max(0, Math.floor(totalSeconds));
    const m = Math.floor(s / 60);
    const r = s % 60;
    return `${m}:${String(r).padStart(2, "0")}`;
  }

  stopCamera() {
    if (!this.running && !this.stream && !this.poseLandmarker) return; // ya estaba parada — nada que hacer
    this.running = false;
    // Sales de la pantalla de la cámara: la voz se calla con ella, no se
    // queda hablando de un ejercicio que ya no ves (ver stopSpeaking()).
    stopSpeaking();
    if (this.restIntervalId) clearInterval(this.restIntervalId);
    if (this.stream) {
      this.stream.getTracks().forEach((t) => t.stop());
      this.stream = null;
    }
    if (this.poseLandmarker) {
      try {
        this.poseLandmarker.close();
      } catch (e) {
        // Si ya estaba cerrado (llamar close() dos veces según la
        // versión de MediaPipe puede tirar), no es un fallo real — solo
        // asegúrate de no dejarlo a medias silenciosamente.
        console.warn("poseLandmarker.close() en una cámara ya parada:", e);
      }
      this.poseLandmarker = null;
    }
  }

  async finish() {
    const isPosture = CAMERA_POSTURE_COUNTERS.has(this.counterKey);
    if (isPosture) {
      if (this.totalHeldSeconds === 0 && this.currentHoldSeconds === 0 &&
          !confirm("No se ha registrado ningún tiempo aguantado. ¿Guardar la sesión igualmente?")) {
        return;
      }
    } else if (this.reps === 0 && !confirm("No se ha contado ninguna dominada. ¿Guardar la sesión igualmente?")) {
      return;
    }
    this.finishBtn.disabled = true;
    this.finishBtn.textContent = "Guardando…";

    // Cierra la serie que estuviera en curso (si tenía reps) antes de mandar los datos.
    if (this.currentSetReps > 0) {
      this.sets.push({ reps: this.currentSetReps, durations: [...this.currentSetDurations] });
      this.currentSetReps = 0;
      this.currentSetDurations = [];
    }
    // Plancha / plancha lateral: mismo cierre, pero para el tramo
    // aguantado en curso (ver _flushPostureHold).
    if (isPosture) this._flushPostureHold();

    const sessionDuration = this.sessionStart ? (performance.now() - this.sessionStart) / 1000 : 0;
    this.stopCamera();

    const payload = {
      total_reps: this.reps,
      rep_durations: this.repDurations,
      // Plancha / plancha lateral: el tiempo que cuenta es lo REALMENTE
      // aguantado (totalHeldSeconds, suma de cada tramo con la postura
      // correcta), no el reloj de pared de toda la sesión — si has
      // parado la cámara un rato entre tramos, ese hueco no cuenta.
      // achievement_pct (ver WorkoutSession.models) ya sabe comparar esto
      // contra target_seconds*target_sets sin ningún cambio en el backend.
      session_duration_seconds: isPosture ? Math.round(this.totalHeldSeconds) : Math.round(sessionDuration),
      rest_alerts_triggered: this.restAlertsTriggered,
      sets: this.sets,
      total_sets: this.sets.length,
    };

    // Cuando esto se reproduce dentro de la sesión de un plan
    // (plan-session.js), es esa pantalla la que decide qué hacer con el
    // resultado — anotarlo y pasar al siguiente ejercicio, no guardar y
    // salir. Suelto (task_workout.html), sigue el fetch de siempre.
    if (typeof window.__workoutSubmit === "function") {
      try {
        await window.__workoutSubmit(payload);
      } catch (err) {
        // Sin este catch, un fallo aquí dejaba el botón en "Guardando…"
        // para siempre sin ningún error visible — silencioso del todo.
        console.error("Error en __workoutSubmit:", err);
        alert("Algo ha fallado al pasar al siguiente ejercicio. Prueba a recargar la página (lo hecho hasta ahora no se ha guardado todavía).");
        this.finishBtn.disabled = false;
        this.finishBtn.textContent = "Terminar sesión";
      }
      return;
    }

    try {
      const resp = await fetch(this.saveUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCookie("csrftoken"),
        },
        body: JSON.stringify(payload),
      });
      const data = await resp.json();
      if (data.ok) {
        window.location.href = data.redirect_url;
      } else {
        alert("No se pudo guardar la sesión: " + (data.error || "error desconocido"));
        this.finishBtn.disabled = false;
        this.finishBtn.textContent = "Terminar sesión";
      }
    } catch (err) {
      console.error(err);
      alert("No se pudo guardar la sesión (sin conexión?). Los datos no se han perdido de la pantalla, prueba de nuevo.");
      this.finishBtn.disabled = false;
      this.finishBtn.textContent = "Terminar sesión";
    }
  }
}

/**
 * Arranca el contador sobre el #workout-root que haya en pantalla.
 * Exportado para que plan-session.js pueda llamarlo por cada ejercicio
 * de cámara de una sesión de plan, en vez de solo al cargar la página.
 */
export function startWorkout() {
  const root = el("workout-root");
  if (!root) return null;
  const session = new WorkoutSession(root);
  session.start();
  return session;
}

// Uso suelto (task_workout.html): arranca solo al cargar la página.
// Cuando lo importa plan-session.js, __LIBRETA_EMBEDDED__ está puesto y
// esto no hace nada — el arranque lo decide esa pantalla, ejercicio a
// ejercicio. Se comprueba document.readyState porque, al ser un script
// de tipo módulo, se ejecuta DESPUÉS de parsear el HTML — a veces antes
// de "DOMContentLoaded", a veces después. Esperar el evento a ciegas es
// una carrera que a veces se pierde y deja la cámara sin encender.
if (!window.__LIBRETA_EMBEDDED__) {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startWorkout);
  } else {
    startWorkout();
  }
}

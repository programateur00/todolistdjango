/**
 * Reproductor de la sesión de un plan: circuito MIXTO, cronómetro y
 * cámara a la vez. Es la contrapartida web de session-runner.js (la
 * app móvil) — misma idea, mismo formato de datos, adaptado a que aquí
 * el guardado es un fetch normal con CSRF, no el cliente de API de la
 * app.
 *
 *   - mode "timed", sin counter_key de postura -> cuenta atrás a secas
 *   - mode "timed", con counter_key de postura (plancha, plancha
 *     lateral…) -> cuenta atrás + cámara verificando la postura, igual
 *     que circuit.js (ver runTimerWithPosture) — antes esto no existía
 *     aquí y una plancha dentro de un plan se jugaba como un cronómetro
 *     ciego, sin comprobar nada con la cámara, a diferencia de un
 *     circuito suelto o de la app móvil (session-runner.js), que sí lo
 *     hacían. Se ha traído la misma función.
 *   - mode "pose"   (dominadas, fondos) -> cámara contando reps
 *     (el conteo de verdad lo sigue haciendo workout.js sin tocarlo;
 *     aquí solo se le engancha vía window.__workoutSubmit)
 */
import {
  checkPlankPosture, checkSidePlankPosture, checkWallSitPosture,
  checkKneeHoldBarPosture, checkHandstandPosture, createLSitHoldChecker, createSupermanHoldChecker,
  speakOut, numeroEnPalabras, isVoiceEnabled, REP_VOICE_RATE, exportDebugLogText, clearVoiceTransitionMute,
} from "./workout.js";
import { PersonGate } from "./workout.js";
import { MEDIAPIPE_BUNDLE_URL, MEDIAPIPE_WASM_BASE_URL, MODEL_URL } from "./mediapipe-vendor.js";

(function () {
  "use strict";

  const root = document.getElementById("circuit-root");
  if (!root) return;

  const items = JSON.parse(root.dataset.items || "[]");
  const saveUrl = root.dataset.saveUrl;
  const cancelUrl = root.dataset.cancelUrl;
  const csrfToken = (root.querySelector("[name=csrfmiddlewaretoken]") || {}).value || "";

  const modeSelect = document.getElementById("circuit-mode-select");
  const playerHost = document.getElementById("session-player");

  const esc = (s) =>
    String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function beep(freq, duration) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq || 880;
      osc.connect(gain);
      gain.connect(ctx.destination);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      osc.start();
      osc.stop(ctx.currentTime + (duration || 0.15));
    } catch (e) {
      /* si el navegador bloquea audio sin interacción previa, no pasa nada */
    }
  }

  function fmt(s) {
    const m = Math.floor(s / 60);
    const r = s % 60;
    return m > 0 ? `${m}:${String(r).padStart(2, "0")}` : String(r);
  }

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  let sequence = [];
  let index = 0;
  let breakdown = [];
  const sessionStartedAt = Date.now(); // cronómetro total de la sesión (se manda al guardar)
  let timerId = null;
  let paused = false;
  let workoutSession = null;

  // Series del ejercicio CRONOMETRADO en curso (2026-10-01, a petición de
  // Alex; mismo comportamiento que session-runner.js en la app móvil):
  // antes un aguante de plan (plancha, pino, silla en pared...) era UNA
  // sola cuenta sin importar target_sets -- "3 series al fallo" hacía una
  // y pasaba al siguiente. Ahora se repite target_sets veces con descanso
  // entre series, igual que los de repeticiones (workout.js).
  // SET_REST_SECONDS = REST_ALERT_SECONDS de workout.js. Solo items con
  // target_source === "plan".
  const SET_REST_SECONDS = 60;
  // "Al fallo" con cámara: la serie se da por terminada sola cuando la
  // postura lleva FAILURE_POSTURE_LOST_SECONDS seguidos rota, siempre que
  // antes se hubieran aguantado FAILURE_MIN_HOLD_SECONDS.
  const FAILURE_POSTURE_LOST_SECONDS = 3;
  const FAILURE_MIN_HOLD_SECONDS = 2;
  let setsTotal = 1;
  let setNo = 1;
  let setsDone = 0;
  let heldTotal = 0;
  let setSeconds = []; // segundos aguantados en cada serie del ejercicio en curso

  // Voz encolada (flush:false) -- "Toca X", "la última vez aguantaste Y" -- que la cuenta
  // del cronómetro (flush:true, cada segundo) cortaba en el segundo 1: el aviso de lo que
  // aguantaste la última vez casi nunca se oía entero. Se estima cuánto dura lo encolado
  // y la cuenta en voz alta espera a que acabe (la pantalla sigue contando).
  let speechBusyUntil = 0;
  function noteQueuedSpeech(text, { reset = false } = {}) {
    const now = performance.now();
    speechBusyUntil = (reset ? now : Math.max(now, speechBusyUntil)) + 400 + String(text).length * 90;
  }
  function countAloudOk() {
    return isVoiceEnabled() && performance.now() >= speechBusyUntil;
  }

  // "45 segundos" / "1 minuto y 5 segundos" -- para "la última vez aguantaste X"
  // en los ejercicios cronometrados (item.last_seconds, ver Plan.session_items()).
  function secondsLabel(n) {
    const t = Math.max(0, Math.round(n));
    if (t < 60) return `${t} ${t === 1 ? "segundo" : "segundos"}`;
    const m = Math.floor(t / 60), s = t % 60;
    const mm = `${m} ${m === 1 ? "minuto" : "minutos"}`;
    return s ? `${mm} y ${s} ${s === 1 ? "segundo" : "segundos"}` : mm;
  }
  /** Lo que aguantaste en ESTA serie la última vez (item.last_seconds,
   *  [45, 40, 38]) o null si no hay historial. Sin parte "Serie N" si el
   *  ejercicio solo tiene una serie. */
  function lastSecondsText(item, { spoken = false } = {}) {
    const last = item && item.last_seconds;
    if (!Array.isArray(last) || !last.length) return null;
    const i = setNo - 1; // serie en curso, base 0
    const sep = spoken ? ". " : ": ";
    const cap = spoken ? "La" : "la";
    // Última serie al fallo: ya se rotula/anuncia como "Última serie de este
    // ejercicio" (setText), así que no se repite como "Serie N".
    const isLast = setNo === setsTotal && setsTotal > 1 && item && !item.work;
    const pre = isLast ? "" : `Serie ${i + 1}${sep}`;
    if (i >= last.length) {
      return `${pre}${cap} última vez hiciste ${last.length} ${last.length === 1 ? "serie" : "series"}${spoken ? "." : ", esta es extra"}`;
    }
    const held = `${cap} última vez aguantaste ${secondsLabel(last[i])}`;
    return setsTotal > 1 ? `${pre}${held}${spoken ? " en esta serie." : ""}` : `${held}${spoken ? "." : ""}`;
  }
  function lastSecondsHintHtml(item) {
    const t = lastSecondsText(item);
    return t ? `<p class="circuit__side-hint run-last-hint">${esc(t)}</p>` : "";
  }
  /** Lo dice por voz al empezar cada serie cronometrada (sin cortar lo que ya sonara). */
  function announceLastSeconds(item) {
    if (!isVoiceEnabled()) return;
    const t = lastSecondsText(item, { spoken: true });
    if (t) {
      noteQueuedSpeech(t);
      speakOut(t, { flush: false });
    }
  }

  function current() {
    return sequence[index];
  }
  function hasNext() {
    return index < sequence.length - 1;
  }
  function progressBase() {
    return `Ejercicio ${index + 1} de ${sequence.length}`;
  }
  // "Al fallo" (item.work vacío): la última serie se anuncia como tal en
  // vez de "Serie N de N".
  function setText(n, item) {
    const last = n === setsTotal && setsTotal > 1 && item && !item.work;
    return last ? "Última serie de este ejercicio" : `Serie ${n} de ${setsTotal}`;
  }
  function progressLabel() {
    return setsTotal > 1 ? `${progressBase()} · ${setText(setNo, current())}` : progressBase();
  }
  function record(entry) {
    breakdown.push(entry);
  }

  // Ver checkPlankPosture/etc. importadas arriba — mismo set que
  // circuit.js.
  const POSTURE_COUNTERS = new Set(["plank", "sideplank", "wallsit", "kneeholdbar", "handstand", "lsithold", "supermanhold"]);

  const STRETCH_FIXED_COUNTERS = new Set(["armcrossstretch", "tricepsoverheadstretch", "seatedhamstringstretch", "standingquadstretch"]);

  /** Series que tiene que hacer un ejercicio CRONOMETRADO (aguante o
   *  cuenta atrás). 1 = como siempre (una sola cuenta). Los de cámara
   *  (mode "pose") llevan sus series dentro de workout.js. */
  function plannedSets(item) {
    if (item.target_source !== "plan" || item.mode === "pose") return 1;
    if (STRETCH_FIXED_COUNTERS.has(item.counter_key)) return 1;
    return Math.max(1, parseInt(item.target_sets, 10) || 1);
  }

  function runCurrent() {
    const item = current();
    if (!item) return finish();
    setsTotal = plannedSets(item);
    setNo = 1;
    setsDone = 0;
    heldTotal = 0;
    setSeconds = [];
    // Dice el nombre del ejercicio al empezar (tren superior o inferior).
    clearVoiceTransitionMute();
    if (isVoiceEnabled()) {
      // El primero del plan dice "Toca ..."; los siguientes, "Ahora toca ...".
      const toca = index === 0 ? "Toca" : "Ahora toca";
      const frase = setsTotal > 1 ? `${toca} ${item.name}. Serie 1 de ${setsTotal}` : `${toca} ${item.name}`;
      noteQueuedSpeech(frase);
      speakOut(frase, { flush: false });
    }
    runSet(item);
  }

  /** Arranca UNA serie (o el ejercicio entero, si solo tiene una). */
  function runSet(item) {
    if (item.mode !== "pose") announceLastSeconds(item);
    if (item.mode === "pose") runCamera(item);
    else if (POSTURE_COUNTERS.has(item.counter_key)) runTimerWithPosture(item);
    else runTimer(item);
  }

  // -------------------------------------------- series de un cronometrado

  /** Cierra UNA serie cronometrada con `seconds` aguantados. Si quedan
   *  series por hacer, descanso (SET_REST_SECONDS) y la siguiente; si era
   *  la última (o `skipExercise`), guarda el ejercicio entero -- segundos
   *  totales y series hechas -- y pasa solo al siguiente. */
  function finishTimedSet(item, seconds, { skipExercise = false, recordEmpty = false } = {}) {
    clearInterval(timerId);
    if (seconds > 0) {
      heldTotal += seconds;
      setsDone += 1;
      setSeconds.push(Math.round(seconds * 10) / 10);
    }
    if (!skipExercise && setNo < setsTotal) {
      const done = setNo;
      setNo += 1;
      runSetRest(item, done);
      return;
    }
    recordTimed(item, recordEmpty);
    advance();
  }

  /** "Terminar sesión antes" a mitad de un cronometrado: guarda lo que
   *  llevara y cierra todo. */
  function quitTimed(item, seconds, recordEmpty = false) {
    if (seconds > 0) {
      heldTotal += seconds;
      setsDone += 1;
      setSeconds.push(Math.round(seconds * 10) / 10);
    }
    recordTimed(item, recordEmpty);
    finish();
  }

  function recordTimed(item, recordEmpty = false) {
    if (heldTotal <= 0 && !recordEmpty) return;
    const entry = { exercise: item.slug, seconds: heldTotal };
    // "sets" solo en ejercicios de plan (el % de los "al fallo" se mide en
    // series hechas).
    if (item.target_source === "plan") entry.sets = setsDone;
    // Segundos de CADA serie: sirven para "la última vez aguantaste X".
    if (setSeconds.length) entry.set_seconds = [...setSeconds];
    record(entry);
  }

  /** Descanso ENTRE series del mismo ejercicio (el de entre ejercicios
   *  sigue siendo item.rest, ver advance()). */
  function runSetRest(item, doneNo) {
    if (isVoiceEnabled()) speakOut(`Serie ${doneNo} de ${setsTotal} terminada. Descanso.`, { flush: false });
    runRest(SET_REST_SECONDS, {
      nextItem: item,
      progress: `${progressBase()} · Serie ${doneNo} de ${setsTotal} hecha`,
      nextLabel: `Siguiente: ${setText(setNo, item).toLowerCase()} — ${item.name}`,
      onDone: () => {
        if (isVoiceEnabled()) {
          const frase = setText(setNo, item);
          noteQueuedSpeech(frase, { reset: true }); // flush:true corta lo anterior
          speakOut(frase, { flush: true });
        }
        runSet(item);
      },
      onSkipExercise: () => {
        recordTimed(item);
        advance();
      },
    });
  }

  // -------------------------------------------------------- cronómetro

  function runTimer(item) {
    // "Al fallo" (item.work vacío/null -- Plan.session_items(),
    // PROG_FAILURE): no hay segundos objetivo que contar hacia atrás --
    // se cuenta libremente hacia ADELANTE desde 0 hasta que el usuario
    // decida que ha llegado al fallo, igual que en session-runner.js
    // (móvil).
    // Estiramientos con cronómetro: 30 s fijos, y al cumplirse pasa solo al siguiente.
    const work = STRETCH_FIXED_COUNTERS.has(item.counter_key) ? 30 : item.work;
    const isFailure = !work;
    // ¿Quedan series después de esta? (ver plannedSets)
    const moreSets = setNo < setsTotal;
    playerHost.innerHTML = `
      <div class="circuit">
        <p class="circuit__progress">${esc(progressLabel())}</p>
        <h2 class="circuit__exercise-name">${esc(item.name)}</h2>
        <p class="circuit__phase circuit__phase--work">${isFailure ? "Al fallo" : "Trabajo"}</p>
        ${lastSecondsHintHtml(item)}
        <div class="circuit__timer" id="run-timer">${fmt(work || 0)}</div>
        <p class="circuit__next">${hasNext() ? `Siguiente: ${esc(sequence[index + 1].name)}` : "¡Último!"}</p>
        <div class="circuit__controls">
          <button type="button" class="workout__btn workout__btn--ghost" id="run-pause">Pausar</button>
          <button type="button" class="workout__btn workout__btn--primary" id="run-skip">${
            moreSets && isFailure ? "Serie hecha ▸" : hasNext() ? "Siguiente ▸" : "Terminar"
          }</button>
        </div>
        ${moreSets && isFailure ? `<button type="button" class="workout__btn workout__btn--ghost" id="run-skip-exercise">Saltar ejercicio ▸</button>` : ""}
        <button type="button" class="workout__btn workout__btn--subtle" id="run-quit">Terminar sesión antes</button>
        <button type="button" class="workout__btn workout__btn--ghost" id="run-debug-export">📋 Enviar registro de depuración</button>
        <p id="run-debug-export-status" class="workout__debug"></p>
      </div>`;

    let remaining = work;
    let elapsed = 0;
    let lastSpokenNumber = null; // último entero ya dicho, para no repetirlo en el mismo segundo
    const timerEl = document.getElementById("run-timer");
    paused = false;

    // Registro de depuración -- misma idea que this.scissorLog en
    // workout.js (ver exportDebugLogText), pero sin controller de
    // cámara: aquí no hay reps que contar, así que basta una línea por
    // segundo con lo que estaba pasando (cuánto llevaba, paused...).
    const debugLines = [];
    const DEBUG_LINES_MAX = 3600;
    const logDebugLine = (line) => {
      debugLines.push(`${elapsed}s ${line}`);
      if (debugLines.length > DEBUG_LINES_MAX) debugLines.shift();
    };

    clearInterval(timerId);
    timerId = setInterval(() => {
      if (paused) return;
      elapsed += 1;
      if (isFailure) {
        timerEl.textContent = fmt(elapsed);
        logDebugLine("al fallo (cuenta libre)");
        if (countAloudOk() && elapsed !== lastSpokenNumber) {
          lastSpokenNumber = elapsed;
          speakOut(numeroEnPalabras(elapsed), { rate: REP_VOICE_RATE });
        }
        return;
      }
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(timerId);
        logDebugLine(`objetivo cumplido (${work}s)`);
        beep(880, 0.2);
        // Con varias series: descanso y la siguiente; con una (o la
        // última): guarda y pasa solo al siguiente ejercicio.
        finishTimedSet(item, work);
        return;
      }
      logDebugLine(`restantes=${remaining}s de ${work}s`);
      if (remaining <= 3) beep(660, 0.1);
      // Cuenta atrás dicha en voz alta cada segundo — igual que ya hacía
      // runTimerWithPosture() más abajo (mismo motivo: se pidió poder
      // seguir un ejercicio cronometrado de oído, sin mirar la pantalla,
      // igual que ya se puede con las repeticiones).
      // Cada 5 segundos, no cada uno - dicho cada segundo la voz no daba
      // abasto (números solapándose/cortados a medias).
      if (countAloudOk() && remaining !== lastSpokenNumber) {
        lastSpokenNumber = remaining;
        speakOut(numeroEnPalabras(remaining), { rate: REP_VOICE_RATE });
      }
      timerEl.textContent = fmt(remaining);
    }, 1000);

    const pauseBtn = document.getElementById("run-pause");
    pauseBtn.addEventListener("click", () => {
      paused = !paused;
      pauseBtn.textContent = paused ? "Reanudar" : "Pausar";
      logDebugLine(paused ? "pausado" : "reanudado");
    });
    // Al fallo: el botón principal cierra ESTA serie (y con ella el
    // ejercicio si era la última). Con objetivo de segundos: sigue siendo
    // "saltar el ejercicio" entero, como siempre.
    document.getElementById("run-skip").addEventListener("click", () => {
      clearInterval(timerId);
      finishTimedSet(item, elapsed, { skipExercise: !isFailure });
    });
    document.getElementById("run-skip-exercise")?.addEventListener("click", () => {
      clearInterval(timerId);
      finishTimedSet(item, elapsed, { skipExercise: true });
    });
    document.getElementById("run-quit").addEventListener("click", () => {
      if (!confirm("¿Terminar la sesión ahora? Se guarda lo hecho hasta aquí.")) return;
      clearInterval(timerId);
      quitTimed(item, elapsed);
    });
    document.getElementById("run-debug-export").addEventListener("click", () => {
      exportDebugLogText({
        lines: debugLines,
        counterKey: item.counter_key || item.slug,
        statusEl: document.getElementById("run-debug-export-status"),
        platform: "web",
      });
    });
  }

  // ------------------------------------------------- cronómetro + postura
  //
  // Igual que circuit.js (ver ahí el porqué de cada cosa): plancha,
  // plancha lateral, sentado en pared, kneehold en barra y pino
  // llevan cámara comprobando la postura, no un cronómetro ciego. Y
  // llegar a item.work YA NO cierra el ejercicio solo — sigue contando
  // hacia ADELANTE por encima del objetivo (con voz), igual que
  // dominadas/fondos pueden seguir sumando reps por encima del 100%.

  async function runTimerWithPosture(item) {
    const checker =
      item.counter_key === "sideplank"
        ? checkSidePlankPosture
        : item.counter_key === "wallsit"
        ? checkWallSitPosture
        : item.counter_key === "kneeholdbar"
        ? checkKneeHoldBarPosture
        : item.counter_key === "handstand"
        ? checkHandstandPosture
        : item.counter_key === "supermanhold"
        ? createSupermanHoldChecker()
        : item.counter_key === "lsithold"
        ? createLSitHoldChecker()
        : checkPlankPosture;

    // "Al fallo" (item.work vacío/null -- PROG_FAILURE): sin objetivo de
    // tiempo, ni cuenta atrás ni aviso de "objetivo cumplido" tienen
    // sentido -- se cuenta libremente desde el principio y el botón
    // principal para avanzar está disponible desde ya (como en runCamera),
    // no escondido detrás de un objetivo que aquí no existe.
    const isFailure = !item.work;
    // Series (ver plannedSets/SET_REST_SECONDS): ¿esta no es la última?
    const moreSets = setNo < setsTotal;
    const multiSets = setsTotal > 1;

    playerHost.innerHTML = `
      <div class="circuit">
        <p class="circuit__progress">${esc(progressLabel())}</p>
        <h2 class="circuit__exercise-name">${esc(item.name)}</h2>
        <p class="circuit__phase circuit__phase--work">${isFailure ? "Al fallo" : "Trabajo"}</p>
        ${lastSecondsHintHtml(item)}
        <div class="workout__camera">
          <video id="posture-video" playsinline muted class="workout__video"></video>
          <canvas id="posture-canvas" class="workout__canvas"></canvas>
        </div>
        <p id="posture-status" class="workout__status">Preparando la cámara…</p>
        <p id="run-goal-banner" class="workout__goal-banner" hidden></p>
        <div class="circuit__timer" id="run-timer">${fmt(0)}</div>
        <p class="circuit__next">${hasNext() ? `Siguiente: ${esc(sequence[index + 1].name)}` : "¡Último!"}</p>
        <div class="circuit__controls">
          <button type="button" class="workout__btn ${isFailure ? "workout__btn--primary" : "workout__btn--ghost"}" id="run-skip">${
            isFailure ? (moreSets ? "Serie hecha ▸" : hasNext() ? "Siguiente ▸" : "Terminar") : "Saltar ▸"
          }</button>
        </div>
        ${isFailure && moreSets ? `<button type="button" class="workout__btn workout__btn--ghost" id="run-skip-exercise">Saltar ejercicio ▸</button>` : ""}
        <button type="button" class="workout__btn workout__btn--subtle" id="run-quit">Terminar sesión antes</button>
        <button type="button" class="workout__btn workout__btn--ghost" id="run-debug-export">📋 Enviar registro de depuración</button>
        <p id="run-debug-export-status" class="workout__debug"></p>
        <p class="workout__note">${
          isFailure
            ? `Aguanta hasta que ya no puedas: la serie se cierra sola si pierdes la postura unos segundos (o pulsa ${moreSets ? "«Serie hecha»" : "Siguiente/Terminar"}).${moreSets ? ` Después, descanso de ${SET_REST_SECONDS} s.` : hasNext() ? " Al terminar pasa solo al siguiente ejercicio." : ""}`
            : multiSets
            ? `Serie ${setNo} de ${setsTotal}: al llegar a 0 ${moreSets ? `descansas ${SET_REST_SECONDS} s y sigue la siguiente serie` : "pasa solo al siguiente ejercicio"}. La cuenta atrás se pausa sola mientras la postura no sea correcta.`
            : "La cuenta atrás se pausa sola mientras la postura no sea correcta. Si sigues después del objetivo, sigue sumando por encima del 100%."
        }</p>
      </div>`;

    let elapsed = 0;
    let postureOk = false;
    let goalReached = false;
    let lastSpokenNumber = null; // último entero (cuenta atrás o adelante) ya dicho, para no repetirlo en el mismo segundo
    let lastPostureDebug = ""; // valores medidos (angulos, etc.) del ultimo check, para el registro
    let lastPostureReason = ""; // último check.reason (o motivo de "no visible"), para el registro de depuración
    let running = true;
    let stream = null;
    let poseLandmarker = null;
    const timerEl = document.getElementById("run-timer");
    const statusEl = document.getElementById("posture-status");
    const goalBannerEl = document.getElementById("run-goal-banner");
    const skipBtn = document.getElementById("run-skip");
    const video = document.getElementById("posture-video");
    const canvas = document.getElementById("posture-canvas");

    // Registro de depuración -- ver exportDebugLogText en workout.js.
    // Aquí sí hay datos reales de postura por segundo (postureOk,
    // check.reason), a diferencia del cronómetro puro de runTimer().
    const debugLines = [];
    const DEBUG_LINES_MAX = 3600;
    const logDebugLine = (line) => {
      debugLines.push(`${elapsed}s ${line}`);
      if (debugLines.length > DEBUG_LINES_MAX) debugLines.shift();
    };

    function stopCamera() {
      running = false;
      if (stream) stream.getTracks().forEach((t) => t.stop());
      if (poseLandmarker) poseLandmarker.close();
    }

    // Para la cámara; el guardado y el paso a descanso/siguiente los hace
    // finishTimedSet (ver "series de un cronometrado").
    function stopThis() {
      clearInterval(timerId);
      stopCamera();
    }

    // Al fallo: el botón principal cierra ESTA serie. Con objetivo de
    // segundos: "Saltar"/"Siguiente" salta el ejercicio entero, como antes.
    skipBtn.addEventListener("click", () => {
      stopThis();
      finishTimedSet(item, elapsed, { skipExercise: !isFailure, recordEmpty: true });
    });
    document.getElementById("run-skip-exercise")?.addEventListener("click", () => {
      stopThis();
      finishTimedSet(item, elapsed, { skipExercise: true, recordEmpty: true });
    });
    document.getElementById("run-quit").addEventListener("click", () => {
      if (!confirm("¿Terminar la sesión ahora? Se guarda lo hecho hasta aquí.")) return;
      stopThis();
      quitTimed(item, elapsed, true);
    });
    document.getElementById("run-debug-export").addEventListener("click", () => {
      exportDebugLogText({
        lines: debugLines,
        counterKey: item.counter_key || item.slug,
        statusEl: document.getElementById("run-debug-export-status"),
        platform: "web",
      });
    });

    try {
      stream = await navigator.mediaDevices.getUserMedia({
        // Misma resolución que workout.js (ver ahí el porqué): 1280x720
        // en vez de 640x480, para que el seguimiento no se degrade a
        // cierta distancia de la cámara.
        video: { facingMode: "user", width: 1280, height: 720 }, audio: false,
      });
    } catch (err) {
      statusEl.textContent = "No se pudo acceder a la cámara — revisa los permisos del navegador. La cuenta atrás sigue sin comprobar la postura.";
      postureOk = true; // sin cámara, no bloquea el ejercicio — degrada a cronómetro normal
    }
    // Si mientras cargaba la cámara se pulsó "Serie hecha"/"Saltar"
    // (stopThis ya puso running=false y se pintó otra pantalla), esta
    // ejecución quedó obsoleta: se suelta la cámara y no se arranca nada --
    // si siguiera, pisaría el temporizador de la pantalla nueva.
    if (!running) {
      if (stream) stream.getTracks().forEach((t) => t.stop());
      return;
    }

    if (stream) {
      video.srcObject = stream;
      await video.play();
      if (!running) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;

      try {
        const { FilesetResolver, PoseLandmarker } = await import(MEDIAPIPE_BUNDLE_URL);
        const vision = await FilesetResolver.forVisionTasks(MEDIAPIPE_WASM_BASE_URL);
        poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
          baseOptions: { modelAssetPath: MODEL_URL, delegate: "GPU" },
          runningMode: "VIDEO", numPoses: 1, outputSegmentationMasks: true,
        });
      } catch (err) {
        statusEl.textContent = "No se pudo cargar el seguimiento de postura. La cuenta atrás sigue sin comprobarla.";
        postureOk = true;
        console.error(err);
      }
      if (!running) {
        // Obsoleta mientras cargaba el modelo (ver arriba).
        if (poseLandmarker) poseLandmarker.close();
        stream.getTracks().forEach((t) => t.stop());
        return;
      }

      if (poseLandmarker) {
        const personGate = new PersonGate(); // 2026-10-08: solo se miden posturas de la persona confirmada (ver PersonGate en workout.js)
        const loop = () => {
          if (!running) return;
          const frameNow = performance.now();
          const result = poseLandmarker.detectForVideo(video, frameNow);
          const hasPoseNow = !!(result.landmarks && result.landmarks.length);
          if (hasPoseNow) personGate.sampleMask(result, frameNow);
          const person = hasPoseNow ? personGate.check(result.landmarks[0], frameNow) : null;
          if (typeof result.close === "function") result.close(); // libera las máscaras de persona
          if (person && person.ok) {
            const check = checker(result.landmarks[0]);
            postureOk = check.ok;
            lastPostureReason = check.ok ? "" : check.reason;
            lastPostureDebug = check.debug ? Object.entries(check.debug).map(([k, v]) => `${k}=${v ?? "-"}`).join(" ") : "";
            statusEl.textContent = check.ok ? "Postura correcta — aguanta." : `⚠️ ${check.reason}`;
          } else {
            postureOk = false;
            lastPostureReason = "no visible";
            statusEl.textContent = "No se te ve — sal en el encuadre.";
          }
          requestAnimationFrame(loop);
        };
        loop();
      }
    }

    clearInterval(timerId);
    let lostSeconds = 0; // segundos seguidos con la postura rota (solo para cerrar una serie al fallo)
    timerId = setInterval(() => {
      if (!postureOk) {
        lostSeconds += 1;
        logDebugLine(`pausado (postura no válida: ${lastPostureReason || "?"}) ${lastPostureDebug}`);
        // Al fallo no hay objetivo que dé la serie por cumplida: como en
        // los ejercicios de repeticiones, se cierra sola cuando ya no
        // aguantas la postura (tras haber aguantado algo).
        if (isFailure && elapsed >= FAILURE_MIN_HOLD_SECONDS && lostSeconds >= FAILURE_POSTURE_LOST_SECONDS) {
          logDebugLine(`serie al fallo cerrada: postura rota ${lostSeconds}s tras ${elapsed}s`);
          stopThis();
          beep(880, 0.2);
          finishTimedSet(item, elapsed, { recordEmpty: true });
        }
        return; // pausado mientras la postura no sea válida
      }
      lostSeconds = 0;
      elapsed += 1;

      if (isFailure) {
        timerEl.textContent = fmt(elapsed);
        logDebugLine(`al fallo (cuenta libre), postura ok ${lastPostureDebug}`);
        if (countAloudOk() && elapsed !== lastSpokenNumber) {
          lastSpokenNumber = elapsed;
          speakOut(numeroEnPalabras(elapsed), { rate: REP_VOICE_RATE });
        }
        return;
      }

      if (!goalReached && elapsed < item.work) {
        const remaining = item.work - elapsed;
        timerEl.textContent = fmt(remaining);
        logDebugLine(`restantes=${remaining}s de ${item.work}s, postura ok ${lastPostureDebug}`);
        if (remaining <= 3) beep(660, 0.1);
        // Cada 5 segundos, no cada uno - ver nota junto a runTimer() más
        // arriba.
        if (countAloudOk() && remaining !== lastSpokenNumber) {
          lastSpokenNumber = remaining;
          speakOut(numeroEnPalabras(remaining), { rate: REP_VOICE_RATE });
        }
        return;
      }

      if (!goalReached) {
        if (multiSets) {
          // Objetivo cumplido con varias series: descanso y la siguiente
          // (o, la última, pasa sola al siguiente ejercicio).
          logDebugLine(`objetivo cumplido (${item.work}s), serie ${setNo} de ${setsTotal}`);
          beep(880, 0.2);
          stopThis();
          finishTimedSet(item, item.work, { recordEmpty: true });
          return;
        }
        goalReached = true;
        lastSpokenNumber = 0;
        logDebugLine(`objetivo cumplido (${item.work}s)`);
        beep(880, 0.2);
        if (isVoiceEnabled()) speakOut(numeroEnPalabras(0), { flush: true, rate: REP_VOICE_RATE });
        if (goalBannerEl) {
          goalBannerEl.hidden = false;
          goalBannerEl.textContent = `🎯 ¡Objetivo cumplido! (${fmt(item.work)}) Sigue si quieres, o termina cuando acabes.`;
        }
        skipBtn.textContent = hasNext() ? "Siguiente ▸" : "Terminar";
        skipBtn.classList.remove("workout__btn--ghost");
        skipBtn.classList.add("workout__btn--primary");
        timerEl.textContent = "+0";
        return;
      }

      const over = elapsed - item.work;
      timerEl.textContent = `+${fmt(over)}`;
      logDebugLine(`propina +${over}s por encima del objetivo`);
      if (countAloudOk() && over !== lastSpokenNumber) {
        lastSpokenNumber = over;
        speakOut(numeroEnPalabras(over), { rate: REP_VOICE_RATE });
      }
    }, 1000);
  }

  // -------------------------------------------------------------- cámara

  async function runCamera(item) {
    // "Al fallo" (PROG_FAILURE): sin target_reps, no hay número de reps
    // que pedir -- ver el mismo caso en runTimer/runTimerWithPosture.
    const objetivo = item.target_reps
      ? `${item.target_sets} × ${item.target_reps}`
      : `${item.target_sets} series al fallo`;
    const fuente =
      item.target_source === "plan"
        ? `<span class="run-plan">plan «${esc(item.plan_name || "")}»</span>`
        : "";
    playerHost.innerHTML = `
      <div id="workout-root" class="workout"
           data-save-url="local" data-cancel-url="#" data-exercise-slug="${esc(item.slug)}"
           data-target-sets="${item.target_sets || ""}" data-target-reps="${item.target_reps || ""}"
           data-last-sets="${item.last_sets ? esc(JSON.stringify(item.last_sets)) : ""}"
           data-counter-key="${esc(item.counter_key || "pullup")}"
           data-voice-step="${item.voice_step || 1}">
        <p class="circuit__progress">${esc(progressLabel())}</p>
        <h2 class="circuit__exercise-name">${esc(item.name)}</h2>
        <p class="run-target">Objetivo: <strong>${objetivo}</strong> ${fuente}</p>
        <p id="workout-last-hint" class="circuit__side-hint run-last-hint" hidden></p>
        <div class="workout__camera">
          <video id="workout-video" playsinline muted class="workout__video"></video>
          <canvas id="workout-canvas" class="workout__canvas"></canvas>
        </div>
        <p id="workout-goal-banner" class="workout__goal-banner" hidden></p>
        <button type="button" id="workout-debug-export" class="workout__btn workout__btn--ghost">📋 Copiar registro de depuración</button>
        <p id="workout-debug-export-status" class="workout__debug"></p>
        <details class="workout__stats-toggle">
          <summary class="workout__stats-summary">Datos</summary>
          <div class="workout__stats">
            <div class="workout__stat"><span class="workout__stat-value" id="workout-reps">0</span><span class="workout__stat-label">reps</span></div>
            <div class="workout__stat"><span class="workout__stat-value" id="workout-sets">1</span><span class="workout__stat-label">serie</span></div>
            <div class="workout__stat"><span class="workout__stat-value" id="workout-timer">0:00</span><span class="workout__stat-label">sesión</span></div>
            <div class="workout__stat"><span class="workout__stat-value" id="workout-rest">0:00</span><span class="workout__stat-label">descanso</span></div>
          </div>
        </details>
        <div class="workout__actions">
          <button type="button" id="workout-cancel" class="workout__btn workout__btn--ghost">Saltar</button>
          <button type="button" id="workout-recalibrate" class="workout__btn workout__btn--ghost">↻ Recalibrar</button>
          <button type="button" id="workout-finish" class="workout__btn workout__btn--primary">
            ${hasNext() ? "Siguiente ▸" : "Terminar"}
          </button>
        </div>
        <p class="workout__note">El vídeo no sale de tu navegador. Solo se guardan los números.</p>
      </div>`;

    // workout.js llama a esto al pulsar "Siguiente/Terminar" en vez de
    // guardar y salir por su cuenta: aquí se apunta lo hecho y se pasa
    // al siguiente ejercicio del circuito.
    window.__workoutSubmit = async (payload) => {
      record({
        exercise: item.slug,
        reps: payload.total_reps || 0,
        sets: payload.total_sets || 0,
        set_reps: (payload.sets || []).map((s) => s.reps || 0).filter((r) => r > 0),
        // Tiempo de cada rep por serie (paralelo a set_reps).
        set_durations: (payload.sets || []).filter((s) => (s.reps || 0) > 0).map((s) => s.durations || []),
        seconds: payload.session_duration_seconds || 0,
      });
      beep(880, 0.2);
      advance();
    };

    window.__LIBRETA_EMBEDDED__ = true;
    const { startWorkout } = await import("./workout.js");
    workoutSession = startWorkout();

    // "Saltar" no debe guardar nada de este ejercicio, solo pasar.
    document.getElementById("workout-cancel").addEventListener(
      "click",
      (e) => {
        e.stopImmediatePropagation();
        workoutSession?.stopCamera?.();
        window.__workoutSubmit = null;
        advance();
      },
      true
    );
  }

  // ---------------------------------------------------------------- flujo

  function advance() {
    const item = current();
    index += 1;
    if (index >= sequence.length) return finish();
    // Las series del ejercicio que acaba de cerrarse no pintan en la
    // pantalla de descanso del siguiente (ver progressLabel).
    setsTotal = 1;
    setNo = 1;
    // Descanso entre ejercicios = el de entre series (60 s, a petición de
    // Alex 2026-10-08).
    const rest = SET_REST_SECONDS;
    if (rest > 0) runRest(rest);
    else runCurrent();
  }

  /** @param {number} seconds
   *  @param {{nextItem?:object, progress?:string, nextLabel?:string,
   *           onDone?:Function, onSkipExercise?:Function}} opts  por
   *   defecto, el descanso de entre ejercicios (siguiente = current() y
   *   luego runCurrent); runSetRest lo usa para el de entre series. */
  function runRest(seconds, opts = {}) {
    const next = opts.nextItem || current();
    const onDone = opts.onDone || (() => runCurrent());
    playerHost.innerHTML = `
      <div class="circuit">
        <p class="circuit__progress">${esc(opts.progress || progressLabel())}</p>
        <h2 class="circuit__exercise-name">Descanso</h2>
        <p class="circuit__phase circuit__phase--rest">Descanso</p>
        <div class="circuit__timer" id="run-timer">${fmt(seconds)}</div>
        <p class="circuit__next">${esc(opts.nextLabel || `Siguiente: ${next.name}`)}</p>
        <div class="circuit__controls">
          <button type="button" class="workout__btn workout__btn--ghost" id="run-skip-rest">Saltar descanso ▸</button>
        </div>
        ${opts.onSkipExercise ? `<button type="button" class="workout__btn workout__btn--ghost" id="run-skip-exercise-rest">Saltar ejercicio ▸</button>` : ""}
      </div>`;

    let remaining = seconds;
    const timerEl = document.getElementById("run-timer");
    clearInterval(timerId);
    timerId = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(timerId);
        beep(880, 0.2);
        onDone();
        return;
      }
      if (remaining <= 3) beep(660, 0.1);
      timerEl.textContent = fmt(remaining);
    }, 1000);

    document.getElementById("run-skip-rest").addEventListener("click", () => {
      clearInterval(timerId);
      onDone();
    });
    document.getElementById("run-skip-exercise-rest")?.addEventListener("click", () => {
      clearInterval(timerId);
      opts.onSkipExercise();
    });
  }

  function finish() {
    clearInterval(timerId);
    window.__workoutSubmit = null;
    workoutSession?.stopCamera?.();

    const totalReps = breakdown.reduce((a, b) => a + (b.reps || 0), 0);
    const totalSecs = breakdown.reduce((a, b) => a + (b.seconds || 0), 0);

    playerHost.innerHTML = `
      <div class="circuit__done">
        <p class="circuit__done-title">¡Sesión completada! 💪</p>
        <p>${breakdown.length} ejercicio(s)${totalReps ? ` · ${totalReps} repeticiones` : ""} · ${fmt(totalSecs)}</p>
        <ul class="run-summary">
          ${breakdown
            .map((b) => {
              const item = sequence.find((i) => i.slug === b.exercise);
              const detail = b.reps
                ? `${b.reps} reps en ${b.sets} serie(s)`
                : b.sets > 1
                ? `${b.seconds}s en ${b.sets} series`
                : `${b.seconds}s`;
              // Porcentaje conseguido sobre el objetivo, si lo había. Para
              // reps es sobre el volumen total (sets × reps); para
              // cronometrados (plancha, plancha lateral…) es sobre el
              // objetivo de ESE tramo (item.work) — ahora puede superar
              // el objetivo (ver runTimerWithPosture, ya no se corta
              // solo al llegar).
              let pct = "";
              if (item?.target_sets && item?.target_reps && b.reps) {
                const meta = item.target_sets * item.target_reps;
                const logro = Math.round((100 * b.reps) / meta);
                const clase = logro >= 100 ? "run-pct--full" : "run-pct--partial";
                pct = `<span class="run-pct ${clase}">${logro}%</span>`;
              } else if (item?.work && b.seconds) {
                // Con series (plan): total aguantado contra series × segundos.
                const series = item.target_source === "plan" ? Math.max(1, item.target_sets || 1) : 1;
                const logro = Math.round((100 * b.seconds) / (item.work * series));
                const clase = logro >= 100 ? "run-pct--full" : "run-pct--partial";
                pct = `<span class="run-pct ${clase}">${logro}%</span>`;
              } else if (item?.target_source === "plan" && !item.work && !item.target_reps && item.target_sets && b.sets) {
                // Al fallo: el % son series hechas sobre las pedidas (igual que el backend).
                const logro = Math.round((100 * b.sets) / item.target_sets);
                const clase = logro >= 100 ? "run-pct--full" : "run-pct--partial";
                pct = `<span class="run-pct ${clase}">${logro}%</span>`;
              }
              return `<li><span>${esc(item?.name || b.exercise)}</span><span>${detail} ${pct}</span></li>`;
            })
            .join("")}
        </ul>
        <button type="button" class="primary-btn" id="run-save">Guardar y volver</button>
      </div>`;

    const sessionSeconds = Math.round((Date.now() - sessionStartedAt) / 1000);
    document.getElementById("run-save").addEventListener("click", async (e) => {
      e.target.disabled = true;
      e.target.textContent = "Guardando…";
      try {
        const resp = await fetch(saveUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-CSRFToken": csrfToken },
          body: JSON.stringify({ breakdown, session_seconds: sessionSeconds }),
        });
        const data = await resp.json();
        window.location.href = (data && data.redirect_url) || cancelUrl;
      } catch (err) {
        e.target.disabled = false;
        e.target.textContent = "Guardar y volver";
        alert("No se pudo guardar. Revisa la conexión e inténtalo otra vez.");
      }
    });
  }

  function begin(randomize) {
    if (!items.length) return;
    sequence = randomize ? shuffle(items) : items.slice();
    index = 0;
    breakdown = [];
    modeSelect.hidden = true;
    playerHost.hidden = false;
    runCurrent();
  }

  document.getElementById("circuit-start-order").addEventListener("click", () => begin(false));
  document.getElementById("circuit-start-random").addEventListener("click", () => begin(true));
})();

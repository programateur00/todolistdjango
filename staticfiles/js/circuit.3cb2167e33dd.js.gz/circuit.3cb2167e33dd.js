/**
 * Reproductor de circuitos: cronómetro, cámara contando reps, o
 * cronómetro CON cámara comprobando la postura (plancha, plancha
 * lateral) — cada ejercicio se juega con lo que le toca:
 *
 *   - mode "timed", sin counter_key (bicicleta…)   -> cuenta atrás a secas
 *   - mode "timed", con counter_key (plancha…)     -> cuenta atrás + cámara
 *     verificando la postura, pausada mientras la postura no es válida
 *   - mode "pose" (dominadas, fondos, crunch…)     -> cámara contando reps
 *     (el conteo de verdad lo sigue haciendo workout.js sin tocarlo; aquí
 *     solo se le engancha vía window.__workoutSubmit)
 *
 * Es la contrapartida de session-runner.js (la app móvil) y comparte
 * estructura con plan-session.js (la sesión de un plan, aquí en la
 * web) — mismo formato de datos, pero esto reproduce una Routine
 * armada a mano, no los objetivos de un plan.
 */
import {
  NOSE, L_SHOULDER, R_SHOULDER, L_HIP, R_HIP, L_ANKLE, R_ANKLE, L_WRIST, R_WRIST,
  angle,
  checkPlankPosture, checkSidePlankPosture, checkWallSitPosture,
  checkKneeHoldBarPosture, checkDeadHangPosture, checkTuckLeverPosture, checkHandstandPosture, checkFrogStandPosture, createLSitHoldChecker, createSupermanHoldChecker, checkArmCrossStretch, checkTricepsOverheadStretch,
  checkSeatedHamstringStretch, createStandingQuadStretchChecker, checkElephantStepsHold,
  speakOut, numeroEnPalabras, isVoiceEnabled, REP_VOICE_RATE, clearVoiceTransitionMute,
} from "./workout.js";
import { PersonGate } from "./workout.js";
// De dónde sale MediaPipe (versión + rutas a los ficheros locales)
// vive en un único sitio — ver static/js/mediapipe-vendor.js.
import { MEDIAPIPE_BUNDLE_URL, MEDIAPIPE_WASM_BASE_URL, MODEL_URL } from "./mediapipe-vendor.js";
import { openCameraStream } from "./camera-stream.js";

(function () {
  "use strict";

  const root = document.getElementById("circuit-root");
  if (!root) return;

  const items = JSON.parse(root.dataset.items || "[]");
  const saveUrl = root.dataset.saveUrl;
  const cancelUrl = root.dataset.cancelUrl;

  const modeSelect = document.getElementById("circuit-mode-select");
  const playerHost = document.getElementById("circuit-player");

  const esc = (s) =>
    String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function beep(freq, duration) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq || 880;
      osc.connect(gain);
      gain.connect(ctx.destination);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      osc.start();
      osc.stop(ctx.currentTime + (duration || 0.15));
    } catch (e) {
      /* si el navegador bloquea audio sin interacción previa, no pasa nada */
    }
  }

  function fmt(s) {
    const m = Math.floor(s / 60);
    const r = s % 60;
    return m > 0 ? `${m}:${String(r).padStart(2, "0")}` : String(r);
  }

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  let sequence = [];
  let index = 0;
  let breakdown = [];
  const sessionStartedAt = Date.now(); // cronómetro total de la sesión (se manda al guardar)
  let timerId = null;
  let paused = false;
  let workoutSession = null;

  // Series del ejercicio CRONOMETRADO en curso (2026-10-01, a petición de
  // Alex; mismo comportamiento que plan-session.js y session-runner.js en
  // la app móvil): un aguante cuyo objetivo viene de un plan
  // (target_source === "plan": plancha, pino, silla en pared...) se repite
  // target_sets veces con descanso entre series, en vez de ser UNA sola
  // cuenta. SET_REST_SECONDS = REST_ALERT_SECONDS de workout.js.
  const SET_REST_SECONDS = 60;
  // "Al fallo" con cámara: la serie se da por terminada sola cuando la
  // postura lleva FAILURE_POSTURE_LOST_SECONDS seguidos rota, siempre que
  // antes se hubieran aguantado FAILURE_MIN_HOLD_SECONDS.
  const FAILURE_POSTURE_LOST_SECONDS = 3;
  const FAILURE_MIN_HOLD_SECONDS = 2;
  let setsTotal = 1;
  let setNo = 1;
  let setsDone = 0;
  let heldTotal = 0;

  function current() {
    return sequence[index];
  }
  function hasNext() {
    return index < sequence.length - 1;
  }
  function progressBase() {
    return `Ejercicio ${index + 1} de ${sequence.length}`;
  }
  // "Al fallo" (item.work vacío): la última serie se anuncia como tal en
  // vez de "Serie N de N".
  function setText(n, item) {
    const last = n === setsTotal && setsTotal > 1 && item && !item.work;
    return last ? "Última serie de este ejercicio" : `Serie ${n} de ${setsTotal}`;
  }
  function progressLabel() {
    return setsTotal > 1 ? `${progressBase()} · ${setText(setNo, current())}` : progressBase();
  }
  function record(entry) {
    breakdown.push(entry);
  }

  // Ejercicios cronometrados que además llevan cámara: comprueban
  // postura en vez de contar repeticiones. Ver checkPlankPosture /
  // checkSidePlankPosture / checkWallSitPosture / checkKneeHoldBarPosture /
  // checkHandstandPosture más abajo.
  const POSTURE_COUNTERS = new Set(["supermanhold", "lsithold", "plank", "sideplank", "wallsit", "kneeholdbar", "tucklever", "deadhang", "handstand", "frogstand", "armcrossstretch", "tricepsoverheadstretch", "seatedhamstringstretch", "standingquadstretch", "elephantstepshold"]);

  // Estiramientos bilaterales cronometrados (armcrossstretch/
  // tricepsoverheadstretch: un brazo y luego el otro; seatedhamstringstretch/
  // standingquadstretch: una pierna y luego la otra) -- en ROUTINES
  // (seed_warmup_routines.py) aparecen dos veces seguidas, una por lado,
  // porque un RoutineItem cronometrado no tiene "series" que alternar por
  // sí solo (a diferencia de armcircles/legrotation, que sí llevan el
  // sentido bloqueado dentro del propio contador -- ver processArmCircles
  // en workout.js). Aquí se avisa (no se bloquea, el lado detectado por
  // cámara puede fallar) si el lado de esta 2ª vez parece el mismo que la
  // 1ª -- ver stretchSideDone/occurrenceInfo más abajo.
  const STRETCH_SIDE_COUNTERS = new Set(["armcrossstretch", "tricepsoverheadstretch", "seatedhamstringstretch", "standingquadstretch"]);
  const STRETCH_FIXED_SECONDS = 30; // duración fija de los estiramientos con cronómetro
  const STRETCH_SIDE_LABEL = {
    armcrossstretch: "brazo",
    tricepsoverheadstretch: "brazo",
    seatedhamstringstretch: "pierna",
    standingquadstretch: "pierna",
  };
  // Rotación de codo (forearmrotation): mismo patrón "lado 1 de 2 / lado 2
  // de 2" que los estiramientos de arriba, pero es un contador de repes por
  // cámara (runCamera), no un aguante cronometrado (runTimerWithPosture) --
  // aparte de STRETCH_SIDE_COUNTERS para no tocar isStretchFixed/
  // POSTURE_COUNTERS, que no le corresponden. Badge/aviso añadidos dentro
  // de runCamera() más abajo, reutilizando occurrenceInfo(). A petición de
  // Alex (2026-09-25): antes un brazo y el otro compartían una sola
  // pantalla con cambio de brazo a mitad (ver FOREARMROTATION_* en
  // workout.js) -- ahora son dos pantallas seguidas, como los estiramientos.
  const REP_SIDE_COUNTERS = new Set(["forearmrotation"]);
  const REP_SIDE_LABEL = { forearmrotation: "brazo" };

  // "Ahora el otro brazo / la otra pierna / el otro lado" -- aviso corto de la 2ª vez
  // de un ejercicio por lados (antes era una frase larga en cada pantalla).
  function otherSideText(label) {
    return label === "pierna" ? "la otra pierna" : `el otro ${label}`;
  }
  // Círculos de brazos (2026-09-29, a petición de Alex): DOS pantallas seguidas
  // (arm-circles listado 2 veces en seed_warmup_routines.py), la 1ª hacia
  // delante y la 2ª hacia atrás; el sentido se fija por aparición (impar =
  // hacia delante, par = hacia atrás) y viaja a workout.js en
  // data-circle-direction. Sin segunda aparición no hay sentido fijo.
  const DIRECTION_COUNTERS = new Set(["armcircles"]);
  // Lado (izquierdo/derecho) detectado por cámara en la última vez que se
  // completó cada counter_key de STRETCH_SIDE_COUNTERS -- se reinicia en
  // begin() (nuevo circuito). Un solo mapa vale para las dos apariciones
  // seguidas del mismo ejercicio en la rutina.
  let stretchSideDone = {};

  /** Para STRETCH_SIDE_COUNTERS con más de una aparición en `sequence`:
   *  en qué posición (1 de 2, 2 de 2...) está `item` entre las suyas -- para
   *  poder avisar "ahora el otro lado" en vez de repetir el mismo nombre
   *  sin más contexto. null si el ejercicio no es de este grupo o solo
   *  aparece una vez (nada que numerar). */
  function occurrenceInfo(item) {
    if (!STRETCH_SIDE_COUNTERS.has(item.counter_key) && !REP_SIDE_COUNTERS.has(item.counter_key) && !DIRECTION_COUNTERS.has(item.counter_key)) return null;
    const siblings = sequence.filter((i) => i.counter_key === item.counter_key);
    if (siblings.length < 2) return null;
    return { occurrence: siblings.indexOf(item) + 1, total: siblings.length };
  }

  /** Series que tiene que hacer un ejercicio CRONOMETRADO (aguante o
   *  cuenta atrás). 1 = como siempre (una sola cuenta). Los de cámara
   *  (mode "pose") llevan sus series dentro de workout.js, y los
   *  estiramientos por lado ya son dos apariciones seguidas. */
  function plannedSets(item) {
    if (item.target_source !== "plan" || item.mode === "pose") return 1;
    if (STRETCH_SIDE_COUNTERS.has(item.counter_key)) return 1;
    return Math.max(1, parseInt(item.target_sets, 10) || 1);
  }

  function runCurrent() {
    const item = current();
    if (!item) return finish();
    setsTotal = plannedSets(item);
    setNo = 1;
    setsDone = 0;
    heldTotal = 0;
    clearVoiceTransitionMute();
    if (setsTotal > 1 && isVoiceEnabled()) speakOut(`Serie 1 de ${setsTotal}`, { flush: false });
    runSet(item);
  }

  /** Arranca UNA serie (o el ejercicio entero, si solo tiene una). */
  function runSet(item) {
    if (item.mode === "pose") runCamera(item);
    else if (POSTURE_COUNTERS.has(item.counter_key)) runTimerWithPosture(item);
    else runTimer(item);
  }

  // -------------------------------------------- series de un cronometrado

  /** Cierra UNA serie cronometrada con `seconds` aguantados. Si quedan
   *  series por hacer, descanso (SET_REST_SECONDS) y la siguiente; si era
   *  la última (o `skipExercise`), guarda el ejercicio entero -- segundos
   *  totales y series hechas -- y pasa solo al siguiente. */
  function finishTimedSet(item, seconds, { skipExercise = false, recordEmpty = false } = {}) {
    clearInterval(timerId);
    if (seconds > 0) {
      heldTotal += seconds;
      setsDone += 1;
    }
    if (!skipExercise && setNo < setsTotal) {
      const done = setNo;
      setNo += 1;
      runSetRest(item, done);
      return;
    }
    recordTimed(item, recordEmpty);
    advance();
  }

  /** "Terminar circuito antes" a mitad de un cronometrado: guarda lo que
   *  llevara y cierra todo. */
  function quitTimed(item, seconds, recordEmpty = false) {
    if (seconds > 0) {
      heldTotal += seconds;
      setsDone += 1;
    }
    recordTimed(item, recordEmpty);
    finish();
  }

  function recordTimed(item, recordEmpty = false) {
    if (heldTotal <= 0 && !recordEmpty) return;
    const entry = { exercise: item.slug, seconds: heldTotal };
    // "sets" solo en ejercicios de plan (el % de los "al fallo" se mide en
    // series hechas); en circuitos sueltos se queda como antes.
    if (item.target_source === "plan") entry.sets = setsDone;
    record(entry);
  }

  /** Descanso ENTRE series del mismo ejercicio (el de entre ejercicios
   *  sigue siendo item.rest, ver advance()). */
  function runSetRest(item, doneNo) {
    if (isVoiceEnabled()) speakOut(`Serie ${doneNo} de ${setsTotal} terminada. Descanso.`, { flush: false });
    runRest(SET_REST_SECONDS, {
      nextItem: item,
      progress: `${progressBase()} · Serie ${doneNo} de ${setsTotal} hecha`,
      nextLabel: `Siguiente: ${setText(setNo, item).toLowerCase()} — ${item.name}`,
      onDone: () => {
        if (isVoiceEnabled()) speakOut(setText(setNo, item), { flush: true });
        runSet(item);
      },
      onSkipExercise: () => {
        recordTimed(item);
        advance();
      },
    });
  }

  // -------------------------------------------------------- cronómetro

  function runTimer(item) {
    // "Al fallo" (item.work vacío/null -- Plan.session_items(),
    // PROG_FAILURE): no hay segundos objetivo que contar hacia atrás --
    // se cuenta libremente hacia ADELANTE desde 0 hasta que el usuario
    // decida que ha llegado al fallo, igual que en session-runner.js
    // (móvil) / plan-session.js.
    const isFailure = !item.work;
    // ¿Quedan series después de esta? (ver plannedSets)
    const moreSets = setNo < setsTotal;
    playerHost.innerHTML = `
      <div class="circuit">
        <p class="circuit__progress">${esc(progressLabel())}</p>
        <h2 class="circuit__exercise-name">${esc(item.name)}</h2>
        <p class="circuit__phase circuit__phase--work">${isFailure ? "Al fallo" : "Trabajo"}</p>
        <div class="circuit__timer" id="run-timer">${fmt(item.work || 0)}</div>
        <p class="circuit__next">${hasNext() ? `Siguiente: ${esc(sequence[index + 1].name)}` : "¡Último ejercicio!"}</p>
        <div class="circuit__controls">
          <button type="button" class="workout__btn workout__btn--ghost" id="run-pause">Pausar</button>
          <button type="button" class="workout__btn workout__btn--primary" id="run-skip">${
            moreSets && isFailure ? "Serie hecha ▸" : hasNext() ? "Siguiente ▸" : "Terminar"
          }</button>
        </div>
        ${moreSets && isFailure ? `<button type="button" class="workout__btn workout__btn--ghost" id="run-skip-exercise">Saltar ejercicio ▸</button>` : ""}
        <button type="button" class="workout__btn workout__btn--subtle" id="run-quit">Terminar sesión antes</button>
      </div>`;

    let remaining = item.work;
    let elapsed = 0;
    let lastSpokenNumber = null; // último entero ya dicho, para no repetirlo en el mismo segundo
    const timerEl = document.getElementById("run-timer");
    paused = false;

    clearInterval(timerId);
    timerId = setInterval(() => {
      if (paused) return;
      elapsed += 1;
      if (isFailure) {
        timerEl.textContent = fmt(elapsed);
        if (isVoiceEnabled() && elapsed !== lastSpokenNumber) {
          lastSpokenNumber = elapsed;
          speakOut(numeroEnPalabras(elapsed), { rate: REP_VOICE_RATE });
        }
        return;
      }
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(timerId);
        beep(880, 0.2);
        // Con varias series: descanso y la siguiente; con una (o la
        // última): guarda y pasa solo al siguiente ejercicio.
        finishTimedSet(item, item.work);
        return;
      }
      if (remaining <= 3) beep(660, 0.1);
      // Cuenta atrás dicha en voz alta cada segundo — igual que ya hacía
      // runTimerWithPosture() más abajo (mismo motivo: se pidió poder
      // seguir un ejercicio cronometrado de oído, sin mirar la pantalla,
      // igual que ya se puede con las repeticiones).
      // Cada 5 segundos, no cada uno - dicho cada segundo la voz no daba
      // abasto (números solapándose/cortados a medias).
      if (isVoiceEnabled() && remaining !== lastSpokenNumber) {
        lastSpokenNumber = remaining;
        speakOut(numeroEnPalabras(remaining), { rate: REP_VOICE_RATE });
      }
      timerEl.textContent = fmt(remaining);
    }, 1000);

    const pauseBtn = document.getElementById("run-pause");
    pauseBtn.addEventListener("click", () => {
      paused = !paused;
      pauseBtn.textContent = paused ? "Reanudar" : "Pausar";
    });
    // Al fallo: el botón principal cierra ESTA serie (y con ella el
    // ejercicio si era la última). Con objetivo de segundos: sigue siendo
    // "saltar el ejercicio" entero, como siempre.
    document.getElementById("run-skip").addEventListener("click", () => {
      clearInterval(timerId);
      finishTimedSet(item, elapsed, { skipExercise: !isFailure });
    });
    document.getElementById("run-skip-exercise")?.addEventListener("click", () => {
      clearInterval(timerId);
      finishTimedSet(item, elapsed, { skipExercise: true });
    });
    document.getElementById("run-quit").addEventListener("click", () => {
      if (!confirm("¿Terminar el circuito ahora? Se guarda lo hecho hasta aquí.")) return;
      clearInterval(timerId);
      quitTimed(item, elapsed);
    });
  }

  // --------------------------------------- cronómetro + postura (plancha)

  // checkPlankPosture / checkSidePlankPosture / checkWallSitPosture /
  // checkKneeHoldBarPosture / checkHandstandPosture viven ahora en
  // workout.js (importadas arriba) — se comparten con el entreno suelto
  // de una tarea (plancha, plancha lateral, silla en pared, kneehold en
  // barra y pino ya no dependen solo de estar dentro de un circuito), en
  // vez de mantener la misma comprobación duplicada en dos sitios.

  async function runTimerWithPosture(item) {
    const checker =
      item.counter_key === "sideplank"
        ? checkSidePlankPosture
        : item.counter_key === "wallsit"
        ? checkWallSitPosture
        : item.counter_key === "kneeholdbar"
        ? checkKneeHoldBarPosture
        : item.counter_key === "deadhang"
        ? checkDeadHangPosture
        : item.counter_key === "tucklever"
        ? checkTuckLeverPosture
        : item.counter_key === "frogstand"
        ? checkFrogStandPosture
        : item.counter_key === "handstand"
        ? checkHandstandPosture
        : item.counter_key === "supermanhold"
        ? createSupermanHoldChecker()
        : item.counter_key === "lsithold"
        ? createLSitHoldChecker()
        : item.counter_key === "armcrossstretch"
        ? checkArmCrossStretch
        : item.counter_key === "tricepsoverheadstretch"
        ? checkTricepsOverheadStretch
        : item.counter_key === "seatedhamstringstretch"
        ? checkSeatedHamstringStretch
        : item.counter_key === "standingquadstretch"
        ? createStandingQuadStretchChecker()
        : item.counter_key === "elephantstepshold"
        ? checkElephantStepsHold
        : checkPlankPosture;

    // "Al fallo" (item.work vacío/null -- PROG_FAILURE): sin objetivo de
    // tiempo, ni cuenta atrás ni aviso de "objetivo cumplido" tienen
    // sentido -- se cuenta libremente desde el principio y el botón
    // principal para avanzar está disponible desde ya (como en runCamera),
    // no escondido detrás de un objetivo que aquí no existe.
    // Estiramientos con cronómetro: 30 s fijos (da igual lo que diga el plan) y,
    // en cuanto se cumplen, pasa solo al siguiente ejercicio (sin pulsar nada).
    const isStretchFixed = STRETCH_SIDE_COUNTERS.has(item.counter_key);
    const work = isStretchFixed ? STRETCH_FIXED_SECONDS : item.work;
    const isFailure = !work;
    // Series (ver plannedSets/SET_REST_SECONDS): ¿esta no es la última?
    const moreSets = setNo < setsTotal;
    const multiSets = setsTotal > 1;
    const occ = occurrenceInfo(item);
    const sideLabel = STRETCH_SIDE_LABEL[item.counter_key] || "lado";

    playerHost.innerHTML = `
      <div class="circuit">
        <p class="circuit__progress">${esc(progressLabel())}</p>
        <h2 class="circuit__exercise-name">${esc(item.name)}${occ ? ` <span class="circuit__side-badge">(lado ${occ.occurrence} de ${occ.total})</span>` : ""}</h2>
        <p class="circuit__phase circuit__phase--work">${isFailure ? "Al fallo" : "Trabajo"}</p>
        ${
          occ
            ? occ.occurrence > 1
              ? `<p class="circuit__side-hint">🔁 Ahora ${otherSideText(sideLabel)}</p>`
              : ""
            : ""
        }
        <div class="workout__camera">
          <video id="posture-video" playsinline muted class="workout__video"></video>
          <canvas id="posture-canvas" class="workout__canvas"></canvas>
        </div>
        <p id="posture-status" class="workout__status">Preparando la cámara…</p>
        <p id="run-goal-banner" class="workout__goal-banner" hidden></p>
        <div class="circuit__timer" id="run-timer">${fmt(0)}</div>
        <p class="circuit__next">${hasNext() ? `Siguiente: ${esc(sequence[index + 1].name)}` : "¡Último ejercicio!"}</p>
        <div class="circuit__controls">
          <button type="button" class="workout__btn ${isFailure ? "workout__btn--primary" : "workout__btn--ghost"}" id="run-skip">${
            isFailure ? (moreSets ? "Serie hecha ▸" : hasNext() ? "Siguiente ▸" : "Terminar") : "Saltar ▸"
          }</button>
        </div>
        ${isFailure && moreSets ? `<button type="button" class="workout__btn workout__btn--ghost" id="run-skip-exercise">Saltar ejercicio ▸</button>` : ""}
        <button type="button" class="workout__btn workout__btn--subtle" id="run-quit">Terminar sesión antes</button>
        <p class="workout__note">${
          isFailure
            ? `Aguanta hasta que ya no puedas: la serie se cierra sola si pierdes la postura unos segundos (o pulsa ${moreSets ? "«Serie hecha»" : "Siguiente/Terminar"}).${moreSets ? ` Después, descanso de ${SET_REST_SECONDS} s.` : hasNext() ? " Al terminar pasa solo al siguiente ejercicio." : ""}`
            : multiSets
            ? `Serie ${setNo} de ${setsTotal}: al llegar a 0 ${moreSets ? `descansas ${SET_REST_SECONDS} s y sigue la siguiente serie` : "pasa solo al siguiente ejercicio"}. La cuenta atrás se pausa sola mientras la postura no sea correcta.`
            : isStretchFixed ? "30 segundos fijos: la cuenta atrás se pausa sola mientras la postura no sea correcta y, al llegar a 0, pasa sola al siguiente ejercicio." : "La cuenta atrás se pausa sola mientras la postura no sea correcta. Si sigues después del objetivo, sigue sumando por encima del 100%."
        }</p>
      </div>`;

    // OJO: a diferencia de antes, llegar a item.work YA NO cierra el
    // ejercicio solo — antes remaining llegaba a 0 y se cerraba la serie
    // de golpe, así que nunca se podía aguantar más del objetivo (ni
    // aunque quisieras). Ahora, igual que en dominadas/fondos (sigue
    // contando por encima del 100% si quieres, se guarda tal cual), el
    // cronómetro pasa a contar hacia ADELANTE los segundos de propina y
    // eres tú quien decide cuándo parar con "Saltar"/"Terminar antes".
    let elapsed = 0;
    let postureOk = false;
    let goalReached = false;
    let lastSpokenNumber = null; // último entero (cuenta atrás o adelante) ya dicho, para no repetirlo en el mismo segundo
    let detectedSide = null; // último lado ("left"/"right") que devolvió checker(), solo para STRETCH_SIDE_COUNTERS
    const previousSide = STRETCH_SIDE_COUNTERS.has(item.counter_key) ? stretchSideDone[item.counter_key] : null;
    let running = true;
    let stream = null;
    let poseLandmarker = null;
    const timerEl = document.getElementById("run-timer");
    const statusEl = document.getElementById("posture-status");
    const goalBannerEl = document.getElementById("run-goal-banner");
    const skipBtn = document.getElementById("run-skip");
    const video = document.getElementById("posture-video");
    const canvas = document.getElementById("posture-canvas");

    function stopCamera() {
      running = false;
      if (stream) stream.getTracks().forEach((t) => t.stop());
      if (poseLandmarker) poseLandmarker.close();
    }

    // Para la cámara y apunta el lado; el guardado y el paso a
    // descanso/siguiente los hace finishTimedSet (ver "series de un
    // cronometrado").
    function stopThis() {
      clearInterval(timerId);
      stopCamera();
      if (STRETCH_SIDE_COUNTERS.has(item.counter_key) && detectedSide) {
        stretchSideDone[item.counter_key] = detectedSide;
      }
    }

    // Al fallo: el botón principal cierra ESTA serie. Con objetivo de
    // segundos: "Saltar"/"Siguiente" salta el ejercicio entero, como antes.
    skipBtn.addEventListener("click", () => {
      stopThis();
      finishTimedSet(item, elapsed, { skipExercise: !isFailure, recordEmpty: true });
    });
    document.getElementById("run-skip-exercise")?.addEventListener("click", () => {
      stopThis();
      finishTimedSet(item, elapsed, { skipExercise: true, recordEmpty: true });
    });
    document.getElementById("run-quit").addEventListener("click", () => {
      if (!confirm("¿Terminar el circuito ahora? Se guarda lo hecho hasta aquí.")) return;
      stopThis();
      quitTimed(item, elapsed, true);
    });

    try {
      stream = await openCameraStream();
    } catch (err) {
      statusEl.textContent = "No se pudo acceder a la cámara — revisa los permisos del navegador. La cuenta atrás sigue sin comprobar la postura.";
      postureOk = true; // sin cámara, no bloquea el ejercicio — degrada a cronómetro normal
    }
    // Si mientras cargaba la cámara se pulsó "Serie hecha"/"Saltar"
    // (stopThis ya puso running=false y se pintó otra pantalla), esta
    // ejecución quedó obsoleta: se suelta la cámara y no se arranca nada --
    // si siguiera, pisaría el temporizador de la pantalla nueva.
    if (!running) {
      if (stream) stream.getTracks().forEach((t) => t.stop());
      return;
    }

    if (stream) {
      video.srcObject = stream;
      await video.play();
      if (!running) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;

      try {
        const { FilesetResolver, PoseLandmarker } = await import(MEDIAPIPE_BUNDLE_URL);
        const vision = await FilesetResolver.forVisionTasks(MEDIAPIPE_WASM_BASE_URL);
        poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
          baseOptions: { modelAssetPath: MODEL_URL, delegate: "GPU" },
          runningMode: "VIDEO", numPoses: 1, outputSegmentationMasks: true,
        });
      } catch (err) {
        statusEl.textContent = "No se pudo cargar el seguimiento de postura. La cuenta atrás sigue sin comprobarla.";
        postureOk = true;
        console.error(err);
      }
      if (!running) {
        // Obsoleta mientras cargaba el modelo (ver arriba).
        if (poseLandmarker) poseLandmarker.close();
        stream.getTracks().forEach((t) => t.stop());
        return;
      }

      if (poseLandmarker) {
        const personGate = new PersonGate(); // 2026-10-08: solo se miden posturas de la persona confirmada (ver PersonGate en workout.js)
        const loop = () => {
          if (!running) return;
          const frameNow = performance.now();
          const result = poseLandmarker.detectForVideo(video, frameNow);
          const hasPoseNow = !!(result.landmarks && result.landmarks.length);
          personGate.noteFrame(hasPoseNow, frameNow); // 2026-10-10: cuenta también los frames sin esqueleto (ver PersonGate.noteFrame)
          if (hasPoseNow) personGate.sampleMask(result, frameNow);
          const person = hasPoseNow ? personGate.check(result.landmarks[0], frameNow) : null;
          if (typeof result.close === "function") result.close(); // libera las máscaras de persona
          if (person && person.ok) {
            const check = checker(result.landmarks[0]);
            postureOk = check.ok;
            if (check.ok && check.side) detectedSide = check.side;
            const sameSideWarning =
              check.ok && previousSide && detectedSide && detectedSide === previousSide
                ? ` ⚠️ Parece el mismo ${sideLabel} que la vez anterior -- prueba con el contrario para trabajar los dos lados.`
                : "";
            statusEl.textContent = check.ok ? `Postura correcta — aguanta.${sameSideWarning}` : `⚠️ ${check.reason}`;
          } else {
            postureOk = false;
            statusEl.textContent = "No se te ve — sal en el encuadre.";
          }
          requestAnimationFrame(loop);
        };
        loop();
      }
    }

    clearInterval(timerId);
    let lostSeconds = 0; // segundos seguidos con la postura rota (solo para cerrar una serie al fallo)
    timerId = setInterval(() => {
      if (!postureOk) {
        lostSeconds += 1;
        // Al fallo no hay objetivo que dé la serie por cumplida: como en
        // los ejercicios de repeticiones, se cierra sola cuando ya no
        // aguantas la postura (tras haber aguantado algo).
        if (isFailure && elapsed >= FAILURE_MIN_HOLD_SECONDS && lostSeconds >= FAILURE_POSTURE_LOST_SECONDS) {
          stopThis();
          beep(880, 0.2);
          finishTimedSet(item, elapsed, { recordEmpty: true });
        }
        return; // pausado mientras la postura no sea válida
      }
      lostSeconds = 0;
      elapsed += 1;

      if (isFailure) {
        timerEl.textContent = fmt(elapsed);
        if (isVoiceEnabled() && elapsed !== lastSpokenNumber) {
          lastSpokenNumber = elapsed;
          speakOut(numeroEnPalabras(elapsed), { rate: REP_VOICE_RATE });
        }
        return;
      }

      if (!goalReached && elapsed < work) {
        // Cuenta atrás normal hacia el objetivo — igual que antes, pero
        // ahora además dicha en voz alta cada segundo (como cada
        // repetición en dominadas/fondos), para poder seguir sin mirar
        // la pantalla.
        const remaining = work - elapsed;
        timerEl.textContent = fmt(remaining);
        if (remaining <= 3) beep(660, 0.1);
        // Cada 5 segundos, no cada uno - ver nota junto a runTimer() más
        // arriba.
        if (isVoiceEnabled() && remaining !== lastSpokenNumber) {
          lastSpokenNumber = remaining;
          speakOut(numeroEnPalabras(remaining), { rate: REP_VOICE_RATE });
        }
        return;
      }

      if (!goalReached) {
        if (isStretchFixed) {
          // 30 s cumplidos: aviso y siguiente ejercicio automático.
          beep(880, 0.2);
          stopThis();
          finishTimedSet(item, work, { recordEmpty: true });
          return;
        }
        if (multiSets) {
          // Objetivo cumplido con varias series: descanso y la siguiente
          // (o, la última, pasa sola al siguiente ejercicio).
          beep(880, 0.2);
          stopThis();
          finishTimedSet(item, work, { recordEmpty: true });
          return;
        }
        // Objetivo alcanzado justo este segundo — un aviso, una sola vez,
        // y sin cortar nada (el ejercicio sigue: ya no se cierra solo).
        goalReached = true;
        lastSpokenNumber = 0;
        beep(880, 0.2);
        if (isVoiceEnabled()) speakOut(numeroEnPalabras(0), { flush: true, rate: REP_VOICE_RATE });
        if (goalBannerEl) {
          goalBannerEl.hidden = false;
          goalBannerEl.textContent = `🎯 ¡Objetivo cumplido! (${fmt(work)}) Sigue si quieres, o termina cuando acabes.`;
        }
        // "Saltar" ya no describe bien lo que hace este botón una vez
        // cumplido el objetivo (no se está saltando nada) — mismo texto
        // que usa workout.js para el botón equivalente en reps.
        skipBtn.textContent = hasNext() ? "Siguiente ▸" : "Terminar";
        skipBtn.classList.remove("workout__btn--ghost");
        skipBtn.classList.add("workout__btn--primary");
        timerEl.textContent = "+0";
        return;
      }

      // Por encima del objetivo: cuenta hacia ADELANTE los segundos de
      // propina, igual que seguir oyendo "9", "10" al pasarte de un
      // objetivo de 8 dominadas — así se nota de oído que vas por encima
      // del 100% (y se guarda tal cual: ver finish(), el % de logro ya
      // sabe compararlo contra item.work).
      const over = elapsed - work;
      timerEl.textContent = `+${fmt(over)}`;
      if (isVoiceEnabled() && over !== lastSpokenNumber) {
        lastSpokenNumber = over;
        speakOut(numeroEnPalabras(over), { rate: REP_VOICE_RATE });
      }
    }, 1000);
  }

  // -------------------------------------------------------------- cámara

  async function runCamera(item) {
    // "Al fallo" (PROG_FAILURE): sin target_reps, no hay número que pedir
    // -- ver el mismo caso en runTimer/runTimerWithPosture.
    const circleOcc = item.counter_key === "armcircles" ? occurrenceInfo(item) : null;
    // 2026-10-01 (Alex): igual que la rotación de codo -- el mismo ejercicio
    // DOS veces, cada una cuenta target_reps giros en el sentido que sea
    // (data-circle-direction="any", ver armCircleAnyDirection en workout.js).
    // Con una sola aparición en el circuito se conserva el modo antiguo.
    const circleDir = circleOcc ? "any" : "";
    const objetivo = circleDir && item.target_reps
      ? `${item.target_reps}`
      : item.target_reps
      ? `${item.target_sets} × ${item.target_reps}`
      : `${item.target_sets} series al fallo`;
    const fuente =
      item.target_source === "plan"
        ? `<span class="run-plan">plan «${esc(item.plan_name || "")}»</span>`
        : "";
    const occ = occurrenceInfo(item);
    const sideLabel = STRETCH_SIDE_LABEL[item.counter_key] || REP_SIDE_LABEL[item.counter_key] || "lado";
    playerHost.innerHTML = `
      <div id="workout-root" class="workout"
           data-save-url="local" data-cancel-url="#" data-exercise-slug="${esc(item.slug)}"
           data-target-sets="${item.target_sets || ""}" data-target-reps="${item.target_reps || ""}"
           data-counter-key="${esc(item.counter_key || "pullup")}"
           data-circle-direction="${circleDir}"
           data-voice-step="${item.voice_step || 1}">
        <p class="circuit__progress">${esc(progressLabel())}</p>
        <h2 class="circuit__exercise-name">${esc(item.name)}${circleDir ? ` <span class="circuit__side-badge">(vez ${circleOcc.occurrence} de ${circleOcc.total})</span>` : occ ? ` <span class="circuit__side-badge">(lado ${occ.occurrence} de ${occ.total})</span>` : ""}</h2>
        <p class="run-target">Objetivo: <strong>${objetivo}</strong> ${fuente}</p>
        ${
          circleDir
            ? circleOcc.occurrence > 1
              ? `<p class="circuit__side-hint">🔁 Ahora el otro sentido</p>`
              : ""
            : occ
            ? occ.occurrence > 1
              ? `<p class="circuit__side-hint">🔁 Ahora ${otherSideText(sideLabel)}</p>`
              : ""
            : ""
        }
        <div class="workout__camera">
          <video id="workout-video" playsinline muted class="workout__video"></video>
          <canvas id="workout-canvas" class="workout__canvas"></canvas>
        </div>
        <p id="workout-goal-banner" class="workout__goal-banner" hidden></p>
        <details class="workout__stats-toggle">
          <summary class="workout__stats-summary">Datos</summary>
          <div class="workout__stats">
            <div class="workout__stat"><span class="workout__stat-value" id="workout-reps">0</span><span class="workout__stat-label">reps</span></div>
            <div class="workout__stat"><span class="workout__stat-value" id="workout-sets">1</span><span class="workout__stat-label">serie</span></div>
            <div class="workout__stat"><span class="workout__stat-value" id="workout-timer">0:00</span><span class="workout__stat-label">sesión</span></div>
            <div class="workout__stat"><span class="workout__stat-value" id="workout-rest">0:00</span><span class="workout__stat-label">descanso</span></div>
          </div>
        </details>
        <div class="workout__actions">
          <button type="button" id="workout-cancel" class="workout__btn workout__btn--ghost">Saltar</button>
          <button type="button" id="workout-recalibrate" class="workout__btn workout__btn--ghost">↻ Recalibrar</button>
          <button type="button" id="workout-finish" class="workout__btn workout__btn--primary">
            ${hasNext() ? "Siguiente ▸" : "Terminar"}
          </button>
        </div>
        <p class="workout__note">El vídeo no sale de tu navegador. Solo se guardan los números.</p>
      </div>`;

    window.__workoutSubmit = async (payload) => {
      record({
        exercise: item.slug,
        reps: payload.total_reps || 0,
        sets: payload.total_sets || 0,
        set_reps: (payload.sets || []).map((s) => s.reps || 0).filter((r) => r > 0),
        // Tiempo de cada rep por serie (paralelo a set_reps).
        set_durations: (payload.sets || []).filter((s) => (s.reps || 0) > 0).map((s) => s.durations || []),
        seconds: payload.session_duration_seconds || 0,
      });
      beep(880, 0.2);
      advance();
    };

    window.__LIBRETA_EMBEDDED__ = true;
    const { startWorkout } = await import("./workout.js");
    workoutSession = startWorkout();

    document.getElementById("workout-cancel").addEventListener(
      "click",
      (e) => {
        e.stopImmediatePropagation();
        workoutSession?.stopCamera?.();
        window.__workoutSubmit = null;
        advance();
      },
      true
    );
  }

  // ---------------------------------------------------------------- flujo

  function advance() {
    const item = current();
    index += 1;
    if (index >= sequence.length) return finish();
    // Las series del ejercicio que acaba de cerrarse no pintan en la
    // pantalla de descanso del siguiente (ver progressLabel).
    setsTotal = 1;
    setNo = 1;
    const rest = item?.rest ?? 0;
    if (rest > 0) runRest(rest);
    else runCurrent();
  }

  /** @param {number} seconds
   *  @param {{nextItem?:object, progress?:string, nextLabel?:string,
   *           onDone?:Function, onSkipExercise?:Function}} opts  por
   *   defecto, el descanso de entre ejercicios (siguiente = current() y
   *   luego runCurrent); runSetRest lo usa para el de entre series. */
  function runRest(seconds, opts = {}) {
    const next = opts.nextItem || current();
    const onDone = opts.onDone || (() => runCurrent());
    playerHost.innerHTML = `
      <div class="circuit">
        <p class="circuit__progress">${esc(opts.progress || progressLabel())}</p>
        <h2 class="circuit__exercise-name">Descanso</h2>
        <p class="circuit__phase circuit__phase--rest">Descanso</p>
        <div class="circuit__timer" id="run-timer">${fmt(seconds)}</div>
        <p class="circuit__next">${esc(opts.nextLabel || `Siguiente: ${next.name}`)}</p>
        <div class="circuit__controls">
          <button type="button" class="workout__btn workout__btn--ghost" id="run-skip-rest">Saltar descanso ▸</button>
        </div>
        ${opts.onSkipExercise ? `<button type="button" class="workout__btn workout__btn--ghost" id="run-skip-exercise-rest">Saltar ejercicio ▸</button>` : ""}
      </div>`;

    let remaining = seconds;
    const timerEl = document.getElementById("run-timer");
    clearInterval(timerId);
    timerId = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(timerId);
        beep(880, 0.2);
        onDone();
        return;
      }
      if (remaining <= 3) beep(660, 0.1);
      timerEl.textContent = fmt(remaining);
    }, 1000);

    document.getElementById("run-skip-rest").addEventListener("click", () => {
      clearInterval(timerId);
      onDone();
    });
    document.getElementById("run-skip-exercise-rest")?.addEventListener("click", () => {
      clearInterval(timerId);
      opts.onSkipExercise();
    });
  }

  function finish() {
    clearInterval(timerId);
    window.__workoutSubmit = null;
    workoutSession?.stopCamera?.();

    const totalReps = breakdown.reduce((a, b) => a + (b.reps || 0), 0);
    const totalSecs = breakdown.reduce((a, b) => a + (b.seconds || 0), 0);

    playerHost.innerHTML = `
      <div class="circuit__done">
        <p class="circuit__done-title">¡Circuito completado! 💪</p>
        <p>${breakdown.length} ejercicio(s)${totalReps ? ` · ${totalReps} repeticiones` : ""} · ${fmt(totalSecs)}</p>
        <ul class="run-summary">
          ${breakdown
            .map((b) => {
              const item = sequence.find((i) => i.slug === b.exercise);
              const detail = b.reps
                ? `${b.reps} reps en ${b.sets} serie(s)`
                : b.sets > 1
                ? `${b.seconds}s en ${b.sets} series`
                : `${b.seconds}s`;
              // Porcentaje conseguido sobre el objetivo, si lo había. Para
              // reps es sobre el volumen total (sets × reps); para
              // cronometrados (plancha, plancha lateral…) es sobre el
              // objetivo de ESE tramo (item.work) — aquí no hay "series"
              // que sumar, cada aparición en el circuito es un aguante
              // suelto, y ahora puede superar el objetivo (ver
              // runTimerWithPosture, ya no se corta solo al llegar).
              let pct = "";
              if (item?.target_sets && item?.target_reps && b.reps) {
                const meta = item.target_sets * item.target_reps;
                const logro = Math.round((100 * b.reps) / meta);
                const clase = logro >= 100 ? "run-pct--full" : "run-pct--partial";
                pct = `<span class="run-pct ${clase}">${logro}%</span>`;
              } else if (item?.work && b.seconds) {
                // Con series (plan): total aguantado contra series × segundos.
                const series = item.target_source === "plan" ? Math.max(1, item.target_sets || 1) : 1;
                const logro = Math.round((100 * b.seconds) / (item.work * series));
                const clase = logro >= 100 ? "run-pct--full" : "run-pct--partial";
                pct = `<span class="run-pct ${clase}">${logro}%</span>`;
              } else if (item?.target_source === "plan" && !item.work && !item.target_reps && item.target_sets && b.sets) {
                // Al fallo: el % son series hechas sobre las pedidas (igual que el backend).
                const logro = Math.round((100 * b.sets) / item.target_sets);
                const clase = logro >= 100 ? "run-pct--full" : "run-pct--partial";
                pct = `<span class="run-pct ${clase}">${logro}%</span>`;
              }
              return `<li><span>${esc(item?.name || b.exercise)}</span><span>${detail} ${pct}</span></li>`;
            })
            .join("")}
        </ul>
        <button type="button" class="primary-btn" id="run-save">Guardar y volver</button>
      </div>`;

    const sessionSeconds = Math.round((Date.now() - sessionStartedAt) / 1000);
    document.getElementById("run-save").addEventListener("click", async (e) => {
      e.target.disabled = true;
      e.target.textContent = "Guardando…";
      try {
        const csrfInput = root.querySelector("[name=csrfmiddlewaretoken]");
        const resp = await fetch(saveUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-CSRFToken": csrfInput ? csrfInput.value : "" },
          body: JSON.stringify({ breakdown, session_seconds: sessionSeconds }),
        });
        const data = await resp.json();
        window.location.href = (data && data.redirect_url) || cancelUrl;
      } catch (err) {
        e.target.disabled = false;
        e.target.textContent = "Guardar y volver";
        alert("No se pudo guardar. Revisa la conexión e inténtalo otra vez.");
      }
    });
  }

  function begin(randomize) {
    if (!items.length) return;
    sequence = randomize ? shuffle(items) : items.slice();
    index = 0;
    stretchSideDone = {};
    breakdown = [];
    modeSelect.hidden = true;
    playerHost.hidden = false;
    runCurrent();
  }

  document.getElementById("circuit-start-order").addEventListener("click", () => begin(false));
  document.getElementById("circuit-start-random").addEventListener("click", () => begin(true));
})();
